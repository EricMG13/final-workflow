## Request

This is the fundamental credit synthesis for Allison Transmission Holdings Inc as of 2026-11-05, on the credit_snapshot pathway. Scope is business risk, financial risk, liquidity and the gaps that limit them, built only from the upstream handoffs, with no peer ranking, instrument recommendation or recovery conclusion.

## Sources

The synthesis uses the three upstream handoffs below. They rest on the seven issuer sources listed, which were not re-read for new facts here; every figure is taken from the handoffs and carries their period and perimeter labels.

### Issuer sources relied on through the handoffs

| Id | Exact name | sha256 |
| --- | --- | --- |
| S1 | 10-K_2025-12-31_alsn-20251231.htm.jsonl | 4759ff666c33cf9b4aa9fc9af406b5ff948ca8c7e8b83ef1d1b8c3371ee474c1 |
| S2 | 10-Q_2026-03-31_alsn-20260331.htm.jsonl | be0a328aec24e49cdf0300569cba1bccab7cce3c7f95d5658c5db76418cb7b3d |
| S3 | 10-Q_2026-06-30_alsn-20260630.htm.jsonl | 0d35855e179d244457d2146b580b35b12b14abea216ea0bdfab3dfa942713609 |
| S4 | 10-Q_2026-09-30_alsn-20260930.htm.jsonl | 45fe422f6a742d85a38f1278f190cb497541b353ed938208d565068e9ab989b0 |
| S5 | EX-99.1_2026-05-04_d138525dex991.htm.jsonl | fe207b266e861065ca33402f15b822e8bf63e3f1f6c76c7ba33719a7889867e5 |
| S6 | EX-99.1_2026-08-03_d95413dex991.htm.jsonl | 351a085e364488314b64d2b881181e5b5b95879fe010b71d75af6ac7e45fdd04 |
| S7 | EX-99.1_2026-11-02_d187329dex991.htm.jsonl | b8087f0341293bcafb0ca28c8fc71ee181a5c666b45fe74a0ca9cfe109b0ba65 |

Run settings, not issuer evidence: context file 1411207-allison-transmission-holdings-inc-alsn.json, sha256 f65312705cd8bb204fde9755509326ba975099b166b8d246c949fcd0ea955b5a.

### Supplied handoffs

| Module | sha256 | Short name used below |
| --- | --- | --- |
| CP-0 | 944a1fdb32b0e105bdb98bcce7fe9920a9ab8a1870c238bf911cb1860242755e | source readiness |
| CP-1 | b27b50a0994fa47ab4bf54e7b8dd4dd25bcc010c8d3d2635214f68fda996a5d1 | financial base |
| CP-1A | be911cd43317c5c9e3b0719c6b55735952efe3e667f403e5f91bac7ad242802a | business and transaction |

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| Allison is a solid mid-leverage industrial credit with a high-margin core, large liquidity and wide covenant headroom, but it still carries acquisition debt of USD 4,037 million and has not shown combined-business leverage. | Medium | Earnings before interest and depreciation cannot be put on a combined basis, and the credit agreement and indentures are not supplied. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Trailing leverage peaked at 3.59x total after the acquisition and was 2.82x total and 2.47x net at 30 September 2026. | Leverage is falling but remains well above the 1.25x net level of year-end 2025. | Medium |
| Liquidity is USD 1,493 million, the first maturity is USD 300 million of notes in October 2027, and the only financial covenant sits at 0.84x against 5.50x. | Refinancing and covenant risk are low for the next two years. | High |
| At current rates, annual cash interest on funded debt is about USD 203 million, giving 7.04x cover on trailing Adjusted EBITDA against 7.73x on cash interest paid. | Interest burden is manageable, and the trailing figure slightly flatters coverage. | Medium |
| The acquired off-highway business has a 12.7% margin against 37.8% for the legacy business and is 42.6% of third quarter sales. | Group margin is lower and more cyclical than before the acquisition. | High |
| Dividends and repurchases of USD 195 million over nine months continue, while management's 2.0x net leverage target is undefined. | Debt reduction competes with shareholder returns and is not contractually committed. | Medium |

### Credit view

Allison Transmission Holdings is a solid mid-leverage industrial credit that is still working off acquisition debt. Its strongest support is a high-margin transmission franchise with long-term customer agreements, liquidity of USD 1,493 million with the revolver undrawn, and a first lien leverage ratio of 0.84x against a 5.50x limit. Its weakest point is leverage: total debt of USD 4,037 million is 2.82x trailing Adjusted EBITDA, a figure that mixes periods with and without the lower-margin off-highway business and cannot be restated on a combined basis. The outcome will be decided by how quickly operating cash flow retires debt while dividends and buybacks continue, by how the acquired business performs through a downturn, and by what the unseen credit agreement permits.

### Credit assessment

| Assessment | Category | Confidence | Basis | Limitation |
| --- | --- | --- | --- | --- |
| Fundamental credit view: moderate credit risk, leverage elevated against the issuer's own history but covered by liquidity and strong cash generation; direction improving since the first quarter of 2026 | Analyst Interpretation | Medium | Financial base: leverage, liquidity, covenant and cash flow sections; business and transaction: operating model, transaction and governance sections | Confidence is below High because combined-business earnings, legal documents and post-acquisition customer data are not supplied |

### Thesis

Allison combines a franchise with high margins and a long-term customer base with a large liquidity cushion, so acquisition leverage of 2.82x trailing is serviceable and falling, provided that the lower-margin acquired business holds its earnings and shareholder returns do not slow deleveraging.

### Strengths and weaknesses

Strength, franchise margin (Documentary Fact). The legacy Allison Transmission unit earned an Adjusted EBITDA margin of 37.8% in the third quarter of 2026, well above the 12.7% of the acquired unit, so it carries most of group earnings.

Strength, revenue visibility (Documentary Fact). Long-term agreements with OEMs cover over 90% of North American on-highway unit volume and run three to five years; they set pricing and commodity cost sharing but not committed volume.

Strength, liquidity (Documentary Fact). Cash of USD 497 million and revolver availability of USD 996 million give USD 1,493 million, with nothing drawn on the revolver, which matures in January 2031.

Strength, covenant headroom (Documentary Fact). The single maintenance test, a maximum first lien net leverage ratio of 5.50x, was 0.84x at 30 September 2026; it is tested when revolving loan commitments remain outstanding and is reproduced from filed numbers.

Strength, cash generation and deleveraging (Documentary Fact). Adjusted free cash flow was USD 662 million for nine months 2026; the revolver was repaid and USD 100 million of notes redeemed.

Strength, debt structure (Documentary Fact). Maturities are spread: USD 300 million in 2027, USD 500 million in 2029, USD 1,505 million in 2031 and USD 1,694 million in 2033, with USD 2,300 million of fixed-rate notes.

Strength, end-market balance (Analyst Interpretation). Defense and aftermarket sales add counter-cyclical stability, and the acquisition added construction, agriculture, mining and industrial markets, though management describes industrial and agriculture demand as subdued.

Weakness, acquisition leverage (Documentary Fact). Net debt rose from USD 1,414 million at year-end 2025 to USD 3,540 million at 30 September 2026 on the note-total debt measure.

Weakness, perimeter mismatch (Insufficient Information). Trailing Adjusted EBITDA of USD 1,431 million holds the acquired unit for only three quarters; pro forma net sales and net income exist but pro forma Adjusted EBITDA does not, so combined leverage is Not calculable.

Weakness, lower-margin and cyclical acquired unit (Documentary Fact). The acquired unit is 42.6% of third quarter net sales with a 12.7% margin, its purchase accounting is preliminary, and integration costs continue.

Weakness, customer concentration (Documentary Fact). The top five OEM customers were 52% of FY2025 net sales before the acquisition, with Daimler AG at 18%; the post-acquisition split is not supplied.

Weakness, shareholder returns (Management Language). Dividends and repurchases of USD 195 million for nine months 2026 continue while management states a 2.0x net leverage target without defining it.

Weakness, earnings definition (Documentary Fact). Adjusted EBITDA includes USD 200 million of adjustments for nine months, 17.2% of the reported figure, defined by a credit agreement that is not supplied.

Weakness, structure and documentation (Insufficient Information). Secured term loans of USD 1,699 million rank ahead of USD 2,300 million of unsecured notes; the guarantor roster is unresolved and legal documents are not supplied.

### Key findings

First (Documentary Fact). Total debt to trailing Adjusted EBITDA peaked at 3.59x at the first quarter of 2026 and was 2.82x at the third quarter, against 2.57x at year-end 2025; net debt to trailing Adjusted EBITDA was 2.47x against 1.25x. Leverage has stepped up and is coming down, so the trajectory rather than the level supports the credit.

Second (Documentary Fact). Liquidity of USD 1,493 million covers the USD 300 million of 2027 notes about five times (calculation B2), and the revolver is undrawn. Refinancing risk is low through 2027, though the 2029 to 2033 maturities are larger.

Third (Analyst Interpretation). With 30 September 2026 rates held constant, annual cash interest on funded debt is about USD 203 million (calculation B1), and trailing Adjusted EBITDA covers it 7.04x, against 7.73x on trailing cash interest paid. The financial base said a run-rate could not be calculated without a rate path; holding quarter-end rates constant it can be estimated, and it is lower than the trailing figure.

Fourth (Analyst Interpretation). Earnings would have to fall about 85% before the first lien covenant ratio reached 5.50x (calculation B3). The covenant gives lenders little early warning and does not constrain distributions.

Fifth (Documentary Fact). Adjusted free cash flow of USD 662 million exceeded dividends and repurchases of USD 195 million by USD 467 million for nine months (calculation B4), which is about 13% of net debt. Retained cash is the main source of further debt reduction.

Sixth (Documentary Fact). Each quarterly report gives unaudited pro forma net sales and net income as if the acquisition had occurred on 2025-01-01, which corrects the earlier statements that none existed. Derived sales of the acquired unit grew 4.1% in the third quarter and 7.6% for nine months over the same periods of 2025, so the unit is not shrinking on a derived basis; its earnings before interest and depreciation are still unknown.

Seventh (Analyst Interpretation). The reported covenant ratio matches term loans less all cash over reported trailing Adjusted EBITDA, with no pro forma credit for the acquired unit's earlier quarters. The covenant measures reported earnings, so it does not capture a full year of the acquired unit's earnings.

### Key credit risks

| Risk | Mechanic | Credit implication | Severity |
| --- | --- | --- | --- |
| Cyclical downturn in North American trucks or off-highway markets | Volumes fall in medium-duty and Class 8 vocational trucks, and in construction and agriculture; the acquired unit has lower margins and so less buffer | Adjusted EBITDA falls against fixed debt of USD 4,037 million; leverage rises from 2.82x; the first lien covenant would not bind but total leverage would | Material |
| Integration and purchase accounting of the acquired unit | Footprint restructuring, stepped-up inventory and preliminary fair values affect cash and reported earnings through 2026 | Cash costs and lower earnings delay deleveraging; goodwill and intangibles of USD 4,410 million are over half of assets (calculation B5) and exposed to impairment | Material |
| Distribution policy | Cash returned through dividends and buybacks competes with debt repayment; the 2.0x target is not defined or dated | The pace of deleveraging depends on management choice, not on a covenant | Material |
| Customer concentration | Top five OEMs were over half of FY2025 net sales; loss or model discontinuation cuts volume | Revenue and margin risk; the post-acquisition mix is Not supplied | Material |
| Earnings quality | Adjusted EBITDA adds back USD 200 million for nine months, defined by an unseen agreement | Leverage on adjusted earnings may understate leverage on plain accounting earnings | Material |
| Refinancing 2027 to 2033 | Notes of USD 300 million due October 2027, USD 500 million 2029, then USD 1,505 million in 2031 and USD 1,694 million in 2033 | Manageable with current liquidity and cash generation; larger maturities depend on market access | Minor |
| Floating-rate exposure | Term loans of USD 1,699 million float over Term SOFR; hedging of this exposure is not assessed in the handoffs | A one percentage point rise in rates adds about USD 17 million of annual cash interest (calculation B6) | Minor |
| Documentation and structure | Legal capacity under the credit agreement and indentures, and the guarantor roster, are unknown | Priming, restricted payment or collateral questions cannot be answered from the pack | Material |

### Corrections to upstream handoffs

Source readiness stated that a search of all sources found no pro forma disclosure, and the financial base stated that results of the acquired business for 2025 were not supplied and that a run-rate interest cover was not calculable. The business and transaction handoff corrected the first point: each quarterly report has supplemental pro forma net sales and net income. This handoff refines the second: holding 30 September 2026 rates constant, run-rate cash interest can be estimated (calculation B1), although it remains an estimate that excludes fees, hedges and interest income. Pro forma Adjusted EBITDA, pro forma interest and any fourth quarter 2025 pro forma figure remain Not supplied, so the conclusion that combined leverage is Not calculable stands.

## Calculations

All inputs are figures from the financial base handoff (FB) and the business and transaction handoff (BT), in US$ millions unless a ratio is stated.

| Id | Calculation | Inputs | Result |
| --- | --- | --- | --- |
| B1 | Run-rate annual cash interest on funded debt at 30 September 2026 | Notes: 300 x 4.75% = 14.25; 500 x 5.875% = 29.375; 1,000 x 3.75% = 37.5; 500 x 5.875% = 29.375. Term loan 505 x 5.29% = 26.71; incremental term loan 1,194 x 5.54% = 66.15 (rates and amounts from FB debt structure). Revolver commitment fee, finance lease interest, hedges and interest income excluded. Trailing Adjusted EBITDA 1,431 (FB) | Interest 203.36, about 203; cover 1,431 / 203.36 = 7.04x |
| B2 | Liquidity cover of the 2027 notes | Liquidity 1,493 (FB) over notes due October 2027 of 300 (FB); cash alone 497 over 300 | 4.98x; cash alone 1.66x |
| B3 | Earnings decline to reach the covenant maximum | First lien net debt 1,202 (FB calculation C10) divided by 5.50 = 218.5 earnings; against trailing Adjusted EBITDA 1,431 | A decline of 84.7% |
| B4 | Retained cash after distributions, nine months 2026 | Adjusted free cash flow 662 less dividends and repurchases 195 (FB); 467 over net debt 3,540 | 467, 13.2% of net debt |
| B5 | Goodwill and intangibles share of assets | Goodwill 2,828 plus intangibles 1,582 over total assets 8,789 (BT calculation A7) | 50.2%, amounts 4,410 |
| B6 | Floating-rate sensitivity | Term loans 505 + 1,194 = 1,699 x 1.00% | 16.99, about 17 per percentage point |
| B7 | Debt composition | Secured 1,699 over total 4,037; notes 2,300 over 4,037 (FB) | 42.1% secured; 57.0% notes; leases 38 |

## Gaps

| Gap | Why it matters and what it affects | Severity | Action |
| --- | --- | --- | --- |
| Pro forma Adjusted EBITDA, interest and fourth quarter 2025 combined data are Not supplied | Combined leverage and cover cannot be computed; the trailing ratios overstate leverage against a combined year and may flatter cover | Material | Obtain pro forma disclosure from the issuer; until then label every trailing ratio |
| Credit agreement, amendments and indentures are Not supplied | Add-back baskets, restricted payment capacity, springing covenant mechanics and guarantors cannot be verified; affects covenant, distributions and structure conclusions | Material | Obtain the documents before sizing capacity |
| Definition of management's 2.0x net leverage target is Not supplied | The distance to target cannot be stated | Material | Obtain the definition and target date |
| Post-acquisition customer concentration, geography and headcount are Not supplied | Business risk uses FY2025 pre-acquisition concentration | Material | Obtain updated disclosure |
| Pension and retiree medical balances after 2025-12-31 are Not supplied | Claims outside debt are stated at year-end 2025 only | Minor | Obtain interim disclosure |
| Ownership above five percent and board control are Not supplied | Governance assessment relies on actions only | Minor | Obtain the proxy statement |
| Purchase accounting is preliminary | Goodwill, intangibles and acquired balances may change | Minor | Reassess at final allocation |
| Source readiness limitation carried: text extraction only | Tables were tied to printed totals but not checked against the original layout | Minor | Reviewers compare handoff figures with cited pages |

## Next module

CP-5, evidence trace and research integrity QA. Carry forward: the three corrections in this handoff and the earlier pro forma correction need checking against the quarterly reports, and the run-rate interest calculation needs checking against the rates in the third quarter 10-Q.
