## Request

This is the fundamental credit synthesis for APi Group Corp (APG, issuer id apg) as of 2026-11-05, on the credit_snapshot pathway, current period Q3 2026 against FY2025, in USD. It combines the financial base from the CP-1 handoff with the business and transaction context from the CP-1A handoff and reads no filing text directly.

## Sources

### Issuer sources underlying the upstream handoffs

This module quotes no source text; every fact comes from the upstream handoffs below, which relied on these pinned sources.

| Source (exact name) | sha256 |
| --- | --- |
| 10-K_2025-12-31_apg-20251231.htm.jsonl | 85e734a169388fec4ab633a5bed87c9c814f23738d0e6cf5a912dd14edbbba4e |
| 10-Q_2026-03-31_apg-20260331.htm.jsonl | 4f2797670271476a95f9547a3540ae303edaa5e40f3e3f08829817127f41c878 |
| 10-Q_2026-06-30_apg-20260630.htm.jsonl | e90d6bf8c69051d7d18a0cfac2ae57b46434273469a8084102121b4455760a9f |
| 10-Q_2026-09-30_apg-20260930.htm.jsonl | 0f3c88ef7de625d84cef8d9062b4481840371b9e18740b974653c45bd1fc951f |
| EX-99.1_2026-04-30_apg-20260331xexx991.htm.jsonl | 1e2bb7155c93f1d7180c8420214b4e920240b52127bf64099c673d664920aca5 |
| EX-99.1_2026-07-30_apg-20260630xexx991.htm.jsonl | f112ae35c8090bbb1d28641903d8fabef87924332451d391abea2504360e0996 |
| EX-99.1_2026-10-29_apg-20260930xexx991.htm.jsonl | f776b9079a3057680b637f70cfc8304a121c49085a5098404f23ccab4852f2c3 |

### Handoffs supplied

| Module | sha256 | Use |
| --- | --- | --- |
| CP-0 | d40ba3564c8793d91987b4dca76c3187df72cdc74c99584f6e488aad8f306a91 | Source limits and source differences |
| CP-1 | f7db30806e7a98570fba7e4bc97f39d6f69658956a05590382766f0c4cdbcca8 | Financial base, leverage, liquidity, covenant position |
| CP-1A | 49e3ff078b6908f3efb88a445708e93fc6e79232aec6b0d708d47eaa20df5368 | Business model, transaction set, governance behaviour, conflicts |

The run context (sha256 5361f531841cad8936701ac126679da0830e0b3a545fa6b1b9ab2f313f6dfc9d) holds dated settings only and is not issuer evidence.

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| APi Group is a diversified, cash-generative services business whose leverage rose in 2026 as acquisitions and buybacks were debt-funded: total debt over adjusted EBITDA is 3.02x on a last-twelve-months basis against 2.67x at FY2025. | Medium | Executed financing documents are not supplied, so covenant definitions, guarantors and permitted payments cannot be verified. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Net debt over adjusted EBITDA rose to 2.71x from 1.79x as acquisitions of USD 1,356 million and buybacks of USD 252 million were funded with debt and cash. | The balance sheet has less room for earnings shocks, and deleveraging now depends on integration and restraint in shareholder returns. | High |
| Liquidity is USD 1,032 million at September 30, 2026, and no bond or committed facility matures before 2029 apart from small short-term loans. | Near-term refinancing risk is low, but liquidity is USD 625 million lower than at FY2025. | High |
| Revolver usage was 33.5% at September 30, 2026, above the 30% trigger of the springing first lien test reported at 1.6:1.0 against 3.75 to 1.00. | Reported headroom is wide, but the test applies and its EBITDA definition cannot be checked. | Medium |
| Customers are diversified and demand is regulation-driven, but the recurring share of revenue is not disclosed. | Revenue durability supports debt service qualitatively but cannot be sized. | Medium |

### Credit view

APi Group Corp is a sound, cash-generative services business whose credit profile weakened in 2026 because acquisitions and buybacks were funded with debt. Its strongest support is diversified, regulation-driven demand, with no customer above 5% of FY2025 net revenues, adjusted EBITDA of USD 896 million for nine months 2026, and debt maturities that start in 2029 apart from small short-term loans. The weakest point is balance sheet capacity: last-twelve-months total debt over adjusted EBITDA is 3.02x (net 2.71x) against 2.67x (1.79x) at FY2025, liquidity is USD 1,032 million, and revolver usage is above the springing-covenant trigger. Whether the rise proves temporary depends on integrating the USD 1,197 million of named 2026 acquisitions and on restraint in buybacks; unverified covenant definitions limit confidence.

### Key findings

First, leverage stepped up sharply in nine months 2026 (Analyst Interpretation on CP-1 figures). Total debt obligations rose to USD 3,601 million from USD 2,776 million at FY2025 and cash fell to USD 373 million from USD 912 million, so net debt rose by USD 1,364 million [CP-1, leverage and Calculations]. The mechanism is that acquisition spend of USD 1,356 million (net of cash acquired; named deals CertaSite, Onyx-Fire and WTech cost USD 1,197 million combined) and buybacks of USD 252 million exceeded free cash flow of USD 317 million, and the acquired EBITDA enters the trailing figure only from closing dates, so reported leverage overstates run-rate leverage while also resting on unproven integration [CP-1; CP-1A, transaction summary]. The implication is a lower cushion against a margin or volume shock until earnings catch up, with last-twelve-months cash interest cover of 9.23x flattering the position because the USD 500 million 5.750% notes issued in May 2026 and the revolver draw have only partly reached cash interest; Q3 2026 interest expense, net, was USD 45 million against USD 34 million a year earlier, and an annualised Q3 figure gives about 6.62x (indicative, CP-1) (Analyst Interpretation).

Second, liquidity is adequate but thinner (Documentary Fact on CP-1 figures). Liquidity was USD 1,032 million at September 30, 2026 (USD 373 million cash and USD 659 million undrawn revolver), against USD 1,657 million at FY2025, and revolver availability was USD 559 million at October 29, 2026 after a further USD 100 million draw, a subsequent event. The revolver matures in 2031 and the term loan in 2033 after the Ninth Amendment, and the notes mature in 2029 and 2034, so there is no near-term wall; the implication is that debt service and refinancing risk are manageable, but the revolver is now the funding buffer for seasonal cash flow, with operating cash flow back-end loaded.

Third, the only maintenance covenant is a springing first lien net leverage test that applies at the latest quarter-end (Documentary Fact for the reported ratio, Analyst Interpretation for the trigger). Revolver usage of 33.5% exceeded the 30% trigger at September 30, 2026, and the reported ratio of 1.6:1.0 compares with a 3.75 to 1.00 limit, 2.15x of headroom on rounded figures [CP-1, covenant position]. The credit agreement is not supplied, so the covenant EBITDA definition is unverified; CP-1's indicative implied covenant EBITDA of about USD 1,318 million against derived last-twelve-months adjusted EBITDA of USD 1,191 million depends on pro forma adjustments the issuer describes but the pack does not quantify. The implication is that headroom looks wide on reported terms but is not independently verified.

Fourth, earnings are growing but cash conversion lags and margins are under input-cost pressure (Documentary Fact). Adjusted EBITDA was USD 896 million for nine months 2026 against USD 746 million, while operating cash flow was USD 393 million against USD 377 million as receivables and contract assets absorbed cash and Q3 2026 gross margin fell to 30.1% from 31.3% on project mix and material and fuel costs [CP-1]. Fixed-price contract cost estimation is a critical audit matter and cost overruns hit margin directly [CP-1A, operating model], so the implication is that growth is not yet translating into proportionate free cash flow, though the fourth quarter is seasonally strong (derived fourth quarter 2025 operating cash flow of USD 382 million).

Fifth, capital allocation is shareholder-friendly alongside leverage build (Analyst Interpretation). Repurchases of USD 252 million in nine months 2026 and about USD 143 million after quarter-end sat beside revolver borrowing; the 2024 Series B conversion and USD 600 million repurchase was part debt-funded [CP-1A, governance]. No priming, uptier, drop-down or debt-funded dividend recapitalisation is documented, but the executed documents showing legal capacity are not supplied, so the implication is a Neutral or Mixed behaviour assessment with legal capacity unassessed.

Sixth, the evidence has known limits (Documentary Fact). Filings give different totals for 2025 acquisition consideration (USD 233 million, USD 235 million and USD 225 million) [CP-1A, conflicts], the issuer of record of the notes differs between the MD&A and the exhibit index [CP-0], and the recurring revenue share and ownership concentration are not disclosed [CP-1A]. The implication is that revenue durability and creditor protections are described qualitatively only.

### Strengths and weaknesses

Strengths. (1) Customer diversification and regulation-driven demand: no customer above 5% of FY2025 net revenues, statutory and insurance-driven inspection demand per management (Documentary Fact for the concentration, Management Language for the demand characterisation) [CP-1A, company profile]; the mechanism is lower single-name revenue risk and less discretionary service demand, implying steadier cash flow than a pure project contractor. (2) Earnings momentum: adjusted EBITDA of USD 896 million for nine months 2026 against USD 746 million, with revenue up in both segments (Documentary Fact) [CP-1]; implying capacity to absorb the acquisition debt if growth persists. (3) Debt structure and market access: maturities begin in 2029 with fixed-rate notes, an extended revolver (2031) and term loan (2033), and a USD 500 million note issue completed in May 2026 (Documentary Fact) [CP-1; CP-1A]; implying low refinancing pressure and demonstrated market access. (4) Low capital intensity: free cash flow after capex of USD 317 million in nine months 2026 and capex management puts below 1.5% of net revenues (Documentary Fact for the cash figure, Management Language for the claim) [CP-1; CP-1A]; implying the business converts EBITDA to cash outside working capital swings. (5) Wide reported covenant headroom of 2.15x (Documentary Fact, unverified definitions) [CP-1].

Weaknesses. (1) Higher leverage from debt-funded acquisitions: 3.02x total and 2.71x net on last-twelve-months adjusted EBITDA (Documentary Fact on derived CP-1 figures); the mechanism is purchase prices in debt before acquired earnings fully arrive, implying thinner cushion and dependence on integration. Reported (unadjusted) EBITDA gives 3.61x and 3.23x, and the add-backs are material, so the choice of EBITDA measure matters (CP-1). (2) Capital returns alongside leverage build: USD 252 million of buybacks plus about USD 143 million after quarter-end (Documentary Fact); implying deleveraging relies on earnings growth rather than debt paydown. (3) Springing covenant trigger exceeded and definitions unverified (Documentary Fact for usage, Insufficient Information for the covenant mechanics). (4) Revenue durability unquantified and project exposure: the recurring share is not disclosed, contracts are mostly under six months, fixed-price estimation is a critical audit matter and Q3 2026 gross margin fell (Documentary Fact; Insufficient Information for the recurring share) [CP-1A]; implying margin and cash volatility that cannot be sized. (5) Rising and partly floating interest cost: the term loan floats on SOFR with hedges that end before its 2033 maturity (the forward swap matures in January 2029), and the new notes carry a 5.750% coupon (Documentary Fact) [CP-1]; implying higher interest burden after the swaps roll off. (6) Documentation gaps: no credit agreement, indentures or guarantor list, and unresolved issuer of record for the notes (Insufficient Information) [CP-0; CP-1A].

### Fundamental credit assessment and thesis

| Element | Statement | Category | Confidence | Basis |
| --- | --- | --- | --- | --- |
| Assessment | The business is solid and diversified with adequate liquidity and no near-term maturity wall, but 2026 debt-funded acquisitions and buybacks have raised leverage and made the covenant position and run-rate earnings dependent on integration and unverified definitions | Analyst Interpretation | Medium | CP-1 leverage, liquidity, covenant; CP-1A operating model, transaction summary, governance |
| Thesis | Cash-generative, diversified services earnings support debt service, but the credit depends on whether 2026 acquisitions deliver the earnings that bring leverage back down while buybacks continue | Analyst Interpretation | Medium | CP-1 and CP-1A as above |

Confidence is below High because the readiness handoff recorded READY_WITH_LIMITATIONS, the business handoff records the recurring-share and ownership gaps, and no executed financing documents are supplied.

### Key credit risks

| Risk | Mechanic | Credit implication | Severity |
| --- | --- | --- | --- |
| Integration and leverage | Debt-funded USD 1,197 million of named acquisitions with earnings only partly in the trailing figures | Leverage stays elevated if integration lags; deleveraging relies on EBITDA growth | Material |
| Capital allocation | Buybacks and revolver draws in the same period as the leverage rise | Cushion erodes if returns continue before leverage falls | Material |
| Covenant trigger and documentation | Springing test applies with revolver usage above 30%; definitions and baskets not supplied | Headroom and permitted-payment capacity unverified | Material |
| Margin and cost estimation | Fixed-price work, input-cost pressure and Q3 2026 gross margin decline | Earnings and cash flow volatility not quantifiable | Material |
| Interest cost | New 5.750% notes, revolver borrowing and floating term loan after hedge expiry | Cash interest cover likely lower than the trailing 9.23x | Material |
| Seasonality and working capital | Revenue lower in the first and second quarters; receivables and contract assets absorbed cash | Revolver is the buffer for intra-year swings | Minor |

## Calculations

All inputs are printed in the upstream handoffs; USD millions.

| Calculation | Inputs | Result |
| --- | --- | --- |
| Liquidity change, FY2025 to September 30, 2026 | 1,657 - 1,032 | USD 625 million lower |
| Net debt change | 3,228 - 1,864 | USD 1,364 million higher |
| Adjusted EBITDA growth, nine months 2026 against 2025 | 896 / 746 - 1 | 20.1% |
| Net revenue growth, nine months 2026 against 2025 | 6,790 / 5,794 - 1 | 17.2% |
| Named 2026 acquisitions | 271 + 532 + 394 | 1,197 |

No other new calculation; leverage, cover, liquidity and covenant figures are taken from the CP-1 handoff as stated there.

## Gaps

| Gap | Why it matters and what it affects | Severity | Action |
| --- | --- | --- | --- |
| Credit Agreement, Ninth Amendment, indentures, guarantor list: Not supplied | Covenant definitions, baskets, security and note issuer roles unverified; affects covenant headroom and distribution capacity | High | Obtain executed documents |
| Recurring (inspection, service and monitoring) revenue share: Not supplied | Revenue durability cannot be sized | Medium | Request revenue by service type |
| Beneficial ownership and control: Not supplied | Alignment and sponsor-type behaviour cannot be assessed | Medium | Add proxy statement |
| Pro forma acquired EBITDA and run-rate interest: Not supplied | Leverage and cover are overstated and flattered respectively on trailing figures | Medium | Management pro forma and swap schedule |
| 2025 acquisition consideration totals differ by filing: unresolved | Accrued consideration uncertainty | Minor | Cite by filing and period |
| Ratings and market data: Not supplied | No external credit or market view | Minor | Add if required |
| Limitations inherited: readiness handoff READY_WITH_LIMITATIONS and the CP-1A readiness judgment of this module READY_WITH_LIMITATIONS | Confidence capped below High | Not applicable | Carry forward |

## Next module

CP-5 should test that the claims here agree with the CP-1 and CP-1A evidence, in particular the leverage and liquidity figures, the covenant-trigger statement (revolver usage of 33.5% against a 30% trigger) and the acquisition totals, and should record the 2025 acquisition consideration difference as an open conflict. Relative value, security selection and the committee's action bias are outside this module and belong to later modules.
