## Request

Financial base extraction (CP-1) for BELDEN INC. (issuer id bdc, NYSE: BDC), as of 2026-11-05, pathway credit_snapshot. Reporting entity: Belden Inc. consolidated. Currency USD; filings are in thousands and are shown in thousands unless a table says US$m. Current period Q3 2026 (quarter ended September 27, 2026) with nine months 2026; prior period FY2025 (year ended December 31, 2025). Cutoff 2026-11-05. Every figure comes from the pinned filings and releases; nothing is taken from outside them.

## Sources

### Issuer sources relied on

| Source (exact name) | sha256 | Used for |
| --- | --- | --- |
| 10-K_2025-12-31_bdc-20251231.htm.jsonl | 80ef274084e1c7703f38055c49f44de69b5a31dd5b2e660bad032bc466600517 | FY2025 statements (pages 59-61), Adjusted EBITDA (pages 40-41), debt Note 15 (pages 92-94), interest paid (page 107) |
| 10-Q_2026-03-29_bdc-20260329.htm.jsonl | 92ae5feb886f18c8068e6e144870a7ce7fe24ecefea2657b8f22ad10746ee6ac | Q1 2026 balance sheet (page 2), revolver availability (page 13) |
| 10-Q_2026-06-28_bdc-20260628.htm.jsonl | 60c04fb4ddf3b8e563e4be095f10f190f61691e26efdac7b09cb5561f0a211ee | Q2 2026 balance sheet (page 2), revolver availability (page 14) |
| 10-Q_2026-09-27_bdc-20260927.htm.jsonl | 7239af9a6f61de7f4eea5ba8a5ab17342b8c139514426ea01b365d68fd81dcfe | Q3 2026 statements (pages 2-3), Ruckus (pages 11-13), leases (pages 16-17), debt Note 9 (pages 17-20), MD&A and liquidity (pages 23-34) |
| EX-99.1_2026-04-30_companynewsreleasedatedmar.htm.jsonl | 800b10b5a6acbba2ef9d00a1b953296d6d2a04b007b53040c5086b01b69c7caa | Context only (Q1 2026 release); no figure here depends on it |
| EX-99.1_2026-07-30_companynewsreleasedatedjul.htm.jsonl | 97518bcedf20ecd151c6170017340147f2d2133733fbcb29ebcfd34f2604e982 | Context only (Q2 2026 release); no figure here depends on it |
| EX-99.1_2026-10-29_companynewsreleasedatedoct.htm.jsonl | bd6ff1210615fc5d7c13577de667703f5a66b803e28876ed410b2fa777310433 | Free cash flow definition and reconciliation (page 6); Q3 2026 statements agree with the 10-Q |

Run settings (not issuer evidence): context, sha256 c6d9bea849396ac29c99bcba0cfe7683fa092d214ad8aab3fe1d1ba06b34ee33.

### Supplied handoffs

| Module | sha256 | Use |
| --- | --- | --- |
| CP-0 | cb24f448d7e562ed131ff8665c52f3b4cf4366d8e66384b5dea0d4a7df37f262 | Readiness view and gap list. Its limits are carried here: no Term Loan B agreement, preliminary Ruckus purchase accounting, one reportable segment from 2026, no pro forma EBITDA. |

CP-0 recorded a Ruckus consideration of $1,869.6 million net of cash acquired (Q3 10-Q page 11) against earlier signed and rounded figures; this module uses the closing figure. CP-0 listed a note-repurchase translation difference ($535.9 million in the 10-Q filings against $537.3 million in the 10-K); this module uses the 10-Q figure, which is the later filing and agrees with the cash flow arithmetic below.

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| Belden's balance sheet changed sharply in Q3 2026: the Ruckus purchase was funded with a USD 1,850.0 million term loan, taking debt to USD 3,103.8 million, while only one quarter of Ruckus earnings is in the trailing figures. | Medium | No pro forma EBITDA for Ruckus is supplied, so a full-year combined leverage ratio cannot be calculated. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Debt before unamortised costs rose from USD 1,292.0 million at FY2025 to USD 3,103.8 million at Q3 2026. | Trailing debt to Adjusted EBITDA is 5.57x, against 2.82x at FY2025, but is overstated because Ruckus is in the trailing earnings for one quarter only. | High |
| Liquidity is USD 754.2 million: USD 380.7 million of cash plus USD 373.5 million of revolver availability. | The revolver is undrawn and matures in 2030; no debt matures before 2028 other than term loan amortisation of USD 18.5 million a year. | High |
| Adjusted EBITDA for nine months 2026 adds back USD 59.4 million of acquisition adjustments and includes tariff refunds. | Headline margin needs care: the refunds on 2025 transactions are USD 17.9 million. | Medium |
| Operating cash flow after capital expenditure was USD 107.4 million for nine months 2026, against USD 97.6 million a year earlier. | Free cash flow carries only one quarter of Term Loan B interest, and cash interest for 2026 is not printed. | Medium |

### Financial base view

Belden is a profitable, cash-generative manufacturer whose capital structure was transformed on July 1, 2026. Before the Ruckus acquisition, debt was three euro senior subordinated notes totalling USD 1,292.0 million at FY2025 against Adjusted EBITDA of USD 458.7 million, and a revolver that had been drawn and repaid within 2025. At September 27, 2026, debt is USD 3,103.8 million before unamortised costs: USD 1,253.8 million of euro notes (2028, 2031 and the new 2033 series) and USD 1,850.0 million of Term Loan B due 2033, which the company priced at term SOFR plus 2.25%. Cash is USD 380.7 million and the USD 400.0 million revolver is undrawn, with USD 373.5 million available. On trailing Adjusted EBITDA of USD 557.2 million, which includes Ruckus for one quarter only, total debt is 5.57x and net debt 4.89x. Those ratios are conservative against a full-year combined base but cannot be restated, because Ruckus earnings before July 1, 2026 are not supplied. GAAP results for Q3 2026 were a net loss of USD 11.4 million because of USD 100 million of purchase-accounting charges that the company excludes from Adjusted EBITDA; the Ruckus loss before tax in the quarter was USD 63.1 million. The company's earlier long-term net leverage goal of about 1.5x appears in the 10-K and the Q1 2026 10-Q, and is absent from the Q2 and Q3 2026 10-Qs. Net interest expense was USD 41.8 million in Q3 2026 against USD 11.6 million in Q3 2025, and nine months 2026 operating cash flow less capital expenditure and disposal proceeds (the company's free cash flow) was USD 107.4 million against USD 97.6 million. The term loan amortises USD 18.5 million a year (0.25% a quarter of USD 1,850.0 million). Legal terms of the new term loan (covenants, security, guarantors) are not in the supplied sources.

### Chart data: leverage

| Period | Total debt / EBITDA | Net debt / EBITDA | Reporting unit | Basis and limitation |
| --- | --- | --- | --- | --- |
| FY2025 | 2.82 | 1.97 | x | Debt before unamortised issuance costs (USD 1,291.950 million) over company Adjusted EBITDA (USD 458.734 million); net of cash USD 389.887 million. Pre-Ruckus capital structure. |
| Q3 2026 (LTM) | 5.57 | 4.89 | x | Debt before unamortised costs (USD 3,103.780 million) over LTM Adjusted EBITDA (USD 557.166 million = FY2025 plus nine months 2026 less nine months 2025). Ruckus is included for one quarter only; debt includes all of Term Loan B. Overstated against a full-year combined base. Company Adjusted EBITDA, not a covenant definition. |

### Chart data: interest cover

| Period | EBITDA / cash interest | Reporting unit | Basis and limitation |
| --- | --- | --- | --- |
| FY2025 | 10.63 | x | Adjusted EBITDA USD 458.734 million over interest paid USD 43.157 million (10-K page 107). Pre-Ruckus capital structure. |
| Q3 2026 (LTM) | Not supplied: cash interest paid for nine months 2026 is not printed in the 10-Q | x | Net interest expense (not cash) is printed: LTM Adjusted EBITDA over LTM net interest expense is 6.85x (see Calculations). That ratio is distorted by one quarter of Ruckus earnings against one quarter of Term Loan B interest. |

### Chart data: liquidity

| Period | Cash | Undrawn committed facilities | Reporting unit | Basis and limitation |
| --- | --- | --- | --- | --- |
| FY2025 | 389.9 | 383.9 | US$m | Cash USD 389.887 million (10-K page 59); revolver available borrowing capacity (10-K page 92). Commitment is USD 400.0 million; availability is as printed, not derived. |
| Q1 2026 | 272.2 | 374.9 | US$m | Cash USD 272.151 million (10-Q Q1 page 2); availability (page 13). |
| Q2 2026 | 348.7 | 369.6 | US$m | Cash USD 348.655 million (10-Q Q2 page 2); availability (page 14). A USD 50.0 million draw on June 29, 2026 followed the period end and was repaid on September 25, 2026. |
| Q3 2026 | 380.7 | 373.5 | US$m | Cash USD 380.706 million, of which USD 232.0 million is held outside the U.S. (10-Q Q3 pages 2 and 34); availability (page 18). The shortfall to the USD 400.0 million commitment is not explained in the sources. |

### Chart data: debt maturities

| Period | Debt maturing | Reporting unit | Basis and limitation |
| --- | --- | --- | --- |
| FY2025 | 0.0 | US$m | Maturities due in 2026 are printed as nil (10-K page 94). First maturity is the 2027 Notes, USD 528.525 million, since repurchased. |
| Q3 2026 | 18.5 | US$m | Current maturities of long-term debt (10-Q Q3 page 2), the Term Loan B amortisation of 0.25% a quarter. The 10-Q prints no multi-year maturity table; instrument maturities are listed under Financials and credit metrics. |

### Financials and credit metrics

| Metric | FY2025 | Nine months 2026 | Nine months 2025 | Q3 2026 | Q3 2025 | Unit and locator |
| --- | --- | --- | --- | --- | --- | --- |
| Revenues | 2,715,194 | 2,412,486 | 1,995,074 | 965,954 | 698,221 | USD thousands; 10-K page 59; 10-Q Q3 page 2 |
| Gross profit | 1,031,172 | 890,462 | 767,606 | 338,750 | 263,198 | USD thousands; same pages |
| Operating income | 315,692 | 193,983 | 228,150 | 16,764 | 76,288 | USD thousands; 10-K page 60; 10-Q Q3 page 2 |
| Interest expense, net | 46,355 | 68,860 | 33,866 | 41,802 | 11,562 | USD thousands; same pages |
| Net income (loss) | 237,522 | 108,212 | 169,633 | (11,351) | 56,690 | USD thousands; same pages |
| Adjusted EBITDA (company, non-GAAP) | 458,734 | 435,104 | 336,672 | 171,137 | 118,643 | USD thousands; 10-K page 41; 10-Q Q3 page 32 |
| Adjusted EBITDA margin | 16.9% | 18.0% | 16.9% | 17.7% | 17.0% | As printed; same pages |
| Net cash from operating activities | 354,864 | 240,200 | 194,476 | 129,642 | 105,006 | USD thousands; 10-K page 60; 10-Q Q3 page 3; release page 6 |
| Capital expenditures | (136,172) | (132,863) | (97,034) | (47,809) | (39,681) | USD thousands; same pages |
| Free cash flow (company definition) | Not printed; see Calculations | 107,444 | 97,610 | 81,932 | 65,378 | USD thousands; release page 6 |
| Cash paid for business acquisitions | 7,744 (cash received) | (1,869,631) | 7,744 (cash received) | Not supplied: quarter not split | Not supplied | USD thousands; 10-K page 60; 10-Q Q3 page 3 |
| Share repurchases, including excise tax | (195,586) | (31,806) | (150,967) | Not supplied: quarter not split | Not supplied | USD thousands; same pages |
| Cash dividends paid | (7,966) | (5,870) | (6,000) | Not supplied: quarter not split | Not supplied | USD thousands; same pages |

### Balance sheet and capital structure

| Item | Dec 31, 2025 | Sep 27, 2026 | Locator |
| --- | --- | --- | --- |
| Cash and cash equivalents | 389,887 | 380,706 | 10-K page 59; 10-Q Q3 page 2 |
| Receivables, net | 462,845 | 684,350 | same |
| Inventories, net | 402,345 | 555,071 | same |
| Goodwill | 1,036,821 | 2,030,937 | same |
| Intangible assets | 399,799 | 1,378,494 | same |
| Total assets | 3,543,621 | 5,967,215 | same |
| Current maturities of long-term debt | nil (not printed) | 18,500 | 10-Q Q3 page 2 |
| Long-term debt (net of unamortised costs) | 1,285,666 | 3,031,910 | same |
| Postretirement benefits | 63,598 | 57,779 | same |
| Deferred income taxes (liability) | 98,060 | 274,261 | same |
| Other long-term liabilities | 40,002 | 146,267 | same |
| Total stockholders' equity | 1,264,424 | 1,391,992 | same |

### Debt register

Carrying values in USD thousands; 10-K page 92, 10-Q Q3 pages 17-20.

| Instrument | Terms | Dec 31, 2025 | Sep 27, 2026 |
| --- | --- | --- | --- |
| Revolver due July 18, 2030 | USD 400.0 million commitment; SOFR plus 1.25% to 1.75%; commitment fee 0.25%; asset-based borrowing base; fixed charge coverage test springs if borrowings exceed 90% of the combined borrowing base or availability falls below USD 27.0 million | nil | nil (availability 373,500) |
| 3.375% senior subordinated notes due 2027 (EUR 450.0 million) | Issued by Belden Inc.; repurchased in February 2026 | 528,525 | nil |
| 3.875% senior subordinated notes due 2028 (EUR 350.0 million) | Guaranteed by domestic subsidiaries on a senior subordinated basis | 411,075 | 398,930 |
| 3.375% senior subordinated notes due 2031 (EUR 300.0 million) | Same ranking and guarantors; redeemable after July 15, 2026 | 352,350 | 341,940 |
| 4.250% senior subordinated notes due 2033 (EUR 450.0 million) | Issued January 2026; same ranking and guarantors | nil | 512,910 |
| Term Loan B due July 1, 2033 | USD 1,850.0 million; term SOFR plus 2.25% or base rate plus 1.25%; amortises 0.25% a quarter; discount USD 4.6 million; fees USD 38.8 million. Guarantors and security: Not supplied | nil | 1,850,000 |
| Total before unamortised costs | | 1,291,950 | 3,103,780 |
| Unamortised issuance costs and discount | | (6,284) | (53,370) |
| Total debt per balance sheet | | 1,285,666 | 3,050,410 |

The notes rank equal to each other and below the Revolver and other senior debt (10-Q Q3 pages 18-20). Euro principal is EUR 1,100.0 million at both dates (sum of the three outstanding series); the fall in the USD carrying values of the 2028 and 2031 notes between the two dates is translation, not repayment.

### Other claims outside the debt figure

USD thousands, September 27, 2026 unless stated: operating lease liabilities 133,727 and finance lease liabilities 8,525 (10-Q Q3 page 16, not in debt); postretirement benefits 57,779 (balance sheet); lease guarantee liability for a former subsidiary 9,000 (page 17); standby letters of credit 17,600, surety bonds 16,800 and bank guaranties 6,800 (page 7). Factoring and supply-chain finance: no mention found in any supplied source. Purchase commitments and litigation funding: none located in the Q3 10-Q; the 10-K shows purchase obligations of USD 37.0 million due in 2026 (page 47) and the legal proceedings are described as not material (Q3 10-Q page 36).

### Quality of earnings and definitions

Adjusted EBITDA is the company's non-GAAP measure, built from net income plus depreciation, amortisation of intangibles and of software development intangibles, tax, net interest, restructuring and integration costs, debt extinguishment and acquisition adjustments (10-Q Q3 page 32). For nine months 2026 it adds back USD 59.4 million (59,363 thousand) of acquisition and divestiture adjustments, primarily the fair value step-up of acquired inventory, and USD 36,696 thousand of severance, restructuring and integration costs. The MD&A attributes part of the increase in gross profit and Adjusted EBITDA to tariff refunds: USD 17.9 million on 2025 transactions in nine months 2026 (USD 4.3 million in Q3), plus USD 8.1 million net on 2026 transactions that offsets 2026 tariff cost (10-Q Q3 pages 25 and 28). Analyst interpretation: refunds of past-year tariffs are unlikely to recur at that level, and they are inside Adjusted EBITDA. No covenant EBITDA definition is supplied, so the company measure should not be read as covenant EBITDA.

Ruckus contributed USD 167.8 million of revenue and a USD 63.1 million loss before taxes in Q3 2026, after USD 56.3 million of inventory fair value charges and USD 43.7 million of intangible amortisation (10-Q Q3 page 13). The purchase price allocation is preliminary (page 12). The 10-Q prints unaudited pro forma revenue, net income and EPS as if Ruckus had been acquired on January 1, 2025 (nine months 2026 revenue USD 2,763.5 million), but no pro forma EBITDA.

## Calculations

All inputs are as printed (USD thousands unless stated). Ratios use debt before unamortised issuance costs, which is the sum of the debt register above.

1. LTM Adjusted EBITDA at Q3 2026 = FY2025 458,734 + nine months 2026 435,104 - nine months 2025 336,672 = 557,166. Inputs: 10-K page 41; 10-Q Q3 page 32.
2. Total debt, Q3 2026 = notes 1,253,780 + Term Loan B 1,850,000 = 3,103,780; this equals the USD 3,103.8 million carrying value stated on 10-Q Q3 page 20. Less unamortised costs 53,370 gives 3,050,410, which equals the balance sheet (18,500 + 3,031,910).
3. Net debt, Q3 2026 = 3,103,780 - cash 380,706 = 2,723,074. FY2025 = 1,291,950 - 389,887 = 902,063.
4. Total debt / LTM Adjusted EBITDA: Q3 2026 3,103,780 / 557,166 = 5.57x; FY2025 1,291,950 / 458,734 = 2.82x.
5. Net debt / LTM Adjusted EBITDA: Q3 2026 2,723,074 / 557,166 = 4.89x; FY2025 902,063 / 458,734 = 1.97x.
6. EBITDA / cash interest, FY2025 = 458,734 / 43,157 = 10.63x. Q3 2026: Not calculable, cash interest paid not printed.
7. EBITDA / net interest expense (not cash), Q3 2026 LTM: net interest expense = FY2025 46,355 + nine months 2026 68,860 - nine months 2025 33,866 = 81,349; 557,166 / 81,349 = 6.85x. FY2025 458,734 / 46,355 = 9.90x. This uses expense, not cash, and one quarter of Term Loan B interest.
8. Liquidity, Q3 2026 = cash 380,706 + revolver availability 373,500 = 754,206 (USD 754.2 million). FY2025 = 389,887 + 383,900 = 773,787. Net of letters of credit by facility: Not calculable, because the filings print the letters of credit as a total without saying how much is issued under the Revolver. The commitment less availability is 400,000 - 373,500 = 26,500 at Q3 2026; the sources do not attribute that gap.
9. Free cash flow, FY2025 (company definition: operating cash flow less capital expenditures plus disposal proceeds) = 354,864 - 136,172 + 191 = 218,883. Nine months 2026 as printed 107,444 = 240,200 - 132,863 + 107.
10. Funding cross-check: borrowings under credit arrangements 2,432,630 compare with Term Loan B 1,850,000 + 2033 Notes 537,300 at issuance + revolver draw 50,000 - discount 4,600 = 2,432,700 (difference 70, rounding of the stated USD 537.3 million and USD 4.6 million). Payments under borrowing arrangements 585,860 compare with 2027 Notes repurchase 535,900 + revolver repayment 50,000 = 585,900 (difference 40, rounding).
11. Adjusted EBITDA reconciliation re-added from the printed rows: FY2025 458,734, nine months 2026 435,104, nine months 2025 336,672 and Q3 2026 171,137 each equal the printed totals.
12. Nominal growth, Q3 2026 revenue over Q3 2025: 965,954 / 698,221 - 1 = 38.3%, which agrees with the 38% in the release; the release attributes 11% to organic growth, 24% to acquisitions and 3% to copper pass-through (release page 6).

## Gaps

| Gap | Effect | Action |
| --- | --- | --- |
| Term Loan B agreement, revolver agreement and indentures not supplied: no covenant levels, guarantors, security, call protection or mandatory prepayment terms for the term loan. | Covenant headroom and structural ranking cannot be assessed. | Obtain executed agreements; treat as Not supplied. |
| Ruckus pre-acquisition earnings and pro forma EBITDA not supplied. | Combined LTM leverage and interest cover Not calculable; the 5.57x and 4.89x understate the earnings base of the combined business. | Obtain pro forma EBITDA, or an acquisition-date run-rate from management. |
| Cash interest paid for 2026 not printed in the 10-Qs. | EBITDA to cash interest for Q3 2026 Not calculable; the net interest expense ratio is the substitute. | Use the cash flow supplemental disclosure in the next 10-K. |
| Letters of credit under the Revolver not separately stated; USD 26.5 million gap between commitment and availability unexplained. | Liquidity net of letters of credit is not calculated; availability is used as printed. | Obtain the revolver agreement and borrowing base certificate. |
| Segment structure changed to one reportable segment from January 1, 2026; no recast FY2025 segments located. | Segment margins are not comparable across the FY2025 and 2026 periods. | Use consolidated figures only. |
| Purchase price allocation is preliminary; in-process R&D has no fair value. | Goodwill, intangibles and deferred taxes may change. | Re-check in the FY2026 10-K. |
| Quarterly split of Q1, Q2 and Q3 acquisition, dividend and buyback cash flows not printed in the Q3 10-Q. | Quarter-only values shown as Not supplied. | None needed for this module. |
| Adjusted EBITDA includes tariff refunds on 2025 transactions (USD 17.9 million for nine months 2026) and is a company definition. | Earnings quality; covenant EBITDA may differ. | Compare with covenant EBITDA when the agreements are available. |

Consumer readiness: CP-1A can use the Ruckus, debt and segment facts with the limits above (limited). CP-2 can use the leverage, liquidity and cash flow figures with the Ruckus pro forma gap and the missing covenants (limited). CP-5 can trace every figure to the located pages (sufficient for tracing; the limits are recorded here).

## Next module

CP-1A should describe the Ruckus acquisition, its financing and the 2026 realignment to one segment, using the Q3 10-Q Note 3 and the business description in the 10-K, and carry forward that Ruckus earnings history and Term Loan B terms are not supplied. CP-2 should treat the 5.57x total and 4.89x net leverage as an upper bound caused by partial-period Ruckus earnings, and should keep the missing covenant terms and cash interest as explicit gaps.
