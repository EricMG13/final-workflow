## Request

Business and transaction context (CP-1A) for BELDEN INC. (issuer id bdc, NYSE: BDC), as of 2026-11-05, pathway credit_snapshot. Scope: the transaction, ownership, business and operating model, timeline and issuer-level governance behaviour that matter to a creditor, built from the pinned filings and releases up to the cutoff 2026-11-05. Currency USD. Periods: Q3 2026 (quarter ended September 27, 2026), nine months 2026, FY2025. No sponsor, borrower, parent or guarantor is named in the run settings; none is inferred. This module gives no peer ranking, instrument recommendation or recovery conclusion.

## Sources

### Issuer sources relied on

| Source (exact name) | sha256 | Used for |
| --- | --- | --- |
| 10-K_2025-12-31_bdc-20251231.htm.jsonl | 80ef274084e1c7703f38055c49f44de69b5a31dd5b2e660bad032bc466600517 | Business, customers, backlog, history, segments, share repurchases, subsequent events (pages 3-10, 43, 78, 106-107) |
| 10-Q_2026-03-29_bdc-20260329.htm.jsonl | 92ae5feb886f18c8068e6e144870a7ce7fe24ecefea2657b8f22ad10746ee6ac | Ruckus agreement and net leverage goal (pages 16 and 19) |
| 10-Q_2026-06-28_bdc-20260628.htm.jsonl | 60c04fb4ddf3b8e563e4be095f10f190f61691e26efdac7b09cb5561f0a211ee | Ruckus closing as a subsequent event (page 18), goals wording (page 19) |
| 10-Q_2026-09-27_bdc-20260927.htm.jsonl | 7239af9a6f61de7f4eea5ba8a5ab17342b8c139514426ea01b365d68fd81dcfe | Ruckus purchase accounting, debt, geography, deferred revenue, trends, share repurchase (pages 9-13, 17-20, 23-27) |
| EX-99.1_2026-04-30_companynewsreleasedatedmar.htm.jsonl | 800b10b5a6acbba2ef9d00a1b953296d6d2a04b007b53040c5086b01b69c7caa | Seller and approximate price of Ruckus (page 1), management language |
| EX-99.1_2026-07-30_companynewsreleasedatedjul.htm.jsonl | 97518bcedf20ecd151c6170017340147f2d2133733fbcb29ebcfd34f2604e982 | Not relied on for any fact in this module |
| EX-99.1_2026-10-29_companynewsreleasedatedoct.htm.jsonl | bd6ff1210615fc5d7c13577de667703f5a66b803e28876ed410b2fa777310433 | Q3 2026 highlights, data center agreement and guidance (pages 1-2), management language |

Run settings (not issuer evidence): context, sha256 c6d9bea849396ac29c99bcba0cfe7683fa092d214ad8aab3fe1d1ba06b34ee33. Its sector label ("Drawing & Insulating of Nonferrous Wire"), country (United States) and ticker are run settings, not filing text.

### Supplied handoffs

| Module | sha256 | Use |
| --- | --- | --- |
| CP-0 | cb24f448d7e562ed131ff8665c52f3b4cf4366d8e66384b5dea0d4a7df37f262 | Source readiness and the gap list: no Term Loan B agreement, preliminary Ruckus accounting, one segment from 2026. |
| CP-1 | 3e5c83e1173b68bed2223644f0ac2d4646c1f8f4d35660263af5cbd4e64cf59a | Financial base. Figures below that restate CP-1 (debt USD 3,103.8 million, trailing leverage 5.57x, liquidity USD 754.2 million) are copied from it, not recomputed. |

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| Belden is a US-listed network-infrastructure manufacturer that bought Ruckus on July 1, 2026 with a USD 1,850.0 million term loan, adding wireless and software revenue but also debt, integration and purchase-accounting risk. | Medium | The term loan agreement, ownership data and Ruckus history are not supplied. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Ruckus added USD 167.8 million of revenue and a USD 63.1 million pre-tax loss in Q3 2026, and the purchase accounting is preliminary. | Earnings contribution is unproven, and the new term loan carries the acquisition risk. | High |
| Revenue runs through distributors: the ten largest customers are about 47% of FY2025 revenue and the largest distributor about 14%. | Concentration and a lack of purchase commitments make volumes depend on channel behaviour. | High |
| Share repurchases were USD 195.6 million in FY2025 and USD 31.8 million in nine months 2026, and the net leverage goal is absent from the Q2 and Q3 2026 filings. | Capital return fell when debt rose; whether it resumes ahead of deleveraging is undocumented. | Medium |
| Deferred revenue rose to USD 250.6 million from USD 49.7 million at the start of 2026, mostly acquired. | Support and software revenue is added to a mostly point-in-time hardware model, with limited history to judge. | Medium |

### Business and transaction view

Belden is a US-listed manufacturer of copper and fiber cable, connectivity, industrial networking and security products sold mainly through distributors, which moved in 2026 from a low-leverage, buyback-oriented company to one carrying USD 3,103.8 million of debt after a debt-funded acquisition. The Ruckus purchase (wireless access points, switches, cloud management and software, bought from Vistance Networks) closed July 1, 2026 for USD 1,869.6 million net of cash acquired, funded by a USD 1,850.0 million seven-year Term Loan B. For creditors the mechanics are: Ruckus is consolidated for one quarter only, so trailing leverage of 5.57x is on a partial earnings base; the purchase price allocation is preliminary; and goodwill and intangibles of USD 2,040.8 million (the sum of the two printed allocation lines) now sit against equity of USD 1,392.0 million. Management describes record demand in 2026, but that is attributed management language. Belden is NYSE-listed and no sponsor or controlling holder appears in the supplied sources, so sponsor-extraction behaviour is not documented, and neither is any sponsor equity support. What is missing is as important as what is present: the Term Loan B, revolver and indenture documents are not in the pack, so legal capacity for distributions, additional debt and collateral release cannot be judged. Governance conclusions here are limited to documented issuer actions.

### Company and operating model

| Dimension | Fact (category) | Locator and limitation |
| --- | --- | --- |
| Business | Belden supplies connection and networking solutions: copper and fiber cable and connectivity, enclosures, industrial Ethernet, security and, from July 1, 2026, Ruckus wireless networking (Documentary Fact) | 10-K pages 3-5; 10-Q Q3 page 11 |
| Segments | Two reportable segments at FY2025: Smart Infrastructure Solutions (revenue USD 1,219.422 million) and Automation Solutions (USD 1,495.772 million). One reportable segment from January 1, 2026 (Documentary Fact) | 10-K pages 4 and 43; 10-Q Q3 page 26. Segment history is not comparable with 2026 |
| Geography, nine months 2026 | Americas USD 1,604.739 million, EMEA USD 485.850 million, APAC USD 321.897 million; about 42% of FY2025 sales outside the U.S. (Documentary Fact) | 10-Q Q3 page 9; 10-K page 6 |
| Customers | Largest distributor about 14% of FY2025 revenue; ten largest customers, eight of them distributors, about 47% in FY2025 (46% in 2024, 44% in 2023); customers are generally not obliged to buy exclusively or in minimum amounts (Documentary Fact) | 10-K pages 5-6 and 106 |
| Revenue model | Mostly product sales recognised at a point in time; also support and professional services recognised over time. Variable consideration includes rebates, returns and price adjustments (Documentary Fact) | 10-Q Q3 pages 9-10 |
| Pricing and costs | Copper is the principal raw material; costs are on FIFO with about a two-month lag; list prices are updated every few weeks; some OEM contracts pass through raw materials with a lag of a few weeks to three months (Documentary Fact) | 10-K pages 9-10 |
| Backlog | USD 567.7 million at December 31, 2025 (USD 509.7 million a year earlier), almost all scheduled to ship in 2026; orders are short-cycle (Documentary Fact) | 10-K page 10 |
| Deferred revenue | USD 250.6 million at September 27, 2026, of which USD 201.675 million was acquired with Ruckus; USD 49.7 million at January 1, 2026 (Documentary Fact) | 10-Q Q3 page 10 |
| Receivable price adjustments | Price adjustments recognised against gross receivables were USD 131.3 million at September 27, 2026 against USD 33.3 million at December 31, 2025; the filing does not attribute the increase (Documentary Fact; cause Insufficient Information) | 10-Q Q3 page 10 |
| Labour | About 26% of the labour force is under collective bargaining agreements, most to be renegotiated during 2026 (Documentary Fact) | 10-K page 106 |
| Tariffs | IEEPA tariff refunds of USD 17.9 million (2025 transactions) recorded in nine months 2026 as a reduction of cost of sales (Documentary Fact); durability of such refunds is an Analyst Interpretation: unlikely to recur at that level | 10-Q Q3 page 25 |
| Management view | Management says demand is robust, AI and automation are driving orders and a USD 100 million data center fiber supply agreement for 2027 is signed (Management Language, not adopted) | Release October 29, 2026, page 1 |

### Company profile

| Item | Detail | Category and locator |
| --- | --- | --- |
| Legal entity | Belden Inc., a Delaware corporation incorporated in 1988; roots date to 1902 | Documentary Fact; 10-K page 3 |
| Headquarters | St. Louis, Missouri | Documentary Fact; 10-Q Q3 page 1 |
| Listing and shares | NYSE: BDC; 39,100,023 shares outstanding at October 22, 2026 | Documentary Fact; 10-Q Q3 page 1 |
| Sector and country | Drawing and insulating of nonferrous wire; United States | Run settings, not filing text |
| Ownership | No controlling holder or sponsor appears in the supplied sources; beneficial ownership sits in the proxy statement, which is not supplied | Insufficient Information; 10-K page 113 refers to the proxy |
| Ratings | None supplied | Insufficient Information; run settings blank |
| Auditor | Ernst & Young LLP, since 1993 | Documentary Fact; 10-K pages 59 and 113 |
| Principal brands | Belden, Alpha Wire, Hirschmann, Lumberg Automation, OTN Systems, PPC, ProSoft Technology, Thinklogical, West Penn Wire; Ruckus added July 1, 2026 | Documentary Fact; 10-K page 9; 10-Q Q3 page 11 |
| Debt in the structure | Euro senior subordinated notes due 2028, 2031 and 2033; Term Loan B due 2033; USD 400.0 million revolver due 2030 | Documentary Fact; 10-Q Q3 pages 17-20 |

### Transaction summary and new debt issues

Ruckus. On April 29, 2026 Belden signed a definitive agreement to acquire certain entities comprising Ruckus Networks, for approximately USD 1.846 billion to be funded through additional debt (10-Q Q1 pages 16 and 19); the April 30, 2026 release names the seller as Vistance Networks (Nasdaq: VISN) and gives approximately USD 1.85 billion (release page 1). The acquisition closed July 1, 2026 for USD 1,869.6 million net of cash acquired and is accounted for as a business combination (10-Q Q3 page 11). The three descriptions of price differ in rounding and basis (signed price, rounded price, closing price net of cash); the closing figure in the 10-Q controls. The preliminary allocation records receivables USD 146.457 million, inventory USD 153.555 million, intangible assets USD 1,040.0 million (developed technologies USD 800.0 million over 5.0 years, customer relationships USD 160.0 million over 15.0 years, trademarks USD 80.0 million over 20.0 years), goodwill USD 1,000.819 million, and liabilities assumed USD 535.212 million including deferred income taxes USD 175.882 million (10-Q Q3 pages 11-12). In-process R&D has no fair value yet and the allocation may change (page 12). Ruckus contributed USD 167.8 million of revenue and a USD 63.1 million loss before taxes in Q3 2026, after USD 56.3 million of inventory fair value charges and USD 43.7 million of intangible amortisation (page 13). Pro forma revenue and net income as if acquired on January 1, 2025 are printed, but not EBITDA (page 13). Status: completed; integration is management's stated focus (release October 29, 2026, page 2, Management Language).

New debt and use of proceeds. (1) Term Loan B: USD 1,850.0 million, entered July 1, 2026 to fund Ruckus, term SOFR plus 2.25% or base rate plus 1.25%, amortising 0.25% a quarter, maturing July 1, 2033, issued at a discount of USD 4.6 million with USD 38.8 million of fees; fair value approximates carrying value (10-Q Q3 page 20). Guarantors, security and covenants are not described. (2) EUR 450.0 million 4.250% senior subordinated notes due 2033, issued January 28, 2026 (10-K page 107, Note 25), guaranteed on a senior subordinated basis by current and future domestic subsidiaries, ranking equal to the 2028 and 2031 notes, with fees of USD 8.6 million (10-Q Q3 page 20); proceeds with cash on hand funded the full repurchase of the EUR 450.0 million 3.375% notes due 2027 on February 11, 2026 for USD 535.9 million, with a USD 1.3 million loss on extinguishment (10-Q Q3 page 18; the 10-K quotes USD 537.3 million, a translation difference carried from the readiness review). (3) Revolver: a USD 50.0 million draw on June 29, 2026 was repaid in full on September 25, 2026 (page 18). Liquidity effect: per the financial base, liquidity at September 27, 2026 is USD 754.2 million (cash USD 380.7 million plus revolver availability USD 373.5 million). Refinancing effect: the 2027 maturity was removed; the next fixed maturities are the 2028 notes and the Term Loan B amortisation of USD 18.5 million a year. Sponsor: none. Ratings agencies' reactions: Not supplied.

Subsequent events. After the quarter end and before the cutoff, the sources contain the October 29, 2026 release and the Q3 10-Q (signed October 29, 2026); the only forward items are management's fourth quarter 2026 guidance of revenues of USD 960 million to USD 980 million (Management Language, release page 2) and the signed 2027 data center agreement (Management Language, release page 1).

### Timeline

| Date | Event | Category and locator |
| --- | --- | --- |
| 1902 and 1988 | Founded by Joseph Belden; Belden Inc. incorporated in Delaware | Documentary Fact; 10-K page 3 |
| April and August 2023 | Acquisitions of Sichert and CloudRail | Documentary Fact; 10-K page 5 |
| June and September 2024 | Acquisitions of Precision Optical Technologies and Voleatech | Documentary Fact; 10-K page 5 |
| July 18, 2025 | Revolver refinanced to July 18, 2030, capacity raised from USD 300.0 million to USD 400.0 million | Documentary Fact; 10-K page 92 |
| January 1, 2026 | Realignment to one reportable segment | Documentary Fact; 10-K page 107 |
| January 28, 2026 | EUR 450 million 4.250% notes due 2033 issued (Subsequent event to the FY2025 10-K) | Documentary Fact; 10-K page 107 |
| February 11, 2026 | 2027 Notes repurchased | Documentary Fact; 10-K page 107 |
| April 29, 2026 | Definitive agreement to buy Ruckus | Documentary Fact; 10-Q Q1 page 16 |
| July 1, 2026 | Ruckus closed; Term Loan B entered | Documentary Fact; 10-Q Q3 pages 11 and 20 |
| June 29 to September 25, 2026 | USD 50.0 million revolver draw and repayment | Documentary Fact; 10-Q Q3 page 18 |
| October 29, 2026 | Q3 2026 release and 10-Q | Documentary Fact; release page 1 |

### Governance and capital allocation behaviour

Scope: issuer-level documented actions only; no individuals are assessed.

| Behaviour | Documented action (category) | Mechanic and implication | Evidence quality |
| --- | --- | --- | --- |
| Shareholder distributions | Repurchases cost USD 194.6 million in FY2025 (1.7 million shares) and USD 30.4 million in nine months 2026 (0.3 million shares at USD 117.05); USD 145.4 million of authorisation remained at December 31, 2025 (Documentary Fact) | Cash returned to equity in FY2025 was a large share of earnings (USD 195.6 million of cash repurchases against net income of USD 237.522 million, Analyst Interpretation), so the company chose equity returns over deleveraging before the deal. Buybacks slowed in 2026: cash payments under the program were USD 31.8 million in nine months 2026 (10-Q Q3 page 3), including excise tax. Whether they resume before debt falls is not documented; the program has no expiry. | High; 10-K page 106, 10-Q Q3 page 27 |
| Leverage policy | The 10-K and Q1 2026 10-Q list a long-term net leverage goal of about 1.5x; the Q2 and Q3 2026 10-Qs list the capital allocation goal without it (Documentary Fact) | No stated replacement target; leverage tolerance after Ruckus is undocumented. Any deleveraging path is a gap, not a conclusion. | High; 10-K page 37, 10-Q Q1 page 16, 10-Q Q2 page 19, 10-Q Q3 page 23 |
| Acquisition funding | Ruckus funded with new term debt rather than equity (Documentary Fact) | Debt-funded growth places integration risk on creditors. The ranking of Term Loan B is not described; the notes are subordinated to senior debt (10-Q Q3 page 18). | High; 10-Q Q3 pages 11 and 20 |
| Creditor-adverse actions | None located: no priming, uptiering, drop-down, non-pro-rata exchange or collateral release in the sources (absence in the supplied sources only) | Legal capacity cannot be judged without the debt documents; willingness shows no creditor-adverse action. | Insufficient for capacity |
| Transparency | Quarterly reporting with non-GAAP reconciliations, and disclosure of the preliminary nature of purchase accounting (Documentary Fact) | Supports tracing, but Adjusted EBITDA is a company definition. | High |

Classification: Neutral or Mixed on the documented evidence. The legal capacity, willingness and feasibility are kept apart: capacity Insufficient Information; willingness shows debt-funded acquisition plus reduced buybacks; feasibility shows liquidity of USD 754.2 million and trailing leverage of 5.57x.

### Conflicts and discrepancies logged

| Item | Sources and quotes | Effect |
| --- | --- | --- |
| Ruckus price | "approximately $1.846 billion" (10-Q Q1 page 16); "approximately $1.85 billion" (release April 30, 2026, page 1); "$1,869.6 million, net of cash acquired" (10-Q Q3 page 11); "approximately $1.9 billion" (10-Q Q2 page 18) | Different bases and rounding; logged, not reconciled. The 10-Q Q3 closing amount is used for the allocation. |
| 2027 Notes repurchase in USD | "$537.3 million" (10-K page 107) against "$535.9 million" (10-Q Q3 page 18) | Translation difference only; logged. |

### Credit translations

1. Evidence: Ruckus contributed USD 167.8 million of revenue and a USD 63.1 million loss before taxes in Q3 2026 and is funded by a USD 1,850.0 million term loan (10-Q Q3 pages 13 and 20). Mechanic: the earnings that service the new debt are unproven and include non-cash charges that will fade, while cash interest begins in full. Implication: debt service and leverage tolerance depend on Ruckus delivering earnings; the 5.57x trailing ratio (CP-1) is on a partial base and is not a stable measure. Countering item: none logged except the price-basis discrepancy.
2. Evidence: ten largest customers are about 47% of revenue, eight of them distributors, with no minimum purchase obligations (10-K pages 5-6 and 106). Mechanic: channel destocking or a distributor change moves volume quickly, and short backlog limits visibility. Implication: revenue durability depends on distributor behaviour; backlog was USD 567.7 million at December 31, 2025 with almost all shipping in 2026.
3. Evidence: copper pricing is passed through with a lag (10-K pages 9-10) and tariff refunds of USD 17.9 million were recorded (10-Q Q3 page 25). Mechanic: margins have a timing exposure to copper and tariff policy; refunds boost reported results without recurring. Implication: margin resilience should be judged excluding the refunds on 2025 transactions; the amounts are disclosed for Q3 2026 and nine months 2026, while the refunds on 2026 transactions net to zero against tariff cost (10-Q Q3 page 25).
4. Evidence: no sponsor or controlling holder appears in the supplied sources. Mechanic: no sponsor extraction behaviour is documented, but there is also no sponsor equity support. Implication: sponsor alignment is Insufficient Information rather than adverse.

### Consumer judgments

| Consumer | Readiness | What to take from this module | Gap and action |
| --- | --- | --- | --- |
| CP-2 | Ready with limitations | Business risk drivers 1 to 3 above, the transaction summary and the governance classification | Ownership, ratings and debt documents are missing; keep them as explicit gaps |
| CP-5 | Ready | Every fact row carries a locator and category for tracing; two logged conflicts | Verify that the figures restated from CP-1 match it exactly |

## Calculations

1. Goodwill plus amortisable intangibles acquired: 1,000,819 + 1,040,000 = 2,040,819 (USD thousands), equal to the printed total of USD 2,040.819 million (10-Q Q3 page 12); the allocation total of assets acquired is 2,404,844 and liabilities 535,212, giving net assets of 1,869,632, consistent with the 1,869.6 million consideration (page 11).
2. Geography, nine months 2026: 1,604,739 + 485,850 + 321,897 = 2,412,486, equal to total revenues.
3. FY2025 segment revenues: 1,219,422 + 1,495,772 = 2,715,194, equal to consolidated revenues (10-K page 43).
4. Cash returned in FY2025: repurchase payments 195,586 (cash flow, including excise tax) against net income 237,522; ratio 82.3% (195,586 / 237,522). The aggregate cost of the repurchase program is USD 194.6 million (10-K page 106); the two differ by excise tax and timing.
5. Equity and acquired intangibles: goodwill and acquired intangibles of USD 2,040.8 million compare with stockholders' equity of USD 1,392.0 million at September 27, 2026 (10-Q Q3 page 2); these are balance sheet comparisons, not tangible-net-worth calculations.
6. Leverage and liquidity figures restated from CP-1 without recomputation: trailing total debt to Adjusted EBITDA 5.57x; liquidity USD 754.2 million; total debt USD 3,103.8 million.

## Gaps

| Gap | Severity | Effect | Action |
| --- | --- | --- | --- |
| Term Loan B, revolver and indenture documents not supplied | High | Legal capacity for distributions, incremental debt, guarantors and collateral cannot be judged | Obtain executed agreements |
| Ruckus history and pro forma EBITDA not supplied; allocation preliminary | High | The earnings contribution and any synergy case are unverified | Obtain acquisition-date run-rate or pro forma EBITDA |
| Ownership and beneficial holders not supplied (proxy statement not in the pack) | Medium | Control, activist exposure and sponsor-like influence cannot be assessed | Obtain the proxy statement |
| Ratings and rating-agency views not supplied | Medium | External credit view is absent | Obtain current ratings |
| Cause of the increase in receivable price adjustments not stated | Low | Possible Ruckus channel effect unknown | Monitor in the FY2026 10-K |
| Tariff refunds are disclosed as a cost of sales reduction, not as a line in the Adjusted EBITDA reconciliation | Medium | Underlying margin must be adjusted by the analyst | Adjust using the disclosed amounts and flag |
| No replacement for the dropped net leverage goal | Medium | Deleveraging intent is undocumented | Seek management commentary |
| Merger agreement terms (conditions, termination fees, indemnities) not supplied | Low | Contingent exposure to the seller cannot be assessed | Obtain the purchase agreement |

## Next module

CP-2 should use the Ruckus mechanics (partial earnings base, preliminary accounting, debt-funded), the distributor concentration and the capital-allocation record as business-risk drivers, keep sponsor alignment, legal capacity and ratings as Insufficient Information, and restate no CP-1 figure without referencing it. CP-5 should trace the figures restated here to CP-1 and the located pages in the 10-K, the three 10-Qs and the October 29, 2026 release.
