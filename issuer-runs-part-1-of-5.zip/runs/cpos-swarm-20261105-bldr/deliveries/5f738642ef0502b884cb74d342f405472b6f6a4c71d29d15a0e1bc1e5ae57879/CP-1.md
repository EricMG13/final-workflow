## Request

Financial data extraction and credit metrics (CP-1) for Builders FirstSource, Inc. (issuer id bldr, NYSE: BLDR), as of 2026-11-05, evidence cutoff 2026-11-05. Pathway credit_snapshot, current period Q3 2026 (quarter ended September 30, 2026), prior period FY2025 (year ended December 31, 2025), reporting currency USD.

Perimeter: Builders FirstSource, Inc. and its consolidated subsidiaries, as one registrant and one reportable segment. The issuer is the parent registrant itself, not a subsidiary inside a combined filing, so no parent or sister-entity figures are mixed in. Statement amounts are USD thousands as printed; release reconciliations and MD&A tables are USD millions as printed. Chart tables below state their own unit.

Scope of this module: reported statement values, reported debt and liquidity facts, the covenant description, and a small set of calculated metrics with every formula shown. It gives no recommendation. Limitations inherited from the source-readiness handoff (legal documents and guarantor list not supplied, Adjusted EBITDA only in management releases, segment and product-category bases changed in 2026, flattened table extraction) apply to every figure here.

## Sources

### Issuer sources relied on

Locators are written `[label page:N]`, where a page is the source chunk shown as `page:N`, not a printed page.

| Source name (exact) | Label | sha256 | Use in this module |
| --- | --- | --- | --- |
| 10-K_2025-12-31_bldr-20251231.htm.jsonl | K10 | 9bd0da5e45c4f2248ca4db64d57fc684925bf29516d1562226f10d757c9e4459 | Audited FY2025 statements, debt note, leases, maturities, covenant description |
| 10-Q_2026-03-31_bldr-20260331.htm.jsonl | Q1 | 363b4992626af02adfa3367e60743e610fb97e980272b73e97926fb679323cd7 | Q1 2026 statements, debt table, availability |
| 10-Q_2026-06-30_bldr-20260630.htm.jsonl | Q2 | 02ee03cdc0624d85cbcbf7a710722ddc9ac45fd9b91dc10f08e351fa9e01c57b | Six-month 2026 statements, debt table, availability |
| 10-Q_2026-09-30_bldr-20260930.htm.jsonl | Q3 | eb3b1081f3726d9edfb8731ffaa8e1149a0312dcd5760fffdc5c5e326cc6f78d | Nine-month and quarter 2026 statements, debt table, availability, MD&A |
| EX-99.1_2026-04-30_bldr-ex99_1.htm.jsonl | R1 | 57b8b8fc9c442c401865b306d40dc3f4e8bf2c98e87e713da2af276f2efa22fe | Not relied on for figures; context only |
| EX-99.1_2026-07-30_bldr-ex99_1.htm.jsonl | R2 | d9ac22d1edd973fb8f940548ad5207a292c8d1318f8581d90b82000eb7ba1b98 | Not relied on for figures; context only |
| EX-99.1_2026-10-29_bldr-ex99_1.htm.jsonl | R3 | e8822f68613ed2eb08d6f6868127023f13ee8e8fe4e83662a7f4abe50d874bbc | Management Adjusted EBITDA, net debt, guidance, free cash flow definition |

Other pinned input: context, sha256 26c088bea94d5b4a50b7398f335a28e56083f68ba3e62b9362de602502e2ae7e (settings only; it leaves valuation, ratings and deal terms blank, which stay Not supplied).

### Supplied handoffs

| Module | sha256 | Use in this module |
| --- | --- | --- |
| CP-0 | 823065622ac29ad63f87b66c10b3d798ab9303f8c970b85b92f36bc8eed37638 | Readiness view READY_WITH_LIMITATIONS for CP-1; limitations carried as listed in Gaps |

Consistency with CP-0: this module found nothing that corrects CP-0. It adds one precision: CP-0 logged the release's income tax line as differing from the statement; here the release's Adjusted EBITDA is rebuilt from reported lines and agrees with the release to within rounding (calculation C9), so the difference is presentational.

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| Reported EBITDA fell from FY2025 to the twelve months to September 30, 2026 while debt principal rose, lifting total debt to EBITDA from 3.26x to 5.15x. Liquidity is about $1.5 billion; no note or revolver matures before 2030. | Medium | Filings print no EBITDA, so it is built from reported lines; management Adjusted EBITDA is higher, and the fixed charge coverage ratio is not reported. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Twelve-month reported EBITDA is 904.402 million versus 1,377.708 million in FY2025; total debt to EBITDA is 5.15x versus 3.26x. | The leverage cushion thinned sharply within three quarters of 2026. | Medium |
| Cash interest over twelve months is 284.752 million; EBITDA covers it 3.18x versus 5.29x in FY2025. | Fixed charges absorb a larger share of earnings, raising sensitivity to further margin declines. | Medium |
| Liquidity at September 30, 2026 is 1,514.1 million: 55.012 million cash plus 1,459.1 million revolver availability; the springing covenant trigger is 173.2 million. | Near-term liquidity is large relative to the trigger; the fixed charge test is not currently applicable. | Medium |
| Senior notes and the revolver mature from 2030; the revolver and the 5.00% notes both fall due that year. | No refinancing wall before 2030, but 2030 holds both a note and the revolver. | Medium |
| Management Adjusted EBITDA of 1,129.1 million exceeds reported EBITDA by 224.7 million, mostly technology implementation expense. | Management leverage of 4.1x relies on add-backs; the reported basis is more conservative. | Medium |

### Financial base view

The financial base is sufficient to state the debt, earnings, cash flow and liquidity position of Builders FirstSource, Inc. at September 30, 2026, with the limitations listed under Gaps. Over the twelve months to September 30, 2026, reported earnings before interest, tax, depreciation and amortization were well below FY2025 because gross margin fell and selling, general and administrative expense was broadly flat, while debt principal rose by 173.9 million, driven by 197.0 million of revolver borrowing. Total debt to EBITDA therefore moved from 3.26x to 5.15x and EBITDA to cash interest from 5.29x to 3.18x on the reported basis. Operating cash flow for the nine months to September 30, 2026 was 302.0 million against 1,021.1 million a year earlier, and the company repurchased 303.5 million of stock in the same nine months, almost all of it in the first quarter. Liquidity was 1,514.1 million at September 30, 2026 and stayed in a range of about 1.5 billion to 1.7 billion at the four balance dates read. The only financial covenant is a fixed charge coverage test of 1.00 to 1.00 that applies only if excess availability falls below a minimum; availability was far above it, and the ratio itself is not reported. The senior unsecured notes and the revolver are fixed in tenor, with the first maturity in 2030. The figures that most need a second look before use are the EBITDA definition (built here, not printed), the management Adjusted EBITDA that carries a large technology implementation add-back, and the guarantor perimeter, which no pinned source names.

### Chart data: leverage

| Period | Total debt / EBITDA | Net debt / EBITDA | Reporting unit | Basis and limitation |
| --- | --- | --- | --- | --- |
| FY2025 | 3.26 | 3.12 | x | Debt principal 4,485.046 million at December 31, 2025 (includes other finance obligations and finance leases, excludes operating leases) over reported EBITDA 1,377.708 million (income from operations plus depreciation and amortization). EBITDA is built, not printed. Calculations C1, C5 |
| LTM Q1 2026 | 3.86 | 3.78 | x | Twelve months to March 31, 2026, derived as FY2025 plus Q1 2026 less Q1 2025. Debt principal 4,679.948 million, cash 98.342 million, EBITDA 1,213.112 million. Derived, unaudited. Calculation C6 |
| LTM Q2 2026 | 4.49 | 4.42 | x | Twelve months to June 30, 2026, derived as FY2025 plus six months 2026 less six months 2025. Debt principal 4,632.386 million, cash 65.651 million, EBITDA 1,032.812 million. Derived, unaudited. Calculation C6 |
| LTM Q3 2026 | 5.15 | 5.09 | x | Twelve months to September 30, 2026, derived as FY2025 plus nine months 2026 less nine months 2025. Debt principal 4,658.904 million, cash 55.012 million, EBITDA 904.402 million. Management reports 4.1x net debt to Adjusted EBITDA on its own definition, not comparable. Calculation C6 |

### Chart data: interest cover

| Period | EBITDA / cash interest | Reporting unit | Basis and limitation |
| --- | --- | --- | --- |
| FY2025 | 5.29 | x | Reported EBITDA 1,377.708 million over cash paid for interest 260.515 million, K10 page:73. Cash interest is gross of interest income and includes interest on finance obligations. Calculation C7 |
| LTM Q1 2026 | 4.72 | x | EBITDA 1,213.112 million over derived cash interest 257.033 million. Derived, unaudited. Calculation C7 |
| LTM Q2 2026 | 3.66 | x | EBITDA 1,032.812 million over derived cash interest 281.987 million. Derived, unaudited. Calculation C7 |
| LTM Q3 2026 | 3.18 | x | EBITDA 904.402 million over derived cash interest 284.752 million. On management Adjusted EBITDA 1,129.1 million the same ratio would be 3.97x, a management-basis figure shown only for reference. Calculation C7 |

### Chart data: liquidity

| Period | Cash | Undrawn committed facilities | Reporting unit | Basis and limitation |
| --- | --- | --- | --- | --- |
| Dec 31, 2025 | 181.753 | 1527.3 | US$m | Cash from the balance sheet. Undrawn is net excess borrowing availability on the 2,200.0 million revolver after the borrowing base and 79.6 million of letters of credit; no borrowings outstanding. Cash in qualified accounts of 159.1 million is part of the borrowing base and of cash, so adding the two overlaps |
| Mar 31, 2026 | 98.342 | 1428.3 | US$m | Net excess availability after 200.0 million borrowed and 76.0 million of letters of credit. Qualified cash of 79.8 million overlaps cash |
| Jun 30, 2026 | 65.651 | 1559.8 | US$m | Net excess availability after 165.0 million borrowed and 76.0 million of letters of credit. Qualified cash of 40.0 million overlaps cash |
| Sep 30, 2026 | 55.012 | 1459.1 | US$m | Net excess availability after 197.0 million borrowed and 75.6 million of letters of credit. Commitments less borrowings less letters of credit would be 1,927.4 million, but the borrowing base of 1,731.7 million is the binding limit. Qualified cash of 21.3 million overlaps cash. Facility matures May 20, 2030 |

### Chart data: debt maturities

| Period | Debt maturing | Reporting unit | Basis and limitation |
| --- | --- | --- | --- |
| 2026 | 0 | US$m | Derived from principal and maturity dates at September 30, 2026; no note or revolver matures in 2026. Current maturities of long-term debt of 4.114 million are not itemised in the 10-Q; they are not notes or the revolver, so they sit in the unscheduled row |
| 2027 | 0 | US$m | Derived as above; no note or revolver maturity |
| 2028 | 0 | US$m | Derived as above; no note or revolver maturity |
| 2029 | 0 | US$m | Derived as above; no note or revolver maturity |
| 2030 | 747.0 | US$m | 5.00% notes due March 2030 of 550.0 million plus the revolver drawn 197.0 million, due May 20, 2030. Calculation C10 |
| 2031 | 0 | US$m | Derived as above; no note or revolver maturity |
| 2032 | 2000.0 | US$m | 4.25% notes due February 2032 of 1,300.0 million plus 6.375% notes due June 2032 of 700.0 million |
| 2033 | 0 | US$m | Derived as above; no note or revolver maturity |
| 2034 | 1000.0 | US$m | 6.375% notes due March 2034 |
| 2035 | 750.0 | US$m | 6.75% notes due May 2035 |
| Unscheduled | 161.904 | US$m | Other finance obligations 161.174 million plus finance lease obligations 0.730 million at September 30, 2026; no maturity schedule is printed in the 10-Q. At December 31, 2025 the 10-K scheduled other finance obligations of 183.891 million as 13.915 million in 2026 and 160.615 million after 2030. Principal totals 4,658.904 million before unamortized discount |

### Financials and credit metrics

| Metric | Period | Value | Unit | Kind | Source or formula |
| --- | --- | --- | --- | --- | --- |
| Net sales | FY2025 | 15,190,638 | USD thousands | Reported | K10 page:71 |
| Net sales | Nine months 2026 | 11,003,672 | USD thousands | Reported | Q3 page:2 |
| Net sales | Nine months 2025 | 11,832,750 | USD thousands | Reported | Q3 page:2 |
| Net sales | Q3 2026 | 3,854,048 | USD thousands | Reported | Q3 page:2 |
| Net sales | Q3 2025 | 3,941,190 | USD thousands | Reported | Q3 page:2 |
| Gross margin | FY2025 | 4,615,777 | USD thousands | Reported | K10 page:71 |
| Gross margin | Nine months 2026 | 3,088,009 | USD thousands | Reported | Q3 page:2 |
| Gross margin | Nine months 2025 | 3,613,765 | USD thousands | Reported | Q3 page:2 |
| Selling, general and administrative expenses | FY2025 | 3,829,501 | USD thousands | Reported | K10 page:71 |
| Selling, general and administrative expenses | Nine months 2026 | 2,843,896 | USD thousands | Reported | Q3 page:2 |
| Selling, general and administrative expenses | Nine months 2025 | 2,889,269 | USD thousands | Reported | Q3 page:2 |
| Income from operations | FY2025 | 786,276 | USD thousands | Reported | K10 page:71 |
| Income from operations | Nine months 2026 | 244,113 | USD thousands | Reported | Q3 page:2 |
| Income from operations | Nine months 2025 | 724,496 | USD thousands | Reported | Q3 page:2 |
| Income from operations | Q3 2026 | 99,091 | USD thousands | Reported | Q3 page:2 |
| Income from operations | LTM Q3 2026 | 305,893 | USD thousands | Calculated | 786,276 + 244,113 - 724,496 (C2) |
| Interest expense, net | FY2025 | 273,894 | USD thousands | Reported | K10 page:71 |
| Interest expense, net | Nine months 2026 | 222,740 | USD thousands | Reported | Q3 page:2 |
| Interest expense, net | Nine months 2025 | 206,139 | USD thousands | Reported | Q3 page:2 |
| Interest expense, net | Q3 2026 | 72,244 | USD thousands | Reported | Q3 page:2 |
| Income before income taxes | FY2025 | 512,382 | USD thousands | Reported | K10 page:71 |
| Income before income taxes | Nine months 2026 | 21,373 | USD thousands | Reported | Q3 page:2 |
| Income before income taxes | Nine months 2025 | 518,357 | USD thousands | Reported | Q3 page:2 |
| Income tax expense (benefit) | FY2025 | 77,183 | USD thousands | Reported | K10 page:71 |
| Income tax expense (benefit) | Nine months 2026 | 12,278 | USD thousands | Reported | Q3 page:2 |
| Income tax expense (benefit) | Nine months 2025 | 114,638 | USD thousands | Reported | Q3 page:2 |
| Net income | FY2025 | 435,199 | USD thousands | Reported | K10 page:71 |
| Net income | Nine months 2026 | 9,095 | USD thousands | Reported | Q3 page:2 |
| Net income | Nine months 2025 | 403,719 | USD thousands | Reported | Q3 page:2 |
| Net income | Q3 2026 | 60,409 | USD thousands | Reported | Q3 page:2 |
| Depreciation and amortization | FY2025 | 591,432 | USD thousands | Reported | K10 page:72, cash flow statement |
| Depreciation and amortization | Nine months 2026 | 447,167 | USD thousands | Reported | Q3 page:3, cash flow statement |
| Depreciation and amortization | Nine months 2025 | 440,090 | USD thousands | Reported | Q3 page:3, cash flow statement |
| Depreciation and amortization | LTM Q3 2026 | 598,509 | USD thousands | Calculated | 591,432 + 447,167 - 440,090 (C2) |
| EBITDA (income from operations plus D&A), not printed | FY2025 | 1,377,708 | USD thousands | Calculated | 786,276 + 591,432 (C1) |
| EBITDA (income from operations plus D&A), not printed | Nine months 2026 | 691,280 | USD thousands | Calculated | 244,113 + 447,167 (C3) |
| EBITDA (income from operations plus D&A), not printed | Nine months 2025 | 1,164,586 | USD thousands | Calculated | 724,496 + 440,090 (C3) |
| EBITDA (income from operations plus D&A), not printed | LTM Q3 2026 | 904,402 | USD thousands | Calculated | 1,377,708 + 691,280 - 1,164,586 (C4) |
| Management Adjusted EBITDA | Nine months 2026 | 854.2 | USD millions | Management | R3 page:13 |
| Management Adjusted EBITDA | Nine months 2025 | 1,308.9 | USD millions | Management | R3 page:13 |
| Management Adjusted EBITDA | LTM Q3 2026 | 1,129.1 | USD millions | Management | R3 page:13 |
| Management Adjusted EBITDA | FY2025 | 1,583.8 | USD millions | Calculated from management figures | 1,129.1 - 854.2 + 1,308.9 (C8); not printed in any pinned source |
| Net cash provided by operating activities | FY2025 | 1,215,886 | USD thousands | Reported | K10 page:72 |
| Net cash provided by operating activities | Nine months 2026 | 302,031 | USD thousands | Reported | Q3 page:3 |
| Net cash provided by operating activities | Nine months 2025 | 1,021,092 | USD thousands | Reported | Q3 page:3 |
| Purchases of property, plant and equipment | FY2025 | 362,602 | USD thousands | Reported | K10 page:73 |
| Purchases of property, plant and equipment | Nine months 2026 | 157,430 | USD thousands | Reported | Q3 page:3 |
| Purchases of property, plant and equipment | Nine months 2025 | 274,531 | USD thousands | Reported | Q3 page:3 |
| Proceeds from sale of property, plant and equipment | FY2025 | 20,750 | USD thousands | Reported | K10 page:73 |
| Proceeds from sale of property, plant and equipment | Nine months 2026 | 6,274 | USD thousands | Reported | Q3 page:3 |
| Proceeds from sale of property, plant and equipment | Nine months 2025 | 18,408 | USD thousands | Reported | Q3 page:3 |
| Free cash flow (operating cash flow less capex net of proceeds) | FY2025 | 874,034 | USD thousands | Calculated | 1,215,886 - 362,602 + 20,750 (C11) |
| Free cash flow (operating cash flow less capex net of proceeds) | Nine months 2026 | 150,875 | USD thousands | Calculated | 302,031 - 157,430 + 6,274 (C11); release prints 150.8 million from rounded inputs |
| Free cash flow (operating cash flow less capex net of proceeds) | Nine months 2025 | 764,969 | USD thousands | Calculated | 1,021,092 - 274,531 + 18,408 (C11) |
| Free cash flow (operating cash flow less capex net of proceeds) | LTM Q3 2026 | 259,940 | USD thousands | Calculated | 874,034 + 150,875 - 764,969 (C11) |
| Cash used for acquisitions, net of cash acquired | FY2025 | 1,123,328 | USD thousands | Reported | K10 page:73 |
| Cash used for acquisitions, net of cash acquired | Nine months 2026 | 116,678 | USD thousands | Reported | Q3 page:3 |
| Cash used for acquisitions, net of cash acquired | Nine months 2025 | 904,515 | USD thousands | Reported | Q3 page:3 |
| Repurchase of common stock | FY2025 | 413,958 | USD thousands | Reported | K10 page:73 |
| Repurchase of common stock | Nine months 2026 | 303,519 | USD thousands | Reported | Q3 page:3 |
| Repurchase of common stock | Nine months 2025 | 413,958 | USD thousands | Reported | Q3 page:3 |
| Cash paid for interest | FY2025 | 260,515 | USD thousands | Reported | K10 page:73 |
| Cash paid for interest | Nine months 2026 | 230,109 | USD thousands | Reported | Q3 page:4 |
| Cash paid for interest | Nine months 2025 | 205,872 | USD thousands | Reported | Q3 page:4 |
| Cash paid for interest | LTM Q3 2026 | 284,752 | USD thousands | Calculated | 260,515 + 230,109 - 205,872 (C2) |
| Cash paid for income taxes | FY2025 | 67,658 | USD thousands | Reported | K10 page:99, total taxes paid |
| Cash paid for income taxes | Nine months 2026 | 6,369 | USD thousands | Reported | Q3 page:4 |
| Cash paid for income taxes | Nine months 2025 | 72,760 | USD thousands | Reported | Q3 page:4 |
| Cash and cash equivalents | Dec 31, 2025 | 181,753 | USD thousands | Reported | K10 page:72 |
| Cash and cash equivalents | Sep 30, 2026 | 55,012 | USD thousands | Reported | Q3 page:2 |
| Total assets | Dec 31, 2025 | 11,237,530 | USD thousands | Reported | K10 page:72 |
| Total assets | Sep 30, 2026 | 11,334,675 | USD thousands | Reported | Q3 page:2 |
| Goodwill | Sep 30, 2026 | 4,166,201 | USD thousands | Reported | Q3 page:2 |
| Total liabilities | Sep 30, 2026 | 7,253,662 | USD thousands | Reported | Q3 page:3 |
| Total stockholders' equity | Sep 30, 2026 | 4,081,013 | USD thousands | Reported | Q3 page:3 |
| Revolving credit facility drawn | Dec 31, 2025 | 0 | USD thousands | Reported | K10 page:91, printed as a dash |
| Revolving credit facility drawn | Sep 30, 2026 | 197,000 | USD thousands | Reported | Q3 page:13 |
| Total debt principal incl. other finance obligations and finance leases | Dec 31, 2025 | 4,485,046 | USD thousands | Reported | K10 page:91 |
| Total debt principal incl. other finance obligations and finance leases | Sep 30, 2026 | 4,658,904 | USD thousands | Reported | Q3 page:13 |
| Total debt carrying amount, net of discount and issuance costs | Sep 30, 2026 | 4,619,164 | USD thousands | Reported | Q3 page:13 |
| Operating lease liabilities, current plus noncurrent | Sep 30, 2026 | 661,275 | USD thousands | Calculated | 114,887 + 546,388 (C12); outside the debt figure |
| Net debt (principal less cash) | Dec 31, 2025 | 4,303,293 | USD thousands | Calculated | 4,485,046 - 181,753 (C5) |
| Net debt (principal less cash) | Sep 30, 2026 | 4,603,892 | USD thousands | Calculated | 4,658,904 - 55,012 (C5); release prints 4,603.9 million |
| Gross margin percent of net sales | Nine months 2026 | 28.06 | percent | Calculated | 3,088,009 / 11,003,672 (C13) |
| Gross margin percent of net sales | Nine months 2025 | 30.54 | percent | Calculated | 3,613,765 / 11,832,750 (C13) |
| Reported EBITDA margin | LTM Q3 2026 | 6.30 | percent | Calculated | 904,402 / 14,361,560 (C13) |
| Total debt / EBITDA | FY2025 | 3.26 | x | Calculated | 4,485,046 / 1,377,708 (C5) |
| Total debt / EBITDA | LTM Q3 2026 | 5.15 | x | Calculated | 4,658,904 / 904,402 (C6) |
| Net debt / EBITDA | FY2025 | 3.12 | x | Calculated | 4,303,293 / 1,377,708 (C5) |
| Net debt / EBITDA | LTM Q3 2026 | 5.09 | x | Calculated | 4,603,892 / 904,402 (C6) |
| Net debt / management Adjusted EBITDA | LTM Q3 2026 | 4.08 | x | Calculated, management basis | 4,603.892 / 1,129.1 (C8); release states 4.1x |
| EBITDA / cash interest | FY2025 | 5.29 | x | Calculated | 1,377,708 / 260,515 (C7) |
| EBITDA / cash interest | LTM Q3 2026 | 3.18 | x | Calculated | 904,402 / 284,752 (C7) |
| Income from operations / net interest expense | LTM Q3 2026 | 1.05 | x | Calculated | 305,893 / 290,495 (C14) |

### Debt and capital structure at September 30, 2026

| Instrument | Principal, USD thousands | Rate and maturity | Ranking and guarantee as printed | Source |
| --- | --- | --- | --- | --- |
| Revolving credit facility | 197,000 | SOFR or base rate plus margin; weighted average rate 4.7%; due May 20, 2030; 2,200.0 million commitments | First lien on revolving collateral, second lien on notes collateral; guaranteed by the Company and the Debt Guarantors | Q3 page:13, Q3 page:9, K10 page:93 |
| 4.25% 2032 notes | 1,300,000 | Fixed; due February 2032 | Senior unsecured; guaranteed by the Debt Guarantors | Q3 page:13, K10 page:93 |
| 6.375% 2034 notes | 1,000,000 | Fixed; due March 2034 | Senior unsecured; guaranteed by the Debt Guarantors | Q3 page:13, K10 page:93 |
| 6.75% 2035 notes | 750,000 | Fixed; due May 2035 | Senior unsecured; guaranteed by the Debt Guarantors | Q3 page:13, K10 page:93 |
| 6.375% 2032 notes | 700,000 | Fixed; due June 2032 | Senior unsecured; guaranteed by the Debt Guarantors | Q3 page:13, K10 page:93 |
| 5.00% 2030 notes | 550,000 | Fixed; due March 2030 | Senior unsecured; guaranteed by the Debt Guarantors | Q3 page:13, K10 page:93 |
| Other finance obligations | 161,174 | Property leases with a single lessor treated as financing; schedule only at December 31, 2025 | Counted inside long-term debt | Q3 page:13, K10 page:96 |
| Finance lease obligations | 730 | Not printed | Counted inside long-term debt | Q3 page:13 |
| Total principal | 4,658,904 | | | Q3 page:13 |

Series count: five senior unsecured note series plus the revolver, counted from the Q3 debt table, with the 4.25% 2032 notes printed in the 10-K as two issuances of 300,000 and 1,000,000 thousand. Fair values at September 30, 2026 are printed per series (Q3 page:13). Notes are redeemable on terms in the indentures and carry a 101 percent change of control put; the indentures are not supplied.

### Covenants and definitions

- Maintenance test: the revolver has one financial covenant, a minimum fixed charge coverage ratio of 1.00 to 1.00 that applies only when excess availability falls below the specified minimum. [K10 page:93] "of 1.00 to 1.00 if our excess availability falls below the greater of $165.0 million or 10% of the maximum borrowing amount, which was $160.7 million as of December 31, 2025."
- Level at September 30, 2026: [Q3 page:27] "Excess availability must equal or exceed a minimum specified amount, currently $173.2 million, or we are required to meet a fixed charge coverage ratio of 1.00 to 1.00." Reported availability is 1,459.1 million, so headroom to the trigger is 1,285.9 million (C15). The same calculation gives 1,257.9 million at March 31, 2026, 1,379.7 million at June 30, 2026 and 1,362.3 million at December 31, 2025 against the 165.0 million then in force. The threshold moves with the borrowing base (10 percent of 1,731.7 million is 173.17 million).
- Reported figure: the fixed charge coverage ratio itself is Not supplied, because the test is not currently applicable and no pinned source prints a computed ratio. The definition of fixed charges and of the numerator is in the credit agreement, which is not supplied; the EBITDA used in this module is not that covenant definition.
- Compliance: [Q3 page:13] "We were not in violation of any covenants or restrictions imposed by any of our debt agreements at September 30, 2026."
- Negative covenants in the revolver and the indentures limit debt, liens, restricted payments, investments, asset sales and affiliate transactions (K10 page:93, K10 page:95); the baskets are Not supplied.
- Definition differences: reported EBITDA here (income from operations plus D&A) differs from management Adjusted EBITDA, which adds technology implementation expense, stock compensation, acquisition expense and other management-identified adjustments (R3 page:13), and from any covenant definition.

### Non-debt claims and commitments

- Operating leases: current plus noncurrent operating lease liabilities of 661,275 thousand at September 30, 2026 (Q3 page:3), outside the debt figure.
- Other finance obligations: inside the debt figure. [K10 page:96] "the Company is party to 110 individual property lease agreements with a single lessor as of December 31, 2025".
- Letters of credit: 75.6 million, under the revolver and already deducted from availability. [Q3 page:17] "As of September 30, 2026, we had outstanding letters of credit totaling $75.6 million under our Revolving Facility that principally support our self-insurance programs."
- Litigation: [Q3 page:17] "The Company has a number of known and threatened construction defect legal claims." The company states a reasonable possibility of loss that cannot be estimated; no amount is provided.
- Not found in the pinned sources by keyword search: pension or retiree medical obligations, factoring or supply-chain finance programs, purchase commitment tables, surety bond amounts. Their absence from the text is not evidence of nil; they are Not supplied.

### Management guidance, attributed

Management guidance is a management claim, not a filing fact, and is shown without reconciliation (R3 page:4 states none is given). [R3 page:4] "Adjusted EBITDA to be in a range of $1.075 billion to $1.125 billion." [R3 page:4] "Free cash flow of approximately $400 million to $450 million". [R3 page:4] "Interest expense in the range of $290 million to $300 million." [R3 page:4] "Total capital expenditures in the range of $175 million to $225 million."

### Recent events and cash uses

- Share repurchases: [Q3 page:5] "During the three months ended March 31, 2026, we repurchased and retired 3.3 million shares of our common stock for $302.9 million". Nine-month repurchases were 303,519 thousand (Q3 page:3) and the third quarter had none (Q3 page:32).
- Financing mix: [Q3 page:28] "Cash used in financing activities was $133.4 million for the nine months ended September 30, 2026, which consisted primarily of using $303.5 million for repurchases of common stock, partially offset by $197.0 million in net borrowings on the Revolving Facility." The filing states the two together; it does not say the borrowing funded the repurchases.
- Operating cash flow: [Q3 page:28] "The decrease in cash provided by operating activities was primarily driven by the decrease in net income in the current period compared to the prior year period, and an increase in net working capital in the first nine months of 2026."
- Acquisitions: [Q3 page:9] "for a combined total purchase consideration of approximately $129.3 million". Pro forma information is not presented.
- Equity investment: [Q3 page:22] "On August 25, 2026, we announced a strategic investment in, and collaboration with, Digs". Cash used for equity investments in the nine months was 27,578 thousand (Q3 page:3).
- Tax: a discrete income tax expense from an IRS research and development settlement affected the first half of 2026. [Q2 page:24] "we recognized a discrete income tax expense of approximately $43.9 million in the current year period".
- Interest rate sensitivity: [Q3 page:29] "A 1.0% increase in interest rates on the Revolving Facility would result in approximately $2.0 million additional interest expense annually". The notes are fixed rate.
- Subsequent events: none found after September 30, 2026 in the pinned sources; the 10-K subsequent event (the January 2, 2026 acquisition) predates the current period.

### Interpretation

- Leverage. Evidence: the debt table shows principal of 4,485,046 thousand at December 31, 2025 and 4,658,904 thousand at September 30, 2026, with the revolver drawn 197,000 thousand (Q3 page:13), while nine-month income from operations fell from 724,496 thousand to 244,113 thousand (Q3 page:2). Mechanism: the debt is largely fixed-rate notes with no scheduled principal payment before 2030, so leverage moves with earnings, and management attributes the gross profit decline mainly to a lower housing starts environment (R3 page:1). Implication: total debt to EBITDA is above the FY2025 level by about 1.9 turns on the reported basis, and further EBITDA decline raises it without any change in debt.
- Coverage. Evidence: net interest expense for nine months rose from 206,139 thousand to 222,740 thousand (Q3 page:2), and cash interest for the twelve months is 284,752 thousand (C2). Mechanism: the 6.75% 2035 notes were issued on May 8, 2025 and so were outstanding for only part of the nine-month 2025 comparator, and the revolver was drawn in 2026 (K10 page:92, Q3 page:13). Implication: fixed charges are stable to rising while EBITDA is falling, which is why cover moved from 5.29x to 3.18x.
- Cash flow. Evidence: nine-month operating cash flow of 302,031 thousand against 1,021,092 thousand (Q3 page:3), with working capital absorbing cash (Q3 page:28). Mechanism: receivables and inventories absorbed cash of 229,466 thousand and 122,131 thousand, partly offset by payables of 178,060 thousand (Q3 page:3). Implication: operating cash flow is already after cash interest, and free cash flow after capex of 150,875 thousand (C11) was positive but smaller than the repurchase of 303,519 thousand in the same period.
- Liquidity. Evidence: availability of 1,459.1 million against a trigger of 173.2 million (Q3 page:27). Mechanism: availability is borrowing-base driven, so it follows receivables and inventory and can contract as sales fall; the borrowing base grew from 1,606.9 million to 1,731.7 million as receivables and inventory rose, which offset part of the 197.0 million draw, so availability fell only from 1,527.3 million to 1,459.1 million. Implication: liquidity is currently ample, but part of it rests on the same working capital build that reduced operating cash flow.
- Maturities. Evidence: the maturity table above. Mechanism: no note or revolver is due before 2030 and the revolver and the 5.00% notes are both due in 2030, so refinancing risk concentrates in that year. Implication: no near-term refinancing pressure, with the 2030 date as the first test of market access.

### Source context and data quality

All figures are consolidated, in USD, for Builders FirstSource, Inc. and its subsidiaries. K10 is audited; Q1, Q2 and Q3 are unaudited; R3 is a management release. Where a filing and a release differ, the filing controls. Every pinned page was extracted successfully; tables are flattened to one value per line and statements run across chunk breaks, so each statement value above was read from its page and tied: FY2025 gross margin less selling, general and administrative expense equals income from operations of 786,276 thousand; nine-month 2026 and 2025 income statements foot to net income of 9,095 thousand and 403,719 thousand; 4,485,046 thousand and 4,658,904 thousand foot to the debt table lines; and net debt of 4,603,892 thousand equals management's 4,603.9 million. The 2025 comparatives used for the twelve-month figures come from the comparative columns of the Q1, Q2 and Q3 reports, because no 2025 quarterly report is in the pack.

## Calculations

All inputs are USD thousands from the cited pages unless a row says millions. Results are shown to the precision used above.

| ID | Calculation | Inputs and result |
| --- | --- | --- |
| C1 | FY2025 EBITDA = income from operations + depreciation and amortization | 786,276 + 591,432 = 1,377,708 |
| C2 | LTM Q3 2026 = FY2025 + nine months 2026 - nine months 2025, for income from operations, D&A and cash paid for interest | Income from operations: 786,276 + 244,113 - 724,496 = 305,893. D&A: 591,432 + 447,167 - 440,090 = 598,509. Cash interest: 260,515 + 230,109 - 205,872 = 284,752 |
| C3 | Nine-month EBITDA | 2026: 244,113 + 447,167 = 691,280. 2025: 724,496 + 440,090 = 1,164,586 |
| C4 | LTM Q3 2026 EBITDA = FY2025 + nine months 2026 - nine months 2025 | 1,377,708 + 691,280 - 1,164,586 = 904,402; cross-check 305,893 + 598,509 = 904,402 |
| C5 | FY2025 net debt and ratios | Net debt 4,485,046 - 181,753 = 4,303,293. Total debt / EBITDA 4,485,046 / 1,377,708 = 3.26x. Net debt / EBITDA 4,303,293 / 1,377,708 = 3.12x |
| C6 | LTM leverage at each quarter-end | Q1: income from operations 786,276 + 16,516 - 184,441 = 618,351; D&A 591,432 + 148,360 - 145,031 = 594,761; EBITDA 1,213,112; debt 4,679,948 and cash 98,342; total 3.86x, net 3.78x. Q2: income from operations 786,276 + 145,023 - 495,728 = 435,571; D&A 591,432 + 298,364 - 292,555 = 597,241; EBITDA 1,032,812; debt 4,632,386 and cash 65,651; total 4.49x, net 4.42x. Q3: EBITDA 904,402; debt 4,658,904, cash 55,012, net debt 4,603,892; total 5.15x, net 5.09x |
| C7 | EBITDA / cash interest | FY2025 1,377,708 / 260,515 = 5.29x. Q1: cash interest 260,515 + 85,196 - 88,678 = 257,033; 1,213,112 / 257,033 = 4.72x. Q2: 260,515 + 146,805 - 125,333 = 281,987; 1,032,812 / 281,987 = 3.66x. Q3: 904,402 / 284,752 = 3.18x. Adjusted reference: 1,129.1 / 284.752 = 3.97x |
| C8 | Management basis | FY2025 Adjusted EBITDA 1,129.1 - 854.2 + 1,308.9 = 1,583.8 million (derived from rounded millions). Net debt / Adjusted EBITDA 4,603.892 / 1,129.1 = 4.08x, against 4.1x stated by management |
| C9 | Reconcile reported to management EBITDA, LTM Q3 2026, millions | 904.402 + technology implementation 149.0 + stock compensation 43.1 + acquisition and related 6.0 + other management-identified 26.7 = 1,129.2, against 1,129.1 printed; the 0.1 difference is rounding. Add-backs total 224.8 against a difference of 224.7 |
| C10 | 2030 maturities at September 30, 2026 | 550,000 + 197,000 = 747,000. 2032: 1,300,000 + 700,000 = 2,000,000. Notes and revolver total 4,497,000; plus other finance obligations 161,174 and finance leases 730 = 4,658,904, which equals the printed total principal |
| C11 | Free cash flow = operating cash flow - purchases of property, plant and equipment + proceeds from sale (the release's net-of-proceeds definition) | FY2025 1,215,886 - 362,602 + 20,750 = 874,034. Nine months 2026 302,031 - 157,430 + 6,274 = 150,875. Nine months 2025 1,021,092 - 274,531 + 18,408 = 764,969. LTM 874,034 + 150,875 - 764,969 = 259,940 |
| C12 | Operating lease liabilities, September 30, 2026 | 114,887 + 546,388 = 661,275 |
| C13 | Margins | Nine-month 2026 gross margin 3,088,009 / 11,003,672 = 28.06 percent. Nine-month 2025 3,613,765 / 11,832,750 = 30.54 percent. LTM net sales 15,190,638 + 11,003,672 - 11,832,750 = 14,361,560; EBITDA margin 904,402 / 14,361,560 = 6.30 percent |
| C14 | LTM net interest expense and operating income cover | 273,894 + 222,740 - 206,139 = 290,495; 305,893 / 290,495 = 1.05x; the release prints 290.5 million |
| C15 | Covenant headroom (availability - specified minimum), millions | Sep 30, 2026: 1,459.1 - 173.2 = 1,285.9. Jun 30, 2026: 1,559.8 - 180.1 = 1,379.7. Mar 31, 2026: 1,428.3 - 170.4 = 1,257.9. Dec 31, 2025: 1,527.3 - 165.0 = 1,362.3 |
| C16 | Liquidity = cash + net excess availability, millions | Dec 31, 2025: 181.753 + 1,527.3 = 1,709.1. Mar 31, 2026: 98.342 + 1,428.3 = 1,526.6. Jun 30, 2026: 65.651 + 1,559.8 = 1,625.5. Sep 30, 2026: 55.012 + 1,459.1 = 1,514.1 |
| C17 | Change in debt principal | 4,658,904 - 4,485,046 = 173,858 |

## Gaps

| Gap | Severity | Effect | Action |
| --- | --- | --- | --- |
| Legal documents (credit agreement and amendments, indentures, intercreditor and collateral agreements) are not supplied; covenant, guarantor and redemption terms rest on the 10-K and 10-Q summaries (inherited from the readiness review) | Medium | Covenant definitions, baskets and the Debt Guarantors cannot be verified; collateral and ranking are as summarized | Obtain the credit agreement and indentures before any covenant or structural conclusion |
| Fixed charge coverage ratio not reported; the test is springing and not currently applicable | Medium | Covenant headroom is measured only as availability less the specified minimum | Treat headroom as availability based; do not infer a ratio |
| EBITDA is not printed in any filing; the EBITDA used is income from operations plus D&A from the cash flow statement | Medium | Leverage and cover depend on that definition and exclude stock compensation, technology implementation expense and other add-backs | State the definition with every ratio; compare with the management basis |
| Management Adjusted EBITDA and its leverage ratio appear only in the releases; FY2025 Adjusted EBITDA is not printed and is derived from rounded management figures | Medium | Management leverage is attributed and not audited | Use only as attributed, with the 224.7 million bridge shown |
| No maturity schedule at September 30, 2026; the 10-K schedule at December 31, 2025 covers notes and revolver only and excludes other finance obligations | Medium | The maturity chart is derived from principal and maturity dates; other finance obligations are unscheduled | Label as derived |
| Twelve-month figures for Q1, Q2 and Q3 2026 are derived from comparative columns; no Q3 2025 or Q4 2025 stand-alone report is in the pack | Low | Derived, unaudited; Q4 2025 stand-alone is not shown | Keep the derived label |
| Liquidity adds cash and availability although qualified cash is part of the borrowing base | Low | Liquidity may be overstated by up to the qualified cash amount, 21.3 million at September 30, 2026 | Show both components, as in the chart |
| Capex split between maintenance and growth, pension and retiree medical, factoring and surety exposure are not found in the pinned sources | Low | Free cash flow is not split and non-debt claims may be incomplete | Not supplied; do not treat as nil |
| Unquantified construction defect claims | Low | Possible loss not estimable per the filing | Monitor through insurance disclosures |
| Segment and product-category bases changed in 2026 and are not used here | Low | No segment or category figures are presented | Use consolidated figures only |
| Context blanks: borrower, parent, guarantors, ratings, quotes, valuation, peers | Low | No market-based or rating-based metric is possible | Not supplied |
| Table extraction is flattened; negative values split across lines | Medium | Transcription risk | Each cited figure was matched to its page; re-check on reuse |

## Next module

Proceed to CP-1A (business and transaction context). Carry forward: the leverage and cover figures above are on a built reported-EBITDA basis, not a covenant or management basis; liquidity is about 1.5 billion with a springing covenant far from its trigger; the first maturity is 2030; the guarantor perimeter and legal terms are not supplied; and the acquisitions, the Digs investment, the 2026 share repurchase and the segment realignment (Q3 pages:6, 9, 22) are the business and transaction items to source. CP-2 and CP-5 should treat the Calculations table as the register of derived figures, with Adjusted EBITDA figures labelled management-attributed.
