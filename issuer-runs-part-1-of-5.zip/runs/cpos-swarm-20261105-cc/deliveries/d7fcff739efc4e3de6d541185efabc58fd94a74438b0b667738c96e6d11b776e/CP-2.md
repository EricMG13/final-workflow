## Request

Chemours Co (The Chemours Company, issuer id cc), as of 2026-11-05, pathway credit_snapshot. This module synthesises the fundamental credit view from the supplied financial base and business context only, in USD, without peer ranking, instrument recommendation or recovery conclusion.

## Sources

### Issuer sources behind the upstream handoffs

This module quotes no source text. It relies on the issuer sources below through the two handoffs that cite them.

| Source (exact name) | sha256 |
| --- | --- |
| 10-K_2025-12-31_cc-20251231.htm.jsonl | adf80f4588f501b9f797e1b55a5853888465c5d9b30aef8ff07b3cd4340b3957 |
| 10-Q_2026-03-31_cc-20260331.htm.jsonl | 544e858f14516405499b0793277b117ab856893d213de4bfdfd312ae33ddb9fd |
| 10-Q_2026-06-30_cc-20260630.htm.jsonl | 5934bf743b44e940824956ac90d2979f28da0477a0f669044693e5e59c78b62f |
| 10-Q_2026-09-30_cc-20260930.htm.jsonl | f23013a765ad5943b395240230ccfbe7a0cca417e186c8a1a82b34a215485de7 |
| EX-99.1_2026-05-05_cc-ex99_1.htm.jsonl | cf37012a81481ef001a376d207312af6444e1ec5683c9d45ff930f84bd36dd4e |
| EX-99.1_2026-08-04_cc-ex99_1.htm.jsonl | 5e0a77f0453e40d6a00670f0f971f2e2c0487e12a68a0222858c84133578166e |
| EX-99.1_2026-11-02_cc-ex99_1.htm.jsonl | d716a94a423338ae97b02c515014fccad1457c8952131fe6a67cf2f82a22b1e0 |

The run context (sha256 e4e3509e830ce866831093e05761a30c7677098a166e3ae01f6bf5702202686d) holds dates and currency only.

### Supplied handoffs

| Module | sha256 | Role |
| --- | --- | --- |
| CP-0 (source readiness) | 1ecb39c4a4880cffa7ae4a7043208842e01127188022f689018f652251f98699 | Source map and gap register |
| CP-1 (financial base) | 66c8382addeeb6334641b2106aad48df892e2b12eebe59c20cf662cd9c7c2735 | Leverage, liquidity, maturities, covenant evidence, claims outside debt; the basis for every financial figure here |
| CP-1A (business and transaction context) | 68f3c23dab99b4b17ecaf3d393184950ee6d4db0592f5576f2a8e526977fa345 | Business risk, fact register F1 to F30, governance, credit translations |

Basis references in this handoff, such as "CP-1 leverage table" or "CP-1A F13", point to rows in those handoffs. The two earlier corrections (revolver tranche matured one week, not five weeks, after the balance-sheet date; the 23 shift between depreciation and restructuring in the 2025 release) are unchanged.

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| Chemours is a leveraged, cyclical credit with adequate near-term liquidity, falling debt and cost-shared legacy liabilities, but its cash flow is claimed by multi-year PFAS settlements and book equity is thin. | Medium | Covenant headroom, legal capacity and current cash interest cover cannot be tested from the supplied sources. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Total debt principal fell from USD 4,182 million to USD 3,872 million, and net leverage eased from 4.68x to 4.25x between FY2025 and Q3 2026. | Progress is real, but leverage near 4x leaves little room for a weaker earnings quarter. | Medium |
| The 2028 maturity of USD 780 million and the 2029 maturity of USD 647 million sit within the revolver springing-maturity window. | Refinancing of those instruments is the main medium-term funding event. | High |
| Settlement obligations to New Jersey and North Carolina are multi-year cash calls that Adjusted EBITDA excludes. | Debt service capacity is weaker than Adjusted EBITDA suggests until settlement cash is netted. | Medium |
| Refrigerant earnings are falling as the prior-year channel fill reverses, while titanium earnings recover on pricing and rely on a concentrated customer base. | The earnings base is shifting toward the more cyclical segment. | Medium |

### Credit view

Chemours is a leveraged, cyclical chemicals credit with adequate near-term liquidity, whose cash flow is increasingly claimed by legacy PFAS settlements. The strongest support is deleveraging: total debt principal fell to USD 3,872 million at 2026-09-30, net leverage eased to 4.25x, unrestricted cash was USD 698 million, no revolver amounts were drawn, and DuPont and Corteva share half of future qualifying legacy PFAS cost. The weakest point is that Adjusted EBITDA excludes settlement and environmental cash while book equity is only USD 156 million. What decides the outcome is whether titanium dioxide pricing holds as refrigerant sales normalise, and whether the 2028 and 2029 debt is refinanced before the revolver springing maturity applies.

### Credit assessment

| Item | Content |
| --- | --- |
| Fundamental credit view | Leveraged and cash-constrained, with adequate near-term liquidity and credible deleveraging: financial risk is elevated and business risk is moderate but cyclical |
| Category | Analyst Interpretation |
| Confidence | Medium. It is below High because the business-context handoff judges this synthesis READY_WITH_LIMITATIONS, and because covenant headroom, legal capacity and 2026 cash interest cover are open |
| Basis | CP-1 leverage, liquidity and maturity tables and debt schedule; CP-1A F2, F3, F6, F13, F18, F19, F24 to F27 and its credit translations |

### Thesis

Deleveraging and cost-sharing of legacy PFAS liabilities support the credit, but cyclical earnings, a concentrated titanium customer base and multi-year settlement cash calls leave leverage near 4x with little margin for error.

### Strengths and weaknesses

Strengths. Deleveraging is the first: total debt principal fell by USD 310 million in the nine months of 2026 to USD 3,872 million, and net debt over Adjusted EBITDA eased from 4.68x at FY2025 to 4.25x at LTM Q3 2026 on the filing basis; management reports about 4.3x on its own basis (Documentary Fact for the debt figures, Analyst Interpretation for the trend; basis CP-1 leverage table, CP-1A F26). The maturity profile is clear until 2028: the 5.375 percent notes due May 2027 were redeemed, and scheduled payments are USD 26 million for the remainder of 2026 and USD 42 million for 2027 (Documentary Fact; basis CP-1 maturities table). Liquidity at the balance-sheet date was unrestricted cash of USD 698 million and revolver availability of USD 953 million net of letters of credit, with no revolver borrowings, and management states liquidity is adequate through at least the end of November 2027 (Documentary Fact; the horizon is Management Language; basis CP-1 liquidity table, CP-1A F28). The customer base is broad outside titanium: about 2,400 customers in about 110 countries, none above 10 percent of consolidated sales, and none above 10 percent in refrigerants or advanced materials (Documentary Fact; basis CP-1A F2). DuPont and Corteva bear the other half of qualifying future legacy PFAS cost up to an aggregate USD 4,000 million, with about USD 1,130 million available, and funded USD 150 million into escrow when the New Jersey order became final (Documentary Fact; basis CP-1A F13, F20). Issuer behaviour is supportive on the documented actions: the dividend fell from USD 1.00 per share declared in 2024 to USD 0.0875 per quarter in 2026, no shares were repurchased, and land sale proceeds funded repayment of the euro term loan (Analyst Interpretation of documented actions; basis CP-1A F24 to F26). Titanium Technologies segment Adjusted EBITDA rose to USD 85 million in Q3 2026 from USD 25 million a year earlier on a price increase, and management describes a low-cost chloride process (Documentary Fact for the figures, Management Language for the cost position; basis CP-1A F6, F7).

Weaknesses. Leverage is high and equity thin: total debt principal over Adjusted EBITDA was 5.18x at LTM Q3 2026, and total equity was USD 156 million against total liabilities of USD 7,137 million, so book value gives no cushion (Documentary Fact; the cushion reading is Analyst Interpretation; basis CP-1 leverage and financial tables). Adjusted EBITDA overstates the cash available for debt service: it excludes litigation charges of USD 320 million and environmental charges of USD 93 million in FY2025, and USD 106 million and USD 168 million respectively in the nine months of 2026, while reported operating cash flow was negative USD 633 million in FY2024 and USD 264 million in FY2025 (Documentary Fact; the reading is Analyst Interpretation; basis CP-1 financial table and interpretation). Settlement cash calls are large: New Jersey totals USD 875 million over 25 years with USD 100 million paid in September 2026, North Carolina totals USD 455 million over 15 years with a first payment of USD 51 million in October 2026, and matters for which loss is reasonably possible but not estimable remain unreserved (Documentary Fact; basis CP-1A F18, F19, F21). Earnings are rotating toward the more cyclical segment: Thermal and Specialized Solutions Adjusted EBITDA fell to USD 136 million from USD 194 million in Q3 2026 as the prior-year aftermarket channel fill reversed, while the recovery is in titanium (Documentary Fact for the figures, Management Language for the channel-fill cause; basis CP-1A F4 to F6). Titanium customers are concentrated: the ten largest exceed 44 percent of segment sales and one exceeds 20 percent (Documentary Fact; basis CP-1A F3). Interest cover is thin and relief small: Adjusted EBITDA over cash interest was 2.99x in FY2025, and management expects annual interest expense to fall by only about USD 3 million after the 2026 refinancing at higher coupons (Documentary Fact; relief is Management Language; basis CP-1 interest cover table, CP-1A transaction summary). A 2024 audit committee review, 2023 material weaknesses remediated in 2024 and revised prior periods keep a monitoring flag (Documentary Fact; the flag is Analyst Interpretation; basis CP-1A F14 to F16).

### Key findings

First, leverage is high but falling: net debt over Adjusted EBITDA was 4.68x at FY2025 and 4.25x at LTM Q3 2026, and total debt over Adjusted EBITDA 5.58x and 5.18x, on a filing-component basis that sums segment Adjusted EBITDA less corporate expenses (Analyst Interpretation; basis CP-1 leverage table). Second, the refinancing wall begins in 2028: USD 780 million falls in 2028 and USD 647 million in 2029 with USD 2,419 million after 2030, and the revolver has a springing maturity if the term loans or the 2028 and 2029 notes are not repaid or refinanced within 91 days before their maturity (Documentary Fact; basis CP-1 maturities and debt schedule). Third, liquidity is adequate at 2026-09-30 but the headline includes a tranche that matured on October 7, 2026: cash of USD 698 million plus availability of USD 953 million, of which USD 220 million of commitments matured, so availability would be USD 733 million if the tranche lapsed (Documentary Fact for the maturity, Analyst Interpretation for the scenario; basis CP-1 liquidity calculation, CP-1A F27). Fourth, settlement obligations are the dominant claim outside debt: recorded reserves include USD 205 million for North Carolina and USD 176 million for New Jersey on a net present value basis, and environmental remediation liabilities total USD 116 million current and USD 689 million non-current (Documentary Fact; basis CP-1 claims table, CP-1A F18, F19). Fifth, earnings are rotating from refrigerants to titanium dioxide: Q3 2026 segment Adjusted EBITDA was USD 136 million in refrigerants, USD 85 million in titanium and USD 24 million in advanced materials, against USD 194 million, USD 25 million and USD 14 million a year earlier (Documentary Fact; basis CP-1A F6). Sixth, issuer behaviour toward creditors is supportive on the documented actions (lower dividend, no repurchases, asset sale cash applied to debt), with no priming, uptiering or non-pro-rata exchange in the sources, while legal capacity cannot be assessed (Analyst Interpretation; basis CP-1A governance table, F24 to F26, F30).

### Key credit risks

| Risk | Mechanic | Credit implication | Severity |
| --- | --- | --- | --- |
| Legacy PFAS and environmental cash calls | Fixed annual settlement payments over 25 and 15 years, a consent decree penalty and drinking water programs are paid from cash that Adjusted EBITDA excludes, and unreserved matters remain reasonably possible but not estimable | Free cash flow after settlements, not Adjusted EBITDA, is the relevant coverage test; adverse developments would erode liquidity and leverage progress; cost sharing with DuPont and Corteva limits but does not remove the exposure | Critical |
| Refinancing of 2028 and 2029 debt | USD 780 million due in 2028 and USD 647 million in 2029 trigger the revolver springing maturity if not refinanced in the 91-day window | A failure to refinance on acceptable terms would remove revolver access at the time it is most needed; ratings of B1 with a stable outlook constrain market access | Material |
| Revolver tranche matured October 7, 2026 | The USD 220 million tranche was part of the USD 953 million availability, and extension or replacement is not stated | Post-quarter liquidity may be lower than the headline; a USD 733 million availability scenario results if it lapsed | Material |
| Earnings cyclicality and mix | Refrigerant earnings normalise after a regulatory channel fill, while titanium earnings depend on pricing and a concentrated customer base | A weak titanium year or further refrigerant decline would raise leverage; management guides fourth-quarter Adjusted EBITDA of USD 160 million to USD 185 million (attributed) | Material |
| Covenant headroom not verifiable | A maximum senior secured net leverage ratio of 2.00x applies to the revolver, the raised temporary level and the reported ratio are not printed, and the Credit Agreement definitions are not supplied | Headroom may be narrower or wider than management's statement of compliance implies | Material |
| Regulatory and litigation exposure from the audit committee review | Regulatory inquiries and private litigation may produce unquantified costs and indemnification advances | Unquantified cash and reputational costs; a monitoring item, not an adverse conclusion | Minor |
| Interest burden | New 7.875 percent notes and a term loan margin of 3.50 percent replaced lower-cost debt, so interest expense falls only slightly with lower principal | Interest cover stays near 3x on Adjusted EBITDA before settlement cash | Minor |

## Calculations

No new calculation is made. Every figure repeats a row of the financial base or the business-context register. Tie-outs of the figures used:

- Debt principal change: USD 3,872 million less USD 4,182 million equals negative USD 310 million (CP-1 debt schedule).
- Net leverage: USD 3,174 million of net debt over USD 747 million of LTM Adjusted EBITDA equals 4.25x; USD 3,512 million over USD 750 million equals 4.68x (CP-1 leverage table).
- Availability scenario: USD 780 million less USD 47 million of letters of credit equals USD 733 million (CP-1 liquidity calculation).
- Segment Q3 2026 Adjusted EBITDA: USD 136 million plus USD 85 million plus USD 24 million equals USD 245 million (CP-1A calculations).

## Gaps

| # | Gap | Why it matters | Affects | Severity | Action |
| --- | --- | --- | --- | --- | --- |
| 1 | Covenant ratio, the raised temporary level and Credit Agreement definitions are not supplied | Headroom cannot be calculated; it governs revolver access | Liquidity and covenant risk rows | High | Obtain the Credit Agreement and amendments; until then headroom is Not calculable |
| 2 | Cash interest paid is not printed for 2026 interim periods | Cash interest cover is measurable only for FY2024 and FY2025 | Interest burden | Medium | Use interest expense, net as a labelled substitute |
| 3 | The USD 220 million revolver tranche that matured on October 7, 2026 has no stated extension or replacement | Post-quarter liquidity is uncertain | Liquidity strength and risk | High | Treat as a subsequent event; no source after the cutoff is usable |
| 4 | Legal capacity (debt baskets, restricted payments, priming, collateral release) is Insufficient Information because the Credit Agreement and indentures are not supplied | Behaviour is assessed from actions only | Governance reading | High | Obtain the debt documents |
| 5 | Ownership and control rights are Insufficient Information; no holder table is in the sources | Alignment between owners and creditors cannot be assessed | Governance reading | Low | Obtain the proxy statement |
| 6 | Executed settlement documents are not supplied, and the USD 455 million North Carolina total is not stated as company share or all-party total | Obligation timing and acceleration terms rest on company summaries | Settlement risk | Medium | Treat the recorded reserve of USD 205 million as the company obligation |
| 7 | Nine-month 2025 Adjusted EBITDA differs between the release (USD 614 million) and the sum of 10-Q components (USD 619 million) | Trend precision of trailing earnings | Leverage trend | Medium | Quote both; the financial base states its basis |
| 8 | The business-context handoff judges this module READY_WITH_LIMITATIONS | Confidence cannot be High | Assessment confidence | Medium | Carry the limitations above |

## Next module

Run the evidence-trace validator (CP-5) next. It should open the locators behind the figures in this handoff, particularly the leverage and liquidity rows of the financial base, the settlement terms (New Jersey, North Carolina, 2026 Consent Decree), the revolver maturity and the segment Adjusted EBITDA comparison, and flag management-attributed items for separate treatment.
