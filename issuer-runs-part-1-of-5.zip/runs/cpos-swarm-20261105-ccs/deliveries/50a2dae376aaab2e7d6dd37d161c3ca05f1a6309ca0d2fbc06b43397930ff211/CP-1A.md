## Request

Module CP-1A (business and transaction context) for Century Communities, Inc. (ticker CCS, issuer id ccs), as of 2026-11-05 with cutoff 2026-11-05. Pathway: credit_snapshot, public case. Reporting currency USD; current period Q3 2026, prior period FY2025. Question: which transaction, business, ownership and operating facts matter most to a creditor of the consolidated registrant, and how do they transmit to credit risk? The perimeter is Century Communities, Inc. with its consolidated subsidiaries. The context names no sponsor, parent, borrower or guarantor, and it carries no ratings, quotes or deal terms; those fields are blank, not zero.

Each fact row is tagged Documentary Fact, Management Language, Analyst Interpretation or Insufficient Information. Amounts are shown as the source prints them (US$ thousands in statements, US$ millions in text); no new financial figure is introduced beyond those already in the financial base handoff, except simple shares shown in Calculations. Locators are written source page:N using the short names below.

## Sources

### Issuer sources relied on

| Source (exact name) | Short name | Pinned sha256 |
| --- | --- | --- |
| 10-K_2025-12-31_ccs-20251231x10k.htm.jsonl | 10-K | 40822bca77f3d1f280fa9bdb025667cff0a3cbada92f0367c2ce2aea0f14cd10 |
| 10-Q_2026-03-31_ccs-20260331x10q.htm.jsonl | Q1 10-Q | 6dbfc2b9b1702aabe0ae62a15ab79d805237cf407bb87b6f748285ee6819232c |
| 10-Q_2026-06-30_ccs-20260630x10q.htm.jsonl | Q2 10-Q | 7826d33d347b5ba4a0f0ded6692f553b2cb2eab216f48c0b48fab887a5e242a0 |
| 10-Q_2026-09-30_ccs-20260930x10q.htm.jsonl | Q3 10-Q | 5bb6ede8961747c92feb57cbf28091469edbccbe289914d1a5a3c7cff3b959d0 |
| EX-99.1_2026-04-22_ccs-20260422xex99_1.htm.jsonl | Q1 release | ef23de5e89dc27836c0aa67c681d5f651593a95499849c764478ef4002ab9849 |
| EX-99.1_2026-07-22_ccs-20260722xex99_1.htm.jsonl | Q2 release | 8fa7d8813bf620e387c89f24634e9692af83d752a4591b259b033efbe214d3eb |
| EX-99.1_2026-10-28_ccs-20261028xex99_1.htm.jsonl | Q3 release | 1a2c31ec21a3900623ca510eba56234f123a5a1fb09a2e417f1dc9e6e8c01b85 |

Run settings, not issuer evidence: context, sha256 3f4bc378facbce0f1396d451dfff0e16ea0431cd8d227bb7281acea631c866f1.

### Handoffs relied on

| Module | Pinned sha256 | Use |
| --- | --- | --- |
| CP-0 | c251b67407b3993cf09de40f1b6adea510b7bad7bb25a2815575a608bae15041 | Source readiness: no executed debt documents, no ratings or market inputs, releases are management documents, recast 2025 comparatives. |
| CP-1 | deba02fbf78513edd8848cc803441953597a0770ce39b23fafaf06d522a04d21 | Financial base: leverage, liquidity, capital structure, covenant and acquisition-funding gaps. Figures below that repeat it are labelled as from the financial base. |

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| Century Communities is a publicly held, geographically spread US homebuilder with a captive mortgage arm. Demand pressure, rising incentives and a debt-funded acquisition drive the credit story, and no sponsor or related-party leakage is documented. | Medium | No debt agreements, ratings or proxy material are in the sources, so control rights and creditor protections cannot be assessed. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Third-quarter 2026 deliveries were 2,442 homes at an average price of $345.0 thousand, with price down 10.2% on higher incentives, per the company. | Margin and cash conversion depend on incentives and mortgage rates. | High |
| Homebuilding is the revenue base, at 95.8% of nine-month 2026 revenue, across five regional segments, with Century Complete the largest at 25.0%. | Geographic spread limits regional concentration, though demand drivers are shared. | High |
| The October 7, 2026 acquisition of HistoryMaker Homes, for about $160.2 million cash, adds 29 Texas communities and is not in reported balance sheets. | Leverage and liquidity after the deal are not yet visible. | High |
| The Executive Chairman and the Chief Executive Officer, who are brothers, held 13.9% of shares at December 31, 2025; the company says repurchases use cash and the revolver. | Insider alignment is documented; capital returns continued as borrowing rose. | Medium |

### Business and transaction view

Century Communities, Inc. is a US single-family homebuilder that operates in 16 states and over 45 markets under two brands, Century Communities and Century Complete, with a captive mortgage, title, insurance and escrow business and a small multi-family rental development segment in Colorado. Revenue is almost wholly home sales, which depend on affordability, mortgage rates and the use of incentives; the company itself ties its latest price decline to incentives and its lower deliveries to slower absorption. The transaction that matters most to a creditor is the October 7, 2026 purchase of the assets of HistoryMaker Homes in Dallas for about $160.2 million of initial cash, which is a post-balance-sheet event that adds communities and deliveries but also a cash call whose funding is not stated, coming days after the September 30, 2026 revolver amendment that raised commitments to $1.2 billion. Ownership is public with no sponsor; the Executive Chairman and Chief Executive Officer, who are brothers, hold a documented 13.9% stake and have employment agreements with change-of-control severance. No dividend recapitalisation, related-party leakage or creditor-adverse transaction is documented in the sources, but the proxy material and debt agreements that would show control rights, baskets and permitted payments are not supplied, so legal capacity is not assessed. The facts that move the credit most are demand and margin resilience, funding of the acquisition and shareholder returns while operating cash flow is negative, and the structural subordination of the unsecured notes to secured construction and warehouse debt.

### Company and operating model

| Area | Fact | Category | Locator | Risk mechanic and credit implication |
| --- | --- | --- | --- | --- |
| Core business | Development, design, construction, marketing and sale of single-family attached and detached homes in 16 states; in many projects the company also entitles and develops the underlying land. Over 45 markets. | Documentary Fact | 10-K page:5; Q3 10-Q page:8, page:31 | Land development raises capital intensity and inventory exposure; value is realized only at closing. |
| Brands and buyers | Century Communities brand serves entry-level, first and second time move-up and lifestyle buyers with limited personalization; Century Complete targets entry-level buyers, sells through retail studios, centralized locations and the internet, and offers no option or upgrade selections. | Documentary Fact | Q3 10-Q page:8 | Entry-level concentration makes demand sensitive to affordability and mortgage rates. |
| Segments | Five reportable homebuilding segments (West, Mountain, Texas, Southeast, Century Complete), plus Financial Services, Century Living and a non-operating Corporate segment. | Documentary Fact | Q3 10-Q page:8, page:9 | Diversified regional exposure; each region is a separate operating segment. |
| Revenue mix, nine months 2026 | Total revenues 2,581.367 (US$m): West 493.990, Mountain 538.799, Texas 417.153, Southeast 416.327, Century Complete 646.107, Financial Services 68.991. Shares 19.1%, 20.9%, 16.2%, 16.1%, 25.0% and 2.7%. | Analyst Interpretation (shares derived from printed amounts) | Q3 10-Q page:9, page:10 | Century Complete is the largest segment and is a low-price, no-option model; no region exceeds a quarter of revenue. |
| Revenue model | Home sales revenues 2,474.127 of total revenues 2,581.367 in nine months 2026, which is 95.8%; land sales and other 38.249; Financial Services revenues 68.991. | Analyst Interpretation (share derived) | Q3 10-Q page:2, page:3 | Earnings are driven by closings; land sales are small and lumpy, so revenue visibility rests on backlog. |
| Volume and price, Q3 2026 | New homes delivered 2,442 against 2,486; average sales price of new homes delivered 345.0 thousand against 384.2 thousand; net new home contracts 2,284 against 2,386. Nine months: 6,961 against 7,357 deliveries, average price 355.4 thousand against 382.7 thousand, contracts 7,278 against 7,624. | Documentary Fact | Q3 10-Q page:37 | Lower price and volume reduce operating leverage on a partly fixed cost base. |
| Management explanation | Deliveries decreased 1.8% and 5.4%, primarily due to slower absorption rates from lower demand; average price decreased 10.2% and 7.1%, primarily due to increased use of incentives. Mortgage rates rose further in Q3 2026; adjustable-rate mortgages were nearly 35% of mortgages originated by principal in Q3 2026, against less than 5% in Q1 2025. | Management Language | Q3 10-Q page:32, page:35 | Incentives and rate buydowns transfer margin to buyers and raise cancellation and refinancing risk if rates rise after closing. |
| Backlog and communities | Backlog 1,106 homes with value 413,956 (US$ thousands) at 2026-09-30 against 1,117 homes and 416,924; selling communities at period end 343 against 321. | Documentary Fact | Q3 10-Q page:37 | Backlog of about one quarter of deliveries gives limited forward visibility; more communities add capacity but also inventory. |
| Margin and cost structure | Homebuilding gross margin 15.0% in Q3 2026 against 17.9%, including impairment of 19,605 (US$ thousands); selling, general and administrative expense 14.1% of home sales revenue against 12.6%, which the company attributes to decreased revenue on a partially fixed cost base. | Documentary Fact; attribution is Management Language | Q3 10-Q page:37, page:45, page:46 | Operating leverage works against the company when volume and price fall. |
| Land strategy | 60,969 lots owned and controlled at 2026-09-30, of which 33,473 owned and 27,496 controlled, against 60,916 at 2025-12-31; land bought for cash through bulk purchases or option contracts, with obligations under options generally limited to forfeiting deposits of 84.6 (US$m, 77.5 non-refundable). | Documentary Fact | Q3 10-Q page:47, page:56; 10-K page:8 | Option-heavy control (45.1% of lots, derived) lowers owned-land risk but the company still expects to perform on the majority of contracts within 24 months. |
| Construction and product | Construction takes three to four months; about 96% of homes delivered in the first nine months of 2026 were priced below FHA-insured mortgage limits and about 98% were built as move-in-ready homes. | Documentary Fact | Q3 10-Q page:31, page:34 | Short cycle and spec inventory shorten the cash cycle but expose the company to carrying finished homes in a weak market. |
| Working capital and investment | Inventories 3,744,023 against 3,361,158 at 2025-12-31 (US$ thousands); net cash used in operating activities 267,475 in nine months 2026; purchases of property and equipment 21,647. | Documentary Fact | Q3 10-Q page:2, page:3 | Inventory build consumes cash ahead of closings; capital spending is small, so cash flow is driven by working capital. |
| Seasonality | Home starts, construction costs and cash outflows are historically highest in the second and third quarters; most cash receipts from deliveries occur in the second half. | Documentary Fact | 10-K page:11 | Cash needs peak in the second and third quarters, so a year-end balance sheet may not show the intra-year trough in liquidity. |
| Financial Services | Inspire Home Loans Inc. originates mortgages for the company's homebuyers and generally sells loans within 30 days, financing them through repurchase facilities; loans held for sale at fair value 186.5 (US$m); net gains on sale of loans 13.1 in Q3 2026; segment income before tax 6.2 in Q3 2026. | Documentary Fact | Q3 10-Q page:10, page:11, page:35, page:36 | A captive lender supports sales but adds a funding line that is non-guaranteed by the parent and exposes the company to loan repurchase and rate-lock risk. |
| Century Living | Multi-family rental development in Colorado, reported separately from Q1 2025; strategy since Q1 2025 is predominantly to dispose of properties shortly after lease stabilization; multi-family rental properties inventory 241.704 (US$m) at 2026-09-30; one 300-unit property was sold in 2025. | Documentary Fact | 10-K page:66, page:81; Q3 10-Q page:12 | Non-core, construction-loan-funded asset class whose exit timing and pricing are not disclosed. |
| Tax and policy | Section 45L tax credits are disallowed for homes delivered after June 30, 2026 under H.R.1; the 21st Century ROAD to Housing Act became law in July 2026, with an uncertain impact. | Documentary Fact | Q3 10-Q page:18, page:47, page:72 | A loss of tax credit benefit raises the effective tax rate on 2026 second-half deliveries. |

### Company profile

| Attribute | Value | Category | Locator |
| --- | --- | --- | --- |
| Legal name and form | Century Communities, Inc., a Delaware corporation; Commission File Number 001-36491 | Documentary Fact | Q3 10-Q page:1 |
| Headquarters | Greenwood Village, Colorado | Documentary Fact | Q3 10-Q page:1 |
| Listing | Common stock on the New York Stock Exchange under CCS; initial public offering in 2014 | Documentary Fact | Q3 10-Q page:1; 10-K page:5 |
| Sector and country | Operative Builders, United States (from the run context, not issuer evidence) | Documentary Fact (context) | context |
| Fiscal year end and filer status | December 31; large accelerated filer; auditor Ernst & Young LLP since 2013 | Documentary Fact | 10-K page:1, page:106 |
| Shares outstanding | 28,264,817 at 2026-09-30 against 29,050,515 at 2025-12-31 | Documentary Fact | Q3 10-Q page:2 |
| Ownership | Public; no sponsor, controlling parent or private-equity owner is named in the sources | Documentary Fact (absence in sources) | 10-K; Q3 10-Q |
| Insider holdings | Executive Chairman Dale Francescon and Chief Executive Officer Robert Francescon, who are brothers, beneficially owned 4,105,940 shares including 395,546 issuable on vesting of performance share units, which is 13.9% of shares outstanding at 2025-12-31 | Documentary Fact | 10-K page:48 |
| Management structure | Executive Chairman and Chief Executive Officer are Co-Principal Executive Officers and, together, the chief operating decision makers; Chief Financial Officer is Scott Dixon | Documentary Fact | Q3 10-Q page:9; 10-K page:104; Q3 release page:3 |
| Debt group | Senior notes issued by Century Communities, Inc. and guaranteed by substantially all wholly-owned operating subsidiaries; Financial Services subsidiaries are Non-Guarantors | Documentary Fact | Q3 10-Q page:49 |
| Dividend and repurchase policy | Quarterly cash dividend paid since 2021, 0.32 per share in each of the first three quarters of 2026, a 10% increase from 0.29; repurchase program announced July 24, 2024 for up to 4.5 million shares, with 1,294,784 remaining at 2026-09-30 | Documentary Fact | 10-K page:47, page:55; Q3 10-Q page:36, page:73 |
| Ratings | Not supplied: the context carries no ratings and the filings give none | Insufficient Information | context |
| Employment agreements | Agreements with the Executive Chairman and the Chief Executive Officer may require significant severance on a change in control | Documentary Fact | 10-K page:47 |

### Transaction summary and new debt issues

The transaction of record after the balance sheet date is the acquisition, completed on October 7, 2026, of substantially all of the assets and certain liabilities of HMH Lifestyles, L.P., doing business as HistoryMaker Homes, a Dallas-area homebuilder, for initial cash consideration of approximately $160.2 million, subject to customary holdbacks and post-closing adjustments (Q3 10-Q page:7, page:34). It adds 29 active communities to the Texas segment (Q3 10-Q page:7). The company says it will increase its Dallas division's active communities from 12 to 41 as of September 30, 2026 and triple trailing-twelve-month deliveries from 211 to 669 homes, and its outlook includes 100 deliveries from the acquired business in the fourth quarter (Q3 release page:1, page:3); these are Management Language, not filed fact. The company also states it will keep a land relationship with HistoryMaker's sister land development company (Q3 release page:2). Because the deal closed after September 30, 2026, the acquired assets and assumed liabilities are not in the balance sheet, purchase accounting is incomplete, and the filing does not state how the cash consideration is funded. This is a subsequent event and it is kept out of every September 30, 2026 figure. Parties other than the target, any sponsor, a use-of-proceeds statement, and the effect on liquidity are Not supplied; the missing funding statement matters because revolver borrowings already stood at $456.0 million and nine-month operating cash flow was negative (financial base handoff).

New debt and financing events are as follows. On September 30, 2026 the company signed the First Amendment to its Credit Agreement dated November 1, 2024 (administrative agent U.S. Bank National Association): commitments rose from $1.0 billion to $1.2 billion, maturity for participating extending lenders moved to November 1, 2030 with $100.0 million still maturing November 1, 2028, new lenders were added, certain financial covenants were revised, and the 0.10% credit spread adjustment was eliminated (Q3 10-Q page:16). The revised covenant terms are not supplied. In September 2025 the company issued $500.0 million of 6.625% senior notes due September 2033 and extinguished $500.0 million of 6.750% senior notes due 2027 at 100% of principal, for $511.4 million including accrued interest, with a loss on extinguishment of $1.4 million (10-K page:75). Earlier, the revolver was raised from $900.0 million to $1.0 billion on April 22, 2025 (10-K page:77). No new bond issue after September 2025 appears in the sources. The mortgage repurchase facilities, construction loans and revolver are described in the financial base handoff.

### Ownership, governance and capital allocation

| Topic | Evidence | Category | Locator | Mechanic and implication |
| --- | --- | --- | --- | --- |
| Control | Insiders hold 13.9% and the company states that they have significant influence and that conflicts of interest may arise; charter and Delaware law provisions may discourage a change of control. Control rights beyond this, such as voting classes, are Not supplied. | Documentary Fact; control rights Insufficient Information | 10-K page:47, page:48 | Concentrated influence is a governance risk but no creditor-adverse action is documented. |
| Capital returns | In nine months 2026 the company paid dividends of 27.519 and repurchased shares for 71.198 (US$m), while net cash used in operating activities was 267.475; the company states it finances repurchases through available cash and the revolver. | Documentary Fact | Q3 10-Q page:3, page:4, page:62 | Shareholder returns were paid while borrowing rose; they are discretionary and can be cut, but have not been. |
| Dividend recapitalisation or related-party leakage | None documented in the sources. The proxy statement, which would hold related-party detail, is not supplied. | Insufficient Information | 10-K page:2, page:98 | Absence in these sources is not evidence of absence. |
| Behaviour category | Documented actions are acquisitions, share repurchases and dividends funded in part by bank debt, with transparent quarterly reporting. | Analyst Interpretation: Neutral or Mixed | Q3 10-Q page:62, page:7 | Shareholder-friendly spending beside rising leverage; no priming, uptiering, drop-down or collateral release is reported. |
| Legal capacity | The Credit Agreement limits liens, debt, dividends, redemption of stock, investments and affiliate transactions; the indentures restrict future secured debt. The tests and baskets are not supplied. | Documentary Fact for the existence of limits; baskets Insufficient Information | Q3 10-Q page:14, page:17 | Capacity for further payments or secured debt cannot be sized; willingness and feasibility are separate and rest on reported liquidity. |

### Timeline

| Date | Event | Category | Locator |
| --- | --- | --- | --- |
| 2014 | Initial public offering | Documentary Fact | 10-K page:5 |
| 2021 | Quarterly cash dividend begins; 3.875% senior notes due 2029 issued under an indenture dated August 23, 2021 | Documentary Fact | 10-K page:47, page:76 |
| 2024-01-22 | Acquisition of Landmark Homes of Tennessee, Inc. (Nashville, six active communities) for about $33.4 million cash | Documentary Fact | 10-K page:121 |
| 2024-07-24 | Share repurchase program announced for up to 4.5 million shares | Documentary Fact | 10-K page:55 |
| 2024-07-31 | Acquisition of Anglia Homes LP (Houston, 26 active communities) for about $127.0 million cash | Documentary Fact | 10-K page:121 |
| 2024-11-01 | Credit Agreement dated, with U.S. Bank National Association as administrative agent | Documentary Fact | 10-K page:101 |
| 2025-01 to 2025-03 | Century Living strategy changed to disposal after lease stabilization; segment reported separately from Q1 2025 | Documentary Fact | 10-K page:6, page:66 |
| 2025-04-22 | Revolver increased from $900.0 million to $1.0 billion | Documentary Fact | 10-K page:77 |
| 2025 | Mortgage servicing rights portfolio sold for cash proceeds of $46.9 million; one 300-unit multi-family property sold | Documentary Fact | 10-K page:66, page:81, page:108 |
| 2025-09 | 6.625% senior notes due 2033 issued; 6.750% senior notes due 2027 extinguished | Documentary Fact | 10-K page:75, page:100 |
| 2026-07 | 21st Century ROAD to Housing Act became law | Documentary Fact | Q3 10-Q page:72 |
| 2026-09-30 | First Amendment to Credit Agreement signed on the last day of Q3 2026 | Documentary Fact | Q3 10-Q page:16 |
| 2026-10-07 | HistoryMaker Homes acquisition closed (Subsequent event) | Documentary Fact | Q3 10-Q page:7 |
| Rating events | Not supplied | Insufficient Information | context |

### Conflicts and logged differences

- Century Complete geography: the 10-K lists Century Complete states as "Alabama, Arizona, Florida, Georgia, Indiana, Kentucky, Michigan, North Carolina, and South Carolina" (10-K page:6), while the Q3 10-Q lists "Alabama, Arizona, Florida, Georgia, Indiana, Kentucky, Michigan, Nevada, North Carolina, and South Carolina" and states operations in 10 states (Q3 10-Q page:8). Logged, not reconciled; the sources do not say whether Nevada was added in 2026 or omitted earlier. Effect: state-level concentration for the Century Complete segment cannot be fixed.
- Cash definition: the Q1 release describes "$89.8 million of cash" while later releases say cash including cash equivalents and cash held in escrow (Q1 release page:2; Q2 release page:2). The Q1 10-Q balance sheet shows 78,182 and 11,621 (US$ thousands) (Q1 10-Q page:2). Noted in the source-readiness handoff; the filing governs.
- No other conflict was found between the releases and the Forms 10-Q on the figures compared (liquidity, ratios, deliveries).

### Credit translations

- Revenue durability and margin. Evidence: Q3 2026 average price down from 384.2 to 345.0 thousand and gross margin 15.0% against 17.9%, with the company citing incentives and slower absorption (Q3 10-Q page:35, page:37). Mechanic: price cuts fall straight to margin on a cost base that is partly fixed (selling, general and administrative expense rose to 14.1% of home sales revenue). Implication: earnings and cash flow are exposed to further rate rises; the leverage figures in the financial base already reflect lower earnings. Countering evidence: adjusted homebuilding gross margin of 19.3% and a stated backlog of 1,106 homes (Q3 10-Q page:37).
- Cash conversion and liquidity. Evidence: operating cash outflow of 267.475 in nine months 2026 and inventory up to 3,744.023 (Q3 10-Q page:2, page:3). Mechanic: inventory is funded by the revolver, whose availability is subject to covenants that are not supplied. Implication: liquidity is adequate on reported figures but sensitive to the unpublished covenant tests and to the HistoryMaker cash call.
- Acquisition and capital allocation. Evidence: repurchases that the company says it finances with cash and the revolver, and a 160.2 million acquisition seven days after a covenant amendment (Q3 10-Q page:7, page:16, page:62). Mechanic: external growth and returns compete with deleveraging. Implication: monitoring posture should follow post-acquisition leverage and any change in repurchase pace. The company has not shown a deleveraging plan in the sources (Insufficient Information).
- Structural position. Evidence: unsecured notes guaranteed by operating subsidiaries and effectively subordinated to secured debt of the guarantors; Financial Services subsidiaries do not guarantee (Q3 10-Q page:49). Mechanic: warehouse and construction lenders have first claim on their collateral; recovery prospects for unsecured claims depend on inventory value realization, which this handoff does not conclude.
- Concentration and sponsor alignment. Evidence: no customer concentration is given; the insider stake of 13.9% is documented (10-K page:48). Implication: owner-operator alignment is present; no sponsor.

### Consumer readiness

| Consumer | Readiness | Take from this handoff | Gap and action |
| --- | --- | --- | --- |
| CP-2 | READY_WITH_LIMITATIONS | Business model, demand and margin drivers, acquisition and capital allocation behaviour, and structure. | Covenants, ratings and acquisition funding are not supplied; state them as gaps in the synthesis. |
| CP-5 | READY_WITH_LIMITATIONS | Fact categories and locators for tracing; the logged Century Complete state difference. | Check management claims against filings, especially the Dallas communities and deliveries claims, which come only from the release. |

## Calculations

| Item | Formula and inputs | Result |
| --- | --- | --- |
| Segment revenue shares, nine months 2026 | Segment revenue / total revenues 2,581.367: 493.990; 538.799; 417.153; 416.327; 646.107; 68.991 | 19.1%; 20.9%; 16.2%; 16.1%; 25.0%; 2.7% |
| Home sales share of revenue | 2,474.127 / 2,581.367 | 95.8% |
| Controlled share of lots | 27,496 / 60,969 (owned 33,473 / 60,969 = 54.9%) | 45.1% |
| Dallas communities added | 41 − 12, from the release | 29, equal to the 29 stated in the Form 10-Q |
| Percentage changes quoted | Price 345.0 / 384.2 − 1 and 355.4 / 382.7 − 1 | −10.2%; −7.1%, equal to the percentages the company prints |

No other calculation was made; financial metrics are as reported in the financial base handoff.

## Gaps

| Gap | Severity | Why it matters | Action |
| --- | --- | --- | --- |
| Credit Agreement, First Amendment, Incremental Joinder and indentures not supplied | High | Control rights, covenants, baskets for dividends, buybacks and secured debt cannot be assessed. | Obtain the executed agreements. |
| Funding source and purchase accounting for HistoryMaker Homes; no pro forma figures | Medium | Post-acquisition leverage and liquidity. | Use Q4 2026 filings. |
| No proxy statement or Item 13 detail; related-party transactions and control rights not supplied | Medium | Governance assessment rests on risk-factor text only. | Obtain the proxy statement. |
| No ratings, market quotes or deal terms in the context | Low | No external credit view. | Supply if needed. |
| Debt schedule by facility maturity, covenant certificate and add-back bridge not supplied | Medium | Monitoring inputs for CP-2 and CP-5. | Request from the company or filings. |
| Century Complete state list differs between the 10-K and Q3 10-Q | Low | Geographic concentration. | Confirm in a later filing. |
| Management claims on Dallas communities and deliveries appear only in the Q3 release | Low | Not filed fact. | Treat as Management Language. |
| Customer concentration, supplier concentration and employee counts not extracted | Low | Coverage of the operating model. | Not required for the snapshot. |

## Next module

CP-2. It should build the fundamental credit synthesis from this handoff's business and structure rows and the financial base handoff figures, carry the covenant, acquisition-funding and governance gaps, and keep management claims labelled as such. CP-5 should trace the Dallas claims and the Century Complete state difference to their sources.
