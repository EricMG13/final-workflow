## Request

Churchill Downs Incorporated (context name: Churchill Downs Inc, issuer id chdn, ticker CHDN), as of 2026-11-05, evidence cutoff 2026-11-05. Pathway: credit_snapshot. Module: financial base (reported statements, definitions, debt register, calculations and the evidence read-through for later modules). Reporting currency per context: USD; the sources print USD millions, with one decimal in the FY2025 annual report and whole millions in the 2026 quarterly reports and releases. Current period per context: q3-2026 (quarter and nine months ended September 30, 2026); prior period: fy-2025 (year ended December 31, 2025). Perimeter: Churchill Downs Incorporated consolidated, the single registrant in every supplied filing. The context names no borrower, parent or guarantor; guarantor and restricted-group perimeters are therefore not supplied.

Consumers named by the run: CP-1A, CP-2 and CP-5. Nothing dated after 2026-11-05 is used as fact. Events after the September 30, 2026 balance sheet date are labelled subsequent events.

## Sources

### Issuer sources relied on

| Source (exact name) | sha256 | Used for |
| --- | --- | --- |
| 10-K_2025-12-31_chdn-20251231.htm.jsonl | 791973148b4d2826daf79f6e0ecd898b524ba905f6928d4b1fa58e745cfa58e6 | FY2025 statements (pages 77-79), Adjusted EBITDA reconciliation (pages 64-65), debt note (pages 108-113), covenant table (pages 69-70 and 109-110) |
| 10-Q_2026-03-31_chdn-20260331.htm.jsonl | 3d979cd66a5fd3c2d7447c580ef853c0c5a7867f89e2461cd6b817f9d370c641 | Q1 2026 statements (pages 2-4), subsequent event (page:20) |
| 10-Q_2026-06-30_chdn-20260630.htm.jsonl | 4eca3b557126cb1eb2e1c2c8c7ed3827f930ac9e114b1865fffc6dfad00959f1 | Six-month 2026 cash flow and cash-paid lines (page:4) |
| 10-Q_2026-09-30_chdn-20260930.htm.jsonl | 7fff97ce9977f2b2156048dbf8e8996f9058aaa73d34344c7b548ba853ea7229 | Q3 and nine-month 2026 statements (pages 2-5), notes (pages 13-28), MD&A (pages 33-49) |
| EX-99.1_2026-04-22_ex991pressrelease04-22x26.htm.jsonl | bbdcb62a4845e34e0fdd4338c48e18f02c4eceb2b21c6ecefed1bd7b13c21521 | Q1 2026 management claims (page:1) |
| EX-99.1_2026-07-29_ex991pressrelease07-29x26.htm.jsonl | 85b22b14ac2149df8072938d3dbc3e8d85579a1e2355ea8fce27bcd305c203d4 | Q2 2026 management claims (page:1) |
| EX-99.1_2026-10-28_ex991pressrelease10-28x26.htm.jsonl | ecea350f3f38425e2e2322d4e7d883986fb7f745d76fde798f61a64ba8bc0e4f | Q3 2026 management claims and capital events (pages 1-4) |

The context file (sha256 7c4f52e55b5e23c0fba0c45fbf91c794297fbfceecf1db4e9e336166f978aca8) holds run settings only and is not issuer evidence.

### Supplied handoffs

| Module | sha256 | Use |
| --- | --- | --- |
| CP-0 | 6a999e93b94cb197d54e29dcbbccb60dd67263d86ef14e45c08771399f8a861b | Source readiness: consolidated perimeter only; covenant figures only at December 31, 2025; executed credit agreement, amendments and indentures not supplied; October 19, 2026 redemption is a subsequent event; one-decimal annual versus whole-million quarterly units. Each limitation is carried into this handoff and none is contradicted by it. |

CP-0 stated that no stand-alone Q2 or Q3 cash-paid lines exist and that net bank leverage is undefined; both points are confirmed below. One refinement of CP-0: it said cash-paid interest is cumulative only, and this is confirmed (three, six and nine months).

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| Reported leverage fell over 2026 as revolver borrowings were repaid, and cash flow comfortably covers cash interest and capital spending. Near-term pressure comes from the 2028 notes and from what Adjusted EBITDA includes. | Medium | Covenant headroom, guarantor perimeter and the definition of management net bank leverage are not supplied, and last-twelve-months figures mix one-decimal and whole-million sources. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Total debt at September 30, 2026 was 4,748 million against 5,155 million at year-end 2025, as revolver and old term loan repayments exceeded the new 500 million term loan. | Gross leverage on last-twelve-months Adjusted EBITDA moved from 4.28x to 3.81x. | High |
| At September 30, 2026, 65.3% of debt was unsecured senior notes and 34.7% was secured under the credit agreement. | Secured lenders rank ahead of 3,100 million of notes, so note recoveries depend on value left after secured claims. | Medium |
| The 600 million 2027 notes were redeemed on October 19, 2026 using the revolver, which moves the maturity from 2027 to the revolver's 2031 term. | Revolver availability falls to about 511 million on an illustrative basis, and the next note maturity is the 700 million due January 2028. | Medium |
| Revolver and term loan A maturity springs earlier if notes are not refinanced at least 91 days before their maturity. | The 2028 notes set a test date of about October 2027, which ties bank maturity to note refinancing. | Medium |
| Adjusted EBITDA includes the issuer's share of equity affiliates' EBITDA, 143 million in nine months 2026 against 106 million of distributions received. | Part of the earnings base is not cash to the issuer, which lowers true cash coverage. | Medium |

### Financial base view

The financial base is usable for CP-1A, CP-2 and CP-5 on the consolidated Churchill Downs Incorporated perimeter. Facility-level debt, the Adjusted EBITDA reconciliation for FY2025 and nine months 2026, cash flow and cash-paid interest and tax are printed in filed statements. On those figures, total debt at September 30, 2026 was 4,748 million and unrestricted cash 167 million. Last-twelve-months Adjusted EBITDA computed here is 1,245.3 million, giving 3.81x gross and 3.68x net of unrestricted cash. That compares with 4.28x gross and 4.11x net at year-end 2025 on the same method, so leverage fell materially over nine months. The reduction is real in principal terms but involves three pieces that a reader must keep apart: repaid revolver and term loan B-1 borrowings, a new term loan B, and a subsequent-event shift of 600 million of note debt onto the revolver. The view is restricted in three respects: covenant levels are available only at December 31, 2025; the governing legal documents are not in the pack; and the last-twelve-months build mixes sources printed to one decimal (FY2025) with whole-million sources. No restriction blocks the downstream modules.

### Chart data: leverage

| Period | Total debt / EBITDA | Net debt / EBITDA | Reporting unit | Basis and limitation |
| --- | --- | --- | --- | --- |
| Dec 31, 2025 | 4.28 | 4.11 | x | Total debt 5,155.1 (10-K MD&A) over FY2025 Adjusted EBITDA 1,205.3; net of unrestricted cash 200.6. Company Adjusted EBITDA, not covenant EBITDA |
| Mar 31, 2026 | 4.07 | 3.90 | x | Total debt 4,951 over LTM Adjusted EBITDA 1,217.3 (FY2025 plus Q1 2026 257 less Q1 2025 245); net of unrestricted cash 200. Mixed one-decimal and whole-million inputs |
| Jun 30, 2026 | 3.86 | 3.70 | x | Total debt 4,795 over LTM Adjusted EBITDA 1,243.3 (FY2025 plus 734 less 696 for six months); net of unrestricted cash 196. Mixed units |
| Sep 30, 2026 | 3.81 | 3.68 | x | Total debt 4,748 over LTM Adjusted EBITDA 1,245.3; net of unrestricted cash 167. The October 19, 2026 redemption of the 2027 notes with revolver borrowings does not change total debt |

### Chart data: interest cover

| Period | EBITDA / cash interest | Reporting unit | Basis and limitation |
| --- | --- | --- | --- |
| FY2025 | 4.09 | x | Adjusted EBITDA 1,205.3 over cash paid for interest 294.5 |
| LTM Mar 31, 2026 | 4.16 | x | Adjusted EBITDA 1,217.3 over LTM cash interest 292.5 (294.5 plus 43 less 45) |
| LTM Jun 30, 2026 | 4.31 | x | Adjusted EBITDA 1,243.3 over LTM cash interest 288.5 (294.5 plus 139 less 145) |
| LTM Sep 30, 2026 | 4.54 | x | Adjusted EBITDA 1,245.3 over LTM cash interest 274.5 (294.5 plus 173 less 193). Not the covenant interest coverage ratio, which was 3.9 at December 31, 2025 and is not supplied later |

### Chart data: liquidity

| Period | Cash | Undrawn committed facilities | Reporting unit | Basis and limitation |
| --- | --- | --- | --- | --- |
| Dec 31, 2025 | 200.6 | 534.8 | US$m | Unrestricted cash and cash equivalents; revolver availability after 8.2 of letters of credit as printed in the 10-K. Restricted cash of 87.9 excluded |
| Mar 31, 2026 | 200 | 722 | US$m | Revolver availability after 8 of letters of credit as printed. Restricted cash of 91 excluded |
| Jun 30, 2026 | 196 | 861 | US$m | Revolver availability after 10 of letters of credit as printed. Restricted cash of 99 excluded |
| Sep 30, 2026 | 167 | 1111 | US$m | Computed 1,200 commitment less 79 drawn less 10 letters of credit; the filing prints 1.1 billion. Restricted cash of 92 excluded. Before the October 19, 2026 redemption funded by the revolver |

### Chart data: debt maturities

| Period | Debt maturing | Reporting unit | Basis and limitation |
| --- | --- | --- | --- |
| 2027 | 600 | US$m | 2027 Senior Notes due April 1, 2027, principal at September 30, 2026; redeemed October 19, 2026 (subsequent event). Scheduled term loan amortization is excluded in every year |
| 2028 | 700 | US$m | 2028 Senior Notes due January 15, 2028 |
| 2029 | 0 | US$m | No instrument in the September 30, 2026 debt register matures in 2029 |
| 2030 | 1200 | US$m | 2030 Senior Notes due April 1, 2030 |
| 2031 | 1748 | US$m | 2031 Senior Notes 600 (May 1, 2031) plus Term Loan A 1,069 and revolver drawings 79 (September 2031, subject to springing maturity) |
| 2032 | 0 | US$m | No instrument in the September 30, 2026 debt register matures in 2032 |
| 2033 | 500 | US$m | Term Loan B due September 25, 2033, principal before amortization |

### Financials and credit metrics

| Metric (USD millions unless stated) | FY2025 | 9M 2025 | 9M 2026 | LTM Sep 30, 2026 | Basis and locator |
| --- | --- | --- | --- | --- | --- |
| Net revenue | 2,925.9 | 2,260 | 2,339 | 3,004.9 | 10-K p77; Q3 10-Q p2; LTM computed |
| Adjusted EBITDA | 1,205.3 | 958 | 998 | 1,245.3 | 10-K p65; Q3 10-Q p41; LTM computed |
| Net income attributable to the issuer | 383.0 | 332 | 404 | 455.0 | 10-K p77; Q3 10-Q p2; LTM computed |
| Interest expense, net | 297.7 | 222 | 211 | 286.7 | Income statements; LTM computed |
| Cash paid for interest | 294.5 | 193 | 173 | 274.5 | 10-K p79; Q3 10-Q p4; LTM computed |
| Net cash provided by operating activities | 769.8 | 674 | 660 | 755.8 | Cash flow statements; LTM computed |
| Capital expenditures (maintenance plus project) | 274.9 | 225 | 176 | 225.9 | Cash flow statements; Q3 10-Q p27 |
| Free cash flow before dividends and buybacks | 494.9 | 449 | 484 | 529.9 | Operating cash flow less capital expenditures; computed |
| Total debt (period end) | 5,155.1 | not applicable | 4,748 | 4,748 | 10-K MD&A; Q3 10-Q p13 |
| Unrestricted cash (period end) | 200.6 | not applicable | 167 | 167 | Balance sheets |
| Total debt / Adjusted EBITDA (x) | 4.28 | not applicable | not applicable | 3.81 | Computed |
| Net debt / Adjusted EBITDA (x) | 4.11 | not applicable | not applicable | 3.68 | Computed |
| Adjusted EBITDA / cash interest (x) | 4.09 | not applicable | not applicable | 4.54 | Computed |

### Reported statement base

#### Income statement, reported (USD millions)

| Line | FY2025 (10-K p77) | 9M 2025 (10-Q Q3 p2) | 9M 2026 (10-Q Q3 p2) | Q1 2026 (10-Q Q1 p2) | Q3 2026 (10-Q Q3 p2) | Q3 2025 (10-Q Q3 p2) |
| --- | --- | --- | --- | --- | --- | --- |
| Total net revenue | 2,925.9 | 2,260 | 2,339 | 663 | 696 | 683 |
| Operating income | 683.8 | 560 | 643 | 143 | 143 | 98 |
| Interest expense, net | (297.7) | (222) | (211) | (72) | (69) | (75) |
| Equity in income of unconsolidated affiliates | 139.4 | 105 | 115 | 36 | 38 | 35 |
| Income before income taxes | 532.4 | 449 | 552 | 113 | 111 | 61 |
| Income tax provision | (146.9) | (115) | (147) | (30) | (31) | (22) |
| Net income | 385.5 | 334 | 405 | 83 | 80 | 39 |
| Net income attributable to Churchill Downs Incorporated | 383.0 | 332 | 404 | 83 | 80 | 38 |

Second quarter 2026 stand-alone: revenue 980 and net income attributable 241 are printed in the Q2 release (page:1). Quarter sums tie to the nine-month total: revenue 663, 980 and 696 sum to 2,339; net income attributable 83, 241 and 80 sum to 404.

Asset impairments, net were 47.5 in FY2025 (10-K page:77) and 48 in nine months 2025, of which 46 fell in Q3 2025 (Q3 10-Q page:2); there was none in nine months 2026.

#### Segment net revenue and Adjusted EBITDA, nine months (USD millions, Q3 10-Q pages 25-27, 39)

| Segment | Revenue 9M 2026 (external) | Revenue 9M 2025 (external) | Adjusted EBITDA 9M 2026 | Adjusted EBITDA 9M 2025 |
| --- | --- | --- | --- | --- |
| Live and Historical Racing | 1,148 | 1,083 | 542 | 515 |
| Wagering Services and Solutions | 392 | 383 | 145 | 135 |
| Gaming | 799 | 794 | 384 | 374 |
| All Other | — | — | (73) | (66) |
| Total | 2,339 | 2,260 | 998 | 958 |

#### Balance sheet, reported (USD millions)

| Line | Dec 31, 2025 (10-K p77-78) | Mar 31, 2026 (10-Q Q1 p2-3) | Sep 30, 2026 (10-Q Q3 p3) |
| --- | --- | --- | --- |
| Cash and cash equivalents | 200.6 | 200 | 167 |
| Restricted cash | 87.9 | 91 | 92 |
| Total current assets | 443.2 | 452 | 418 |
| Total assets | 7,484.5 | 7,485 | 7,467 |
| Current maturities of long-term debt and notes payable | 63.1 | 63 | 659 |
| Long-term debt, net of current maturities and loan origination fees | 1,985.9 | 1,783 | 1,578 |
| Notes payable, net of current maturities and debt issuance costs | 3,081.2 | 3,082 | 2,485 |
| Total liabilities | 6,428.7 | 6,341 | 6,064 |
| Redeemable noncontrolling interest | 46.1 | 48 | 24 |
| Total shareholders' equity | 1,009.7 | 1,096 | 1,379 |

The Q3 balance sheet ties: current assets 167, 92, 106, nil, 53 sum to 418; total liabilities 6,064 plus redeemable noncontrolling interest 24 plus equity 1,379 sum to 7,467. Long-term debt 1,578, notes payable 2,485 and current maturities 659 sum to 4,722, which equals total debt 4,748 less 26 of unamortized premium and deferred charges (Q3 10-Q pages 3 and 13).

#### Cash flow, reported (USD millions)

| Line | FY2025 (10-K p78-79) | 9M 2025 (10-Q Q3 p4) | 9M 2026 (10-Q Q3 p4) |
| --- | --- | --- | --- |
| Net cash provided by operating activities | 769.8 | 674 | 660 |
| Capital maintenance expenditures | (70.2) | (53) | (57) |
| Capital project expenditures | (204.7) | (172) | (119) |
| Net cash used in investing activities | (471.5) | (421) | (178) |
| Distributions from unconsolidated affiliates (within operating) | 116.0 | 91 | 106 |
| Equity in income of unconsolidated affiliates (within operating) | (139.4) | (105) | (115) |
| Payment of dividends | (30.8) | (30) | (31) |
| Repurchase of common stock | (427.8) | (396) | (44) |
| Net cash used in financing activities | (262.5) | (237) | (512) |
| Cash paid for interest | 294.5 | 193 | 173 |
| Cash paid for income taxes (10-K: net of refunds) | 63.6 | 17 | 65 |

Nine-month 2026 operating cash flow of 660 compares with 674 a year earlier; the filing attributes the 14 decrease mainly to higher cash taxes, offset by higher equity distributions and lower cash interest (Q3 10-Q page:43). The 9M 2025 column includes acquisition of gaming rights of 185 within investing (Casino Salem); none in 2026.

### Debt register at September 30, 2026

Issuer for every instrument is Churchill Downs Incorporated; the 10-K exhibit index describes each series of 2027, 2028, 2030 and 2031 note indentures as made "by and among Churchill Downs Incorporated, the Guarantors (stated therein) and U.S. Bank" (10-K pages 136-138), so guarantors exist but are not named in the supplied text. A text search found no co-issuer disclosure. Security and guarantors are described only at summary level: the 10-K states the credit agreement is "collateralized by substantially all the wholly owned assets of the Company" (page:69) and the notes are "senior unsecured". No guarantor list is supplied.

| Instrument | Principal 9/30/26 (10-Q Q3 p13) | Principal 12/31/25 | Rate and maturity (source) | Security |
| --- | --- | --- | --- | --- |
| 2031 Revolver (commitment 1,200) | 79 | 657 | SOFR plus 10 bps plus margin (150 bps at 9/30/26); September 2031, springing (p14) | Secured |
| Term Loan A due 2031 | 1,069 | 1,112 | Same pricing as revolver; September 2031, springing; 1.25% quarterly amortization of 1.1 billion (p14) | Secured |
| Term Loan B due 2033 | 500 | not outstanding | SOFR plus 175 bps; September 25, 2033; issued at 99.875%; 0.25% quarterly amortization (p14) | Secured |
| Term Loan B-1 due 2028 | repaid | 286 | SOFR plus 175 bps (p16) | Secured |
| 2027 Senior Notes | 600 | 600 | 5.50%; April 1, 2027; redeemed October 19, 2026 (subsequent event, p28) | Unsecured |
| 2028 Senior Notes | 700 | 700 | 4.75%; January 15, 2028; 500 at par plus 200 at 103.25% (p16) | Unsecured |
| 2030 Senior Notes | 1,200 | 1,200 | 5.75%; April 1, 2030 (p16) | Unsecured |
| 2031 Senior Notes | 600 | 600 | 6.75%; May 1, 2031 (p16) | Unsecured |
| Total debt | 4,748 | 5,155 | | |

Letters of credit under the revolver: 10 outstanding at September 30, 2026 (page:14), against 8.2 at December 31, 2025 (10-K page:68). A 100 swing line commitment is part of the facility (page:14).

Maturity profile of September 30, 2026 principal (illustrative; excludes scheduled amortization, which the sources give only as percentages):

| Year | Instrument | Principal |
| --- | --- | --- |
| 2027 | 2027 Senior Notes (redeemed October 19, 2026) | 600 |
| 2028 | 2028 Senior Notes | 700 |
| 2030 | 2030 Senior Notes | 1,200 |
| 2031 | 2031 Senior Notes (May); 2031 Revolver and Term Loan A (September, subject to springing maturity) | 600; 79; 1,069 |
| 2033 | Term Loan B | 500 |

Springing maturity: the eighth amendment extended the revolver and Term Loan A "subject to an earlier springing maturity" if notes or other material debt maturing before September 25, 2031 are not refinanced at least 91 days before their stated maturity (page:14). Dates implied by the printed 91-day wording are computed in the Calculations section; they are indicative and not a reading of the executed amendment.

### Adjusted EBITDA and definitions

Adjusted EBITDA is a company non-GAAP measure. Per the 10-K (page:57) and 10-Q (page:33) it "includes our portion of EBITDA from our equity investments and the portion of EBITDA attributable to noncontrolling interests" and excludes transaction expense, stock-based compensation, impairments, pre-opening expense, legal reserves and other charges. It is not the credit agreement's covenant EBITDA, whose definition is not supplied.

| Reconciliation item (USD millions) | FY2025 (10-K p64-65) | 9M 2025 (10-Q Q3 p41) | 9M 2026 (10-Q Q3 p41) |
| --- | --- | --- | --- |
| Net income | 385.5 | 334 | 405 |
| Depreciation and amortization | 233.1 | 174 | 176 |
| Interest expense | 297.7 | 222 | 211 |
| Income tax provision | 146.9 | 115 | 147 |
| Stock-based compensation | 30.2 | 18 | 19 |
| Pre-opening expense | 11.7 | 9 | 7 |
| Other expense, net | 10.1 | 7 | 2 |
| Transaction expense, net | 5.1 | 3 | 6 |
| Asset impairments, net | 47.5 | 48 | — |
| Interest, depreciation and amortization related to equity investments | 38.6 | 29 | 28 |
| Other charges and recoveries, net | (1.1) | (1) | (3) |
| Adjusted EBITDA | 1,205.3 | 958 | 998 |

Quarterly Adjusted EBITDA as printed in the releases: Q1 2026 257 (Q1 release page:1), Q2 2026 477 (Q2 release page:1), Q3 2026 264 (Q3 release page:1). These sum to 998 and tie to the nine-month figure. The Q3 2025 figure of 262 included a one-time insurance recovery, which the Q3 release states as the basis for its adjusted comparison (page:1).

Management "net bank leverage" was 3.8x at Q1 2026, 3.7x at Q2 2026 and 3.8x at Q3 2026 (release page:1 in each). No supplied source defines it or reconciles it to a covenant ratio; it is an attributed management claim.

### Liquidity and cash flow quality

- Reported revolver availability: "$1.1 billion available borrowing capacity, after consideration of $10 million in outstanding letters of credit" (Q3 10-Q page:14). Components computed below give 1,111.
- Operating cash flow is seasonal: Q1 2026 operating cash flow was 295 (Q1 10-Q page:3), including a 103 deferred revenue inflow; the Q3 10-Q (page:42) attributes the later decrease in deferred revenue to recognition of revenue related to the 152nd Kentucky Derby, which the Q2 release (page:1) places in the second quarter. Nine-month and last-twelve-months views are therefore used rather than stand-alone quarters.
- Cash outflows to shareholders fell sharply: repurchases of 44 and dividends of 31 in nine months 2026 against 396 and 30 in nine months 2025. The Board approved a new share repurchase program of up to 750 million on October 27, 2026 (subsequent event, Q3 10-Q page:28), which includes 306 million still available under the prior program; the capacity to resume buybacks competes with debt reduction.
- Project capital: management expects about 160 to 180 million in 2026 (Q3 10-Q page:43), against 180.0 to 220.0 million expected in the 10-K (page:66), a reduction in the guided range. Rockingham Grand Casino carries a planned 180 to 200 million investment with a mid-2027 opening (Q1 release page:1).
- Interest rate sensitivity: "a one-percentage point increase in the SOFR rate would reduce net income and cash flows from operating activities by $12 million" on 1.6 billion of floating-rate credit agreement debt (Q3 10-Q page:49).

### Claims outside the debt figure

| Item | Amount and locator | Inside or outside total debt |
| --- | --- | --- |
| Operating leases, minimum rent payable | 52, of which 7 within twelve months (10-Q Q3 p48) | Outside |
| Financing obligations (leases accounted as financing) | 31, of which 4 within twelve months (p48) | Outside the 4,748 table |
| Other contractual obligations | 9, of which 2 within twelve months (p48) | Outside |
| Redeemable noncontrolling interest (Casino Salem holders' put rights) | 24 (p3, p21) | Outside; contingent redemption claim |
| Accrued interest | 75 at 9/30/26 against 48 at 12/31/25 (p20) | Outside; within accrued liabilities |
| Account wagering deposits liability | 65 (p20) against restricted cash of 92 (p3) | Outside; customer funds |
| Unconsolidated affiliates' long-term debt (100% basis, Rivers Des Plaines and Miami Valley Gaming) | 760 at 9/30/26 against 803 at 12/31/25 (p22) | Outside; not consolidated, recourse to the issuer not stated |
| Deferred revenue | current 36 and non-current 12 (p3) | Outside |
| Litigation | No accrual amount stated; the filing states excess exposure "would not be material" (p24) | Outside |
| Pensions and retiree medical | A search for pension, retiree medical and postretirement terms in the 10-K and the Q3 10-Q found no hit; note 17 describes deferred compensation and profit-sharing plans (10-K page:120) | No defined-benefit obligation located; Not supplied |

### Subsequent events and events in the quarter

- August 3, 2026: closed acquisition of 49% of United Tote from NYRA subsidiary; the cash flow statement shows "Acquisition of noncontrolling interest (31)" for nine months 2026 (Q3 10-Q page:4) and the redeemable noncontrolling interest fell by 27 on that account (page:21).
- September 25, 2026: eighth amendment to the credit agreement and the new 2033 TLB (Q3 10-Q page:14; Q3 release page:3).
- September 18, 2026: conditional notice to redeem the 2027 Senior Notes; October 19, 2026: redeemed using the revolver (pages 16 and 28). The redemption price and accrued interest paid are not stated.
- October 27, 2026: annual dividend of $0.469 per share payable January 5, 2027 and the new repurchase authorization (page:28).
- April 21, 2026: agreement to buy the Preakness and Black-Eyed Susan intellectual property for 85 million, subject to closing conditions (Q1 10-Q page:20). The Q2 and Q3 reports and releases do not mention it, and no investing outflow of that size appears in nine months 2026, so closing status is not supplied.

### Evidence-based interpretation by dimension

#### Leverage

On the method used here, gross leverage fell from 4.28x at December 31, 2025 to 3.81x at September 30, 2026 and net leverage from 4.11x to 3.68x. Secured debt (revolver, Term Loan A and Term Loan B) is 1,648, which is 1.32x last-twelve-months Adjusted EBITDA gross, and about 34.7% of total debt. At December 31, 2025 the company reported a covenant secured net leverage ratio of 1.4x against a limit of 4.0x. The same secured-debt arithmetic on year-end figures gives 1.54x net of unrestricted cash, so covenant definitions (EBITDA, cash netting, letters of credit) differ from the metric computed here by an unexplained margin. Evidence to risk to implication: Adjusted EBITDA includes affiliate EBITDA that is not cash to the issuer, so leverage on a cash basis is higher than the ratios above; the subsequent-event shift of 600 of notes to the revolver does not change total debt but raises the secured share.

#### Coverage

Last-twelve-months Adjusted EBITDA covers net interest expense 4.34x and cash interest 4.54x. For comparison, the company's reported covenant interest coverage at December 31, 2025 was 3.9x against a 2.5x minimum, and the simple FY2025 ratio of Adjusted EBITDA to interest expense is 4.05x. The covenant figure is lower than the simple ratio; possible causes are a narrower covenant EBITDA or a broader interest definition, but neither is verified because the definitions are not supplied. Headroom at September 30, 2026 is Not calculable because neither the covenant figure nor its definition is printed for any 2026 date.

#### Cash flow quality

Last-twelve-months operating cash flow of 755.8 less capital expenditures of 225.9 gives free cash flow of 529.9 before dividends and buybacks. Capital project spending fell from 172 to 119 across nine months, and FY2025 project spending of 204.7 itself followed 463.4 in FY2024 (10-K page:79); falling project capital lifts free cash flow relative to those years. Equity-method income in Adjusted EBITDA (143 in nine months 2026, Q3 10-Q page:26) exceeded distributions received (106, page:4), a 37 difference that is earnings, not cash, in the period. Cash taxes rose from 17 to 65 in nine months, reducing operating cash flow.

#### Liquidity

Unrestricted cash 167 plus computed revolver availability 1,111 gives 1,278 at September 30, 2026. After the October 19, 2026 redemption, illustrative availability is 511 and liquidity 678 if no other revolver or cash movement occurred, which cannot be confirmed from the sources. Cash at October 19, 2026 is not supplied. Near-term maturities after the redemption: next note maturity January 15, 2028.

#### Data quality

The sums tested above tie: the Q3 balance sheet, both Adjusted EBITDA reconciliations, the segment and quarterly totals and the capital expenditure table. Units differ (one decimal versus whole millions). Derived last-twelve-months figures inherit rounding of up to about 0.5 per whole-million input. The net debt line in the MD&A (4,063) is total debt net of current maturities and issuance costs, not net of cash.

#### Definition risks

(1) Adjusted EBITDA includes proportionate equity-affiliate EBITDA and noncontrolling interest EBITDA and excludes stock-based compensation, pre-opening expense and "other charges"; (2) "net bank leverage" is undefined; (3) covenant ratios use agreement definitions not supplied; (4) "Net debt" in the MD&A excludes cash netting; (5) restricted cash of 92 is excluded from liquidity because the sources do not state what it is restricted for; the 65 account wagering deposits liability (page:20) is a possible but unconfirmed link.

#### Key gaps

See Gaps. The material ones are covenant headroom at September 30, 2026, guarantor and restricted-group perimeter, redemption price of the 2027 notes and Preakness closing status.

### Downstream readiness

| Consumer | View | Basis |
| --- | --- | --- |
| CP-1A | Sufficient with limits | Statements, Adjusted EBITDA bridge, segment data and cash-paid lines are printed; stand-alone Q2 and Q3 cash flow items must be derived from cumulative lines |
| CP-2 | Sufficient with limits | Facility-level debt, maturities, revolver availability and subsequent events are located; covenant headroom and legal terms are not |
| CP-5 | Sufficient with limits | Cash flow, shareholder returns and definition risks are located; management guidance beyond project capital is not supplied |

## Calculations

All inputs are as printed. FY2025 inputs are to one decimal and 2026 and 9M 2025 inputs to whole millions, so results carry rounding of about 0.5 per whole-million input.

1. Last-twelve-months (LTM) to September 30, 2026 = FY2025 + 9M 2026 - 9M 2025.
   - Adjusted EBITDA: 1,205.3 + 998 - 958 = 1,245.3 (10-K p65; Q3 10-Q p41).
   - Revenue: 2,925.9 + 2,339 - 2,260 = 3,004.9.
   - Interest expense, net: 297.7 + 211 - 222 = 286.7.
   - Cash paid for interest: 294.5 + 173 - 193 = 274.5.
   - Operating cash flow: 769.8 + 660 - 674 = 755.8.
   - Capital expenditures (maintenance plus project): FY2025 70.2 + 204.7 = 274.9; 9M 2026 57 + 119 = 176; 9M 2025 53 + 172 = 225; LTM 274.9 + 176 - 225 = 225.9. The 176 and 225 tie to the segment capital expenditure table (Q3 10-Q p27).
   - Free cash flow before dividends and buybacks: 755.8 - 225.9 = 529.9.
2. Fourth-quarter 2025 implied Adjusted EBITDA = 1,205.3 - 958 = 247.3 (derived; mixed units; not printed as a discrete quarter).
3. Adjusted EBITDA reconciliation check, FY2025: 385.5 + 233.1 + 297.7 + 146.9 + 30.2 + 11.7 + 10.1 + 5.1 + 47.5 + 38.6 - 1.1 = 1,205.3, equal to the printed total. Nine months 2026: 405 + 176 + 211 + 147 + 19 + 7 + 2 + 6 + 28 - 3 = 998, equal to the printed total.
4. Leverage at September 30, 2026: total debt 4,748; unrestricted cash 167; net 4,581. Gross 4,748 / 1,245.3 = 3.81x; net 4,581 / 1,245.3 = 3.68x.
5. Leverage at December 31, 2025: total debt 5,155.1 (10-K MD&A table); unrestricted cash 200.6; net 4,954.5. Gross 5,155.1 / 1,205.3 = 4.28x; net 4,954.5 / 1,205.3 = 4.11x.
6. Secured debt at September 30, 2026 = 79 + 1,069 + 500 = 1,648 (equals the 1.6 billion floating-rate figure at Q3 10-Q p49). Share of total debt 1,648 / 4,748 = 34.7%; notes 3,100 / 4,748 = 65.3%. Gross secured leverage 1,648 / 1,245.3 = 1.32x; net of unrestricted cash (1,648 - 167) / 1,245.3 = 1.19x.
7. Secured leverage at December 31, 2025 on the same method: secured 657 + 1,112 + 286 = 2,055; net of cash 200.6 = 1,854.4; / 1,205.3 = 1.54x. Netting total cash and restricted cash of 288.5 instead gives (2,055 - 288.5) / 1,205.3 = 1.47x. The company printed 1.4x (10-K p69).
8. Coverage: LTM 1,245.3 / 286.7 = 4.34x; 1,245.3 / 274.5 = 4.54x. FY2025: 1,205.3 / 297.7 = 4.05x and 1,205.3 / 294.5 = 4.09x, against 3.9x printed.
9. Revolver availability = 1,200 - 79 - 10 = 1,111 (reported 1.1 billion). Liquidity = 167 + 1,111 = 1,278. Illustrative post-redemption: revolver drawn 79 + 600 = 679; availability 1,200 - 679 - 10 = 511; liquidity 511 + 167 = 678. This assumes no other movement and a redemption at principal with no accrued interest funded by the revolver, neither of which the sources state.
10. Coupon run-rate on notes at September 30, 2026: 600 x 5.50% = 33.00; 700 x 4.75% = 33.25; 1,200 x 5.75% = 69.00; 600 x 6.75% = 40.50; total 175.75. After the 2027 redemption: 33.25 + 69.00 + 40.50 = 142.75. The credit agreement 12-month estimate of 149 (page:47) compares with 1,648 x 5.48% = 90.3 of interest plus quarterly amortization of roughly 60 (1.25% x 1,100 x 4 = 55; 0.25% x 500 x 4 = 5), about 150; this reading of the 149 is an analyst inference and not stated in the filing.
11. Springing-maturity test dates (maturity less 91 days): 2028 notes January 15, 2028 gives October 16, 2027; 2030 notes April 1, 2030 gives December 31, 2029; 2031 notes May 1, 2031 gives January 30, 2031. The 2027 notes (April 1, 2027) would have given December 31, 2026 but were redeemed on October 19, 2026.
12. Equity affiliates: Gaming segment equity income within Adjusted EBITDA 143 for nine months 2026 (Q3 10-Q p26) against distributions received 106 (p4): difference 37. Share of total Adjusted EBITDA 143 / 998 = 14.3%.
13. Cash taxes LTM, net of refunds: 63.6 + 65 - (17 - 1) = 112.6.
14. Shareholder distributions nine months 2026: dividends 31 + repurchases 44 = 75.
15. Current maturities at September 30, 2026: 659 less the 600 2027 notes = 59, close to scheduled amortization of 55 on Term Loan A plus 5 on Term Loan B; this attribution is an analyst inference.
16. Net income attributable LTM = 383.0 + 404 - 332 = 455.0. Free cash flow by period: FY2025 769.8 - 274.9 = 494.9; 9M 2025 674 - 225 = 449; 9M 2026 660 - 176 = 484.
17. Chart-series inputs. LTM Adjusted EBITDA at March 31, 2026 = 1,205.3 + 257 - 245 = 1,217.3; at June 30, 2026 = 1,205.3 + (257 + 477) - (245 + 451) = 1,243.3 (quarterly figures from the releases, page:1 of each). Total debt at March 31, 2026 is 4,951 and at June 30, 2026 is 4,795 (10-Q notes). Ratios: 4,951 / 1,217.3 = 4.07x and (4,951 - 200) / 1,217.3 = 3.90x; 4,795 / 1,243.3 = 3.86x and (4,795 - 196) / 1,243.3 = 3.70x. Cash interest LTM at March 31 = 294.5 + 43 - 45 = 292.5 and at June 30 = 294.5 + 139 - 145 = 288.5; cover 1,217.3 / 292.5 = 4.16x and 1,243.3 / 288.5 = 4.31x.
18. Maturity 2031 bucket = 600 + 1,069 + 79 = 1,748.

## Gaps

| Gap | Severity | Affected | Action |
| --- | --- | --- | --- |
| Covenant ratios and headroom after December 31, 2025 are Not supplied; the covenant EBITDA and interest definitions are Not supplied | Medium | CP-2, CP-5 | Obtain compliance certificate or the credit agreement; treat headroom as Not calculable |
| Identity of the note guarantors (the indentures name "the Guarantors (stated therein)"), restricted subsidiaries and any co-issuers: Not supplied | Medium | CP-2, CP-5 | Obtain subsidiary and guarantor lists |
| Executed eighth amendment, credit agreement and indentures: Not supplied; 2027 notes redemption price and accrued interest paid: Not supplied | Medium | CP-2 | Add the 8-K exhibit and indentures |
| "Net bank leverage" definition and reconciliation: Not supplied | Low | CP-1A, CP-2 | Use computed ratios; quote management figure as attributed |
| Stand-alone Q2 and Q3 2026 cash flow lines are not printed; derivable from cumulative columns | Low | CP-1A | Derive downstream with rounding caveat |
| Preakness IP purchase of 85 million: closing status and funding Not supplied | Low | CP-2 | Check the next filing |
| Defined-benefit pension and retiree medical obligations: none located by text search, so Not supplied | Low | CP-2 | Confirm absence in 10-K note 17 and the exhibits |
| Recourse to the issuer for affiliate debt of 760: Not supplied | Low | CP-2 | Read affiliate guarantee disclosure if any |
| Unit mix: FY2025 to one decimal versus whole millions in 2026 | Low | CP-1A | Carry rounding caveat |

## Next module

CP-1A, then CP-2 and CP-5 per the dependency order. Carry forward: the LTM base figures and their calculation steps above; the subsequent-event treatment of the 2027 notes redemption (balance sheet figures at September 30, 2026 still show the notes outstanding); the springing-maturity test dates; the equity-affiliate share of Adjusted EBITDA; and the covenant gap. Next evidence action: covenant compliance figures for September 30, 2026 and the eighth amendment text.
