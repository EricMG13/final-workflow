## Request

Module: fundamental credit data and financial base for CoreWeave, Inc. (CRWV), consolidated, as of 2026-11-05. Evidence cutoff: 2026-11-05. Reporting currency: USD. Units: US$ millions as printed in the FY2025 10-K and the 2026 filings and releases. Current period per the run context: Q2 2026 (quarter ended 2026-06-30). Prior period per the run context: FY2025. The Q3 2025 10-Q prints in US$ thousands and is used here only for one cross-check, rescaled as stated.

Perimeter: the issuer is the ultimate parent, CoreWeave, Inc., reporting on a consolidated basis. It is not a subsidiary inside a combined filing, so no parent-versus-subsidiary split is needed. Within the consolidation the filings split debt into recourse debt (obligations of CoreWeave, Inc. or of subsidiaries it unconditionally guarantees) and non-recourse debt (recourse limited to the assets of the borrowing subsidiary; 10-Q 2026-06-30, page:27). Both are in the totals below and are shown separately where the filings allow.

Question answered: what do the filed statements say about earnings, cash flow, debt, liquidity, maturities and claims outside debt at the latest filed date, and how do those combine into leverage, cover and liquidity measures? Only reported facts and shown calculations are given. Every ratio uses the company's non-GAAP adjusted EBITDA unless labelled otherwise, because the company does not print an unadjusted EBITDA.

## Sources

### Issuer sources relied on

| Source name | sha256 | Used for |
| --- | --- | --- |
| 10-K_2025-12-31_crwv-20251231.htm.jsonl | 0d0cf44f53b9a917ce74530e1073134d5052786896b56bf540c0ff56c3d09cf5 | FY2025 statements, FY2025 debt note and maturities, FY2025 liquidity table, cash income taxes, covenant risk factor |
| 10-Q_2025-09-30_crwv-20250930.htm.jsonl | 4ab2a43787603e448a27ee75655cd8189c101995b2b2a09f948fefcf24dc65dc | One cross-check of last-twelve-month revenue (rescaled from thousands) |
| 10-Q_2026-03-31_crwv-20260331.htm.jsonl | 02ad347fc934b455da7d76c35b5ed5e2481a8b415629a65ddd1d28789dd893ea | Q1 2026 statements, debt table, liquidity table, leases |
| 10-Q_2026-06-30_crwv-20260630.htm.jsonl | 8c1fe67059916099b1322f23cd4d1d50ec7098f810b5bf54d990d03a024fa1d1 | Q2 2026 and six months 2026 statements, debt note, leases, commitments, liquidity, subsequent events |
| EX-99.1_2026-02-26_coreweave4q25earningspress.htm.jsonl | d1cb2e7f415a836bfc361c60f3592d7d5ff529dbcae4e476b1fc937be4fb40b5 | FY2025 adjusted EBITDA reconciliation, Q4 2025 backlog |
| EX-99.1_2026-05-07_coreweave1q26earningspress.htm.jsonl | e0f8ee20aa75c8abb15cd88aa7bc89813b32cc2ad3558378d8026da7d76cfee8 | Q1 2026 adjusted EBITDA reconciliation, power and backlog statements |
| EX-99.1_2026-08-11_coreweave2q26earningspress.htm.jsonl | af17b6e32fc6d5e125e64130df944ece5d560c39bdc4236cbad0414accede85b | Q2 2026 and six months 2026 adjusted EBITDA reconciliation, discrete Q2 2026 cash flow, backlog |

Context file (settings, not issuer evidence): sha256 98f66cde15d4d68ac95da915aeb204ed4c29c1430841991cd3be8e950d45a9a2.

### Handoffs

| Module | sha256 | How it was consumed |
| --- | --- | --- |
| CP-0 | 0a718ae2802587f76f44cc2a61e8815a4a88834928edca0479e39f7d34976401 | Opened and read in full. Its readiness view (ready with limitations), its unit warning on the Q3 2025 file, its gap list (covenant levels, guarantors, financing agreements, Q3 2026 results, guidance) and its next-module instructions were carried into this module. One CP-0 gap is corrected in the Gaps section. |

### Evidence register

The quotes below are verbatim substrings of the named page. Page is the source chunk shown as page:N.

| Fact | Locator | Verbatim quote |
| --- | --- | --- |
| Total debt principal and its schedule at June 30, 2026 | 10-Q 2026-06-30, page:27 | "Thereafter 14,896 Total $ 35,551" |
| Balance sheet debt lines | 10-Q 2026-06-30, page:5 | "Recourse debt, non-current 25,170 14,608" |
| Revenue, operating loss, interest, net loss | 10-Q 2026-06-30, page:6 | "Interest expense, net (640) (267) (1,176) (531)" |
| Operating cash flow and capex, six months 2026 | 10-Q 2026-06-30, page:8 | "Purchase of property and equipment, including capitalized internal-use software $ (14,117) $ (3,860)" |
| Cash paid for interest, six months 2026 | 10-Q 2026-06-30, page:9 | "Cash paid for interest, net of capitalized amounts $ 806 $ 362" |
| Capitalized interest | 10-Q 2026-06-30, page:21 | "$176 million and $36 million of interest capitalized" |
| Liquidity table, June 30, 2026 | 10-Q 2026-06-30, page:53 | "Total liquidity $ 15,553 $ 6,862" |
| Facilities behind the availability figure | 10-Q 2026-06-30, page:133 | "we had $10.0 billion of undrawn availability under our Revolving Credit Facility, DDTL 3.0 Facility, DDTL 4.0 Facility" |
| Revolver capacity and drawn amount | 10-Q 2026-06-30, page:31 | "had no borrowings outstanding under the Revolving Credit Facility and had $2.0 billion of remaining capacity" |
| Revolver size | 10-Q 2026-06-30, page:57 | "$2.0 billion of available capacity under our $2.5 billion Revolving Credit Facility" |
| Letters of credit on the revolver | 10-Q 2026-06-30, page:31 | "the outstanding balances associated with letters of credit were $533 million and $294 million" |
| DDTL 4.0 commitment | 10-Q 2026-06-30, page:28 | "The agreement provides an $8.5 billion delayed draw term loan facility" |
| DDTL 5.0 commitment and draw end | 10-Q 2026-06-30, page:30 | "available in one or more draws through September 30, 2026" |
| DDTL 3.0 size | 10-Q 2026-06-30, page:133 | "entered into the DDTL 3.0 Facility providing for up to $2.6 billion in delayed draw term loans" |
| DDTL 3.0 draw end | 10-K, page:177 | "that may be drawn through July 2026" |
| Guarantee of DDTL facilities | 10-Q 2026-06-30, page:134 | "All obligations under the DDTL Facilities, other than the DDTL 4.0 Facility, are unconditionally guaranteed by us." |
| Operating and finance lease totals | 10-Q 2026-06-30, page:23 | "Total undiscounted lease payments 29,135 235" |
| Leases not yet commenced | 10-Q 2026-06-30, page:24 | "estimated future undiscounted lease payments associated with such leases is $35.5 billion" |
| Single-site lease maximum | 10-Q 2026-06-30, page:24 | "subject to a contractual maximum of $14.7 billion over the sixteen year term of this lease" |
| Equipment commitments under leases | 10-Q 2026-06-30, page:24 | "between $500 million and $1.2 billion to fulfill these commitments" |
| Equipment lessor exposure | 10-Q 2026-06-30, page:25 | "which total approximately $1.8 billion as of June 30, 2026" |
| Joint venture funding commitments | 10-Q 2026-06-30, page:16 | "limited to its total funding commitments of $1.7 billion as of June 30, 2026" |
| Accrued purchases | 10-Q 2026-06-30, page:22 | "Accrued purchases $ 5,520 $ 5,196" |
| Remaining performance obligations | 10-Q 2026-06-30, page:15 | "the Company had $103.7 billion of unsatisfied RPO" |
| Customer concentration | 10-Q 2026-06-30, page:14 | "Customer A 36% 71% 40% 72%" |
| Subsequent events | 10-Q 2026-06-30, page:46 | "Subsequent to the closing, the Company has drawn $1.2 billion." |
| DCSP setoff | 10-Q 2026-06-30, page:36 | "presented net of the financing obligation and finance lease of $230 million" |
| FY2025 income statement | 10-K, page:138 | "Interest expense, net(a) (1,229) (361) (28)" |
| FY2025 cash flow | 10-K, page:140 | "Net cash provided by operating activities $ 3,058 $ 2,749 $ 1,833" |
| FY2025 cash interest | 10-K, page:141 | "Cash paid for interest, net of capitalized amounts $ 869 $ 184 $ —" |
| FY2025 debt and maturities | 10-K, page:175 | "Total principal of debt 21,615 8,033" |
| FY2025 liquidity table | 10-K, page:126 | "Total liquidity $ 6,862 $ 5,767" |
| FY2025 cash income taxes | 10-K, page:196 | "Income taxes, net of amounts refunded $ (1) $ 14 $ —" |
| FY2025 adjusted EBITDA | Q4 2025 release, page:7 | "Adjusted EBITDA $ 898 $ 486 $ 3,093 $ 1,219" |
| Q1 2026 adjusted EBITDA | Q1 2026 release, page:7 | "Adjusted EBITDA $ 1,157 $ 606" |
| Q2 2026 and six months adjusted EBITDA | Q2 2026 release, page:7 | "Adjusted EBITDA $ 1,510 $ 753 $ 2,667 $ 1,360" |
| Q1 2026 cash flow | 10-Q 2026-03-31, page:7 | "Net cash provided by operating activities $ 2,984 $ 61" |
| Q1 2026 cash interest | 10-Q 2026-03-31, page:8 | "Cash paid for interest, net of capitalized amounts $ 364 $ 142" |
| Q1 2026 debt | 10-Q 2026-03-31, page:24 | "Total principal of debt 25,149 21,615" |
| Q1 2026 liquidity | 10-Q 2026-03-31, page:46 | "Total liquidity $ 11,091 $ 6,862" |
| Q3 2025 revenue in thousands | 10-Q 2025-09-30, page:6 | "Revenue $ 1,364,676 $ 583,941" |

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| Principal debt reached $35,551 million at June 30, 2026 against LTM adjusted EBITDA of $4,400 million, 8.08x gross. Free cash flow is deeply negative and liquidity rests on conditional delayed-draw commitments. | Medium | Covenant levels and headroom, guarantor identities and third quarter 2026 results are not in the sources, so debt capacity cannot be tested. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Principal debt rose from $21,615 million at December 31, 2025 to $35,551 million at June 30, 2026, while LTM adjusted EBITDA is $4,400 million. | Gross leverage moved from 6.99x to 8.08x, so debt is growing faster than earnings. | Medium |
| Six months 2026 operating cash flow of $3,663 million was well below purchases of property and equipment of $14,117 million. | Free cash flow was $(10,454) million, so growth depends on continued debt, equity and customer prepayment funding. | High |
| Reported availability of $10,014 million reconciles to the revolver and three delayed-draw facilities; draws depend on asset purchases and two commitments passed their draw dates. | Usable liquidity is lower and less certain than the headline total of $15,553 million. | Medium |
| Maturities are $4,413 million in the remainder of 2026 and $6,184 million in 2027, against cash of $5,524 million. | Refinancing and amortization need continued market access. | High |
| Operating lease liabilities are $16,319 million and leases not yet commenced are $35.5 billion undiscounted, both outside the debt figure. | Fixed charges will rise beyond reported debt service as leases commence. | High |

### Financial base view

The financial base is sufficient to describe the June 30, 2026 position and the path from FY2025, with stated limits. The audited FY2025 statements, three quarterly filings and three releases tie to each other: six months 2026 revenue of $4,653 million equals Q1 2026 plus Q2 2026, and the debt table sums to the printed total. The picture is of fast, debt-financed growth. Revenue in Q2 2026 was $2,575 million against $1,212 million a year earlier, adjusted EBITDA was $1,510 million, but the company still reported an operating loss of $(49) million and net interest expense of $(640) million in the quarter. Principal debt of $35,551 million (about 89.5 percent recourse by principal, calculated below) is mostly secured, project-level delayed-draw debt plus unsecured notes and convertibles. Leverage on LTM adjusted EBITDA is 8.08x gross and 6.82x net of unrestricted cash and marketable securities, and cash interest cover is 3.35x; both are flattered by the EBITDA definition (it adds back stock compensation and acquisition costs, and is struck after operating lease cost, so lease cost is not in the add-backs) and by cash interest being net of capitalized interest. Debt at period end also funds assets not yet earning revenue, so period-end debt over trailing earnings overstates run-rate leverage, and the contracted backlog (remaining performance obligations of $103.7 billion) is the offsetting evidence. The main restrictions are that financial covenant levels are not printed, so headroom is Not calculable, that guarantors are not named, and that nothing after the Q2 2026 filing except the August 2026 events in the filing note is in the pack.

### Financials and credit metrics

| Metric (US$ millions unless stated) | FY2025 | Q1 2026 | Q2 2026 | Six months 2026 | LTM June 2026 | Source and basis |
| --- | --- | --- | --- | --- | --- | --- |
| Revenue | 5,131 | 2,078 | 2,575 | 4,653 | 7,590 | Reported: 10-K page:138; 10-Q 2026-03-31 page:6; 10-Q 2026-06-30 page:6. LTM calculated: FY2025 plus six months 2026 less six months 2025 |
| Revenue growth year on year (percent) | 167.9 | 111.6 | 112.5 | 112.1 | Not calculable: six months 2024 is not in the pack | Calculated from current and prior-year columns of the same sources |
| Operating income (loss) | (46) | (144) | (49) | (193) | (231) | Reported; LTM calculated as FY2025 plus six months 2026 less six months 2025 of (8) |
| Depreciation and amortization (cash flow statement) | 2,454 | 1,147 | 1,393 | 2,540 | 3,991 | 10-K page:140; 10-Q 2026-03-31 page:7; Q2 2026 release page:6; LTM calculated |
| Adjusted EBITDA (company non-GAAP) | 3,093 | 1,157 | 1,510 | 2,667 | 4,400 | Releases, reconciliation tables (Q4 2025 page:7, Q1 2026 page:7, Q2 2026 page:7); management measure, adds back stock compensation and acquisition costs; LTM calculated |
| Adjusted EBITDA margin (percent, calculated) | 60.3 | 55.7 | 58.6 | 57.3 | 58.0 | Adjusted EBITDA divided by revenue; the releases print 60, 56, 59 and 57 percent |
| Operating income plus D&A (calculated, unadjusted) | 2,408 | 1,003 | 1,344 | 2,347 | 3,760 | Sum of the two rows above; no stock compensation add-back |
| Interest expense, net | (1,229) | (536) | (640) | (1,176) | (1,874) | Income statements; LTM calculated |
| Capitalized interest | 182 | 97 | 79 | 176 | 322 | 10-K page:175; 10-Q 2026-03-31 page:24; 10-Q 2026-06-30 pages:21 and 27; LTM uses six months 2025 of 36 |
| Cash paid for interest, net of capitalized amounts | 869 | 364 | 442 | 806 | 1,313 | Supplemental cash flow disclosures; Q2 2026 is six months less Q1 2026; LTM uses six months 2025 of 362 |
| Net loss | (1,167) | (740) | (626) | (1,366) | (1,928) | Income statements; LTM calculated with six months 2025 of (605) |
| Net cash from operating activities | 3,058 | 2,984 | 679 | 3,663 | 6,911 | 10-K page:140; 10-Q 2026-03-31 page:7; Q2 2026 release page:7; LTM calculated with six months 2025 of (190) |
| Change in deferred revenue (operating cash flow line) | 4,174 | 575 | 790 | 1,365 | 4,796 | Cash flow statements; Q1 2026 is six months less Q2 2026; LTM calculated with six months 2025 of 743 |
| Purchase of property and equipment | (10,309) | (7,695) | (6,422) | (14,117) | (20,566) | Cash flow statements; LTM calculated with six months 2025 of (3,860) |
| Free cash flow (operating cash flow less purchase of property and equipment, calculated) | (7,251) | (4,711) | (5,743) | (10,454) | (13,655) | Calculated; before lease principal, acquisitions, joint venture and other investing |
| Cash income taxes paid, net of refunds | (1) | Not supplied: interim filings do not print it | Not supplied: interim filings do not print it | Not supplied: interim filings do not print it | Not calculable: interim periods not supplied | 10-K page:196 for FY2025 only |
| Cash and cash equivalents (period end) | 3,127 | 2,244 | 5,524 | Same as Q2 2026 column | Same as Q2 2026 column | Balance sheets: 10-Q 2026-06-30 page:5; 10-Q 2026-03-31 page:5 |
| Restricted cash, current plus non-current (period end) | 1,003 | 1,076 | 1,380 | Same as Q2 2026 column | Same as Q2 2026 column | Balance sheets; calculated sum of the two lines; held for collateralized loan facilities |
| Marketable securities (period end) | 34 | 22 | 15 | Same as Q2 2026 column | Same as Q2 2026 column | Balance sheets |
| Total debt principal (period end) | 21,615 | 25,149 | 35,551 | Same as Q2 2026 column | Same as Q2 2026 column | Debt notes: 10-K page:175; 10-Q 2026-03-31 page:24; 10-Q 2026-06-30 pages:26-27; excludes leases |
| Total debt carrying value (period end) | 21,373 | 24,859 | 35,068 | Same as Q2 2026 column | Same as Q2 2026 column | Principal less unamortized discount and issuance costs of 242, 290 and 483 |
| Recourse debt principal (period end) | 20,968 | Not supplied: Q1 2026 note does not split the OEM financing | 31,832 | Same as Q2 2026 column | Same as Q2 2026 column | Calculated: carrying value of recourse debt plus unamortized discount (20,726 plus 242; 31,405 plus 427) |
| Non-recourse debt principal (period end) | 647 | Not supplied: Q1 2026 note does not split the OEM financing | 3,719 | Same as Q2 2026 column | Same as Q2 2026 column | Calculated: DDTL 4.0 of 2,837 plus OEM financing of 882 at June 30, 2026; OEM financing of 647 at December 31, 2025 |
| Net debt (principal less cash and marketable securities, calculated) | 18,454 | 22,883 | 30,012 | Same as Q2 2026 column | Same as Q2 2026 column | Restricted cash excluded; including it would give 28,632 at June 30, 2026 |
| Operating lease liabilities (period end) | 8,195 | 10,050 | 16,319 | Same as Q2 2026 column | Same as Q2 2026 column | Lease notes; outside the debt figure |
| Finance lease liabilities (period end) | 254 | 238 | 221 | Same as Q2 2026 column | Same as Q2 2026 column | Lease notes; outside the debt figure; some DCSP amounts are set off (see claims outside debt) |
| Leases not yet commenced, undiscounted | 38,500 | 40,700 | 35,500 | Same as Q2 2026 column | Same as Q2 2026 column | Printed in billions (38.5, 40.7, 35.5); converted to millions; excludes the items listed under claims outside debt |
| Deferred revenue, current plus non-current (period end) | 8,185 | 7,523 | 9,692 | Same as Q2 2026 column | Same as Q2 2026 column | Balance sheets; calculated sum of the two lines |
| Total stockholders' equity (period end) | 3,335 | 4,759 | 5,024 | Same as Q2 2026 column | Same as Q2 2026 column | Balance sheets |
| Remaining performance obligations (US$ billions, period end) | 60.7 | 98.8 | 103.7 | Same as Q2 2026 column | Same as Q2 2026 column | 10-K page:164; 10-Q 2026-03-31 page:14; 10-Q 2026-06-30 page:15; release backlog is a wider measure (see Gaps) |
| Reported availability under existing facilities (period end) | 3,701 | 8,825 | 10,014 | Same as Q2 2026 column | Same as Q2 2026 column | Liquidity tables: 10-K page:126; 10-Q 2026-03-31 page:46; 10-Q 2026-06-30 page:53 |
| Total debt / adjusted EBITDA (x) | 6.99 | 6.90 | 8.08 | Same as Q2 2026 column | Same as Q2 2026 column | Period-end principal over LTM adjusted EBITDA at that date; the Q1 2026 column uses LTM March 2026 of 3,644 |
| Net debt / adjusted EBITDA (x) | 5.97 | 6.28 | 6.82 | Same as Q2 2026 column | Same as Q2 2026 column | As above |
| Total debt / (operating income plus D&A) (x) | 8.98 | 8.40 | 9.46 | Same as Q2 2026 column | Same as Q2 2026 column | Unadjusted sensitivity; LTM March 2026 base of 2,995 |
| Adjusted EBITDA / cash interest (x) | 3.56 | 3.18 | 3.42 | 3.31 | 3.35 | Quarter and period columns use that period's adjusted EBITDA over that period's cash interest; LTM March 2026 is 3.34 |
| Adjusted EBITDA / interest expense, net (x) | 2.52 | 2.16 | 2.36 | 2.27 | 2.35 | Same periods over interest expense, net |

### Chart data: leverage

| Period | Total debt / EBITDA | Net debt / EBITDA | Reporting unit | Basis and limitation |
| --- | --- | --- | --- | --- |
| FY2025 (December 31, 2025) | 6.99 | 5.97 | x | Principal debt 21,615 and net debt 18,454 over FY2025 adjusted EBITDA 3,093 (company non-GAAP). Excludes lease liabilities. Net debt deducts unrestricted cash and marketable securities only. |
| LTM March 2026 (March 31, 2026) | 6.90 | 6.28 | x | Principal debt 25,149 and net debt 22,883 over LTM adjusted EBITDA 3,644. Same definitions; Q1 2026 split of recourse and non-recourse not printed. |
| LTM June 2026 (June 30, 2026) | 8.08 | 6.82 | x | Principal debt 35,551 and net debt 30,012 over LTM adjusted EBITDA 4,400. Period-end debt funds assets not yet earning revenue, and adjusted EBITDA adds back stock compensation; on operating income plus D&A the gross ratio is 9.46. Covenant leverage definitions are not supplied. |

### Chart data: interest cover

| Period | EBITDA / cash interest | Reporting unit | Basis and limitation |
| --- | --- | --- | --- |
| FY2025 | 3.56 | x | Adjusted EBITDA 3,093 over cash paid for interest net of capitalized amounts 869. Cash interest is net of capitalized interest of 182, which flatters the ratio. |
| LTM March 2026 | 3.34 | x | Adjusted EBITDA 3,644 over LTM cash interest 1,091 (869 plus 364 less 142). |
| Q1 2026 | 3.18 | x | Adjusted EBITDA 1,157 over cash interest 364. Single quarter; timing of semi-annual note coupons affects quarterly cash interest. |
| Q2 2026 | 3.42 | x | Adjusted EBITDA 1,510 over cash interest 442 (six months 806 less Q1 364). Derived quarter. |
| LTM June 2026 | 3.35 | x | Adjusted EBITDA 4,400 over LTM cash interest 1,313 (869 plus 806 less 362). Over interest expense, net of 1,874 the ratio is 2.35. Covenant coverage definitions are not supplied. |

### Chart data: liquidity

| Period | Cash | Undrawn committed facilities | Reporting unit | Basis and limitation |
| --- | --- | --- | --- | --- |
| December 31, 2025 | 3127 | 3701 | US$m | Unrestricted cash and cash equivalents; excludes restricted cash of 1003 and marketable securities of 34. Availability as reported by the company for the revolver, DDTL 2.1 and DDTL 3.0; not rebuilt by facility. |
| March 31, 2026 | 2244 | 8825 | US$m | Excludes restricted cash of 1076 and marketable securities of 22. Availability as reported for the revolver, DDTL 3.0 and DDTL 4.0; not rebuilt by facility. |
| June 30, 2026 | 5524 | 10014 | US$m | Excludes restricted cash of 1380 and marketable securities of 15. Availability rebuilt as 1967 revolver (2500 capacity less 533 letters of credit), 385 DDTL 3.0, 5663 DDTL 4.0 and 1999 DDTL 5.0. Draws are tied to eligible asset purchases; DDTL 3.0 (draw period to July 2026) and DDTL 5.0 (to September 30, 2026) had passed their stated draw dates by the as-of date, and August 2026 draws are not reflected. |

### Chart data: debt maturities

| Period | Debt maturing | Reporting unit | Basis and limitation |
| --- | --- | --- | --- |
| Remaining portion of 2026 | 4413 | US$m | Principal payments scheduled as of June 30, 2026; includes DDTL and OEM amortization. |
| 2027 | 6184 | US$m | Same schedule. |
| 2028 | 4416 | US$m | Same schedule. |
| 2029 | 2421 | US$m | Same schedule. The revolver matures November 2029 and was undrawn at June 30, 2026. |
| 2030 | 3221 | US$m | Same schedule. |
| Thereafter | 14896 | US$m | Same schedule; total of all periods 35551 equals total principal. Excludes unamortized discount of 483. DDTL 4.0 payment timing is a management estimate. Excludes lease liabilities. |

### Debt instruments at June 30, 2026

Principal by instrument, all in US$ millions, from the debt note (10-Q 2026-06-30, pages:26-27 and 28-34; 10-K page:175 for December 31, 2025). "Effective" is the printed effective interest rate. Stated rates are given where printed.

| Instrument | Issuer or borrower | Security and guarantee | Maturity | Rate | June 30, 2026 | December 31, 2025 |
| --- | --- | --- | --- | --- | --- | --- |
| DDTL 1.0 Facility (recourse) | CoreWeave Compute Acquisition Co. II, LLC | First-priority pledges over the subsidiary equity and substantially all subsidiary assets; unconditionally guaranteed by CoreWeave, Inc. | Mar 2028 | Effective 15%; stated spread not printed in pages read | 1,300 | 1,553 |
| DDTL 2.0 Facility (recourse) | CoreWeave Compute Acquisition Co. IV, LLC | As above | Aug 2030 | Effective 11% | 3,190 | 5,037 |
| DDTL 2.1 Facility (recourse) | CoreWeave Compute Acquisition Co. IV, LLC (tranche of the 2.0 facility) | As above | Mar 2031 (the 10-K prints December 2030) | Effective 9%; stated SOFR plus 4.25% | 3,000 | 2,741 |
| DDTL 3.0 Facility (recourse) | CoreWeave Compute Acquisition Co. V, LLC and CoreWeave Compute Acquisition Co. VII, LLC | As above | Aug 2030 | Effective 9%; stated SOFR plus 4.00% | 2,215 | 340 |
| DDTL 5.0 Facility (recourse) | CoreWeave Financing DDTL V, LLC | As above, plus parent guarantee and pledge agreement | Nov 2031 in the table; text says expected final payment May 2031 | Effective 9%; stated SOFR plus 4.50% | 1,101 | 0 |
| 2030 Senior Notes | CoreWeave, Inc. | Unsecured; guaranteed by certain wholly-owned subsidiaries | Jun 2030 | Effective 10%; stated 9.25% | 2,000 | 2,000 |
| 2031 9.00% Senior Notes | CoreWeave, Inc. | Same | Feb 2031 | Effective 10%; stated 9.00% | 1,750 | 1,750 |
| 2031 9.75% Senior Notes | CoreWeave, Inc. | Same | Oct 2031 | Effective 10%; stated 9.75% | 2,750 | 0 |
| 2032 9.625% Senior Notes | CoreWeave, Inc. | Same | Jul 2032 | Effective 10%; stated 9.625% | 1,250 | 0 |
| 2032 EUR Senior Notes | CoreWeave, Inc.; 2,000 million euro principal, shown in US$ | Same; fair value hedged by a cross currency swap of 2,000 million euro | Jul 2032 | Effective 9%; stated 8.50% | 2,279 | 0 |
| 2031 Convertible Senior Notes | CoreWeave, Inc. | Unsecured; guaranteed as the Notes | Dec 2031 | Effective 2%; stated 1.75% | 2,588 | 2,588 |
| 2032 Convertible Senior Notes | CoreWeave, Inc. | Unsecured; guaranteed as the Notes | Oct 2032 | Effective 2%; stated 1.75%; conversion price about 119.60 per share | 4,000 | 0 |
| Convertible Promissory Notes | CoreWeave, Inc. (issued to former shareholders of an acquiree) | Not stated | Apr 2026 | Effective 7% | 0 | 168 |
| Revolving Credit Facility | CoreWeave, Inc. | Senior secured by pledges of certain assets; capacity 2,500; letter of credit sub-facility; undrawn fee 0.25% | Nov 2029 | Effective 7% | 0 | 1,000 |
| OEM and Software License Financing Arrangements (recourse) | CoreWeave, Inc. and guaranteed subsidiaries | Security interest in financed equipment (OEM) | Dec 2026 to Jul 2030 | Effective 11% | 4,220 | 3,518 |
| Magnetar Loan | CoreWeave, Inc. (refundable deposit under a capacity agreement with MagAI Ventures, treated as debt) | Not stated | Jan 2029 | Effective 12% | 189 | 273 |
| Less unamortized discount and issuance costs (recourse) | n/a | n/a | n/a | n/a | (427) | (242) |
| DDTL 4.0 Facility (non-recourse) | CoreWeave Compute Acquisition Co. VIII, LLC | First-priority pledges over the subsidiary equity and substantially all of its assets; limited carve-out guarantees only | Mar 2032 | Effective 7%; floating SOFR plus 2.25% on 1,400 and fixed Treasury plus 2.00% on 1,500 (rounded in text) | 2,837 | 0 |
| OEM and Software License Financing Arrangements (non-recourse) | Subsidiaries | Recourse limited to subsidiary assets | Aug 2026 to Aug 2028 | Effective 9% | 882 | 647 |
| Less unamortized discount and issuance costs (non-recourse) | n/a | n/a | n/a | n/a | (56) | 0 |

Totals: principal 35,551 at June 30, 2026 (21,615 at December 31, 2025); carrying value 35,068 (21,373); current portion 7,513 (6,708) and non-current 27,555 (14,665). Of the OEM and software financing, the notes print 4.8 billion for OEM and 347 million for software license arrangements at June 30, 2026.

### Claims outside the debt figure

| Claim | Amount and period | In or outside debt figure | Locator and note |
| --- | --- | --- | --- |
| Operating lease liabilities | 16,319 at June 30, 2026 (undiscounted 29,135) | Outside | 10-Q 2026-06-30, page:23. Operating lease cost for six months 2026 was 888 and cash paid on operating leases 707. |
| Finance lease liabilities | 221 at June 30, 2026 (undiscounted 235) | Outside | 10-Q 2026-06-30, page:23. |
| DCSP financing obligation and finance lease | 112 financing obligation and 118 finance lease (230 together) | Outside the debt figure and set off against a DCSP note receivable of 302 | 10-Q 2026-06-30, pages:35-36. Reported net, so the gross obligation is not on the balance sheet lines above. |
| Leases signed but not commenced | 35.5 billion undiscounted, commencing 2026 to 2029, terms seven to sixteen years | Outside, not on the balance sheet | 10-Q 2026-06-30, page:24. |
| Single-site data center lease with rent based on construction cost | Up to 14.7 billion over sixteen years; 393 MW undelivered | Outside, excluded from the 35.5 billion | 10-Q 2026-06-30, page:24. |
| Other construction-cost-based leases | Amount Not calculable: payments depend on lessor costs; 355 MW undelivered | Outside | 10-Q 2026-06-30, page:24. |
| Lessee-owned equipment to be installed at leased sites | 500 million to 1.2 billion through 2028 | Outside | 10-Q 2026-06-30, page:24. |
| Equipment lessor variable interest entity | About 1.8 billion of committed payments | Outside; included in the 35.5 billion | 10-Q 2026-06-30, page:25. |
| Prepayments to unconsolidated lessors | 108 maximum loss exposure | Outside | 10-Q 2026-06-30, pages:24-25. |
| Joint venture funding commitments | 1.7 billion maximum exposure; carrying value 479 | Outside | 10-Q 2026-06-30, page:16. Six months 2026 investments related to joint ventures were 550 (cash flow statement). |
| Letters of credit | 533 outstanding on the revolver | Inside the liquidity calculation (reduces revolver availability); not debt | 10-Q 2026-06-30, page:31. |
| Accrued purchases (equipment and related) | 5,520 at June 30, 2026 against 5,196 | Outside debt; a supplier payable | 10-Q 2026-06-30, page:22. Accounts payable were a further 3,633. |
| Deferred revenue (customer prepayments) | 9,692 | Outside debt | Balance sheet; 554 of revenue was recognized from the opening balance in six months 2026 (page:15). |
| Asset retirement obligations | 120 | Outside | 10-Q 2026-06-30, page:21. |
| Securities class action and derivative suits | No accrual; loss not estimable | Outside | 10-Q 2026-06-30, pages:25-26. |
| Pensions and retiree medical | Not supplied: no such obligation found | Not applicable | Searched pension and postretirement in the 10-K and 10-Q; no match. |
| Factoring and supply-chain finance | Not supplied: no such arrangement found | Not applicable | Searched factoring and supply chain financing; no match. The OEM and software financing is inside debt. |
| Other purchase commitments | Not supplied: described as routine commitments with no amount | Outside | 10-K and 10-Q contractual obligations text lists the category without a total. |

### Liquidity and covenants

Liquidity at June 30, 2026, from printed inputs: unrestricted cash and cash equivalents 5,524 plus marketable securities 15 plus reported availability 10,014 equals the company's total liquidity of 15,553. The availability of 10,014 reconciles exactly to the facilities the risk factor names: revolver 2,500 capacity less 533 letters of credit gives 1,967; DDTL 3.0 up to 2,600 less 2,215 outstanding gives 385; DDTL 4.0 of 8,500 less 2,837 outstanding gives 5,663; DDTL 5.0 of 3,100 less 1,101 outstanding gives 1,999. Cash is partly restricted: restricted cash of 1,380 sits outside the figure. Commitment periods ending within twelve months of June 30, 2026: DDTL 3.0 draw period (July 2026, per the 10-K), DDTL 5.0 draw period (September 30, 2026) and DDTL 4.0 commitments (June 30, 2027); DDTL 5.0 amortization also starts in November 2026. The revolver matures November 2029. Because DDTL draws are limited to a percentage of the depreciable cost of eligible equipment and project-level conditions, availability is not freely drawable cash.

Covenants: no financial maintenance test, level, step-down or reported ratio is printed in any pinned source, so headroom is Not calculable. What is printed: the company was in compliance with all covenants under its delayed draw term loan agreements at June 30, 2026 (10-Q page:31); the revolver was amended in November 2025 "to modify certain covenant metrics" (10-K page:180); risk factors state the company is "required to maintain specified financial covenant ratios" (10-Q page:137, 10-K page:96); DDTL 4.0 requires restricted cash based on a forward-looking three-month coverage of scheduled cash interest and principal payments, periodic swap settlements and operating expenses (10-Q page:30); DDTL 4.0 and 5.0 require interest rate hedges on at least 95 percent of reasonably anticipated floating-rate borrowings (pages:29-30); debt sizing for DDTL 4.0 references projected debt service coverage (page:29). Differences from the metrics computed here: any lender definition of EBITDA, leverage or coverage is not supplied, and the ratios above use the company's non-GAAP adjusted EBITDA.

### Latest quarter and events to the cutoff

| Date | Event | Amount | Locator |
| --- | --- | --- | --- |
| Jan 2026 | NVIDIA private placement of Class A shares (about 23 million shares at 87.20) | 2.0 billion gross | 10-Q 2026-06-30, page:56 |
| Mar 2026 | DDTL 4.0 (non-recourse) entered; first draws | 8.5 billion commitment | 10-Q 2026-06-30, page:28 |
| Apr 2026 | 2031 9.75% Senior Notes issued | 2.8 billion (2,750 principal) | 10-Q 2026-06-30, page:33 |
| Apr 2026 | 2032 Convertible Senior Notes issued; capped calls bought | 4.0 billion; capped calls 492 | 10-Q 2026-06-30, pages:32-33 |
| Apr 2026 | Revolver balance repaid; convertible promissory notes settled in shares | Revolver had 1.0 billion drawn at December 31, 2025; promissory notes 172 principal | 10-Q 2026-06-30, pages:31 and 34 |
| Apr 2026 | Class A private placement | 1.0 billion gross at 109.00 per share | 10-Q 2026-06-30, page:56 |
| May 2026 | DDTL 5.0 entered (Morgan Stanley agent) | 3.1 billion commitment | 10-Q 2026-06-30, page:30 |
| Jun 2026 | 2032 9.625% Senior Notes and 2032 EUR Senior Notes issued; cross currency swap | 1.3 billion and 2.0 billion euro | 10-Q 2026-06-30, pages:19 and 33 |
| Aug 2026 (subsequent event) | DDTL 5.5 entered with JPMorgan as agent, draws available to December 2026, matures September 2031, SOFR plus 5.5%; 1.2 billion drawn after closing | 2.6 billion commitment | 10-Q 2026-06-30, page:46 |
| Aug 2026 (subsequent event) | Revolver draw | 1.2 billion | 10-Q 2026-06-30, page:46 |
| Early Q3 2026 (stated in the Q2 2026 release) | Net new customer commitments added after quarter end and not in the backlog figure | More than 25 billion | Q2 2026 release, page:1 |
| As of Jun 30, 2026 | Active power 1.5 GW and contracted power about 3.7 GW (management statements in the release) | Not a filing figure | Q2 2026 release, page:2 |

Customer concentration in Q2 2026: Customer A 36 percent, Customer B 26 percent and Customer C 10 percent of revenue (10-Q 2026-06-30, page:14); Customers A and B were 32 percent each of net accounts receivable (page:15). Committed contracts were 98 percent of revenue (page:14). No ratings, defaults or waivers are disclosed in the pages read; the 10-Q reports material weaknesses in internal control continuing at June 30, 2026 (page:59).

## Calculations

All inputs are US$ millions as printed. LTM means last twelve months. Rounding is to the stated decimals.

1. LTM June 2026 for any flow = FY2025 plus six months 2026 less six months 2025.
   - Revenue: 5,131 + 4,653 - 2,194 = 7,590.
   - Adjusted EBITDA: 3,093 + 2,667 - 1,360 = 4,400.
   - Operating income: (46) + (193) - (8) = (231). The prior-year six months of (8) is the printed 2025 comparative.
   - D&A: 2,454 + 2,540 - 1,003 = 3,991.
   - Operating income plus D&A: (231) + 3,991 = 3,760. FY2025: (46) + 2,454 = 2,408. Q1 2026: (144) + 1,147 = 1,003. Q2 2026: (49) + 1,393 = 1,344. Six months 2026: (193) + 2,540 = 2,347.
   - Interest expense, net: 1,229 + 1,176 - 531 = 1,874.
   - Capitalized interest: 182 + 176 - 36 = 322.
   - Cash paid for interest: 869 + 806 - 362 = 1,313.
   - Net loss: (1,167) + (1,366) - (605) = (1,928).
   - Operating cash flow: 3,058 + 3,663 - (190) = 6,911.
   - Purchase of property and equipment: 10,309 + 14,117 - 3,860 = 20,566.
   - Deferred revenue change: 4,174 + 1,365 - 743 = 4,796.
2. LTM March 2026 (used for the Q1 2026 leverage and cover): adjusted EBITDA 3,093 + 1,157 - 606 = 3,644; cash interest 869 + 364 - 142 = 1,091; operating income (46) + (144) - (27) = (163); D&A 2,454 + 1,147 - 443 = 3,158; sum 2,995.
3. Derived quarters and splits: Q2 2026 cash interest 806 - 364 = 442. Q2 2026 operating cash flow 3,663 - 2,984 = 679 (equals the release). Q2 2026 purchase of property and equipment 14,117 - 7,695 = 6,422 (equals the release). Q1 2026 deferred revenue change 1,365 - 790 = 575. Q1 2026 net loss plus Q2 2026 net loss: 740 + 626 = 1,366, equals six months.
4. Free cash flow (operating cash flow less purchase of property and equipment): FY2025 3,058 - 10,309 = (7,251); Q1 2026 2,984 - 7,695 = (4,711); Q2 2026 679 - 6,422 = (5,743); six months 2026 3,663 - 14,117 = (10,454); LTM 6,911 - 20,566 = (13,655).
5. Margins and growth: adjusted EBITDA margin FY2025 3,093 / 5,131 = 60.3 percent; Q1 2026 1,157 / 2,078 = 55.7; Q2 2026 1,510 / 2,575 = 58.6; six months 2,667 / 4,653 = 57.3; LTM 4,400 / 7,590 = 58.0. Growth: FY2025 5,131 / 1,915 - 1 = 167.9 percent; Q1 2026 2,078 / 982 - 1 = 111.6; Q2 2026 2,575 / 1,212 - 1 = 112.5; six months 4,653 / 2,194 - 1 = 112.1.
6. Net debt = total principal less cash and cash equivalents less marketable securities: December 31, 2025 21,615 - 3,127 - 34 = 18,454; March 31, 2026 25,149 - 2,244 - 22 = 22,883; June 30, 2026 35,551 - 5,524 - 15 = 30,012. After also deducting restricted cash of 1,380 at June 30, 2026: 28,632.
7. Leverage: total debt / adjusted EBITDA: 21,615 / 3,093 = 6.99; 25,149 / 3,644 = 6.90; 35,551 / 4,400 = 8.08. Net: 18,454 / 3,093 = 5.97; 22,883 / 3,644 = 6.28; 30,012 / 4,400 = 6.82. Unadjusted sensitivity: 21,615 / 2,408 = 8.98; 25,149 / 2,995 = 8.40; 35,551 / 3,760 = 9.46.
8. Cover: 3,093 / 869 = 3.56; Q1 2026 1,157 / 364 = 3.18; Q2 2026 1,510 / 442 = 3.42; six months 2,667 / 806 = 3.31; LTM March 2026 3,644 / 1,091 = 3.34; LTM June 2026 4,400 / 1,313 = 3.35. Over interest expense, net: 3,093 / 1,229 = 2.52; 1,157 / 536 = 2.16; 1,510 / 640 = 2.36; 2,667 / 1,176 = 2.27; 4,400 / 1,874 = 2.35.
9. Recourse split: recourse principal = carrying 31,405 + discount 427 = 31,832; non-recourse principal = 2,837 + 882 = 3,719; sum 35,551 equals the printed total. Recourse share = 31,832 / 35,551 = 89.5 percent. December 31, 2025: 20,726 + 242 = 20,968 plus non-recourse 647 = 21,615.
10. Debt checks: recourse principal at June 30, 2026 adds from the instrument table to 31,832 (1,300 + 3,190 + 3,000 + 2,215 + 1,101 + 2,000 + 1,750 + 2,750 + 1,250 + 2,279 + 2,588 + 4,000 + 4,220 + 189). Carrying value 31,405 + 3,663 = 35,068 equals balance sheet debt 6,235 + 1,278 + 25,170 + 2,385. Maturity schedule: 4,413 + 6,184 + 4,416 + 2,421 + 3,221 + 14,896 = 35,551.
11. Liquidity: 5,524 + 15 + 10,014 = 15,553 (equals the printed total). Availability rebuild: (2,500 - 533) + (2,600 - 2,215) + (8,500 - 2,837) + (3,100 - 1,101) = 1,967 + 385 + 5,663 + 1,999 = 10,014. The rebuild uses DDTL 3.0 size from the Q2 10-Q and the 10-K, so a later amendment to that size would not show here. December 31, 2025: 3,127 + 34 + 3,701 = 6,862. March 31, 2026: 2,244 + 22 + 8,825 = 11,091.
12. Restricted cash: 873 + 507 = 1,380 (June 30, 2026); 819 + 184 = 1,003; 777 + 299 = 1,076.
13. Leases and deferred revenue: operating plus finance lease liabilities 16,319 + 221 = 16,540; deferred revenue 2,686 + 7,006 = 9,692; 1,709 + 6,476 = 8,185; 2,130 + 5,393 = 7,523. Debt plus all lease liabilities at June 30, 2026 would be 35,551 + 16,540 = 52,091; no lease-adjusted ratio is given because adjusted EBITDA is stated after operating lease cost, so the numerator and denominator would not match.
14. Revenue cross-check across filings: Q3 2025 revenue 1,364,676 thousand is 1,365 million; 1,365 + 1,572 (Q4 2025 release) + 2,078 + 2,575 = 7,590, equal to the LTM revenue of 7,590.
15. Pro forma August 2026 revolver availability, indicative only: 2,500 - 533 - 1,200 = 767, assuming letters of credit unchanged and no repayment after the quarter end. Not a reported figure.
16. Customer concentration: 36 + 26 + 10 = 72 percent of Q2 2026 revenue for the three customers above 10 percent.

## Gaps

1. Covenant levels, definitions and headroom: Not supplied. Searched covenant, coverage, leverage, minimum liquidity and compliance in all filings; only compliance statements and the revolver's "modify certain covenant metrics" appear. Needed: the credit agreements. Headroom is Not calculable.
2. Guarantors and the borrower structure behind each note: Not supplied. The filings say "certain of our wholly-owned subsidiaries" guarantee the Notes; no list is in the pack.
3. Correction to CP-0: CP-0 listed cash paid for income taxes as Not supplied. The 10-K does print it for FY2025 (net of refunds, (1) for 2025, 14 for 2024; page:196). Interim periods remain Not supplied.
4. Third quarter 2026 results and any events after the August 2026 items in the filing note: Not supplied. Cash, debt and liquidity as of the as-of date 2026-11-05 are therefore Not calculable. DDTL 3.0 and DDTL 5.0 draw periods ended before the as-of date; draws after June 30, 2026 other than the August items are unknown.
5. Quarterly coverage: Q3 2025 and Q4 2025 discrete quarters are not rebuilt here beyond the Q4 2025 release highlights; Q3 2025 adjusted EBITDA is not in the pack (the Q3 2025 release is not supplied).
6. Backlog versus remaining performance obligations: the releases state revenue backlog of approximately 104 billion at June 30, 2026 and 99.4 billion at March 31, 2026, a wider management measure than the filed remaining performance obligations of 103.7 billion and 98.8 billion. The filed figure controls where they differ.
7. Management guidance: Not supplied; the releases say guidance is given on the call and no transcript is in the pack.
8. The Q2 2026 release prints depreciation and amortization of 560 for Q2 2025 in the cash flow statement and 559 in the adjusted EBITDA reconciliation (pages:6 and 7). Both are prior-year comparatives and neither enters a figure above.
9. Date differences: DDTL 2.1 matures in March 2031 in the 2026 filings and December 2030 in the 10-K; DDTL 5.0 shows November 2031 in the table and expected final payment May 2031 in the text. The later filing and the table are used; the reason is not explained in the pages read.
10. Facility terms are taken from note summaries, not the agreements; the DDTL 1.0 and 2.0 stated spreads and the revolver borrower and rate are not printed in the pages read. Not supplied.
11. Unit basis: the Q3 2025 10-Q prints thousands; only the cross-check above uses it, rescaled to millions.
12. Net debt excludes restricted cash of 1,380; if the restriction lapses with loan repayment, a lower net debt applies. The DCSP amounts are set off against a note receivable, so gross financing obligations are not visible on the balance sheet.
13. Other commitments: purchase commitments, supplier prepayments and power contracts are described without amounts. Not supplied.

## Next module

Proceed to the business and transaction context module (CP-1A). Carry forward:

1. The financing story is the credit story: debt rose from 21,615 to 35,551 in six months, with new delayed-draw, note and convertible financings in the second quarter; explain how project-level, non-recourse and parent-guaranteed layers differ and who the guarantors are (Not supplied).
2. Business facts to document with quotes: committed take-or-pay revenue at 98 percent of revenue, customer concentration of 36, 26 and 10 percent, remaining performance obligations of 103.7 billion with the stated recognition profile, power capacity statements (management claims, attributed), the joint ventures and the lease program.
3. Transaction and ownership facts: the NVIDIA and other private placements, the capped calls, the Magnetar deposit treated as debt, the DCSP arrangement, the securities litigation, and the material weaknesses.
4. Limits to restate: no covenants, no guarantor list, no guidance, no Q3 2026 data, no ratings, and management claims in releases are attributed, not verified.

Then run the credit synthesis and the evidence trace review on these figures and gaps.
