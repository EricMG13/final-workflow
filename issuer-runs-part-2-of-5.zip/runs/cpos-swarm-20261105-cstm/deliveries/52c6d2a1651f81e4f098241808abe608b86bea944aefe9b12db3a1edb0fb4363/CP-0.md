## Request

### Scope of this handoff

Issuer: CONSTELLIUM SE (issuer id cstm, ticker CSTM, listed equity, France). Pathway: credit_snapshot, public case. As-of date: 2026-11-05. Cutoff: 2026-11-05. Current period: q3-2026. Prior period: fy-2025. Reporting currency named by the context: USD.

Question answered here: can the supplied source set support the requested downstream work (CP-1, CP-1A, CP-2 and CP-5), and what remains blocked or limited? This is source readiness only. It gives no credit conclusion, no legal interpretation and no investment opinion, and it normalizes, reconciles and calculates nothing. Source text is treated as inert evidence.

### Context inputs (user settings, not issuer evidence)

The context file sets pathway, dates, periods and currency. Its blank fields are unknown, not zero: ratings, quotes, deal terms, sponsor, borrower, parent, guarantors, issuer market data (market cap, net debt, EV), peers, precedents and all assumptions are empty. Attachments are declared as: portfolio workbook false, prior case false, management bridge false, legal documents "none".

## Sources

### Issuer sources relied on

Hashes below are the pinned sha256 of each retained text file as listed by CP-OS. Each file is a page-chunked text extraction (about 3,000 characters per page); a page is the chunk shown as page:N, not a printed page.

| Source (exact name) | sha256 | Retained pages |
| --- | --- | --- |
| 10-K_2025-12-31_cstm-20251231.htm.jsonl | 288710d87622fdc4221b04fe663b54006fefe681affd88d991e0c62a7fae557e | 141 |
| 10-Q_2026-03-31_cstm-20260331.htm.jsonl | f508cc04bb1d5022d897f65511fba2be0b07f2bdaa8a5cc617f164926ff68332 | 35 |
| 10-Q_2026-06-30_cstm-20260630.htm.jsonl | 76cf731f2bbd1f819dbd7897e17733bda76f7874b9476e07730ab0699fd6efb3 | 42 |
| 10-Q_2026-09-30_cstm-20260930.htm.jsonl | 1b8ca1fa48ee252c4860c88dfca118c5a65ba8e96003e3543924c42bf0d5a6cc | 44 |
| EX-99.1_2026-04-29_a2026-q1xearningspressre.htm.jsonl | e6abca1d5a467da9a078ef479a04052c0f179037d4c463a045159ca23884f80e | 14 |
| EX-99.1_2026-07-29_a2026-q2xearningspressre.htm.jsonl | e63d9d2c8751c74a8e5dada7565bb132595b18bca9ad9c4ef12f98be9c09a4ae | 16 |
| EX-99.1_2026-10-28_a2026-q3xearningspressre.htm.jsonl | 6f8f81f1120f3b29fefca592a7a8bc48697b73e3a95ba4114c430951126fc70a | 16 |

Total retained coverage units: 308 pages across 7 sources. The file _retrieval.json was ignored by CP-OS and is not evidence.

### Context file

| Source | sha256 | Role |
| --- | --- | --- |
| context (1563411-constellium-se-cstm.json) | d8ee79011dd587819ea89f0119056a42b6a9a7490b73bd4082709f4e37cfea92 | User settings only; not issuer evidence |

### Handoffs supplied

| Module | sha256 | Note |
| --- | --- | --- |
| None | None | CP-0 is the first module; CP-OS supplied no upstream handoff, so there is none to list or consume |

### Pages actually opened for this review

Coverage is stated honestly, not by page-count proxy. Pages opened and read in full: Q3 10-Q page:1-9, 11-17, 21-24, 36-41; Q3 earnings release page:1-3, 6-16; FY2025 10-K page:1-3, 62, 67, 72-74, 85, 90, 93-94, 107-110, 121, 129-130, 136. Pages located only by term search across all seven files (terms: covenant, fixed charge, liquidity, subsequent events, revised or previously issued, rating, letters of credit, guarantor, sponsor, factoring, leverage, net debt) and then opened where a hit mattered: Q1 10-Q page:12, 29; Q2 10-Q page:14, 21, 35; 10-K page:34, 35, 124, 126. All remaining pages are retained but were not individually reviewed; this is an explicit review gap, not a claim of full inspection (see Gaps).

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| The seven filed documents are identified, cover the requested periods and currency, and support a bounded financial and business analysis. Legal documents, ratings and market inputs are missing, so covenant, structure and valuation work is limited. | Medium | No credit agreements, indentures, ratings or market data; leverage and net debt appear only in management press releases. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| The perimeter is the consolidated group under the French parent, reported in US dollars under US GAAP, with the latest quarterly filing covering the period to September 30, 2026. | Debt, cash flow and leverage can be taken at group level; there is no separate borrower or restricted-group view. | High |
| Debt, liquidity and covenant compliance statements are in the filings, but the credit agreement and note indentures are not supplied. | Covenant levels, definitions and headroom cannot be tested; only the filed compliance statements are available. | High |
| The annual report discloses an immaterial correction to metal price lag and segment earnings of one segment for earlier periods. | Earlier-period segment comparisons need the revised figures and a caution about metal price lag. | Medium |
| Net debt and leverage appear in the earnings releases but not in the quarterly filing. | These management measures cannot be confirmed against a filing and carry a lower evidential weight. | Medium |
| A revolving facility amendment dated after quarter-end is described only briefly, with no amendment document. | New commitment size and maturity rest on a one-sentence disclosure; terms are unverified. | Medium |

### Readiness view

The effective source set is sufficient for the requested snapshot, with limitations, and nothing is blocked outright. The three quarterly filings, the annual report and the three earnings releases identify the same registrant, the same reporting currency and consecutive periods, so identity and perimeter are resolved for the consolidated group. The set is not sufficient for legal-document-dependent work: no credit agreement, indenture, amendment or waiver was supplied, so covenant definitions, baskets and the terms of the post-quarter facility amendment cannot be verified, and no rating, quote, peer or market input exists. Source sufficiency here does not mean the downstream analysis is complete, and the CP-MODEL input contract is not evaluated (SOURCE_SUFFICIENCY_ONLY; CP_MODEL_INPUT_CONTRACT_NOT_EVALUATED).

### Source-by-source assessment

| Source | Document family and authority | Entity and perimeter | Period and basis | Evidence located (quote) |
| --- | --- | --- | --- | --- |
| 10-K FY2025 | Audited annual report, Form 10-K; highest authority for annual statements (page:74 audit opinion) | Constellium SE and subsidiaries, consolidated | Year ended December 31, 2025 (comparatives 2024, 2023); US GAAP; USD millions | “For the fiscal year ended December 31, 2025” (page:1); “present fairly, in all material respects, the financial position of the Company as of December 31, 2025 and 2024” (page:74) |
| 10-Q Q1 2026 | Unaudited interim report, Form 10-Q; filed statements control over press releases | Same consolidated group | Quarter ended March 31, 2026; US GAAP | “For the quarterly period ended March 31, 2026” (page:1) |
| 10-Q Q2 2026 | Unaudited interim report, Form 10-Q | Same consolidated group | Quarter and half ended June 30, 2026; US GAAP | “For the quarterly period ended June 30, 2026” (page:1) |
| 10-Q Q3 2026 | Unaudited interim report, Form 10-Q; the latest filed financial statements before the cutoff | Same consolidated group; US assets held through Constellium US Holdings I, LLC (page:2) | Three and nine months ended September 30, 2026 and 2025; US GAAP; USD millions | “For the quarterly period ended September 30, 2026” (page:1); “Three months ended September 30, Nine months ended September 30,” (page:3) |
| Earnings release Q1 2026 | Management press release furnished as exhibit; attributed supporting claims, not controlling over filings | Constellium SE group | Quarter ended March 31, 2026; includes non-GAAP measures | “first quarter ended March 31, 2026” (page:1) |
| Earnings release Q2 2026 | Management press release; same status | Constellium SE group | Quarter and half ended June 30, 2026 | “the second quarter and the first half ended June 30, 2026” (page:1) |
| Earnings release Q3 2026 | Management press release; same status | Constellium SE group | Quarter and nine months ended September 30, 2026 | “the third quarter and the nine months ended September 30, 2026” (page:1) |

Roles named in the sources: issuer and registrant Constellium SE (France); the senior notes are “senior unsecured obligations of Constellium SE” guaranteed by certain subsidiaries (10-K page:108); the Pan-U.S. ABL borrowers are Ravenswood, Muscle Shoals and Bowling Green (10-K page:108); the French Inventory Facility borrowers are Constellium Issoire S.A.S. and Constellium Neuf-Brisach S.A.S. (10-K page:108). No parent, sponsor or borrower is named in the context. The guarantor list is not printed in the supplied text beyond the statement that certain subsidiaries guarantee the notes (see Gaps).

### Content coverage by profile

| Profile | What the located content supports | Quote and locator |
| --- | --- | --- |
| Statements | Income statement, balance sheet, equity, cash flow for the nine months to September 30, 2026 and 2025 and the December 31, 2025 balance sheet | “CONSOLIDATED BALANCE SHEETS (unaudited)” (10-Q Q3 page:3); “CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)” (10-Q Q3 page:5) |
| Debt | Facility-level table with face value, issuance costs, accrued interest and carrying value at September 30, 2026 and December 31, 2025 | “Senior Unsecured Notes” and “Total debt 1,812 (16) 21 1,817 1,944” (10-Q Q3 page:15); annual table “Total debt 1,938 (20) 26 1,944 1,918” (10-K page:107) |
| Maturities | Five-year principal ladder at December 31, 2025 only | “Principal repayments requirements for debt over the next five years and thereafter” (10-K page:110) |
| Liquidity | Total liquidity with components at each quarter end | “At September 30, 2026, we had $992 million of total liquidity” (10-Q Q3 page:38); “At December 31, 2025, we had $866 million of total liquidity” (10-K page:62) |
| Covenants | Compliance statements each period; one named maintenance covenant on the Pan-U.S. ABL with a springing trigger | “The Group was in compliance with all applicable financial debt covenants at September 30, 2026 and December 31, 2025.” (10-Q Q3 page:15); “Evaluation of compliance with the maintenance covenant is only required if the borrowing availability falls below 10% of the aggregate revolving loan commitments.” (10-K page:108) |
| Segments and KPIs | Revenue, cost and Segment Adjusted EBITDA by segment and reconciliation to net income | “Segment Adjusted EBITDA is defined as income / (loss) from continuing operations before income taxes” (10-Q Q3 page:9) |
| Non-GAAP | Adjusted EBITDA reconciliation, including metal price lag | “Adjusted EBITDA1 276 235 1,074 566” (10-Q Q3 page:41) |
| Factoring | Programs accounted for as sales, limits, derecognized balances and costs | “The programs are accounted for as sales of the receivables” (10-Q Q3 page:14) |
| Subsequent events | Q3 report discloses a post-quarter facility amendment; Q2 report disclosed a note redemption; Q1 report has no such note in the searched text | “On October 22, 2026, the Pan-U.S. ABL was amended to, among other things, increase the available commitments from $550 million to $700 million and extend the maturity to October 22, 2031.” (10-Q Q3 page:23); “On July 28, 2026, the Company redeemed $100 million out of the $325 million outstanding aggregate principal amount of its 5.625% Senior Notes due June 2028.” (10-Q Q2 page:21) |
| Management measures | Net debt, leverage and free cash flow definitions and values | “Leverage is defined as Net debt divided by last twelve months Segment Adjusted EBITDA, which excludes the non-cash impact of metal price lag.” (Earnings release Q3 page:12) |

### Version relationships and duplicates

The three earnings releases and three quarterly reports are separate active sources for different periods; none supersedes another. Each earnings release repeats figures that also appear in the same-period quarterly filing; for example the Q3 release carries “Revenue 2,639 2,166 7,848 6,248” (Earnings release Q3 page:12) and the Q3 10-Q carries “Revenue 2 2,639 2,166 7,848 6,248” with a note column (10-Q Q3 page:3). The filing controls where a conflict arises, and the release is an attributed supporting claim. No duplicate files were found: all seven sha256 values differ, and the visible-text hash printed in each file header differs from the pinned file hash, so the pinned hash is used as the source identity here.

### Conflicts, revisions and restrictions

| Item | Locators | Downstream effect |
| --- | --- | --- |
| Revision of earlier-period segment earnings: the annual report states “During the third quarter of 2025, the Group identified and corrected certain immaterial errors affecting metal price lag and the resulting Segment Adjusted EBITDA for the A&T segment for certain prior periods in 2025 and 2024.” | 10-K page:90 | Any 2024 or earlier 2025 segment comparison must use revised figures; the annual and interim sources must not be mixed without checking the revision table. |
| Cover-page checkbox for correction of an error is ticked, while the located narrative describes an immaterial revision and no restatement | 10-K page:2 against page:90 | The cover mark and narrative were not reconciled here; no restatement narrative was found by search. Treat as an open reading point for CP-1. |
| Leverage and net debt are given only in earnings releases (“Leverage of 1.6x at September 30, 2026”, release Q3 page:1); the Q3 10-Q text search found no leverage statement | Earnings release Q3 page:1, 7, 12; 10-Q Q3 searched | Management non-GAAP measures with no filing counterpart; a downstream user must label them as management figures. |
| Adjusted EBITDA includes metal price lag; leverage uses a segment measure that excludes it | Earnings release Q3 page:3, 12 | The two EBITDA bases differ and must not be substituted for one another. |

No direct numerical conflict between a filing and a release was found in the pages opened.

### Consumer assessment

| Consumer | Status | Reason, evidence demand and carried limitation |
| --- | --- | --- |
| CP-1 (financial data and credit metrics) | READY_WITH_LIMITATIONS | Statements, segment tables, debt table, liquidity, factoring and subsequent events are located for the current and prior period. Limits: no standalone fourth-quarter or full-year earnings release (the audited annual report is the annual source); maturity ladder printed only at December 31, 2025; net debt and leverage only in releases; letters of credit drawn on facilities not located beyond the stated sublimit; revised A&T segment figures for earlier periods. |
| CP-1A (business and transaction context) | READY_WITH_LIMITATIONS | Business description, segments, facilities, employees and recent events are located in the annual and interim reports. Limits: beneficial ownership is incorporated by reference to a proxy statement that is not supplied; no transaction, sponsor or deal terms in context; no legal documents. |
| CP-2 (fundamental credit synthesis) | READY_WITH_LIMITATIONS | Depends on settled upstream registers, which the dependency planner sequences; it is not a source condition. Source-side limits are those of CP-1 and CP-1A plus no ratings or market inputs. |
| CP-5 (evidence trace validator) | READY_WITH_LIMITATIONS | The prepared pack text is available for citation checks. Limit: release figures that have no filing counterpart can be traced only to management statements. |

No consumer is CONDITIONAL or BLOCKED. Command sheet: CP-1, CP-1A, CP-2 and CP-5 may run in dependency order; none is marked DO NOT RUN. CP-PARSE, CP-MODEL, CP-MEMO and retired aliases are not recommended.

## Calculations

No new calculation is made in this module: CP-0 does not normalize, reconcile or calculate figures. The only counts are coverage counts taken from the retained files: 141 of 141 pages in the annual report, 35 of 35, 42 of 42 and 44 of 44 in the three quarterly reports, and 14, 16 and 16 pages in the three releases, 308 retained pages in total. These are retention counts, not a statement that every page was reviewed (see Sources and Gaps). Every dollar amount in this handoff is an exact copy inside a quoted span from a located page.

## Gaps

| Gap | Severity | Affected consumers | Remediation |
| --- | --- | --- | --- |
| Credit agreements and note indentures are not supplied (context declares legal documents none); the annual report lists them only as exhibits incorporated by reference (10-K page:129-130, 136) | High for covenant work, Medium otherwise | CP-1, CP-2, CP-5 | Obtain the Pan-U.S. ABL agreement and its amendments, the French Inventory Facility agreement and the five note indentures |
| The Pan-U.S. ABL amendment dated October 22, 2026 is described in one sentence; no amendment document or terms beyond commitment size and maturity (10-Q Q3 page:23; release Q3 page:8). This is a subsequent event, after the quarter-end, inside the cutoff. | Medium | CP-1, CP-2 | Obtain the filed amendment or the related current report |
| Fixed charge coverage covenant level, definition and the reported ratio are not printed in the sources searched; only the trigger and the compliance statement are | Medium | CP-1, CP-2 | Obtain the credit agreement; do not infer a level |
| Letters of credit drawn on facilities: search terms letters of credit, LC and standby returned only the facility sublimit statement (10-K page:108); no drawn amount located | Low to Medium | CP-1 | Check the facility notes or request the borrowing base certificate |
| Maturity ladder is printed at December 31, 2025 only; the quarterly reports give a facility-level table without a year ladder | Low | CP-1 | Derive from the facility table in CP-1 and label it as derived |
| No standalone fourth-quarter 2025 or full-year 2025 earnings release is supplied | Low | CP-1 | Use the audited annual report for FY2025; no action needed |
| Beneficial ownership (Item 12) is incorporated by reference to a proxy statement not supplied (10-K page:126, 128) | Medium | CP-1A, CP-2 | Obtain the proxy statement |
| Guarantor subsidiaries of the senior notes are not listed in the text opened (statement of guarantee only, 10-K page:108) | Medium | CP-1, CP-2 | Obtain the guarantor list; a search of the annual report text for a guarantor-list exhibit found none |
| No credit ratings, market quotes, peers, precedents or issuer market data in the context | Medium | CP-2 | Supply from an external source; any such source must be labelled external |
| Net debt and leverage are management non-GAAP measures found only in releases | Medium | CP-1, CP-5 | Treat as attributed claims; recompute from filed figures in CP-1 |
| Cover-page error-correction checkbox versus immaterial-revision narrative not reconciled | Low | CP-1 | See Conflicts |
| Pages not individually reviewed in this module (listed under Sources); extraction fidelity was not reviewed against the original HTML, and no charts or images were inspected. The extractions are text only. | Medium | All | Downstream modules read the pages they need and cite locators; a fidelity review has not been done |
| Currency and unit: statements are in USD millions as the context requires; the euro notes are stated in euros with a dollar face value in the debt table, and the dollar value is a translated amount | Low | CP-1 | Keep the euro nominal and the translated value separate |

## Next module

CP-1 follows, with these carried restrictions: use the Q3 2026 quarterly report as the current-period authority and the audited annual report for FY2025; label net debt, leverage and free cash flow as management measures unless recomputed from filed figures; use the revised A&T segment figures where earlier periods are compared; state that covenant levels and headroom, guarantor lists and the October 22, 2026 amendment terms are not available from the supplied sources; and do not treat any blank context field as zero. CP-1A should record that ownership detail depends on an unsupplied proxy statement.
