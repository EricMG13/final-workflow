## Request

Issuer: CVR ENERGY INC (CVR Energy, Inc.; NYSE: CVI; issuer id cvi). As-of date: 2026-11-05; evidence cutoff 2026-11-05. Pathway: credit_snapshot. Reporting currency USD, in millions unless a line says otherwise.

Question: does each material claim in the financial base, business context and credit synthesis handoffs rest on the evidence it names, and do the three tell one consistent story? The review traces claims to the pinned filings and releases, recomputes derived figures, compares figures and scope across the handoffs, grades the set and states whether committee use is permitted, restricted or blocked. The source readiness handoff is the gate and is not itself graded. The review changes no figure in the handoffs; where it finds a point the handoffs should have made, it says so here because the accepted handoffs cannot be edited.

## Sources

### Issuer sources used to trace claims

| Source name | sha256 | Role in the trace |
| --- | --- | --- |
| 10-K_2025-12-31_cvi-20251231.htm.jsonl | 11b2ae0e09456bfa771d4cab8a17d5e6eecebad270822a0aa27a6321ae3e1326 | FY2025 statements, debt note, obligations table, governance text |
| 10-Q_2026-03-31_cvi-20260331.htm.jsonl | 0d5ec22f9043f7de61004c1d3fc3166812200367bbaae195e5e1fbdd81619bfc | Q1 2026 cash, debt, facilities, cash interest, Adjusted EBITDA |
| 10-Q_2026-06-30_cvi-20260630.htm.jsonl | 358aaec14a40e7fb2473ba1f5c1574588c88cdab98ea0a6156b8c6e07d430343 | Q2 2026 equivalents; management change exhibits |
| 10-Q_2026-09-30_cvi-20260930.htm.jsonl | c1bc2003ec1856161a58b4e8e6474dd136cd1e6864fe6be884dd4ce7689172a8 | Q3 2026 statements, notes, liquidity, acquisition note, risk factors |
| EX-99.1_2026-04-29_exhibit991-cviq12026earnin.htm.jsonl | ec1426d7dc5a0e9978dd49bcfe1d59907ecfcc63064a0912a9028158f50040e7 | Q1 release, management attribution |
| EX-99.1_2026-07-29_exhibit991-cviq22026earnin.htm.jsonl | 1459a1187a6f9d055543784814ad9e46560c18ce90ff9327aed9062ea6d7d429 | Q2 release, management attribution |
| EX-99.1_2026-11-03_d897437dex991.htm.jsonl | a8afdbbc4ca0ef0b0aa3933661eb6fa3f49fab4f6b6643dc433309cf920a00ae | Q3 release, operating statistics and management language |

### Supplied handoffs

| Module | sha256 | Role |
| --- | --- | --- |
| CP-0 | 1a8afb0886e9641787b9eba27d5f0b727ffb872f803108f1a4c711fde39ffcd9 | Gate; limits carried forward |
| CP-1 | 9c164a98bc29dc8cc35cb5f96e9f8a657f07617efbc98c8c5211d463b38e186e | Evaluated |
| CP-1A | e11038a3e84cc7ca65afae07f6ea044a394b2b341c239b0cdbd893b749d4ccc0 | Evaluated |
| CP-2 | fbf82cc4a311b78a88fb80beaa24473a87779fff9bbde5ffada078f4d16384e1 | Evaluated |

The context file (sha256 90a4adce7121ac13b0bc8c46b1ee93789832813a3c6223523e8f15963f3f61b5) is user settings, not evidence; its blank fields are not treated as zero.

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| The figures and quotes in the three analytical handoffs trace to the filings and recompute correctly, and they agree with each other. Committee use is restricted because decision-critical documents are missing and the review is not independent. | Medium | Covenant levels, debt documents, the acquisition papers and target earnings are not supplied, and the same session wrote and checked the handoffs. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| All 73 quoted spans in the financial base and all 61 in the business context were found on the page cited, and every derived figure recomputed. | Reported numbers can be relied on as stated and labelled. | High |
| Headline liquidity of USD 1,853 million includes USD 158 million of cash and a USD 45 million facility that belong to the consolidated CVR Partners entity. | Liquidity available to the parent is nearer USD 1,650 million, before the minimum cash condition. | Medium |
| Two statements are only partly supported: the chief executive change date, inferred from exhibits, and the unsecured status of the 2031 and 2034 notes. | Wording points; the direction of the credit view is unaffected. | Medium |
| No contradiction between the three handoffs was found, and every upstream limitation is carried forward. | The set tells one consistent, standalone story. | Medium |

### Evidence trace view

The evidence trace holds. Each material claim in the financial base, business context and credit synthesis handoffs was matched to a located source span or to a recomputation from located figures, and the three handoffs agree on every shared figure, period and perimeter label. The credit view of the synthesis, a strong standalone profile that is conditional on a pending acquisition, with Medium confidence, follows from its cited basis and is not overstated. Three points need wording care rather than correction. The headline liquidity figure includes cash and a facility that belong to the consolidated CVR Partners entity, and the synthesis mentions the cash but not the facility. The chief executive change is inferred from exhibits dated June 18, 2026 and from who is quoted in the April and July releases, not from a stated effective date. The unsecured status of the 2031 and 2034 notes rests on the guarantee wording, with the title of the 2028 notes stating it directly. No claim is unsupported and no contradiction between modules was found. The integrity verdict for the evaluated set is Restricted, not Committee Ready, because the conclusions that matter most to a creditor after the transaction, namely covenant headroom, ranking after closing and pro forma leverage, rest on documents and earnings that are not in the sources. The review itself is limited: it was done in the same session as the analysis, from the same extraction text, and page locators are extraction chunks rather than printed pages.

### Evaluated set (inputs and status)

| Input | Status | Evaluated | Notes |
| --- | --- | --- | --- |
| CP-0 source readiness | Accepted; gate | No | Executed documents, acquisition papers and covenant levels flagged as not supplied |
| CP-1 financial base | Accepted | Yes | Trailing figures built from FY2025 and interim comparatives; segment re-cut labelled |
| CP-1A business and transaction context | Accepted | Yes | Readiness judgment for the synthesis: ready with limitations |
| CP-2 credit synthesis | Accepted | Yes | Confidence Medium, inside the cap set by the upstream limits |

All four are current for the as-of date 2026-11-05 and use USD millions. No input is stale; the latest source is dated 2026-11-03.

### Material claim register and support review

Verdicts: supported (the named evidence states the claim), partly supported (carries part of it or carries it only with a qualification the claim omits), unsupported (does not carry it).

| Claim | Module | Evidence traced | Verdict | Reviewer note |
| --- | --- | --- | --- | --- |
| Total debt including finance leases 1,765 at December 31, 2025 and 1,781 at September 30, 2026 | CP-1, CP-2 | 10-K page:151; 10-Q Q3 page:16 | Supported | Carrying basis; excludes pending acquisition |
| Trailing Adjusted EBITDA 393 (FY2025), 406, 517 and 919 (Q1 to Q3 2026) | CP-1, CP-2 | 10-K page:115; 10-Q Q1 page:49; 10-Q Q2 page:49; 10-Q Q3 page:56 | Supported | Recomputed; comparatives taken from the 2026 reports |
| Gross leverage 4.49x, 4.39x, 3.45x, 1.94x; net 3.19x, 3.13x, 2.02x, 0.55x | CP-1, CP-2 | Inputs above plus cash on balance sheets | Supported | Recomputed to two decimals |
| Cash interest cover 2.77x, 3.01x, 4.01x, 6.96x | CP-1, CP-2 | Cash paid for interest: 10-K page:177; 10-Q Q1 page:25; 10-Q Q2 page:25; 10-Q Q3 page:27 | Supported | Trailing cash interest 142, 135, 129, 132 recomputed |
| Liquidity 807, 1,101, 1,327, 1,853 | CP-1, CP-2 | Cash and facility tables: 10-K page:151; 10-Q Q1 page:14; 10-Q Q2 page:14; 10-Q Q3 page:16, page:59 | Supported | Ties to the company statements of about 1.1 billion, 1.3 billion, 1.9 billion and 807 |
| Liquidity is usable by the parent | CP-1, CP-2 | 10-Q Q3 page:8; 10-K page:158 | Partly supported | See finding on the CVR Partners cash and facility |
| No note principal due before 2028; 733 in 2028, 600 in 2031, 400 in 2034 | CP-1, CP-2 | 10-Q Q3 page:16 | Supported | Principal total 1,733; ABLs undrawn |
| Free cash flow after capex and turnaround 872 (nine months 2026), 816 (trailing), negative 238 (FY2025) | CP-1, CP-2 | 10-K page:133; 10-Q Q3 page:10 | Supported | Recomputed |
| Claims outside debt: RFS 230, derivative liabilities 160 and 18, accrued taxes 132, transport 995, purchases 165 | CP-1, CP-2 | 10-Q Q3 page:15, page:19; 10-K page:121 | Supported | Transport and purchase figures are December 31, 2025 |
| Adjusted EBITDA adds back unrealized derivative losses 278 and differs from reported trailing EBITDA 964 | CP-1, CP-2 | 10-Q Q3 page:56; 10-K page:115 | Supported | Recomputed 591 + 913 − 540 |
| Acquisition about 4.2 billion in cash, bridge up to 2.5 billion, equity 800 plus up to 500, ABL increase of 550 to 1.1 billion, minimum cash 500, termination fees 6%, 4% or 2% | CP-1, CP-1A, CP-2 | 10-Q Q3 page:11, page:12, page:31, page:32 | Supported | Filing summary only; agreement not supplied |
| Existing unsecured notes would be effectively subordinated to a larger secured pool after closing | CP-1A, CP-2 | 10-Q Q3 page:32 (senior secured bridge and ABL); 10-K page:151, page:153 | Partly supported | Tagged Analyst Interpretation; unsecured status of the 2031 and 2034 notes is inferred from guarantee wording |
| Icahn Enterprises owns about 71% of the stock; controlled company | CP-1A, CP-2 | 10-Q Q3 page:11; 10-K page:78 | Supported | |
| Chief executive changed in 2026; interim chief financial officer | CP-1A, CP-2 | 10-Q Q2 page:57; 10-Q Q3 page:73; Release Q1 page:2; Release Q2 page:1 | Partly supported | Effective date and reason are not stated; inferred from exhibits and release attributions |
| Crack spreads rose after the Iran war began on February 28, 2026 | CP-1A, CP-2 | 10-Q Q3 page:35, page:38 | Supported | Management discussion, tagged Management Language |
| Two reportable segments in 2026, three in FY2025 | CP-1, CP-1A | 10-K page:88; 10-Q Q3 page:26, page:33 | Supported | Retrospective recast stated for prior period activity |
| Gunvor covered about 23% of 2025 crude purchases; top customers 12% and 28% | CP-1A, CP-2 | 10-K page:170, page:22, page:28 | Supported | |
| Dividends 453 (2023) and 151 (2024), suspension in October 2024, 20 paid in nine months 2026 | CP-1A, CP-2 | 10-K page:133; 10-Q Q3 page:61, page:28 | Supported | |
| Sensitivities: 4.53x, 1.28x, 7.61x, 3.26x, 4,281 and 4.66x | CP-2 | Recomputed from the financial base | Supported | Labelled illustrative and a mechanical bound |
| Fundamental credit view strong standalone, conditional, Medium confidence | CP-2 | The rows above | Supported | Not above what the basis carries |

### Citation trace

| Check | Method | Result |
| --- | --- | --- |
| Verbatim quotes in the financial base | Each quoted span in the evidence register searched on the page named in its row | 73 of 73 found |
| Verbatim quotes in the business context | Same method | 61 of 61 found; one span has a line break in the source between the label and its figures, which the quoting rule allows |
| Figures that appear in the sources | Each comma-grouped or decimal number in the three handoffs searched in all seven source texts | Figures not found in the sources are all derived ones (sums, trailing totals, ratios, liquidity totals, run-rate coupon) shown in Calculations tables, or maturity-year labels |
| Cutoff | Dates after 2026-11-05 | Only labelled terms: dividend record date November 16, 2026 and payment date November 23, 2026, note maturities in 2031 and 2034 |
| Currency and period labels | Header and row labels read | USD millions throughout; trailing, nine-month, quarter and year figures labelled; no nine-month amount used as a full-year figure |
| Subsequent events | Acquisition of November 2, 2026 and dividend declaration of November 3, 2026 | Both flagged as after the September 30, 2026 balance sheet and kept out of period figures |

### Figure identity across modules

| Figure | CP-1 | CP-1A | CP-2 | Result |
| --- | --- | --- | --- | --- |
| Total debt at September 30, 2026 | 1,781 | Not stated | 1,781 | Identical |
| Trailing Adjusted EBITDA | 919 | Not stated | 919 | Identical |
| Gross and net leverage | 1.94x and 0.55x | Not stated | 1.94x and 0.55x | Identical |
| Cash interest cover | 6.96x | Not stated | 6.96x | Identical |
| Liquidity | 1,853 | Not stated | 1,853 | Identical |
| Maturity in 2028 | 733 | Not stated | 733 | Identical |
| Acquisition consideration, bridge, equity | 4.2 billion, 2.5 billion, 800 and 500 | Same | Same | Identical |
| Minimum cash | 500 | 500 | 500 | Identical |
| Icahn Enterprises ownership | Not stated | 71% | 71% | Identical |
| Reported trailing EBITDA | 964 | Not stated | 964 | Identical |

### Input currency and scale

All inputs are USD millions; share counts and per-share amounts are not used in the analysis. No scale mismatch was found: statement amounts are in millions as printed, and the acquisition amounts are written in billions only where the source prints billions.

### Gap propagation

| Upstream limitation | Carried by CP-1 | Carried by CP-1A | Carried by CP-2 |
| --- | --- | --- | --- |
| Covenant levels not supplied | Yes | Yes | Yes |
| Executed indentures and credit agreements missing | Yes | Yes | Yes |
| Acquisition papers, target earnings and financing size missing | Yes | Yes | Yes |
| Segment re-cut between FY2025 and 2026 | Yes | Yes | Yes |
| Ratings and market data blank in context | Yes | Yes | Yes |
| Extraction fidelity not reviewed | Yes | Not stated as a separate item | Yes |
| Q3 2025 balance sheet not in pack | Yes | Not applicable | Yes |

### Findings register

| Finding | Type | Severity | Modules | Effect |
| --- | --- | --- | --- | --- |
| Headline liquidity of 1,853 includes 158 of cash in the consolidated CVR Partners entity and a 45 CVR Partners ABL that, per the 10-K, may be used for the general corporate purposes of CVR Partners and its subsidiaries. Excluding both gives 1,650 (recomputed here), before the 500 minimum cash condition, which overlaps cash and is not additive | Scope of a figure | MINOR | CP-1, CP-2 | CP-1 flags the VIE cash inside the liquidity row; CP-2 mentions the cash but not the facility. Direction of the credit view unchanged |
| The chief executive change is dated by exhibits (June 18, 2026) and release attributions, not by a stated effective date or reason | Partly supported claim | MINOR | CP-1A, CP-2 | Wording; the filings do not state the cause |
| The unsecured status of the 2031 and 2034 notes is inferred from guarantee wording on a senior unsecured basis; the 2028 notes are titled senior unsecured | Partly supported claim | MINOR | CP-1A, CP-2 | Supports the effective subordination reading, which is tagged Analyst Interpretation |
| Trailing Adjusted EBITDA and cash interest use 2025 interim comparatives printed in the 2026 reports; the original 2025 quarterly filings are not in the pack, so a later revision of a 2025 figure cannot be excluded | Input limitation | MINOR | CP-1, CP-2 | Consolidated Adjusted EBITDA is not affected by the segment re-cut; definition unchanged between reports |
| Source conflicts on segment basis and on segment debt rounding are logged, not reconciled | Source conflict | MINOR | CP-1, CP-1A | Carried; no figure depends on the unreconciled item |
| The review is not independent of the authors | Process limitation | MATERIAL | All | A second reviewer is still needed before external use |

### Cross-module contradictions

None found. Pairs examined and found consistent: the improvement in leverage in CP-1 against the cautious wording in CP-2 that it came from earnings rather than repayment (total debt moved only from 1,765 to 1,781); strong liquidity in CP-1 against the minimum cash condition and VIE cash in CP-1A and CP-2; the expected closing before the end of 2026 against the 270-day outside date in CP-1A; supportive equity commitment from the controlling holder against the mixed distribution history, both tagged and not netted; the sponsor behaviour table, which finds no priming or extraction, against the absence of indentures, which is carried as a gap rather than as evidence of absence.

### Verdict consistency

The verdicts agree across modules for every shared claim. CP-2's confidence of Medium is no higher than the readiness judgment of ready with limitations allows, and its gaps ledger matches the inherited gaps.

### Contrary evidence and what would change the view

The strongest evidence against a cautious reading is that nine-month 2026 free cash flow of 872 and trailing Adjusted EBITDA of 919 are real cash and earnings, that debt is little changed, that no note principal is due before 2028, and that the controlling holder has committed equity. The evidence against a comfortable reading is that the improvement comes from the numerator. What would make the supportive case win: a permanent financing and equity package that holds post-closing leverage near the standalone level, clearance of the antitrust review, and margins staying above mid-cycle through the first quarters after closing. Downside chain with observable triggers: the initiating condition is a normalization of crack spreads or an end to Middle East supply disruption, which cuts refining margin per barrel first, then Adjusted EBITDA and free cash flow; the financial transmission is a return of leverage toward the FY2025 level (4.53x on current debt in the CP-2 sensitivity), with RFS purchases, derivative settlements and tax payments drawing on the 1,853 of liquidity; the refinancing consequence is the 364-day bridge and the 733 maturing in 2028. Triggers to watch: Group 3 crack spreads, RIN prices and the D.C. Circuit outcomes, antitrust clearance, launch and pricing of the permanent financing, and the covenant certificates once obtainable.

## Calculations

Independent recomputation from the cited inputs. All matched the stated value.

| Figure | Inputs | Recomputed | Stated in handoffs |
| --- | --- | --- | --- |
| Trailing Adjusted EBITDA | 393 + 37 − 24; 393 + 246 − 122; 393 + 828 − 302 | 406; 517; 919 | 406; 517; 919 |
| Trailing cash interest | 142 + 40 − 47; 142 + 60 − 73; 142 + 106 − 116 | 135; 129; 132 | 135; 129; 132 |
| Net debt | 1,765 − 511; 1,784 − 512; 1,783 − 737; 1,781 − 1,278 | 1,254; 1,272; 1,046; 503 | 1,254; 1,272; 1,046; 503 |
| Gross leverage | 1,765 / 393; 1,784 / 406; 1,783 / 517; 1,781 / 919 | 4.49; 4.39; 3.45; 1.94 | 4.49; 4.39; 3.45; 1.94 |
| Net leverage | 1,254 / 393; 1,272 / 406; 1,046 / 517; 503 / 919 | 3.19; 3.13; 2.02; 0.55 | 3.19; 3.13; 2.02; 0.55 |
| Cash interest cover | 393 / 142; 406 / 135; 517 / 129; 919 / 132 | 2.77; 3.01; 4.01; 6.96 | 2.77; 3.01; 4.01; 6.96 |
| Liquidity | 511 + 248 + 48; 512 + 539 + 50; 737 + 540 + 50; 1,278 + 530 + 45 | 807; 1,101; 1,327; 1,853 | 807; 1,101; 1,327; 1,853 |
| Adjusted EBITDA tie-out | 913 − 190 + 278 − 173; 804 − 314 + 127 − 35; 591 − 262 − 4 + 66 + 2; 540 − 271 + 6 + 27 | 828; 582; 393; 302 | 828; 582; 393; 302 |
| Quarterly sum of Adjusted EBITDA | 37 + 209 + 582 | 828 | 828 (nine months) |
| Reported trailing EBITDA and cover | 591 + 913 − 540; 964 / 132 | 964; 7.30 | 964; 7.30 |
| Principal outstanding | 183 + 600 + 400 + 550; 733 + 600 + 400 | 1,733 | 1,733 |
| Free cash flow | 1,026 − 152 − 2; 144 − 185 − 197; 1,026 − (185 + 152 − 130) − (197 + 2 − 196) | 872; −238; 816 | 872; −238; 816 |
| Run-rate coupon on notes | 600 × 7.500% + 400 × 7.875% + 183 × 5.750% + 550 × 6.125% | 120.71 | 120.71 |
| CP-2 sensitivities | 1,781 / 393; 503 / 393; 919 / 120.71; 393 / 120.71; 1,781 + 2,500; 4,281 / 919 | 4.53; 1.28; 7.61; 3.26; 4,281; 4.66 | Same |
| Liquidity excluding CVR Partners cash and facility (new in this review) | 1,853 − 158 − 45 | 1,650 | Not stated |
| Cash above the minimum cash condition (CP-1) | 1,278 − 500 | 778 | 778 |

## Gaps

| Gap | Severity | Affects | Action |
| --- | --- | --- | --- |
| Covenant levels, executed indentures and credit agreements, guarantor map not supplied | High | CP-1, CP-2; any covenant, ranking or recovery work | Obtain the executed documents |
| Acquisition agreement, commitment letter, target earnings, permanent financing size and total sources and uses not supplied | High | CP-1A, CP-2; any post-closing view | Obtain the November 3, 2026 current report and target financials |
| Review not independent of the authors; same extraction text used; locators are extraction chunks | Medium | All | Second reviewer to compare the handoffs with the original filings |
| Original 2025 quarterly filings not in the pack | Low | Trailing figures | Use as labelled, or add the filings |
| Table and image content read as extracted text; no fidelity review of the extraction | Low | All | Spot-check key tables against the original filings |
| Ratings, quotes and valuation inputs blank in the context | Medium | CP-2 | Supply if needed |

## Next module

None remains in the selected set. The integrity verdict is Committee use restricted: the research may support a screening view of standalone liquidity, maturities, earnings direction, business risk and the existence and mechanics of the pending acquisition, with the stated labels, but should not support covenant, ranking after closing, recovery or pro forma leverage conclusions until the gaps above are closed. Next actions in order: obtain the acquisition agreement and November 3, 2026 current report; obtain the executed indentures and asset based loan agreement; obtain target refinery financials and the permanent financing terms; have a second reviewer compare the handoffs with the original filings before external use.
