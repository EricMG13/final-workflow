# CP-1A business and transaction context: Energy Transfer LP (et)

## Request

Module CP-1A for Energy Transfer LP (issuer id et, ticker ET), as of 2026-11-05, pathway credit_snapshot, information cutoff 2026-11-05. Current period Q3 2026; prior period FY2025; reporting currency USD. Question: which transaction, business, ownership and operating facts matter most to a creditor of the Energy Transfer parent, and how do they reach leverage, liquidity, refinancing and creditor control? Required decision drivers: transaction and ownership structure; business and operating model; credit-relevant history or change.

This handoff consumes CP-0 (source readiness, READY_WITH_LIMITATIONS) and CP-1 (financial base). Carried forward from CP-0 and CP-1: the 10-K and 10-Qs control statement facts and the releases are issuer non-GAAP; consolidated debt combines the parent with Sunoco LP and USAC, which have separate facilities; the issuer changed state of organisation and exchange in 2026 and only cover pages and one cross-reference show it; executed debt documents and the partnership agreement are not supplied. Figures from CP-1 are used only as references and are labelled "CP-1". No peer ranking, instrument recommendation or recovery conclusion is made.

## Sources

### Issuer sources relied on

| Source (exact name) | sha256 | Used for |
| --- | --- | --- |
| 10-K_2025-12-31_et-20251231.htm.jsonl | cf6ec450a74c280b3feab654167ed9d76760431021a13bf17a88d72b8532eaa7 | Business description, segments, strategy, governance risk factors, acquisitions note, debt note, repurchase program, employees |
| 10-Q_2026-03-31_et-20260331.htm.jsonl | 204d33e965723c9110a8bd3c410929503a162c990398e4a307e9e4585208124c | Cover page (state and exchange) at the first quarter of 2026 |
| 10-Q_2026-06-30_et-20260630.htm.jsonl | f6fbfa69a08a1bbb53482543b3abf672768e886f0ec8d32dd533da3f97f4bf88 | Cover page (state and exchange) at the second quarter of 2026 |
| 10-Q_2026-09-30_et-20260930.htm.jsonl | b99e2e6cdfbc85d8be8a5393c48692fdcdcd98f8ad63f20f2e4b37b17c6562f1 | 2026 acquisitions, debt transactions, equity, litigation, recent developments, subsequent events |
| EX-99.1_2026-05-05_ex991eterq12026.htm.jsonl | 28e020c73aad041b3d8d17b54f534d805074c7d2b4b4b027cc87b57e5e12fd7c | First-quarter 2026 listing label |
| EX-99.1_2026-08-04_ex991eterq22026.htm.jsonl | ee1907b3dce0abf5f0cf3c0b28a73722fa7c995776f463ee976582a26da21fa9 | Second-quarter 2026 listing label |
| EX-99.1_2026-11-03_ex991eterq32026.htm.jsonl | 5531a7cf0a40c534ed0feab25ecafdebb29b6fb0df1d6b068954124b5c1f91f7 | Operating highlights, growth projects, guidance, segment results |

Run context (settings, not issuer evidence): context sha256 dfad783f6af55323b89ba2b387376722ec78e773820c07687193a91e09314cf8. The context names no sponsor, no guarantors, no ratings and no transaction terms.

Locators are the file name or short name (10-K, Q1 10-Q, Q2 10-Q, Q3 10-Q, Q1 release, Q2 release, Q3 release) and `page:N`, the chunk number inside the file.

### Supplied handoffs

| Module | sha256 | Use |
| --- | --- | --- |
| CP-0 | 1b2196fae78086f62479df5a2fd3f99eb6278b9f99a6e4364bc9961bc241c594 | Source readiness, identity and perimeter points, gaps |
| CP-1 | e1f728d8ef2389dd86a9731e74ebfa406b4f14ddfa5f40add9ef875434607923 | Financial base, debt register, liquidity, leverage and coverage, cash flow, subsequent events |

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| A diversified US midstream partnership with eight segments, controlled through its general partner by one individual, is growing by acquisition, including a pending 2.63 billion US$ deal, while its state and exchange changed in 2026. | Medium | The partnership agreement, credit documents and the filing recording the 2026 change are not supplied, so control rights and creditor protections rest on summaries. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| No customer exceeded 10 percent of revenue and the largest segment was 24.3 percent of Q3 2026 Adjusted EBITDA; the Sunoco LP segment supplied the largest part of growth. | Broad asset diversity supports earnings durability, while a large part of earnings growth sits in a subsidiary with its own creditors. | Medium |
| One individual owns 81.2 percent of the general partner and all Class A units, about 20 percent of votes, and unitholders cannot elect the general partner. | Creditors rely on contract terms, not governance rights, to protect their position. | Medium |
| Acquisitions continued: Parkland in 2025, J-W Power, TanQuid, Delta and Offen in 2026, and Vaquero pending with 1.95 billion US$ of cash. | Cash acquisitions add to borrowing needs at the parent and at Sunoco LP and USAC. | Medium |
| In 2026 the parent redeemed 900 US$m of Series H preferred units, funded in part by 1,750 US$m of junior subordinated notes issued in July. | Perpetual preferred equity was replaced by debt-ranking claims below senior notes, raising debt-type obligations. | Medium |
| The cover pages show a change from Delaware to Texas and from the New York Stock Exchange to the Texas Stock Exchange during 2026. | Whether obligors or indenture parties changed is unresolved and must be confirmed before structural work. | Low |

### Business and transaction view

Energy Transfer LP is a large, diversified midstream operator whose eight reportable segments cover natural gas gathering, processing and transportation, NGL and refined products, crude oil, and two publicly traded consolidated subsidiaries: Sunoco LP (fuel distribution and terminals) and USAC (compression). The 10-K states that no customer individually accounted for more than 10 percent of revenue in FY2025, and in Q3 2026 no segment contributed more than a quarter of Adjusted EBITDA on the figures in CP-1, so concentration risk by customer or segment is limited on the documents read. The creditor-relevant features are three. First, change: Sunoco LP acquired Parkland on October 31, 2025, which enlarged that segment's revenue and earnings (it supplied 560 US$m of the 1,193 US$m increase in Q3 Adjusted EBITDA in CP-1) and added subsidiary debt, so the reported leverage improvement depends on a subsidiary with separate creditors. Second, a continuing programme of acquisitions and growth capital: J-W Power, TanQuid, Delta and Offen in 2026, Vaquero agreed on October 6, 2026 for about 2.63 billion US$ (1.95 billion US$ cash plus about 33.3 million new common units), growth capital guided at 5.4 billion to 5.6 billion US$ for 2026 and about 7 billion US$ for 2027. Third, structure and control: the parent's senior notes are unguaranteed by subsidiaries, a single individual controls the general partner, and the issuer's state of organisation and exchange changed in 2026 without a supplied explanation.

What is documented is stated as such below; management language (for example "exceptional product and geographic diversity") is quoted and not adopted. Nothing here is an opinion on creditworthiness. The sponsor field in the context is blank, which is not evidence that no controlling holder exists: the 10-K identifies one.

### Company and operating model

| Area | Fact | Category | Source locator | Mechanic and credit implication |
| --- | --- | --- | --- | --- |
| Core activities | "The primary activities in which we are engaged, which are located in the United States, are as follows: •natural gas operations, including the following: ◦natural gas midstream and intrastate transportation and storage; ◦interstate natural gas transportation and storage; and •crude oil, NGL and refined products transportation, terminalling services and acquisition and marketing activities" | Documentary Fact | 10-K page:6 | Multi-commodity network; earnings depend on volumes, capacity reservation and marketing margins rather than one product |
| Intrastate gas | Approximately 12,200 miles of intrastate pipelines with approximately 24 Bcf/d of capacity; customers pay "a demand fee, which is a fixed fee for the reservation of an agreed amount of capacity" plus transportation fees and fuel retention | Documentary Fact | 10-K page:7 and page:8 | Demand fees give contracted revenue visibility; volume-based fees and gas sales add exposure to throughput and spreads |
| Interstate gas | Approximately 20,090 miles of interstate pipelines with approximately 20.1 Bcf/d of capacity, plus about 7,080 miles through joint ventures; rates regulated by the FERC | Documentary Fact | 10-K page:8 and page:39 | Regulated cost-of-service and negotiated rates stabilise cash flow but face rate-case risk; Panhandle's rate proceedings are on appeal (Q3 10-Q page:60) |
| Lake Charles LNG | Import and regasification terminal with all revenue from "long-term contracts with a wholly owned subsidiary of Royal Dutch Shell plc"; liquefaction development suspended in December 2025 and several offtake agreements terminated | Documentary Fact | 10-K page:9 | Regasification income depends on one counterparty; suspension avoids a large capital commitment, a point for capital discipline |
| Midstream | Gathering, treating and processing with aggregate processing capacity of approximately 13.5 Bcf/d; results "derived primarily from margins we earn from natural gas volumes that are gathered, transported, purchased and sold" | Documentary Fact | 10-K page:10 | Margin exposure to volumes and NGL and gas prices; producer drilling activity is a driver |
| NGL and refined products | About 5,750 miles of NGL pipelines, Mont Belvieu fractionation of 1.15 MMBbls/d, working NGL storage of about 63 MMBbls; revenue "principally generated from fees charged to customers under dedicated contracts or take-or-pay contracts" | Documentary Fact | 10-K page:10 and page:11 | Fee-based contracts with minimum commitments support cash conversion; the segment was the largest contributor to Q3 2026 Adjusted EBITDA (Calculations C2) |
| Crude oil | More than 18,000 miles of crude trunk and gathering pipelines, equity stakes in seven pipeline systems and about 73 MMBbls of terminal storage; tariffs filed with the FERC and state regulators, plus acquisition and marketing | Documentary Fact | 10-K page:12 | Tariff income is stable; marketing margin is commodity-spread dependent; Bakken Pipeline carries separate project debt |
| Fuel distribution | Sunoco LP distributes "over 15 billion gallons annually to approximately 11,000 Sunoco and partner branded locations"; acquired Parkland on October 31, 2025 with operations in 26 countries | Documentary Fact | 10-K page:13 | High-revenue, thin-margin distribution; revenue and margin are exposed to fuel prices, foreign exchange (Canadian dollar functional currency for Parkland) and refinery risk |
| Compression | USAC provides compression services in unconventional plays, "primarily in connection with infrastructure applications" | Documentary Fact | 10-K page:13 | Contracted fee income linked to gathering activity; separate credit facility and notes |
| Revenue mix | Gathering, transportation and other fees were 14.5 percent of FY2025 total revenues and 10.0 percent for nine months 2026 (Calculations C1); the rest is product sales including refined products, crude, NGL and natural gas | Analyst Interpretation | 10-K page:287; Q3 10-Q page:4 | Revenue is mostly pass-through product sales, so revenue growth overstates earnings growth; margin analysis must use Adjusted EBITDA (CP-1) |
| Customers | "During the year ended December 31, 2025, none of our customers individually accounted for more than 10% of our consolidated revenues." | Documentary Fact | 10-K page:39 | Low single-customer concentration at the consolidated level; segment- or contract-level concentration is Not supplied |
| Segment balance | Q3 2026 Segment Adjusted EBITDA: NGL and refined products 1,224, Sunoco LP 1,049, crude oil 871, midstream 864, interstate 500, intrastate 346, USAC 198, all other (21), total 5,031; management says "no single business segment contributing more than one-third" | Management Language, checked against Documentary Fact | Q3 release page:4 and page:11; CP-1 | The largest segment is 24.3 percent (C2), consistent with the claim; Sunoco LP is 20.9 percent and carries its own creditors |
| Cost structure | FY2025 cost of products sold 63,495, operating expenses 5,867, selling, general and administrative 1,180 against revenues of 85,536 | Documentary Fact | 10-K page:287 | Cost of products sold is 74.2 percent of revenue (C3), so margin depends on spreads, with fixed operating cost a smaller part |
| Capital spending | Expected 2026 capital expenditure of 5,250 growth and 1,150 maintenance excluding Sunoco LP and USAC, per the 10-K; later guidance of "$5.4 billion to $5.6 billion in growth capital for 2026 and approximately $7 billion for 2027" | Documentary Fact; Management Language for guidance | 10-K page:201; Q3 release page:2 | Growth capital of about 7 billion US$ in 2027 exceeds the 2026 range, so funding needs persist alongside distributions (CP-1 shows an LTM shortfall after distributions) |
| Working capital | Net change in operating assets and liabilities: FY2025 outflow of 1,976; nine months 2026 inflow of 784 (CP-1) | Documentary Fact | 10-K page:289; Q3 10-Q page:7 | Operating cash flow is sensitive to working capital swings tied to commodity prices |
| Growth projects | Hugh Brinson Pipeline Phase I placed in full service September 1, 2026 and Phase II due in the first quarter of 2027; Mustang Draw II plant in service in October; Bear II plant planned for the third quarter of 2027; South Mississippi Pipeline FID at about 1.6 billion US$ with Energy Transfer "likely" a 51 percent owner; Frac X planned for the first half of 2029 | Management Language | Q3 release page:2 to page:4 | Projects add capacity and contracted demand but also capital calls through 2029; shipper co-ownership shares the South Mississippi cost |
| Operating volumes | Q3 2026 intrastate volumes up 14 percent and midstream gathered volumes up 6 percent, each a stated record | Management Language | Q3 release page:2 | Supports the revenue driver view; the percentages are management's and not recomputed |
| Regulation and litigation | Pending matters include Dakota Access, a Williams antitrust claim and unitholder derivative suits; contingent accruals 536 at September 30, 2026 and additional reasonably possible loss "up to approximately $76 million" | Documentary Fact | Q3 10-Q page:27, page:28, page:31 and page:32 | Accruals and the stated range are small against EBITDA, but several matters have no loss estimate |

### Company profile

| Attribute | Value | Category | Source locator |
| --- | --- | --- | --- |
| Legal name and form | Energy Transfer LP; the 10-K states "Energy Transfer LP is a Delaware limited partnership"; Commission file number 1-32740 | Documentary Fact | 10-K page:6 and page:1 |
| State in later filings | Cover pages show Delaware for the 10-K and first-quarter report, and Texas for the second- and third-quarter reports (logged as a conflict) | Documentary Fact | 10-K page:1; Q1 10-Q page:1; Q2 10-Q page:1; Q3 10-Q page:1 |
| Headquarters | 8111 Westchester Drive, Suite 600, Dallas, Texas 75225 | Documentary Fact | Q3 10-Q page:1 |
| Country and sector | United States and Natural Gas Transmission (context fields); activities described as midstream natural gas, NGL, crude and refined products | Documentary Fact | Context file; 10-K page:6 |
| Listing | Common units "ET" and 9.250% Series I preferred units "ETprI" listed on the New York Stock Exchange through the second quarter 2026 report and the Texas Stock Exchange on the third-quarter report | Documentary Fact | 10-K page:1; Q2 10-Q page:1; Q3 10-Q page:1 |
| Units outstanding | 3,444,252,188 common units at October 30, 2026; non-affiliate market value of common units "$55.98 billion" at June 30, 2025 (stale, pre-dates the cutoff by more than a year) | Documentary Fact | Q3 10-Q page:1; 10-K page:2 |
| General partner | LE GP, LLC is the general partner of Energy Transfer; the Q3 10-Q is signed "By: LE GP, LLC, its general partner" | Documentary Fact | 10-K page:4; Q3 10-Q page:99 |
| Controlling holder | "Mr. Warren owns an 81.2% membership interest in our general partner and controls our general partner" | Documentary Fact | 10-K page:132 |
| Management | Marshall S. McCrea, III and Thomas E. Long, Co-Chief Executive Officers of the General Partner, as of the 10-K evaluation of controls | Documentary Fact | 10-K page:226 |
| Subsidiaries and interests | Sunoco LP: 100% of general partner interests and incentive distribution rights plus 28.5 million common units; USAC: 100% of general partner interests and 46.1 million common units; controls SunocoCorp Management LLC, which controls SunocoCorp | Documentary Fact | Q3 10-Q page:8 |
| Employees | 22,311 employees at December 31, 2025, of which 1,362 are represented by labor unions | Documentary Fact | 10-K page:68 |
| Auditor | Grant Thornton LLP, Dallas, Texas, auditor since 2004; unqualified opinion on the FY2025 statements | Documentary Fact | 10-K page:283 and page:286 |
| Reporting | Eight reportable segments; consolidated US GAAP; fiscal year ends December 31 | Documentary Fact | Q3 10-Q page:52; 10-K page:283 |
| Ratings | Not supplied: the context lists none and the pack has no rating report; the 10-K states a goal of "investment grade credit metrics" and "investment grade credit ratings" without naming agencies or levels | Insufficient Information | Context file; 10-K page:36 |
| Sponsor | Not applicable: the context names none; the controlling holder above is an individual, not a sponsor fund | Insufficient Information | Context file; 10-K page:132 |
| Dividend policy | The Partnership Agreement "requires us to distribute, on a quarterly basis, 100% of our Available Cash"; the quarterly distribution for the quarter ended September 30, 2026 is 0.3425 US$ per common unit, the twentieth consecutive increase | Documentary Fact; Management Language for the count | 10-K page:95; Q3 10-Q page:19; Q3 release page:4 |

### Transaction summary and new debt issues

Pending and recent transactions, with status. Vaquero: on October 6, 2026 Energy Transfer entered a definitive agreement to acquire all equity interests of Vaquero and related assets "for total consideration of approximately $2.63 billion", consisting of $1.95 billion in cash and approximately 33.3 million newly issued Energy Transfer common units; it owns natural gas gathering, processing and transportation assets in the Delaware Basin and is expected to close in the fourth quarter of 2026 subject to closing conditions and regulatory approvals (Q3 10-Q page:9 and page:57). The release describes it as a "bolt-on transaction for approximately $2.6 billion" (Q3 release page:2). The source of the cash is not stated, so the effect on the parent's liquidity and debt is Not supplied. For scale only, the cash is 44.3 percent of the parent revolver availability of 4,406 US$m at September 30, 2026 in CP-1 (C5); no funding plan is implied.

Subsidiary transactions: Sunoco LP completed the Offen acquisition for approximately 600 US$m in cash on October 27, 2026 (Q3 10-Q page:58), which is a subsequent event after the September 30 balance sheet; Sunoco LP also completed TanQuid on January 16, 2026 for 206 million euros (239 US$m) with assumed debt of 346 US$m fair value, and Delta on April 1, 2026 for about 81 US$m (Q3 10-Q page:57). USAC completed J-W Power on January 12, 2026 for about 912 US$m, of which about 455 US$m was cash and about 457 US$m was 18.2 million new USAC common units (Q3 10-Q page:58). TanQuid was funded using Sunoco LP cash on hand and its credit facility (Q3 10-Q page:57); these subsidiary transactions consolidate into Energy Transfer's debt.

New debt issues and redemptions in 2025 and 2026, from the 10-K and Q3 10-Q. Energy Transfer parent: March 2025, 650 US$m of 5.20% senior notes due 2030, 1.25 billion US$ of 5.70% notes due 2035 and 1.10 billion US$ of 6.20% notes due 2055, with proceeds to refinance debt; August 2025, 1.20 billion US$ of Series 2025A and 800 US$m of Series 2025B junior subordinated notes due 2056; January 2026, 1.00 billion US$ each of 4.55% notes due 2031, 5.35% notes due 2036 and 6.30% notes due 2056; July 2026, 650 US$m of Series 2026A and 1.10 billion US$ of Series 2026B junior subordinated notes due 2057 (together 1,750 US$m), initially at 6.550% and 6.700%, with proceeds to redeem the Series H preferred units, repay Five-Year Credit Facility borrowings and for general partnership purposes (10-K page:325; Q3 10-Q page:17). Redemptions: 4.05% notes of 1.00 billion US$ (March 2025), 2.90% notes of 1.00 billion US$ (May 2025), 5.95% notes of 400 US$m (September 2025), 4.75% notes of 1.00 billion US$ (January 2026), 5.625% notes of 600 US$m (February 2026) and 3.90% notes of 550 US$m (July 2026). Sunoco LP: March 2025, 1.00 billion US$ of 6.25% notes due 2033; September 2025, 1.00 billion US$ of 5.625% notes due 2031 and 900 US$m of 5.875% notes due 2034 to fund Parkland; March 2026, 600 US$m each of 5.375% notes due 2031 and 5.625% notes due 2034, used partly to redeem 500 US$m and 600 US$m of 6.000% notes; Parkland note exchanges in November 2025. USAC: September 2025, 750 US$m of 6.250% notes due 2033; September 2026, 600 US$m of 6.750% notes due 2035.

Preferred and hybrid: the Series H preferred units of 900 US$m were redeemed on August 17, 2026 (Q3 10-Q page:19 and page:21); the Series F redemption of 500 US$m occurred in 2025 (10-K page:289; Q3 10-Q page:87). The creditor mechanics are in the CP-1 handoff: the parent's junior subordinated notes are 5,550 US$m in principal on CP-1's calculation, and the preferred equity outstanding fell to 2,480 US$m.

Status labels: Vaquero is agreed and unclosed; Offen is completed after quarter end; the October 8, 2026 termination of Sunoco LP's NuStar receivables financing agreement is completed (Q3 10-Q page:18); the change of state and exchange is documented only on cover pages. Timeline, ownership and conflicts follow.

### Ownership, governance and capital allocation

Control. "Mr. Warren owns an 81.2% membership interest in our general partner and controls our general partner" and "owns all of the outstanding Energy Transfer Class A Units, which represents an approximately 20% voting interest in the Partnership"; the general partner "has the right to appoint and replace the members of the board, including all of its independent directors"; common unitholders "have no right to elect our general partner or the board of directors" (10-K page:132). The filing requires a vote of at least 66 2/3 percent of outstanding common units to remove the general partner and notes that the Class A units vote with the common units, so his holdings make removal harder (Analyst Interpretation). The 851,420,597 Class A units at December 31, 2025 are 19.8 percent of Class A plus common units outstanding (C6), which agrees with the filing's approximate 20 percent. His direct common unit holding is Not supplied in the pages read; the proxy statement is not in the pack. Ownership percentages are not inferred beyond what is stated.

Governance disputes. Unitholders have filed derivative actions against past and current officers, directors, LE GP, LLC and the Partnership as nominal defendant, alleging breach of fiduciary duties related primarily to pipeline construction in Pennsylvania and Ohio, and seeking damages and changes to governance (Q3 10-Q page:32). They are pending and unquantified.

Legal capacity, willingness and feasibility are kept apart. Legal capacity: the senior notes carry covenants including "a limitation on liens, a limitation on transactions with affiliates, a restriction on sale-leaseback transactions and limitations on mergers and sales of all or substantially all of the Partnership’s assets" and are unguaranteed (10-K page:325); the Five-Year Credit Facility has a maximum leverage ratio of 5.00 to 1.00, generally 5.50 to 1.00 in a Specified Acquisition Period (10-K page:330). The documents read do not show financial maintenance covenants on the notes; executed indentures are not supplied. Willingness (documented actions): the Partnership distributes all available cash quarterly and raised the distribution for 2026 quarters from 0.3350 to 0.3425 US$ per unit (Q3 10-Q page:19); it made no unit repurchases in the nine months to September 30, 2026, with 880 US$m remaining under the 2015 programme (Q3 10-Q page:19); it redeemed preferred units with proceeds of junior subordinated notes; it suspended the Lake Charles LNG liquefaction project in December 2025 (10-K page:9). Feasibility: liquidity, leverage and refinancing capacity are in CP-1 (liquidity 8,692 US$m including subsidiary facilities, with 4,406 US$m at the parent).

Behaviour category (issuer level, documented actions only): Neutral or Mixed. Distributions are paid from available cash and increased while growth capital is large, and growing distributions coexist with a falling reported covenant leverage ratio (CP-1) and debt-funded growth. No priming, uptier, drop-down, non-pro-rata exchange or collateral release was found in the pages read. Evidence quality: High for the filings; the scoring dimensions informed are control concentration, distribution policy and capital allocation.

Capital allocation mechanics. Cash acquisitions at the parent and at Sunoco LP and USAC are funded by cash, commercial paper and facility borrowings or new notes, raising consolidated debt unless offset by EBITDA; unit consideration reduces cash needs but increases distributions. Paying 100 percent of available cash leaves growth to be financed by debt and subsidiary-level capital, as CP-1 shows a negative LTM free cash flow after distributions of 873 US$m. Preferred redemption funded by junior subordinated notes raises debt-ranking claims while lowering the preferred coupon base (the notes' initial rates are 6.550% and 6.700%, against 6.500% on Series H, 10-K page:336); this is an Analyst Interpretation.

### Timeline

| Date | Event | Category | Source locator |
| --- | --- | --- | --- |
| May 2, 2023 | Lotus Midstream acquired for total consideration of 1.50 billion US$ (930 US$m cash and about 44.5 million units) | Documentary Fact | 10-K page:312 |
| November 3, 2023 | Crestwood acquired; consideration about 216 million common units, 41 million Series I preferred units and 300 US$m cash; 2.85 billion US$ of Crestwood notes assumed | Documentary Fact | 10-K page:311 |
| July 15, 2024 | WTG Midstream acquired for 2.28 billion US$ cash and about 50.8 million units | Documentary Fact | 10-K page:310 |
| 2025 | Terminal facilities acquired for about 176 US$m (third quarter); parent senior and junior subordinated notes issued (March and August) | Documentary Fact | 10-K page:310 and page:325 |
| October 31, 2025 | Sunoco LP acquired Parkland, paying about 2.6 billion US$ to shareholders and transferring 51,517,198 SunocoCorp common units | Documentary Fact | 10-K page:313 |
| December 2025 | Lake Charles LNG liquefaction development suspended | Documentary Fact | 10-K page:9 |
| February 19, 2026 | FY2025 10-K filed | Documentary Fact | Q3 10-Q page:8 |
| January 2026 | Parent issues three tranches of 1.00 billion US$; USAC completes J-W Power (January 12); Sunoco LP completes TanQuid (January 16) | Documentary Fact | Q3 10-Q page:17 and page:57 to page:58 |
| April 1, 2026 | Sunoco LP completes the Delta acquisition | Documentary Fact | Q3 10-Q page:57 |
| May 7, 2026 and August 6, 2026 | First- and second-quarter 10-Qs signed; state shown as Delaware then Texas | Documentary Fact | Q1 10-Q page:83; Q2 10-Q page:95 |
| July 6, 2026 | Current report on Form 8-K12B filed (content not supplied) | Documentary Fact (cross-reference only) | Q3 10-Q page:57 |
| July 2026 | Parent issues junior subordinated notes due 2057 and redeems 3.90% notes | Documentary Fact | Q3 10-Q page:17 |
| August 17, 2026 | Series H preferred units redeemed | Documentary Fact | Q3 10-Q page:21 |
| September 1, 2026 | Hugh Brinson Pipeline Phase I placed in full service | Management Language | Q3 release page:2 |
| September 2026 | USAC issues 6.750% senior notes due 2035 | Documentary Fact | Q3 10-Q page:89 |
| September 30, 2026 (period end) | Q3 2026 balance sheet date | Documentary Fact | Q3 10-Q page:3 |
| October 6, 2026 (subsequent event) | Vaquero agreement signed | Documentary Fact | Q3 10-Q page:57 |
| October 8, 2026 (subsequent event) | Sunoco LP receivables financing agreement terminated | Documentary Fact | Q3 10-Q page:18 |
| October 2026 (subsequent event) | CPS Energy appeal period lapsed and the Partnership recorded a contingent gain, the judgment of 393 US$m including interest and legal fees, part of favorable verdicts of approximately 795 US$m in aggregate not recorded at September 30, 2026 | Documentary Fact | Q3 10-Q page:28 |
| October 27, 2026 (subsequent event) | Sunoco LP completes Offen acquisition for about 600 US$m | Documentary Fact | Q3 10-Q page:58 |
| November 3, 2026 (subsequent event) | Q3 release issued with raised 2026 guidance and new projects; November project announcements (Bear II, South Mississippi, Frac X) | Management Language | Q3 release page:2 to page:4 |
| November 5, 2026 | Q3 10-Q signed | Documentary Fact | Q3 10-Q page:99 |

### Credit translations

1. Revenue durability. Evidence: no customer above 10 percent of revenue (10-K page:39); demand-fee and take-or-pay contracts (10-K page:8 and page:11). Mechanic: contracted fee streams cover a share of margin, while marketing, processing margins and fuel distribution vary with commodity spreads. Implication: earnings are more stable than the product-sales revenue suggests, but the proportion of margin that is contracted is Not supplied, so the coverage of fixed charges by contracted income cannot be stated. Counter-evidence: working capital and unrealized commodity swings in cash flow (CP-1).
2. Subsidiary leverage and structural subordination. Evidence: separate Sunoco LP and USAC facilities and notes, and parent notes unguaranteed (10-K page:325; Q3 10-Q page:18). Mechanic: subsidiary creditors rank ahead of the parent in subsidiary assets and cash, while Sunoco LP supplied 560 US$m of the Q3 Adjusted EBITDA increase (CP-1). Implication: the parent's creditors benefit from growth in those subsidiaries only through distributions, so parent leverage measured on consolidated EBITDA overstates parent-available coverage; this is a consideration for CP-2, not a conclusion.
3. Acquisition-led growth and funding. Evidence: Vaquero, Offen, J-W Power, TanQuid and Parkland (Q3 10-Q page:57 and page:58; 10-K page:313). Mechanic: cash components add to borrowings or draw on facilities; unit components dilute distributions per unit. Implication: leverage tolerance depends on EBITDA growth outpacing debt; the Vaquero funding plan is Not supplied, so pro forma leverage is Not calculable.
4. Control and governance. Evidence: 81.2 percent of the general partner and all Class A units (10-K page:132); derivative litigation (Q3 10-Q page:32). Mechanic: unitholders cannot remove the general partner without the vote described, and creditors have no governance rights. Implication: monitoring posture should rest on covenants and disclosure; the partnership agreement is Not supplied.
5. Identity and listing change. Evidence: cover pages and 8-K12B reference. Mechanic: a change of state of organisation could alter the obligor, the governing documents or successor language. Implication: structural analysis should wait for the filing; the conflict logged below counters any assumption of continuity.
6. Key uncertainties: breakdown of contracted versus commodity-linked margin, Vaquero funding, covenant definitions, hybrid treatment, litigation outcomes (Dakota Access and others), and the 8-K12B.

### Conflicts and anomalies (logged, not reconciled)

1. State of organisation and exchange. The 10-K states "Energy Transfer LP is a Delaware limited partnership with common units publicly traded on the NYSE" (10-K page:6) and its cover shows Delaware (10-K page:1). The second-quarter report cover shows Texas with the New York Stock Exchange (Q2 10-Q page:1) and the third-quarter report cover shows Texas with the "Texas Stock Exchange" (Q3 10-Q page:1). The first-quarter report shows Delaware (Q1 10-Q page:1). The Q3 10-Q refers to a "Current Report on Form 8-K12B filed with the SEC on July 6, 2026" (Q3 10-Q page:57), which is not supplied. The effect on the legal entity, indentures and credit agreements is unresolved; the explanation lies outside the sources. Downstream effect: CP-2 cannot assume the 10-K entity is the Q3 obligor.
2. Listing label of subsidiaries. The 10-K says SunocoCorp's units "began trading on the New York Stock Exchange effective November 6, 2025" (10-K page:313) while the Q3 10-Q glossary lists "SunocoCorp LLC (TXSE: SUNC)" and "Sunoco LP (TXSE: SUN)" (Q3 10-Q page:3). Consistent with an exchange move; the dates and reasons are Not supplied.
3. Vaquero value. The 10-Q gives "approximately $2.63 billion" and the release gives "approximately $2.6 billion" (Q3 release page:2); a rounding difference, not a conflict. The cash and unit split is only in the 10-Q.
4. Segment concentration claim. Management says "no single business segment contributing more than one-third"; the calculation gives a maximum of 24.3 percent, so the claim is consistent (C2).
5. Correction to earlier handoffs: none found. CP-1's debt and liquidity figures were reused as references and are not restated here.

### Consumer assessment

| Consumer | Readiness | What to take from CP-1A | Why it matters | Gap | Required action |
| --- | --- | --- | --- | --- | --- |
| CP-2 | READY_WITH_LIMITATIONS | Structure points: unguaranteed parent notes, separate subsidiary borrowers, control by the general partner, 2026 hybrid issuance and preferred redemption, pending Vaquero, the identity change | Debt priority, recovery mechanics and covenant work depend on which entity owes what | Indentures, credit agreements, partnership agreement, 8-K12B and Vaquero funding are not supplied | Obtain them; build an instrument-level schedule; keep parent and subsidiary claims separate |
| CP-5 | READY_WITH_LIMITATIONS | The category tags and locators for each fact; management claims are labelled and not adopted | Traceability of the claims in the report | No original HTML or XBRL; chunk locators are not printed page numbers | Verify quotes against the filings; carry the logged conflict |

## Calculations

C1. Revenue mix. FY2025 gathering, transportation and other fees 12,423 over total revenues 85,536 = 14.52 percent (10-K page:287). Nine months 2026: 9,935 over 99,208 = 10.01 percent (Q3 10-Q page:4).

C2. Segment shares of Q3 2026 Adjusted EBITDA of 5,031 (Q3 release page:11): NGL and refined products 1,224 = 24.33 percent; Sunoco LP 1,049 = 20.85; crude oil 871 = 17.31; midstream 864 = 17.17; interstate 500 = 9.94; intrastate 346 = 6.88; USAC 198 = 3.94; all other (21) = -0.42. The shares sum to 100 percent (1,224 + 1,049 + 871 + 864 + 500 + 346 + 198 - 21 = 5,031). Sunoco LP share of nine-month Adjusted EBITDA: 2,889 over 15,034 = 19.22 percent.

C3. Cost structure, FY2025: cost of products sold 63,495 over 85,536 = 74.23 percent; operating expenses 5,867 over 85,536 = 6.86 percent; selling, general and administrative 1,180 over 85,536 = 1.38 percent.

C4. Vaquero consideration: 1.95 billion US$ cash plus units; total 2.63 billion US$ less cash 1.95 billion = 0.68 billion US$ of unit value for about 33.3 million units, an implied 20.42 US$ per unit (680 over 33.3). This is an implied figure from the agreement terms, not a market price.

C5. Cash consideration against parent availability: 1,950 over 4,406 (CP-1, September 30, 2026) = 44.26 percent. A scale reference only.

C6. Class A voting share: 851,420,597 over (3,439,986,779 common units + 851,420,597 Class A units) = 19.84 percent (10-K page:132 and page:287). The Class A units vote together with common units.

## Gaps

| Gap | Severity | Affected consumers | Action |
| --- | --- | --- | --- |
| Form 8-K12B of July 6, 2026 and documents explaining the change of state and exchange not supplied | High | CP-2, CP-5 | Obtain the filing and successor or supplemental indenture documents |
| Partnership agreement (including Class A unit terms, removal vote and conflicts provisions) not supplied; the proxy statement with holdings is not in the pack | High for governance; Medium for credit | CP-2 | Obtain the partnership agreement and proxy statement |
| Executed indentures, credit agreements and covenant certificates not supplied | High | CP-2 | Obtain executed documents |
| Vaquero funding plan, pro forma leverage and closing conditions not supplied | Medium | CP-2 | Await closing or financing disclosure |
| Share of margin that is contracted or fee-based versus commodity-linked not supplied | Medium | CP-2 | Search the 10-K segment sections for contract tenor and minimum volume detail or request it |
| Segment- or contract-level customer concentration not supplied | Low | CP-2 | Not required for this scope |
| Ratings and agency commentary not supplied | Low | CP-2 | Not required for this scope; no external information is used |
| Litigation outcomes for Dakota Access, antitrust and derivative claims are not estimable from the sources | Medium | CP-2 | Treat as unquantified beyond the accruals and the stated range |
| Sponsor and prior ownership history: no sponsor; recapitalisation history not found | Low | CP-2 | None |

## Next module

Proceed to CP-2 with CP-0, CP-1 and this handoff. Carry forward:

- The structure: parent senior notes unguaranteed, separate Sunoco LP and USAC credit facilities, hybrid junior subordinated notes and preferred equity as distinct claims, and the control by the general partner owner.
- The unresolved identity point (state and exchange change, 8-K12B), so CP-2 should not assume the 10-K obligor equals the Q3 obligor.
- Subsequent events with dates: Vaquero (October 6, 2026, unclosed, 1.95 billion US$ cash), receivables facility termination (October 8), CPS Energy judgment recorded (October), Offen completed (October 27), project announcements and guidance (November 3 and November announcements).
- Management claims are quoted and labelled, not adopted. Peer ranking, instrument recommendation and recovery conclusions are out of scope.
