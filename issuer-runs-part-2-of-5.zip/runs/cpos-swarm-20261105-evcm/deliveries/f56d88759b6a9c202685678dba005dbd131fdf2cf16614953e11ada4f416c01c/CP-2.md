## Request

EverCommerce Inc. (EVCM), as of 2026-11-05, pathway credit_snapshot, current period q2-2026, prior period fy-2025, reporting currency USD, evidence cutoff 2026-11-05. This handoff synthesizes the fundamental credit view from the accepted source-readiness, financial base and business and transaction handoffs, with direct checks against the filings where a number is re-derived. It makes no peer ranking, instrument recommendation or recovery conclusion. Figures follow the financial base handoff: US$ thousands in the filings, US$m or x in chart tables, LTM meaning FY2025 plus H1 2026 less H1 2025.

## Sources

### Issuer sources relied on

| Source | sha256 | Use in this module |
| --- | --- | --- |
| 10-K_2025-12-31_evcm-20251231.htm.jsonl | 9453e2f9c8cc62a7277621021c62f3f54236a25bf3cf1e3b80b24b270acfdeda | Interest rate sensitivity (page:156), covenant text (page:146) |
| 10-Q_2025-09-30_evcm-20250930.htm.jsonl | c623a998349d981306a4008c02834586a4ebe2e4107c66b4b568d918f958b19e | Not relied on directly; only through the financial base |
| 10-Q_2026-03-31_evcm-20260331.htm.jsonl | 5c26bdd8bf153e5bfd09b7fbf88482355fd2b7aa6070fa7591d5646bba84c567 | Not relied on directly; only through the financial base |
| 10-Q_2026-06-30_evcm-20260630.htm.jsonl | 10448bb75b9f2c76dfd332b46c1c0f84482b82dea66954fe734c59c4942a2fc7 | Debt, swaps, maturities, covenant, liquidity (page:18 to page:21, page:49 to page:54), Adjusted EBITDA (page:39) |
| EX-99.1_2026-03-12_evcm4q25earningsrelease.htm.jsonl | a9dd89e7b8b9caedc67b5ca23c4c00c50167031adbb4a9acf31fb4d79b184de8 | Not relied on directly; only through the financial base |
| EX-99.1_2026-05-07_evcmq126earningsrelease.htm.jsonl | 23a859e7b010a64ac0174f20afb33fcbcd2794ab62794c2c0fa2908a92c61007 | Not relied on directly |
| EX-99.1_2026-08-05_evcmq226earningsrelease.htm.jsonl | c993c59da637677fd5abb60ae274814e4acec6999b88d0a88f7a5a9eb9801129 | Outlook and commentary (page:2, page:3) |
| context | d7ba235d89e8ce4355aaee443a70a11c6953f0338ca9492a954e8f1ca023cd96 | Dates and currency only |

### Handoffs relied on

| Module | sha256 | Use |
| --- | --- | --- |
| CP-0 | 1b69fec6f76b0a3db45b22b03548a19960b48042c9a99336086eb38f6dbef02a | Readiness view READY_WITH_LIMITATIONS and its gaps |
| CP-1 | 02f078fbdeee66616a3b8d173ac98668bec5b263e4f78a7fc555877fdeed2cd9 | Financial base: leverage, cover, liquidity, maturities, cash flow, definition risks |
| CP-1A | 2a658067f4722a628dcda1b72756ebabfb227dcc77c00517f2201cf7f970e27f | Business, ownership, sponsor behaviour, timeline, transaction facts, consumer judgment of this module as ready with limitations |

Consistency with upstream: no correction is needed beyond the one CP-1 already made to the CP-0 locator. One precision is added here. CP-1 described a proxy first lien leverage of 2.98x against a 7.50x test; that test applies only if revolver borrowings exceed 35% of commitments, and the revolver is undrawn, so the test is not currently operative.

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| EverCommerce has moderate leverage of 2.98x gross and 2.22x net, ample liquidity and no term loan maturity before 2031, but flat earnings, large add-backs and sponsor-directed shareholder returns leave the credit view stable with a negative earnings bias. | Medium | Credit agreement and covenant-basis EBITDA are not supplied, and the pack stops at August 5, 2026. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Leverage is 2.98x gross and 2.22x net, and cash interest cover is 5.31x, with most floating-rate exposure fixed by swaps to October 2027. | Debt service is comfortable today; swap expiry in 2027 exposes the whole term loan to base rates. | Medium |
| Cash of 133.5 US$m plus an undrawn revolver of 155.0 US$m at quarter end, falling to 125.0 US$m after July 6, 2026, compares with scheduled amortization of 5.500 US$m. | Near-term liquidity risk is low, subject to unknown letters of credit. | Medium |
| LTM Adjusted EBITDA of 175.819 US$m is below FY2025, add-backs are 29.7% of it, and management guides to the low end for 2026. | Leverage is 3.47x gross without the stock compensation add-back, so tolerance is thinner than the headline. | Medium |
| Two sponsors hold approximately 85.7% of the stock with consent rights, and buybacks exceeded free cash flow over the last twelve months. | Cash can leave the group at sponsor-aligned discretion, and covenant limits on this are not visible. | Medium |

### Credit view

The fundamental credit view for EverCommerce Inc. is stable on current metrics with a negative earnings bias, at a confidence of Medium. Evidence from the financial base shows a single secured term loan of 523.875 US$m maturing in July 2031, an undrawn revolver of 155.0 US$m at quarter end, LTM Adjusted EBITDA of 175.819 US$m, LTM leverage of 2.98x gross and 2.22x net and cash interest cover of 5.31x; the business handoff shows a diversified base of more than 745,000 small service customers with recurring revenue near all of the total. The mechanics supporting the view are low customer concentration, modest amortization, a maturity profile with no principal due before 2030 beyond amortization, and cash on hand that exceeds a year of mandatory debt service by a wide margin. The mechanics pulling against it are a net revenue retention of about 94% for the June 2026 quarter, H1 2026 Adjusted EBITDA below H1 2025, investment-led cost growth, a management signal that 2026 will land at the low end of guidance, add-backs of 29.7% of LTM Adjusted EBITDA and an unremediated material weakness in revenue accounting. Credit implication: default risk over the next twelve months is low on these inputs because debt service and amortization are covered several times by operating cash flow and liquidity; leverage tolerance is the issue, because earnings are flat to down while shareholders receive cash through buybacks that exceeded free cash flow over the last twelve months, under sponsor control whose limits in the credit agreement are not visible. The view is bounded by the absent credit agreement, the unreported letters of credit and covenant EBITDA, and the cutoff of the sources at August 5, 2026.

### Key findings

The first finding a committee must read is that the debt structure is simple and conservative on its face: one term loan of 523.875 US$m, secured and guaranteed, repriced and extended in 2024 and 2025, with 425,000 thousand of swaps fixing about 81.1% of the balance until October 31, 2027 and no principal wall before the 2030 revolver and 2031 term loan maturities. Gross leverage of 2.98x and net leverage of 2.22x on LTM company Adjusted EBITDA are below FY2024's 3.24x and 2.41x, and cash interest cover rose from 3.61x to 5.31x. Evidence of mechanism: lower base rates and margin cuts reduced cash interest, and scheduled amortization of 5.500 US$m a year is small against free cash flow, so debt service is covered. Implication: near-term payment risk is low.

The second finding is that the headline overstates the earnings base. Adjusted EBITDA adds back stock compensation, amortization of contract costs and non-recurring costs of 52.275 US$m on an LTM basis, 29.7% of the total, and non-recurring costs have been positive in every period shown. Without the stock compensation add-back leverage is 3.47x gross and 2.58x net. H1 2026 Adjusted EBITDA of 85.211 US$m is below H1 2025's 89.902 US$m, LTM is below FY2025, and free cash flow fell from 57.3% to 40.8% of Adjusted EBITDA between FY2024 and LTM. Implication: the leverage cushion is real but narrower than the headline implies, and a continuing earnings decline would move leverage toward the 3.7x area under a 20% stress.

The third finding is the guidance arithmetic. Management said on August 5, 2026 that results are expected toward the lower end of the 183 to 191 US$m Adjusted EBITDA range, yet reaching even the low end after the third quarter range of 44 to 46 US$m requires a fourth quarter of 51.789 to 53.789 US$m against 44.155 US$m a year earlier. Implication: either the fourth quarter steps up materially or full-year results land below the stated range; creditors should expect LTM Adjusted EBITDA near the first-half run rate absent evidence to the contrary, which is a monitoring position and not a forecast.

The fourth finding is capital allocation and control. Providence Strategic Growth and Silver Lake parties hold approximately 85.7% of the common stock with consent rights over change of control, asset deals above 500.0 US$m, equity issuance to non-strategic financial investors and chief executive changes. The company returned 85.141 US$m through buybacks in FY2025 and 82.105 US$m on an LTM basis against LTM free cash flow of 71.687 US$m. No dividend or debt-funded distribution is documented. Implication: willingness to return cash is demonstrated; capacity to do more depends on credit agreement baskets that are not supplied, so restricted-payment headroom is a priority diligence item.

The fifth finding is the set of near-term events: the 30.0 US$m revolver tranche expired on July 6, 2026 leaving 125.0 US$m, a Delaware case challenging the sponsors' chief executive approval right has oral argument scheduled for October 19, 2026 with no outcome in the sources, and a chief executive transition is signalled by the August release without date or full name while the same-day 10-Q is signed by Eric Remer as chief executive. Implication: the pack should be refreshed for third quarter 2026 reporting before a committee relies on it.

### Strengths and weaknesses

Strengths. Business durability: the customer base is granular, with approximately 93% of customers each contributing under $2 thousand of revenue, recurring or re-occurring revenue near all of the total, so no single-customer concentration is indicated; the mechanic is low idiosyncratic loss risk, and the implication is stable revenue visibility in the near term (Documentary Fact in the business handoff). Liquidity and maturity profile: cash of 133.5 US$m, an undrawn revolver of 125.0 US$m after July 6, 2026, scheduled amortization of 5.500 US$m a year and no maturity of principal beyond amortization until the revolver in July 2030 and the term loan in July 2031 mean refinancing risk is distant, about 56 months to the term loan maturity from the cutoff (Documentary Fact and calculation). Interest rate protection: swaps fixing 425,000 thousand of notional until October 31, 2027 reduce earnings volatility from base rates, and cover of 5.31x is above FY2025's 5.06x (Documentary Fact). Cash generation: operating cash flow after interest covered capital spending, capitalized software and amortization, with LTM free cash flow of 71.687 US$m (Documentary Fact).

Weaknesses. Earnings momentum and quality: Adjusted EBITDA is lower year on year in H1 2026, add-backs are large and recurring, net revenue retention fell to about 94% from about 97%, and the company-defined measure is the only EBITDA available (Documentary Fact and Analyst Interpretation). Sponsor control and shareholder returns: the sponsors can block a sale or an insolvency filing and approve the chief executive, buybacks have exceeded free cash flow over twelve months, and covenant restrictions are unseen (Documentary Fact and Analyst Interpretation). Controls and disclosure: an unremediated material weakness in order-to-cash revenue accounting and disclosure controls that were not effective at June 30, 2026 reduce confidence in reported revenue timing (Documentary Fact). Dependency: payments are about 20% of revenue and rely on card networks, Worldpay and PayPal, a single-point exposure not captured in leverage (Documentary Fact). Information limits: no credit agreement, no letters of credit amount, no covenant-basis EBITDA and no filing after August 5, 2026 (Insufficient Information; missing evidence is not treated as adverse).

Thesis. EverCommerce is a diversified, recurring-revenue software credit with moderate leverage, long-dated and modest debt service, and ample liquidity, whose credit quality is held back by flat earnings, large add-backs and sponsor-directed shareholder returns whose limits cannot yet be tested.

### Key credit risks

| Risk | Mechanic | Credit implication | Severity |
| --- | --- | --- | --- |
| Earnings erosion | Net revenue retention below 100%, cost investment ahead of revenue, low-end guidance | Leverage drifts from 2.98x gross toward 3.7x under a 20% EBITDA decline; remains far inside the 7.50x revolver test but reduces tolerance for distributions | Material |
| Earnings quality | Add-backs of 29.7%; unremediated material weakness in revenue accounting | Reported EBITDA and revenue timing may overstate sustainable cash earnings; leverage 3.47x without stock compensation add-back | Material |
| Sponsor-directed cash returns | Buybacks above LTM free cash flow; sponsor consent rights; unseen restricted-payment baskets | Cash and revolver capacity could be used for distributions ahead of debt reduction | Material |
| Rate reset after swaps expire on October 31, 2027 | Floating base rate on the full 523.875 US$m thereafter | Roughly 5.2 US$m more annual interest per 100 basis points on the full balance against about 1.0 US$m now | Minor |
| Payment processor dependence | About 20% of revenue through processors and card networks | Termination or compliance failure interrupts that revenue | Minor |
| Governance events | Delaware case, undated chief executive transition, chief executive share sale plan | Key-person and control uncertainty; no direct debt effect shown | Minor |
| Revolver availability | 30.0 US$m expired July 6, 2026; letters of credit unknown | Net availability could be below 125.0 US$m | Minor |

### Gaps ledger

| Gap | Why it matters | Affects | Severity | Action |
| --- | --- | --- | --- | --- |
| Credit agreement, covenant EBITDA definition, restricted-payment and debt baskets, named borrower | Legal capacity for distributions and priming cannot be assessed | Sponsor behaviour, leverage tolerance | Material | Obtain credit agreement and amendments |
| Letters of credit outstanding under the 20.0 US$m sub-limit | Undrawn availability is stated gross | Liquidity | Minor | Obtain from issuer |
| Itemised add-back schedule | Quality of Adjusted EBITDA | Leverage | Material | Request bridge by item |
| Third quarter 2026 results and later events | The pack ends August 5, 2026 | All metrics | Material | Refresh before committee |
| Date and identity of the chief executive transition; Delaware case outcome | Governance and control | Sponsor alignment | Minor | Search later filings |
| Source readiness limits inherited from the first module, including the discontinued-operations recast | Prior-period comparability | Trend statements | Minor | Use continuing-operations bases as in the financial base |

## Calculations

All inputs are from the financial base handoff unless a page is cited. US$ thousands.

| Item | Formula | Result |
| --- | --- | --- |
| Total debt / Adjusted EBITDA, LTM | 523,875 / 175,819 | 2.98x |
| Net debt / Adjusted EBITDA, LTM | (523,875 - 133,496) / 175,819 | 2.22x |
| Gross leverage without stock compensation add-back | 523,875 / (175,819 - 24,752) | 3.47x |
| Net leverage without stock compensation add-back | 390,379 / 151,067 | 2.58x |
| EBITDA decline needed to reach the revolver test level | 523,875 / 7.50 = 69,850; 1 - 69,850 / 175,819 | 60.3% decline (proxy; covenant EBITDA not supplied and the test is inoperative while the revolver is undrawn) |
| Leverage at the guidance low end | 523,875 / 183,000 | 2.86x |
| Leverage at an annualized H1 2026 run rate | 523,875 / (85,211 x 2 = 170,422) | 3.07x (assumes flat seasonality; H2 2025 Adjusted EBITDA was 90,608 against 89,902 in H1 2025) |
| Stress: Adjusted EBITDA 20% lower | 175,819 x 0.80 = 140,655; 523,875 / 140,655 | 3.72x |
| Free cash flow over scheduled amortization, LTM | 71,687 / 5,500 | 13.0x (free cash flow is after cash interest) |
| Rate sensitivity now (unhedged part) | (523,875 - 425,000) x 1% | 989 per 100 basis points; the 10-K gives approximately 1.0 US$m at December 31, 2025 (page:156) |
| Rate sensitivity after swap expiry | 523,875 x 1% | 5,239 per 100 basis points; cover on LTM cash interest plus that increase 175,819 / (33,109 + 5,239) = 4.58x (mechanical, not a forecast) |
| Liquidity after July 6, 2026 expiry, gross of letters of credit | 133.496 + 125.0 US$m | 258.496 US$m |
| Months from the cutoff to the term loan maturity | November 5, 2026 to July 6, 2031 | About 56 months |
| Guidance arithmetic | 183,000 - 85,211 - (44,000 to 46,000) | Fourth quarter 51,789 to 53,789 against 44,155 |
| Buybacks less free cash flow, LTM | 82,105 - 71,687 | 10,418 |

Checks: leverage figures tie to the financial base handoff; the 60.3% is a proxy and not a covenant headroom; stress cases are mechanical sensitivities.

## Gaps

- Credit agreement and covenant definitions: Not supplied; headroom to any covenant is Not calculable on the covenant basis and only a proxy is shown.
- Letters of credit: Not supplied, so net revolver availability is Not calculable.
- Itemised add-back schedule: Not supplied.
- Third quarter 2026 reporting and the October 19, 2026 hearing outcome: Not supplied; nothing after August 5, 2026 is used as fact.
- No rating, market quote or valuation input is in the context; none is used.
- Recovery: no conclusion is made; security over substantially all assets and subsidiary guarantees are mechanics only.

## Next module

CP-5 should test the evidence trace for the claims above: the LTM Adjusted EBITDA construction, the leverage and cover figures, the add-back share, the guidance arithmetic, the sponsor ownership and consent rights, the buyback and free cash flow comparison, and the proxy status of every covenant statement. Carry forward the limitations on legal capacity, letters of credit and the August 5, 2026 information cutoff.
