## Request

This is the fundamental credit synthesis for Hudbay Minerals Inc., as of 2026-11-05, on the credit_snapshot pathway, with an evidence cutoff of 2026-11-05. It combines the financial base (USD millions, Q2 2026 and FY2025) and the business and transaction register into one credit view for a committee. It gives no relative value, instrument recommendation or recovery conclusion.

## Sources

CP-2 works from the upstream handoffs only and reads no new source text. The seven issuer sources below are the ones those handoffs rest on. I rechecked the figures used here against them and found no correction to any handoff.

### Issuer sources relied on

| Source name | sha256 | Reached through |
| --- | --- | --- |
| 40-F_2025-12-31_form40f.htm.jsonl | 2e155789735b2bff45a2bcbe054290dc180366fb4697dc24f2f2d4f1c7050c41 | Source readiness and business register (share count, filer status) |
| 6-K-EX-99.1_2025-09-30_exhibit99-1.htm.jsonl | 55a93575304a5e2b953260f4e274c5a39ae30021f2c92b99af4427f537390e4f | Financial base (Q3 2025 history) and business register |
| 6-K-EX-99.1_2026-03-31_exhibit99-1.htm.jsonl | 532cee6ac6a8650d6600327aa510e9427055b8d19ea466fcd1e56834f9e80c49 | Financial base (Q1 2026 statements) |
| 6-K-EX-99.1_2026-06-30_exhibit99-1.htm.jsonl | 12a37c8778b0cbc30486cf54048199e1b52e4f3eeea4aa98f015138ba6c8b8ca | Financial base and business register (Q2 2026 statements and notes) |
| 6-K-EX-99.3_2025-12-31_exhibit99-3.htm.jsonl | 99f49739a1f92152e3b1a86a18c1ee2162a4da0c2cc8d427da3a3335818d9569 | Financial base (FY2025 release) |
| 6-K-EX-99.3_2026-03-31_exhibit99-3.htm.jsonl | ada0c26b16ac32d6f2b222633c4110e11a601b22fd66b81f76af348b97d3b4a8 | Financial base and business register (Q1 2026 release) |
| 6-K-EX-99.3_2026-06-30_exhibit99-3.htm.jsonl | 5519d54c6ee343772d1472890091915c574ee3b20549bcd2dd8544703027a844 | Financial base and business register (Q2 2026 release) |

The run context (sha256 021d8bac1e30ca507d1d237248f47111a88bf0caf21c22980b85e1e72c6ea47c) supplies run settings only and is not issuer evidence. Its ratings, market data, valuation, borrower, parent and guarantor fields are blank and are treated as not supplied, never as zero.

### Supplied handoffs

| Module | sha256 | Use |
| --- | --- | --- |
| CP-0 | e9dbd2ab9d4365edb1c5ad19429b023878f8b986a46fedd1e14735a884877657 | Source readiness, five named conflicts, gap list |
| CP-1 | da8f8dbede6b46939301242ef9c6bcc579e27714e531f445631581d70f3523ab | Financial base: debt register, leverage, liquidity, maturities, cash flow |
| CP-1A | 77f18427d7183f493b28a7833bd301e13f46ac3f9e2d8bdfc3348905ae80e888 | Business and transaction register: operating model, structure, behaviour, conflicts, readiness judgment of CP-2 |

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| Hudbay has a sound credit profile on reported figures: debt of USD 860.2 million against trailing adjusted EBITDA of USD 1,271.6 million, no funded maturity before 2028. Thin committed liquidity and Arizona capital needs limit it. | Medium | Covenant levels, debt documents, ownership data and anything after 2026-07-29 are not supplied, and trailing earnings are the company's own non-GAAP measure. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Total debt was 0.68x trailing adjusted EBITDA at 2026-06-30, against 0.95x at 2025-12-31, and the ratio would still be 0.20x after setting aside ring-fenced Copper World items. | Leverage leaves wide room for earnings to fall before debt looks heavy. | Medium |
| Undrawn revolver was USD 153.7 million after a USD 272.0 million draw, and USD 334.5 million of the USD 890.9 million cash is restricted to Copper World. | Liquidity for the rest of the group is thinner than the headline of USD 1,044.6 million. | High |
| Funded maturities of USD 272.0 million in 2028 and USD 542.4 million in 2029 fall close together, with none earlier. | Refinancing is a 2028 and 2029 task, supported by trailing free cash flow of USD 413.0 million and long mine lives. | Medium |
| Copper World, Mason and Cactus sit outside the note guarantees and revolver security, while the Copper World bonds carry a parent guarantee. | Value and cash build outside creditor collateral, and project debt can become a group claim. | High |
| Earnings depend on gold by-product credits and on three exposed mines, with a Copper World sanction decision and higher study capital cost due in late 2026. | A gold price fall or a large project commitment would test the current low leverage. | Medium |

### Credit view

Hudbay Minerals Inc. has a sound fundamental credit profile today, with low leverage and strong cash generation, but the profile is exposed to thin committed liquidity and to a large Arizona capital programme. The strongest support is total debt of USD 860.2 million against trailing adjusted EBITDA of USD 1,271.6 million (0.68x), no funded maturity before 2028, and earnings spread over three mines, two countries of operation and several metals. The weakest point is liquidity: undrawn revolver of USD 153.7 million after the April 2026 draw, and USD 334.5 million of cash restricted to Copper World, so that cash available to the rest of the group is USD 556.4 million. The outcome will be decided by the Copper World sanction decision expected in late 2026 and how it is funded, by the gold price that supports by-product credits, and by covenant terms that are not supplied.

### Credit assessment

| Dimension | View | Category | Basis | Confidence |
| --- | --- | --- | --- | --- |
| Overall fundamental credit view | Sound and improving on reported leverage, constrained by liquidity structure, project funding and missing legal documents | Analyst Interpretation | Financial base: leverage, liquidity and maturity tables; business register: structure and behaviour read | Medium |
| Leverage | Total debt 0.68x and company net debt negative (-0.06x) on trailing adjusted EBITDA; 0.64x total and 0.20x net after setting aside ring-fenced Copper World items | Documentary Fact for the ratios' inputs; Analyst Interpretation for the ring-fenced view | Financial base: Chart data: leverage | Medium |
| Interest cover | High on the half-year measure (24.77x on cash interest paid) but timing-distorted; a full-year cash measure is Not supplied | Insufficient Information for a full-year measure | Financial base: Chart data: interest cover | Low |
| Liquidity | Headline USD 1,044.6 million; USD 710.1 million after removing Copper World cash; undrawn revolver USD 153.7 million | Documentary Fact; Analyst Interpretation for the adjusted view | Financial base: Chart data: liquidity | Medium |
| Refinancing | No funded maturity until 2028; USD 814.4 million falls in 2028 and 2029 | Documentary Fact | Financial base: Chart data: debt maturities | Medium |
| Business risk | Diversified by mine and metal, long reserve-based mine lives, exposed to disruption events and to gold prices | Documentary Fact and Management Language | Business register: operating model and credit translations | Medium |
| Structure and creditor control | Project assets outside collateral; parent guarantees project bonds; no indenture or credit agreement supplied | Documentary Fact; Insufficient Information on capacity | Business register: ownership, control and governance behaviour | Medium |
| Covenant headroom | Not assessable: only compliance statements exist | Insufficient Information | Financial base: gaps | Not assessable |

### Credit thesis

Hudbay's low reported leverage, long-lived diversified mines and no funded maturity before 2028 support a sound credit profile, provided that the Copper World and Cactus capital programme is funded without eroding the thin committed liquidity or pushing project debt back onto the group (Analyst Interpretation).

### Key findings

Hudbay Minerals Inc. reported total long-term debt of USD 860.2 million at 2026-06-30, down from USD 1,008.6 million at 2025-12-31, while trailing adjusted EBITDA rose to USD 1,271.6 million, the highest of the five trailing quarter-ends in the financial base. Total debt over trailing adjusted EBITDA was 0.68x, against 0.95x at 2025-12-31, and the company's own net debt was negative USD 80.5 million (Documentary Fact). The measure is the company's non-GAAP adjusted EBITDA, which adds back share-based compensation and deducts non-cash stream amortisation, and no covenant definition is supplied (Documentary Fact).

The headline net cash position needs three qualifications. USD 334.5 million of the USD 890.9 million cash is held by Copper World LLC and restricted to that project. USD 49.8 million of municipal bond proceeds are also restricted. The USD 52.0 million of bonds is Copper World debt that the parent guarantees. Setting those aside, total debt is 0.64x and net debt USD 253.1 million, or 0.20x, still low (Analyst Interpretation).

Liquidity changed shape in the second quarter. The company repaid USD 472.5 million of 4.50% notes at maturity on 2026-04-01 using cash and a USD 272.0 million revolver draw, so undrawn revolver availability fell from USD 425.2 million at 2026-03-31 to USD 153.7 million. Headline liquidity of USD 1,044.6 million is now mostly cash. The revolver split between its Canadian and Peruvian facilities is not printed, so the USD 153.7 million is an aggregate that may overstate what is usable on the facility that carries the draw (Documentary Fact; Insufficient Information on the split).

The next funded maturities are the USD 272.0 million revolver draw at its November 2028 facility maturity and USD 542.4 million of 6.125% notes due April 2029, with nothing earlier. Together they equal about two years of trailing free cash flow of USD 413.0 million (1.97x, derived), which is manageable if earnings hold, but the two maturities fall within five months of each other (Analyst Interpretation).

Cash conversion is strong but sensitive. First-half 2026 cash taxes paid were USD 262.8 million, equal to 35.4% of adjusted EBITDA, and the effective tax rate was 43.1%. Capital spending of USD 293.1 million took more than half of operating cash flow of USD 508.3 million. Free cash flow on the company definition was USD 204.1 million for the half, but the free cash flow history differs between releases (Documentary Fact; derived ratios in Calculations).

The business is diversified but exposed. Revenue comes from three operating regions with gold by-product credits that lower unit cost, and mine lives to 2040, 2041 and 2045 are management estimates. Recent interruptions include Peruvian unrest and Manitoba wildfires in 2025 and port closures in the second quarter of 2026 that delayed about 10,000 dry metric tonnes of concentrate (Documentary Fact; Management Language on mine lives).

The structure is the main creditor point. Copper World, Mason and Cactus are excluded from the note guarantees and from the revolver security, Copper World cash is restricted, and the parent guarantees the Copper World bonds. The Copper World sanction decision is expected in late 2026 after a feasibility study that management says will reflect higher capital cost than the 2023 study, the Wheaton enhanced stream is not confirmed as signed, and the Arizona Sonoran acquisition added USD 102.8 million of secured deferred land payments (Documentary Fact; Management Language on timing). Whether creditors' collateral and cash are diluted by this programme depends on documents that are not supplied.

### Strengths and weaknesses

Strengths. Low leverage: total debt at 0.68x trailing adjusted EBITDA and a trend from 1.12x at 2025-09-30 (Documentary Fact for inputs). Cash generation: trailing free cash flow of USD 413.0 million on the company definition, with a first-half operating cash flow of USD 508.3 million (Documentary Fact). Maturity runway: no funded maturity before 2028 after the 2026 notes were repaid (Documentary Fact). Diversification: three operating regions, copper plus gold, with by-product credits and long reserve-based mine lives (Documentary Fact and Management Language). Documented behaviour: repurchases below par, repayment at maturity, an equity-funded acquisition, partner funding of 30% of Copper World, a very small dividend and no buyback purchases under the current authority (Documentary Fact; Analyst Interpretation that behaviour is supportive to neutral).

Weaknesses. Committed liquidity: undrawn revolver of USD 153.7 million, 65.8% of the USD 450.0 million facilities used including letters of credit, and facility-level availability not printed (Documentary Fact; derived). Ring-fenced cash: USD 334.5 million not available to the wider group (Documentary Fact). Structural position: project assets outside collateral with a parent guarantee of project bonds (Documentary Fact). Project and capital intensity: Copper World sanction, higher study cost, the Cactus programme and New Ingerbelle spending ahead (Management Language). Earnings sensitivity: dependence on gold by-product credits, and a 43.1% effective tax rate on first-half income (Analyst Interpretation on sensitivity). Evidence quality: FY2025 figures from a management release, a misprinted trailing cell in the July release, a conflicting share count and no covenant levels (Insufficient Information on covenants).

### Key credit risks

| Risk | Mechanic | Credit implication | Severity |
| --- | --- | --- | --- |
| Thin committed liquidity and facility-level availability | A USD 272.0 million draw and USD 24.3 million of letters of credit use 65.8% of the USD 450.0 million facilities; the split between the two facilities is not printed | Back-up liquidity is small relative to USD 860.2 million of debt and to project calls; group liquidity leans on cash that is partly restricted | Material |
| Ring-fenced cash and cash trapping | USD 334.5 million sits at Copper World LLC and USD 49.8 million of bond proceeds are restricted | Cash for other creditors is USD 556.4 million, not USD 890.9 million; net debt for the rest of the group is USD 253.1 million | Material |
| Project funding and parent recourse | Copper World sanction needs funding beyond Mitsubishi's 30%; the study capital cost is higher than in 2023; the Wheaton agreement is unconfirmed; the parent already guarantees USD 52.0 million of project bonds | New project debt with a parent guarantee would become a claim on the group while project assets are outside collateral | Material |
| Maturity concentration in 2028 and 2029 | USD 272.0 million (November 2028) and USD 542.4 million (April 2029) fall within five months | Refinancing needs to be completed by 2028; USD 814.4 million equals about two years of trailing free cash flow | Material |
| Metal price and gold dependence | By-product credits lower unit cost; stream amortisation is non-cash; the share of revenue from gold is disputed between management and the filed note | A gold price fall hits both revenue and cost offsets; a 32.4% fall in trailing adjusted EBITDA would lift total debt to 1.0x (derived) | Material |
| Operating event risk | Peruvian unrest, Manitoba wildfires and Peruvian port closures each delayed output or shipments within the last 12 months | Quarterly cash flow and working capital swing; a longer event would test liquidity | Material |
| Acquisition and development dilution | The all-share Arizona Sonoran purchase added a second Arizona development asset and USD 102.8 million of secured land payments | Competes with Copper World for capital after sanction; no new corporate debt so far | Minor |
| Cash tax intensity | Cash taxes were 35.4% of first-half adjusted EBITDA | Free cash flow is lower than EBITDA suggests; a tax change or timing swing moves cash | Minor |
| Covenant and documentation opacity | No covenant level, indenture or credit agreement is supplied | Headroom and permitted-payment capacity cannot be tested; missing evidence is not an adverse finding | Material |

## Calculations

Inputs are US$ millions from the financial base unless stated. All results are derived arithmetic on cited upstream figures.

| Item | Formula and inputs | Result |
| --- | --- | --- |
| Total debt to trailing adjusted EBITDA | 860.2 / 1,271.6 | 0.68x |
| Ring-fenced view, total and net | 809.5 / 1,271.6; (809.5 - 556.4) / 1,271.6 | 0.64x; 0.20x |
| Cash available outside Copper World | 890.9 - 334.5 | 556.4 |
| Liquidity outside Copper World | 556.4 + 153.7 | 710.1 |
| Undrawn revolver as a share of total debt | 153.7 / 860.2 | 17.9% |
| Cash outside Copper World as a share of total debt | 556.4 / 860.2 | 64.7% |
| Revolver use including letters of credit | (272.0 + 24.3) / 450.0 | 65.8% |
| Funded maturities in 2028 and 2029 | 272.0 + 542.4 | 814.4 |
| 2028 and 2029 maturities against trailing free cash flow | 814.4 / 413.0 | 1.97 times |
| Maturities in 2028 and 2029 against liquidity outside Copper World | 710.1 / 814.4 | 0.87 times |
| Earnings fall that lifts total debt to 1.0x | 1 - 860.2 / 1,271.6 | 32.4% |
| Total debt to adjusted EBITDA after a 25% earnings fall, debt unchanged | 860.2 / (1,271.6 x 0.75) | 0.90x |
| First-half adjusted EBITDA less cash sustaining capital expenditures | 321.2 + 421.9 - 108.3 - 106.4 | 528.4 |
| That amount over first-half interest expense on long term debt | 528.4 / 27.7 | 19.08x (accrual basis) |
| Trailing free cash flow over total debt | 413.0 / 860.2 | 48.0% |
| Lease-adjusted debt over trailing adjusted EBITDA | 1,147.3 / 1,271.6 | 0.90x |

## Gaps

| Gap | Why it matters | What it affects | Severity | Action |
| --- | --- | --- | --- | --- |
| Covenant levels, step-downs, ratios and headroom are Not supplied; only compliance statements exist | Headroom against the revolver tests cannot be measured | Leverage and liquidity views | High | Obtain the credit agreements and compliance certificates |
| No indenture, credit agreement or Copper World joint venture contract | Legal capacity for distributions, asset transfers and project guarantees cannot be tested; behaviour rests on actions only | Structure, project funding | High | Obtain the executed documents |
| Facility-level availability of the USD 450.0 million revolver and revolver pricing are not printed | The usable amount of the USD 153.7 million and the interest cost of the USD 272.0 million draw are unknown | Liquidity, coverage | High | Obtain the credit agreements |
| Full-year or trailing cash interest is not printed; half-year ratios are timing-distorted | Interest cover over twelve months is Not calculable | Coverage | High | Obtain the FY2025 cash flow statement and coupon dates |
| Nothing dated after 2026-07-29 is supplied | The sanction decision, Q3 2026 results, financing and the Wheaton agreement are Not supplied | All dimensions | High | Supply later filings |
| Audited FY2025 statements and annual information form are not supplied; FY2025 rests on a management release; share count conflicts | The prior-period base and ownership data are second-hand | Leverage trend, ownership | Medium | Obtain the annual exhibits |
| Free cash flow history differs between releases and one trailing cell is misprinted | Cash generation series must name the version | Cash flow quality | Medium | Use the later consistent version and say so |
| Gold share of revenue: management 38% against the filed note at 39.9% of contract revenue | The sensitivity of revenue to gold is uncertain | Business risk | Medium | Ask for the management basis |
| Readiness judgment of this module in the business register is READY_WITH_LIMITATIONS, not READY | Confidence is held below High | Whole assessment | Medium | Restated here as an inherited limit; resolved only by the legal documents and later filings |
| Ratings, market data, valuation and peer inputs are blank in the context | No market-based view is possible and none is given | Whole assessment | Low | None for this pack |

## Next module

Proceed to CP-5 (evidence trace validation). CP-5 should trace each figure above to the financial base, treat management mine lives, guidance and the stated net debt ceiling as management language, keep the five named conflicts and the gold share conflict open, and not read the ring-fenced ratios as company or covenant measures.
