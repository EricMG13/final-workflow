## Request

Issuer: IRON MOUNTAIN INC (issuer id irm; registrant IRON MOUNTAIN INCORPORATED, "IMI", NYSE: IRM). As-of date: 2026-11-05, which is also the evidence cutoff. Pathway: credit_snapshot. Current period: Q3 2026 (September 30, 2026 balance sheet; nine months ended September 30, 2026 flows); prior period: FY2025. Reporting currency: USD. The filings report in thousands of US dollars; this handoff keeps US$ thousands in the statement table and uses US$m (one decimal) in the chart tables. No currency or period mismatch with the context was found.

Perimeter: the consolidated statements of Iron Mountain Incorporated and its subsidiaries. IMI is a holding company and the direct obligor on the Parent Notes; the Note Guarantors guarantee them and the remaining subsidiaries do not (10-Q Q3 2026 page:21). Debt, earnings, leverage and coverage below are for this consolidated perimeter. The Credit Agreement covenant ratios use a different perimeter (consolidated subsidiaries other than designated "Unrestricted Subsidiaries"); that perimeter is not separately supplied.

Scope of CP-1: build the financial base (reported statement lines, debt inventory, liquidity, maturities, covenants, claims outside debt, leverage and cover) for the downstream modules CP-1A, CP-2 and CP-5. No credit rating, valuation or investment opinion is given here.

## Sources

Issuer sources relied on (name as pinned and sha256):

| Source name | sha256 |
| --- | --- |
| 10-K_2025-12-31_irm-20251231.htm.jsonl | 9c991d6cdd465558fe3d6c3b1ca180e1a4934be45256793a9fbd2c983d1c3d21 |
| 10-Q_2026-03-31_irm-20260331.htm.jsonl | c097a3f585d908ce47931b28757115d3a00ba271c949277b2995e2c2344465f7 |
| 10-Q_2026-06-30_irm-20260630.htm.jsonl | fe08302fa04f9d8c593cf06c79704bdfe3f3999447ef79511393f443f2e9e013 |
| 10-Q_2026-09-30_irm-20260930.htm.jsonl | c9d6cf1ac242db8c215c06c4487b7325abcfccb724b4417b8410eb43258ea1f1 |
| EX-99.1_2026-04-30_q12026earningspressrelea.htm.jsonl | 1ea5cf7035da8aa87dd1ad93c853ce455e98a75bb727fb04ac272e58d34c3493 |
| EX-99.1_2026-08-05_final-q22026earningspres.htm.jsonl | 0d0d4258db90617a30c1e3c9ffb5f20e0de342df888db740df22d17b30f2e886 |
| EX-99.1_2026-11-05_q32026earningspressrelea.htm.jsonl | 55477d582fc2c850f9912e2fa4b11c0af530fa7f8e752b29ae4633a58c75327b |

Run settings (not issuer evidence): context 1020569-iron-mountain-inc-irm.json, sha256 9bee5f583dd9c7776f1152268ebe2d2da262ea2bd6a67a8712cdfef3c69af924.

Supplied handoffs:

| Module | sha256 | Use |
| --- | --- | --- |
| CP-0 | 076fb4d2b6b8339ab438834a3632e4ceb7893ce55c2f36ff0e387d2dd78e3329 | Source readiness; its gap log is carried forward and one item is corrected below. |

Locator convention: `page:N` is the retained source chunk, not the printed page number. Short names: "10-K" is the FY2025 annual report; "10-Q Q1", "10-Q Q2", "10-Q Q3" are the 2026 quarterly reports; "Release Q1/Q2/Q3" are the exhibit 99.1 earnings releases.

Correction to the CP-0 handoff: its gap G1 said no consolidated annual debt maturity table was located. That was wrong for the annual report. The 10-K prints "MATURITIES OF LONG-TERM DEBT (GROSS OF DISCOUNTS)" at page:150, as at December 31, 2025. The quarterly reports print no such table (searched "maturities of" in all three). The gap therefore stands only for September 30, 2026. CP-0 is otherwise relied on as written, including its Q2 2026 par call date finding.

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| Total debt is 17,972,202 thousand, 6.22x LTM Adjusted EBITDA of 2,888,192 thousand. Operating cash flow trails capex and dividends, so debt keeps rising. Liquidity is large but fell in Q3 2026. | Medium | Adjusted EBITDA is a management measure, covenant ratios use other definitions, and no maturity table exists after December 31, 2025. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Total debt rose to 17,972,202 thousand at September 30, 2026 from 16,431,959 thousand at December 31, 2025, while LTM Adjusted EBITDA reached 2,888,192 thousand. | Leverage on Adjusted EBITDA eased to 6.22x from 6.38x, but absolute debt keeps growing. | High |
| Operating cash flow of 1,203,634 thousand for nine months 2026 was below capex of 1,724,205 thousand and dividends of 789,997 thousand. | The business relies on debt and joint-venture capital to fund growth and distributions. | High |
| Cash plus revolver availability was 2,406,378 thousand at September 30, 2026, down from 2,912,367 thousand at June 30, 2026. | Liquidity is ample, but the revolver drawing rose by 489,500 thousand in one quarter. | High |
| Credit Agreement ratios are 4.8x lease adjusted leverage (maximum 7.0x) and 2.5x fixed charge cover (minimum 1.5x). | Reported covenant headroom is wide, but it cannot be rebuilt from Adjusted EBITDA. | Medium |
| Current portion of debt rose to 1,232,903 thousand from 216,074 thousand, including notes due September 15, 2027. | A refinancing event falls inside twelve months of the balance sheet date. | Medium |

### Financial base view

IRON MOUNTAIN INC is a growing, highly levered REIT whose reported leverage on its own Adjusted EBITDA is around six times and whose free cash flow after capital expenditure is negative. For the twelve months to September 30, 2026 (LTM Q3 2026), Adjusted EBITDA is 2,888,192 thousand (FY2025 2,573,950 plus nine months 2026 2,182,915 less nine months 2025 1,868,673), revenue is 7,799.0 US$m and the Adjusted EBITDA margin is 37.0%. Total debt at carrying amount is 17,972.2 US$m, so total debt to LTM Adjusted EBITDA is 6.22x and net debt to LTM Adjusted EBITDA is 6.16x, against 6.38x and 6.32x at FY2025. Adjusted EBITDA to cash interest paid is 3.16x on an LTM basis against 3.12x at FY2025. These ratios improved against FY2025 because Adjusted EBITDA grew faster than debt, but total debt over Adjusted EBITDA edged up from 6.19x at LTM Q2 2026 to 6.22x at LTM Q3 2026.

Cash generation does not cover the investment programme. Operating cash flow less capital expenditure is negative 520.6 US$m for nine months 2026 and negative 536.8 US$m LTM, before 790.0 US$m of nine-month dividends. Financing in the period included 1,500,000 thousand principal of new 6 1/4% notes due 2035 (net proceeds of 1,485,000 thousand in the cash flow statement), data center project loan and revolver borrowings, and 95.2 US$m of noncontrolling interest equity contributions; the filings do not tie each source to the funding gap. The Credit Agreement covenant ratios (4.8x and 2.5x) show wide reported headroom, but they are EBITDAR and EBITDA based with adjustments and the filings state they are not directly comparable to Adjusted EBITDA. Liquidity of 2,406.4 US$m is cash plus revolver availability only; other undrawn lines are small, project specific or tied to eligible receivables. The Adjusted EBITDA definition adds back stock-based compensation and other items, so a stricter operating income plus depreciation and amortization measure gives a higher LTM leverage of 6.81x (calculation below); both are shown and neither is a covenant measure.

### Chart data: leverage

| Period | Total debt / EBITDA | Net debt / EBITDA | Reporting unit | Basis and limitation |
| --- | --- | --- | --- | --- |
| FY2024 | 6.13 | 6.06 | x | Carrying amount of total debt at Dec 31, 2024 (13,719,086 thousand, 10-K page:138) over FY2024 Adjusted EBITDA (2,236,380 thousand, 10-K page:57); cash 155,716 thousand. Company-defined Adjusted EBITDA; consolidated perimeter. |
| FY2025 | 6.38 | 6.32 | x | Carrying amount of total debt at Dec 31, 2025 (16,431,959 thousand, 10-K page:138) over FY2025 Adjusted EBITDA (2,573,950 thousand, 10-K page:57); cash 158,535 thousand. Debt includes financing leases, excludes operating leases. |
| LTM Q1 2026 | 6.33 | 6.24 | x | Debt 17,102,981 thousand (10-Q Q1 page:16) over LTM Adjusted EBITDA 2,701,983 thousand derived as FY2025 plus Q1 2026 (707,939) less Q1 2025 (579,906), Release Q1 page:8; cash 250,710 thousand. Derived LTM. |
| LTM Q2 2026 | 6.19 | 6.12 | x | Debt 17,349,649 thousand (10-Q Q2 page:19) over LTM Adjusted EBITDA 2,800,613 thousand derived as FY2025 plus six months 2026 (1,434,957) less six months 2025 (1,208,294), 10-Q Q2 page:31; cash 204,793 thousand. Derived LTM. |
| LTM Q3 2026 | 6.22 | 6.16 | x | Debt 17,972,202 thousand (10-Q Q3 page:19-20) over LTM Adjusted EBITDA 2,888,192 thousand derived as FY2025 plus nine months 2026 (2,182,915) less nine months 2025 (1,868,673), 10-Q Q3 page:42; cash 188,160 thousand. Derived LTM; principal basis (18,096,426 thousand) gives 6.27x. |

### Chart data: interest cover

| Period | EBITDA / cash interest | Reporting unit | Basis and limitation |
| --- | --- | --- | --- |
| FY2024 | 2.90 | x | Adjusted EBITDA 2,236,380 thousand over cash paid for interest 770,688 thousand (10-K page:99). Cash interest may include capitalized interest; the split is not stated. |
| FY2025 | 3.12 | x | Adjusted EBITDA 2,573,950 thousand over cash paid for interest 824,591 thousand (10-K page:99). Capitalized interest for FY2025 was 78,367 thousand (10-K page:103). |
| LTM Q1 2026 | 3.00 | x | LTM Adjusted EBITDA 2,701,983 thousand over LTM cash interest 899,171 thousand (FY2025 824,591 plus Q1 2026 341,794 less Q1 2025 267,214, 10-Q Q1 page:5). Derived LTM. |
| LTM Q2 2026 | 3.11 | x | LTM Adjusted EBITDA 2,800,613 thousand over LTM cash interest 899,659 thousand (FY2025 plus six months 2026 461,459 less six months 2025 386,391, 10-Q Q2 page:7). Derived LTM. |
| LTM Q3 2026 | 3.16 | x | LTM Adjusted EBITDA 2,888,192 thousand over LTM cash interest 914,978 thousand (FY2025 plus nine months 2026 801,904 less nine months 2025 711,517, 10-Q Q3 page:7). Derived LTM; 2026 capitalized interest is not disclosed in the pinned 10-Qs. |

### Chart data: liquidity

| Period | Cash | Undrawn committed facilities | Reporting unit | Basis and limitation |
| --- | --- | --- | --- | --- |
| FY2025 (Dec 31, 2025) | 158.5 | 1986.1 | US$m | Cash from 10-K page:96. Undrawn is revolving credit facility availability after drawings and letters of credit that reduce capacity, as printed (10-K page:141). Other lines excluded (project loans, receivables program, UK facility). |
| Q1 2026 (Mar 31, 2026) | 250.7 | 1452.6 | US$m | Cash from 10-Q Q1 page:2; revolver availability as printed (10-Q Q1 page:16). Same basis. |
| Q2 2026 (Jun 30, 2026) | 204.8 | 2707.6 | US$m | Cash from 10-Q Q2 page:2; revolver availability as printed (10-Q Q2 page:19). Same basis. |
| Q3 2026 (Sep 30, 2026) | 188.2 | 2218.2 | US$m | Cash from 10-Q Q3 page:2; revolver availability as printed (10-Q Q3 page:20). Same basis; other undrawn lines of about 207.9 US$m are listed in Calculations and excluded. |

### Chart data: debt maturities

| Period | Debt maturing | Reporting unit | Basis and limitation |
| --- | --- | --- | --- |
| 2026 | 216.1 | US$m | Company-printed maturities gross of discounts as at Dec 31, 2025 (10-K page:150). No later table exists; the 2027 bucket still includes the receivables program later extended to 2029 and excludes the June 2026 notes. |
| 2027 | 2330.8 | US$m | Same table. Includes the 4 7/8% notes due September 15, 2027 (1,000,000 thousand), two 2027 data center loans and the receivables program (400,000 thousand) as it stood at Dec 31, 2025. |
| 2028 | 1663.7 | US$m | Same table (10-K page:150). |
| 2029 | 2137.5 | US$m | Same table (10-K page:150). |
| 2030 | 3035.7 | US$m | Same table; includes the revolving credit facility and Term Loan A due March 18, 2030 (10-K page:141). |
| Thereafter | 7173.1 | US$m | Same table; total of all buckets 16,556.8 US$m before net discounts and deferred financing costs, reconciling to 16,431,959 thousand carrying amount. |

### Financials and credit metrics

| Line | FY2024 | FY2025 | 9M 2025 | 9M 2026 | LTM Q3 2026 | Unit | Basis and source |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Total revenues | 6,149,909 | 6,901,737 | 5,058,570 | 5,955,828 | 7,798,995 | US$ thousand | Statements of operations: 10-K page:96-97; 10-Q Q3 page:3-4. LTM = FY2025 + 9M 2026 - 9M 2025. |
| Storage rental revenue | 3,682,259 | 4,052,510 | 2,991,262 | 3,378,884 | 4,440,132 | US$ thousand | Same pages. LTM derived. |
| Service revenue | 2,467,650 | 2,849,227 | 2,067,308 | 2,576,944 | 3,358,863 | US$ thousand | Same pages. LTM derived. |
| Operating income | 1,009,519 | 1,163,822 | 822,779 | 1,179,331 | 1,520,374 | US$ thousand | Same pages. LTM derived. |
| Depreciation and amortization | 900,905 | 1,024,435 | 746,923 | 841,030 | 1,118,542 | US$ thousand | Same pages. LTM derived. |
| Interest expense, net | 721,559 | 829,335 | 609,541 | 663,788 | 883,582 | US$ thousand | Same pages. Net of interest income. LTM derived. |
| Net income (incl. noncontrolling interests) | 183,666 | 152,254 | 59,134 | 383,979 | 477,099 | US$ thousand | Same pages. 9M 2026 includes 69.9 US$m loss on deferred purchase obligations in other expense, net. LTM derived. |
| Adjusted EBITDA (company-defined) | 2,236,380 | 2,573,950 | 1,868,673 | 2,182,915 | 2,888,192 | US$ thousand | 10-K page:57; 10-Q Q3 page:42. Management non-GAAP; adds back stock-based compensation, restructuring, other expense and acquisition costs. LTM derived. |
| Adjusted EBITDA margin | 36.4% | 37.3% | 36.9% | 36.7% | 37.0% | % of revenue | Computed from the two rows above; printed margins: FY2025 37.3%, 9M 2026 36.7%, 9M 2025 36.9% (10-K page:75, 10-Q Q3 page:42). |
| Cash flows from operating activities | 1,196,708 | 1,339,999 | 840,001 | 1,203,634 | 1,703,632 | US$ thousand | Cash flow statements: 10-K page:98-99; 10-Q Q3 page:6-7. LTM derived. |
| Capital expenditures (cash) | 1,791,564 | 2,271,628 | 1,755,383 | 1,724,205 | 2,240,450 | US$ thousand | Same pages. Shown as positive outflow. LTM derived. |
| Operating cash flow less capital expenditures | -594,856 | -931,629 | -915,382 | -520,571 | -536,818 | US$ thousand | Computed. Excludes acquisitions, intangibles and contract costs. |
| Parent cash dividends paid | 789,527 | 919,388 | 687,204 | 789,997 | 1,022,181 | US$ thousand | Financing section of the same cash flow statements. LTM derived. |
| Cash paid for interest | 770,688 | 824,591 | 711,517 | 801,904 | 914,978 | US$ thousand | Supplemental information, 10-K page:99, 10-Q Q3 page:7. LTM derived. |
| Cash paid for income taxes, net | 90,742 | 121,606 | 89,828 | 93,409 | 125,187 | US$ thousand | Same pages. LTM derived. |
| Cash and cash equivalents (period end) | 155,716 | 158,535 | Not supplied: Sep 30, 2025 balance sheet not in pack | 188,160 | 188,160 | US$ thousand | Balance sheets: 10-K page:96; 10-Q Q3 page:2. LTM column repeats Sep 30, 2026. |
| Total debt, carrying amount | 13,719,086 | 16,431,959 | Not supplied: Sep 30, 2025 balance sheet not in pack | 17,972,202 | 17,972,202 | US$ thousand | Debt notes: 10-K page:138; 10-Q Q3 page:19-20. Current portion plus long-term; includes financing leases. |
| Total debt, principal | 13,836,364 | 16,544,473 | Not supplied: Sep 30, 2025 balance sheet not in pack | 18,096,426 | 18,096,426 | US$ thousand | Same tables, "Debt (inclusive of discount)" column, before deferred financing costs. |
| Current portion of long-term debt | 715,109 | 216,074 | Not supplied: Sep 30, 2025 balance sheet not in pack | 1,232,903 | 1,232,903 | US$ thousand | Balance sheets. |
| Operating lease liabilities (outside debt) | 2,650,226 | 2,619,577 | Not supplied: Sep 30, 2025 balance sheet not in pack | 2,518,768 | 2,518,768 | US$ thousand | Current plus long-term; 10-Q Q3 page:9; Dec 31, 2025 and Dec 31, 2024 from 10-K page:106 (315,400 + 2,334,826 for 2024). |
| Total (deficit) equity | -304,674 | -709,331 | Not supplied: Sep 30, 2025 balance sheet not in pack | -1,062,942 | -1,062,942 | US$ thousand | Balance sheets (10-K page:96; 10-Q Q3 page:3); includes noncontrolling interests, excludes redeemable noncontrolling interests. |
| Total debt / Adjusted EBITDA | 6.13 | 6.38 | Not calculable: no 9M balance sheet or annualized EBITDA | Not calculable: nine-month EBITDA is not an annual base | 6.22 | x | Carrying amount over annual or LTM Adjusted EBITDA. |
| Net debt / Adjusted EBITDA | 6.06 | 6.32 | Not calculable: see above | Not calculable: see above | 6.16 | x | Carrying debt less cash and cash equivalents. |
| Adjusted EBITDA / cash interest paid | 2.90 | 3.12 | 2.63 | 2.72 | 3.16 | x | Nine-month columns are not annualized; both use the same nine-month basis. |
| Adjusted EBITDA / interest expense, net | 3.10 | 3.10 | 3.07 | 3.29 | 3.27 | x | Accounting interest, net of interest income. |
| Credit Agreement net total lease adjusted leverage | Not supplied: the 10-K prints only the Dec 31, 2025 ratios | 4.9 | Not supplied | 4.8 | 4.8 | x | 10-K page:84 (Dec 31, 2025); 10-Q Q3 page:50. Maximum allowable 7.0x. Company-reported; EBITDAR basis. |
| Credit Agreement fixed charge coverage | Not supplied: the 10-K prints only the Dec 31, 2025 ratios | 2.5 | Not supplied | 2.5 | 2.5 | x | Same pages. Minimum allowable 1.5x. |

## Calculations

All inputs are in US$ thousands as printed unless stated. Ratios round half up to two decimals.

### LTM bridges (Q3 2026)

| Item | FY2025 | plus 9M 2026 | less 9M 2025 | LTM Q3 2026 |
| --- | --- | --- | --- | --- |
| Adjusted EBITDA | 2,573,950 | 2,182,915 | 1,868,673 | 2,888,192 |
| Cash paid for interest | 824,591 | 801,904 | 711,517 | 914,978 |
| Revenue | 6,901,737 | 5,955,828 | 5,058,570 | 7,798,995 |
| Operating cash flow | 1,339,999 | 1,203,634 | 840,001 | 1,703,632 |
| Capital expenditures | 2,271,628 | 1,724,205 | 1,755,383 | 2,240,450 |
| Parent cash dividends | 919,388 | 789,997 | 687,204 | 1,022,181 |

Check: 2,573,950 + 2,182,915 - 1,868,673 = 2,888,192. 824,591 + 801,904 - 711,517 = 914,978. The comparative nine-month 2025 amounts are as printed in the 2026 filings; the Q3 2025 10-Q is not in the pack, so the 2025 basis was not checked against its original filing.

### Leverage and cover (LTM Q3 2026)

- Total debt / Adjusted EBITDA = 17,972,202 / 2,888,192 = 6.2226, shown as 6.22x. On principal 18,096,426 / 2,888,192 = 6.27x.
- Net debt = 17,972,202 - 188,160 = 17,784,042; / 2,888,192 = 6.1575, shown as 6.16x.
- Adjusted EBITDA / cash interest = 2,888,192 / 914,978 = 3.1566, shown as 3.16x.
- Adjusted EBITDA / interest expense, net = 2,888,192 / 883,582 = 3.27x (883,582 = 829,335 + 663,788 - 609,541).
- Stricter measure: operating income plus D&A LTM = 1,520,374 + 1,118,542 = 2,638,916; total debt / that = 17,972,202 / 2,638,916 = 6.81x; net = 17,784,042 / 2,638,916 = 6.74x. This measure does not add back stock-based compensation, restructuring or acquisition costs, and it is not a covenant measure. The LTM gap between the two EBITDA measures is 249,276 (2,888,192 - 2,638,916).
- Earlier periods: FY2025 16,431,959 / 2,573,950 = 6.38x and (16,431,959 - 158,535) / 2,573,950 = 6.32x; FY2024 13,719,086 / 2,236,380 = 6.13x and (13,719,086 - 155,716) / 2,236,380 = 6.06x; LTM Q1 2026 17,102,981 / 2,701,983 = 6.33x and 16,852,271 / 2,701,983 = 6.24x; LTM Q2 2026 17,349,649 / 2,800,613 = 6.19x and 17,144,856 / 2,800,613 = 6.12x.
- Cover earlier: FY2024 2,236,380 / 770,688 = 2.90x; FY2025 2,573,950 / 824,591 = 3.12x; LTM Q1 2,701,983 / 899,171 = 3.00x; LTM Q2 2,800,613 / 899,659 = 3.11x. Nine months: 2,182,915 / 801,904 = 2.72x (2026) and 1,868,673 / 711,517 = 2.63x (2025).
- Cash interest paid for nine months 2026 (801,904) exceeds interest expense, net (663,788) by 138,116. The filings do not give 2026 capitalized interest or the coupon timing, so the cause is Not supplied; FY2025 capitalized interest was 78,367 (10-K page:103).

### Free cash flow and funding

- Nine months 2026: 1,203,634 - 1,724,205 = -520,571; after dividends paid of 789,997 the shortfall is 1,310,568.
- LTM: 1,703,632 - 2,240,450 = -536,818; after dividends 1,022,181 the shortfall is 1,558,999.
- Nine months 2026 financing sources named in the cash flow statement: net proceeds from sale of senior note 1,485,000; proceeds from revolving credit facility, term loans and other debt 12,372,027 less repayments 12,423,074 (net repayment 51,047); equity contributions from noncontrolling interests 95,168 (10-Q Q3 page:7).
- Debt change from December 31, 2025 to September 30, 2026: 17,972,202 - 16,431,959 = 1,540,243. This is a balance sheet change that includes foreign exchange on euro, Australian dollar and sterling debt as well as new borrowing; the split is Not supplied.

### Liquidity by facility (September 30, 2026)

| Input | Amount (US$ thousand) | Locator and note |
| --- | --- | --- |
| Cash and cash equivalents | 188,160 | 10-Q Q3 page:2. Held partly through cash pools shown net (10-K page:149); restricted cash is not shown separately, and none was found. |
| Revolving credit facility commitment | 2,750,000 | 10-K page:141; not restated in the 10-Qs. Used because the printed availability reconciles exactly: 2,750,000 - 519,500 - 12,282 = 2,218,218. |
| Revolver drawn | 519,500 | 10-Q Q3 page:19 |
| Letters of credit reducing revolver capacity | 12,282 | 10-Q Q3 page:23 |
| Revolver availability (printed) | 2,218,218 | 10-Q Q3 page:20, "maximum availability". Matures March 18, 2030 (10-K page:141). |
| Virginia 9 credit agreement: commitment 298,000 less drawn 138,627 | 159,373 | 10-Q Q3 page:21-22. Construction financing of a joint venture subsidiary, secured by that subsidiary's assets; not freely available to the parent. |
| Receivables program: maximum 450,000 less outstanding 408,000 | 42,000 | 10-Q Q3 page:22. Capacity is limited by eligible receivables (10-K page:148-149). |
| Virginia 7 loans: facility 300,000 less outstanding 293,455 | 6,545 | Facility size from 10-K page:142; 10-Q Q3 gives only the outstanding amount. |
| UK revolving credit facility | Not calculable | Facility is 140,000 British pounds sterling and was fully drawn at Dec 31, 2025 (10-K page:147); the Q3 report prints only the drawn US dollar equivalent (185,656), so current headroom is Not supplied. |

- Liquidity used in the chart = 188,160 + 2,218,218 = 2,406,378 (cash plus revolver availability). Including the three smaller project and receivables lines (159,373 + 42,000 + 6,545 = 207,918) would give 2,614,296, but those amounts are restricted in purpose and are excluded from the chart.
- Q2 2026: 204,793 + 2,707,574 = 2,912,367. Change to Q3: 2,406,378 - 2,912,367 = -505,989. The revolver drawn balance rose from 30,000 (10-Q Q2 page:18) to 519,500, an increase of 489,500, and availability fell by 489,356 (2,707,574 - 2,218,218), the small difference being the change in letters of credit (12,426 to 12,282).
- Letters of credit total 61,252 at Sep 30, 2026 (10-Q Q3 page:23), of which 12,282 reduce the revolver; 48,970 (61,252 - 12,282) do not, and the facilities that carry them are Not supplied.
- Within twelve months of September 30, 2026: current portion of long-term debt is 1,232,903 (10-Q Q3 page:2). The 4 7/8% notes due 2027 (1,000,000, due September 15, 2027, 10-K page:144) mature inside that window, which is consistent with the rise from 216,074 at Dec 31, 2025; the filings do not itemize the current portion, so the composition is Not supplied. The Virginia 6 loans (210,000, May 3, 2027) and Virginia 7 loans (293,455, April 12, 2027) carry dates from the 10-K and two one-year extension options each (10-K page:142-143); whether they were extended is Not supplied. Letters of credit expire between December 2026 and December 2027 (10-Q Q3 page:23).
- Uses over the next quarters, all from the sources: capital expenditure guidance for FY2026 of about 2,200.0 US$m (growth about 2,050.0, recurring about 150.0, 10-Q Q3 page:46) against 1,724.2 US$m spent in nine months on a cash basis (the guidance and the cash figure are on different bases, so an implied fourth quarter is not computed); a quarterly dividend of 0.993 per share declared November 5, 2026, payable January 6, 2027 (10-Q Q3 page:24); dividends payable of 268,838 at Sep 30, 2026 for the October 2, 2026 payment (10-Q Q3 page:7). Shares outstanding were 297,833,786 at October 30, 2026 (10-Q Q3 page:1), so the declared dividend is about 295,748,949 (0.993 x 297,833,786), a derived estimate that ignores share changes before the record date.

### Debt inventory at September 30, 2026 (from the debt table)

| Instrument | Debt incl. discount (US$ thousand) | Carrying amount (US$ thousand) | Obligor and guarantors, as printed | Rate | Maturity |
| --- | --- | --- | --- | --- | --- |
| Revolving Credit Facility | 519,500 | 512,742 | IMI and certain subsidiaries; guaranteed and secured by Credit Agreement Collateral (10-K page:139, 141) | 5.7% weighted average | March 18, 2030 |
| Term Loan A | 468,750 | 468,750 | Credit Agreement; same guarantors and collateral | SOFR plus 1.75% | March 18, 2030 |
| Term Loan B | 2,006,988 | 1,996,179 | Credit Agreement; same guarantors and collateral | SOFR plus 2.00% | January 31, 2031 |
| Virginia 6 Term Loans | 210,000 | 208,848 | Iron Mountain Data Centers Virginia 6, LLC; secured by its equity and assets | SOFR plus 2.75% | May 3, 2027 (10-K) |
| Virginia 7 Term Loans | 293,455 | 291,552 | Iron Mountain Data Centers Virginia 7, LLC; secured by its equity and assets | SOFR plus 2.50% | April 12, 2027 (10-K) |
| Virginia 9 Term Loans | 138,627 | 132,176 | Iron Mountain Data Centers Virginia 9, LLC; secured by equity and assets | SOFR plus 3.00% (6.9%) | June 9, 2029 |
| Virginia 4/5 Term Loans due 2030 | 208,224 | 205,236 | Virginia 4/5 Subsidiary, LLC; secured by its property | 5.60% | November 1, 2030 |
| Virginia 3 Term Loans due 2031 | 433,000 | 425,307 | Virginia 3, LLC and Virginia 3 Intermediate II, LLC; mortgage and mezzanine; secured by Virginia 3 property | 6.3% weighted average | January 9, 2031 |
| Australian Dollar Term Loan | 268,280 | 266,528 | Iron Mountain Australia Group Pty, Ltd.; guaranteed by Australian subsidiaries and Credit Agreement guarantors; secured | BBSY plus 3.50% | September 30, 2030 |
| UK Revolving Credit Facility | 185,656 | 184,532 | IM UK and Iron Mountain (UK) Data Centre Limited; guaranteed by IMI and subsidiaries; secured by UK properties | SONIA plus 2.0% | September 24, 2028 |
| 4 7/8% Notes due 2027 | 1,000,000 | 998,578 | IMI; guaranteed by Note Guarantors | 4 7/8% | September 15, 2027 |
| 5 1/4% Notes due 2028 | 825,000 | 823,229 | IMI; Note Guarantors | 5 1/4% | March 15, 2028 |
| 5% Notes due 2028 | 500,000 | 498,674 | IMI; Note Guarantors | 5% | July 15, 2028 |
| 7% Notes | 1,000,000 | 995,037 | IMI; Note Guarantors | 7% | February 15, 2029 |
| 4 7/8% Notes due 2029 | 1,000,000 | 995,660 | IMI; Note Guarantors | 4 7/8% | September 15, 2029 |
| 5 1/4% Notes due 2030 | 1,300,000 | 1,294,234 | IMI; Note Guarantors | 5 1/4% | July 15, 2030 |
| 4 1/2% Notes | 1,100,000 | 1,094,502 | IMI; Note Guarantors | 4 1/2% | February 15, 2031 |
| 5% Notes due 2032 | 750,000 | 742,384 | Iron Mountain Information Management Services, Inc. as direct obligor; guaranteed by IMI and Note Guarantors | 5% | July 15, 2032 |
| 5 5/8% Notes | 600,000 | 596,612 | IMI; Note Guarantors | 5 5/8% | July 15, 2032 |
| 6 1/4% Notes | 1,200,000 | 1,188,598 | IMI; Note Guarantors | 6 1/4% | January 15, 2033 |
| Euro Notes | 1,361,166 | 1,345,956 | IMI; Note Guarantors; 1,200,000 thousand euros | 4 3/4% | January 15, 2034 |
| 6 1/4% Notes due 2035 | 1,500,000 | 1,482,276 | IMI; Note Guarantors (Parent Notes, 10-Q Q3 page:21) | 6.25% | January 15, 2035 |
| Real Estate Mortgages, Financing Lease Liabilities and Other | 819,780 | 818,241 | Various; at Dec 31, 2025 mortgages 73,250, financing leases 527,199, other notes 185,048 (10-K page:140) | Mortgages about 4.2%; financing leases 5.6% weighted; other 6.5% weighted (Dec 31, 2025) | Various |
| Accounts Receivable Securitization Program | 408,000 | 406,371 | Special purpose subsidiaries are the obligors; IMI performance guaranty; secured by US receivables | 4.7% | July 1, 2029 (extended from July 1, 2027, 10-Q Q3 page:22) |
| Total long-term debt | 18,096,426 | 17,972,202 | Less current portion 1,232,903 gives long-term 16,739,299 | 5.7% weighted average incl. letter of credit fees (10-Q Q3 page:39) | Various |

The table has 24 lines and sums to the printed totals (check: debt 18,096,426; unamortized deferred financing costs 124,224; carrying 17,972,202). Senior notes (12 series) total 12,136,166 on principal, or 67.1% of 18,096,426; bank, project, receivables and other debt total 5,960,260. The indentures rank the notes pari passu with the Credit Agreement debt but effectively subordinated to secured debt and structurally subordinated to non-guarantor subsidiary liabilities (10-K page:144). Change of control put at 101% (10-K page:145). The covenants carry no rating trigger (10-Q Q3 page:23). Rates for the loans are those in the 10-K debt note, carried to Q3 unless the Q3 note states a new rate; floating-rate loans may have repriced.

### Claims outside the debt figure

| Item | Amount (US$ thousand) | Inside or outside debt | Locator and note |
| --- | --- | --- | --- |
| Operating lease liabilities | 2,518,768 (332,050 current + 2,186,718 long-term) | Outside | 10-Q Q3 page:9. Operating lease cost for nine months 2026 was 553,526. The Credit Agreement leverage is lease adjusted; the headline debt ratios above are not. |
| Financing lease liabilities | 570,931 (71,869 + 499,062) | Inside, within "Real Estate Mortgages, Financing Lease Liabilities and Other" | 10-Q Q3 page:9. |
| Finance lease not yet commenced | About 223,400 undiscounted minimum payments, 31-year term, expected to start in Q4 2026 | Outside | 10-Q Q3 page:10. |
| Deferred purchase obligations (Regency Transaction, Level 3 fair value) | 210,188, up from 134,142 at Dec 31, 2025 | Outside | 10-Q Q3 page:10-11. Nine-month remeasurement loss 69,803 (10-Q Q3 page:6). |
| Redeemable noncontrolling interests and noncontrolling interests | 62,186 and 325,265 | Outside | 10-Q Q3 page:2-3. Noncontrolling interests include the Virginia 9 JV, initial 49,900 (10-Q Q3 page:24). |
| Purchase commitments | 234,027 total at Dec 31, 2025 (2026 80,208; 2027 94,778; 2028 37,333; 2029 9,141; 2030 6,382; thereafter 6,185) | Outside | 10-K page:151. Not restated in the 10-Qs. |
| Data center construction commitments | About 1,085,725 at Dec 31, 2025, expected over one to two years | Outside | 10-K page:151. Not restated at Sep 30, 2026: Not supplied. |
| Derivative liabilities (fair value) | 49,909 (assets 8,997) | Outside | 10-Q Q3 page:10. Hedge notionals: interest rate swaps about 770,000; cross-currency swaps 1,054,559 (10-Q Q3 page:51-52). |
| Self-insurance accruals | About 44,300 at Dec 31, 2025 | Outside | 10-K page:151. |
| Unconsolidated Frankfurt JV | Carrying value 74,323, 20% equity interest | Outside; its debt is not consolidated | 10-Q Q3 page:52. Adjusted EBITDA includes IMI's share of JV reconciling items (2,500 in Q3 2026, Release Q3 page:9). |
| Pensions and retiree medical | Not supplied: searched "pension", "retiree" and "post-retirement" in all pinned sources and found no disclosure | n/a | Do not treat as zero. |
| Factoring and supply-chain finance | Not supplied: no such program found by search; the receivables securitization is on balance sheet and inside debt | n/a | Search covered factoring and supply chain finance. |
| Litigation and consent decrees | No amount: the filings state no current litigation is expected to have a material adverse effect (10-Q Q3 page:24); no consent decree found by search | n/a | 10-K page:151 states the same for FY2025. |

### Covenants

| Test (Credit Agreement) | Level | Reported figure | Headroom on reported figures | Definition note |
| --- | --- | --- | --- | --- |
| Net total lease adjusted leverage ratio, maximum | 7.0x | 4.8x at Sep 30, 2026 (also 4.8x at Jun 30 and Mar 31, 2026; 4.9x at Dec 31, 2025) | 2.2x turns (7.0 - 4.8) | EBITDAR based, with adjustments for non-cash charges and expected benefits of acquisitions, signed but not yet commenced data center leases and restructuring; consolidated subsidiaries other than Unrestricted Subsidiaries; trailing four quarters. Not comparable to Adjusted EBITDA. |
| Fixed charge coverage ratio, minimum | 1.5x | 2.5x at Sep 30, 2026 (2.5x at each earlier date shown) | 1.0x (2.5 - 1.5) | Same basis. |

Locators: 10-Q Q3 page:50, 10-Q Q2 page:48, 10-Q Q1 page:38, 10-K page:84. No step-down schedule appears in the pinned sources (searched "step-down" and "springing"). The bond indentures use leverage and fixed charge coverage ratios (not lease adjusted) as incurrence conditions for dividends and debt; their thresholds and the reported indenture ratios are Not supplied. The Credit Agreement limits revolver availability by leverage and EBITDAR (10-K page:141), so the printed availability is a covenant-aware figure. The company states compliance with all ratios at Sep 30, 2026 (10-Q Q3 page:51).

### Latest quarter and subsequent events

- Q3 2026 results (Release Q3 page:1, 7): total revenues 1,990,617 against 1,754,093 in Q3 2025; Adjusted EBITDA 747,958 against 660,379; net income 128,878 against 86,241; margin 37.6%. Q3 2026 revenue was below Q2 2026 (2,029,062) while Q3 2026 Adjusted EBITDA was above Q2 2026 (727,018) (Release Q3 page:7, 9).
- Financing during Q3 2026: revolver borrowings rose (30,000 to 519,500); Virginia 9 term loans rose from 29,595 at June 30 (10-Q Q2 page:21) to 138,627; receivables program rose from 400,500 to 408,000 (10-Q Q2 page:21; 10-Q Q3 page:22). The 6 1/4% notes due 2035 (1,500,000, June 26, 2026) were issued before the quarter began, in Q2 2026, with net proceeds of about 1,481,800 used to repay revolver borrowings (10-Q Q3 page:23).
- Earlier 2026 events still shaping the balance sheet: Virginia 3 refinancing of 433,000 due 2031 (January 9, 2026); Virginia 9 credit agreement and joint venture (June 9, 2026); receivables program amended May 28, 2026 to 450,000 and July 1, 2029.
- Effective tax rate for Q3 2026 was 30.6% against 16.1% in Q3 2025 (10-Q Q3 page:15).
- Subsequent events up to the cutoff: a dividend of 0.993 per share was declared on November 5, 2026 (an increase of 15%), payable January 6, 2027 to holders of record December 15, 2026 (Release Q3 page:2; 10-Q Q3 page:24). Management raised full-year 2026 guidance (revenue 7,950 to 8,020 US$m, Adjusted EBITDA 2,948 to 2,978 US$m, Release Q3 page:2); this is a management forward-looking claim, not a filed fact, and is not used in any calculation. No other subsequent event was found; no separate subsequent events note is printed.

### Evidence citations

| Source | Locator | Exact quote |
| --- | --- | --- |
| 10-Q Q3 2026 | page:20 | "Total Long-term Debt 18,096,426 (124,224) 17,972,202" |
| 10-Q Q3 2026 | page:20 | "The remaining amount available for borrowing under the Revolving Credit Facility as of September 30, 2026 was $2,218,218" |
| 10-Q Q3 2026 | page:23 | "we have outstanding letters of credit totaling $61,252, of which $12,282 reduces our borrowing capacity under the Revolving Credit Facility" |
| 10-Q Q3 2026 | page:50 | "Net total lease adjusted leverage ratio 4.8 Maximum allowable of 7.0" |
| 10-Q Q3 2026 | page:50 | "Fixed charge coverage ratio 2.5 Minimum allowable of 1.5" |
| 10-Q Q3 2026 | page:42 | "Adjusted EBITDA $ 2,182,915 $ 1,868,673 $ 314,242 16.8 %" |
| 10-Q Q3 2026 | page:7 | "Cash Paid for Interest $ 801,904 $ 711,517" |
| 10-Q Q3 2026 | page:6 | "Cash Flows from Operating Activities 1,203,634 840,001" |
| 10-K FY2025 | page:57 | "Adjusted EBITDA $ 2,573,950 $ 2,236,380" |
| 10-K FY2025 | page:99 | "Cash Paid for Interest $ 824,591 $ 770,688 $ 512,446" |
| 10-K FY2025 | page:141 | "not to exceed $2,750,000 in United States dollars" |
| 10-K FY2025 | page:150 | "Thereafter 7,173,071" |
| 10-K FY2025 | page:150 | "Total Long-term Debt (including current portion) $ 16,431,959" |
| 10-K FY2025 | page:144 | "47/8% Notes due 2027 $ 1,000,000 IMI September 15, 2027" |

## Gaps

- G1 (corrected from CP-0): no consolidated maturity table after December 31, 2025. The chart uses the 10-K table; the Q3 2026 wall is only known by instrument (debt inventory above). Remediation: treat any Q3 2026 maturity profile as derived.
- G2: covenant definitions differ from Adjusted EBITDA, no credit agreement or indenture is supplied, and indenture ratios and thresholds are Not supplied. Headroom is stated only on the printed Credit Agreement ratios.
- G3: capitalized interest for 2026, and the reason cash interest paid exceeds interest expense, net for nine months 2026, are Not supplied. The cover ratio uses cash interest paid as printed.
- G4: composition of the current portion of debt (1,232,903) is not itemized; whether the 2027 data center loans were extended is Not supplied.
- G5: the Sep 30, 2025 balance sheet and the Q3 2025 10-Q are not in the pack, so 9M 2025 balance items and the original basis of the 9M 2025 comparatives could not be checked; LTM flows rely on the comparatives printed in the 2026 filings.
- G6: UK revolver current headroom, the facilities behind 48,970 of letters of credit outside the revolver, and construction commitments at Sep 30, 2026 are Not supplied.
- G7: pensions, retiree medical, factoring and consent decrees: no disclosure found after search; not zero.
- G8: Adjusted EBITDA and AFFO are management non-GAAP measures; the filings reconcile Adjusted EBITDA to net income but the add-backs (stock-based compensation 115,911 and other expense, net 35,488 for nine months 2026, Release Q3 page:10) are large enough to move leverage; the stricter measure is shown.
- G9: no guarantor or restricted-group financial information is supplied, so structural subordination cannot be quantified.

## Next module

CP-1A, business and transaction context, followed by CP-2 and CP-5. Carry forward: the correction to CP-0 gap G1, the LTM basis, the leverage and cover figures (6.22x, 6.16x, 3.16x), liquidity of 2,406.4 US$m, the near-term maturities (4 7/8% notes due 2027 and the 2027 data center loans), the funding gap (negative free cash flow before dividends), and gaps G2 to G9.
