## Request

Issuer: MURPHY OIL CORP (issuer id mur; ticker MUR; registrant "Murphy Oil Corporation and consolidated subsidiaries"). As-of date and cutoff: 2026-11-05. Pathway: credit_snapshot. Current period q3-2026; prior period fy-2025. Reporting currency USD. Nothing dated after 2026-11-05 is used as fact.

Reader question for this module: which transaction, business, ownership and operating facts matter most to a creditor of MURPHY OIL CORP? The decision drivers are the transaction and ownership structure, the business and operating model, and credit-relevant history or change. Each material conclusion is built as evidence, then risk mechanic, then credit implication. Fact rows carry one category: Documentary Fact (the cited source states it), Management Language (management's characterisation, quoted and qualified, not adopted), Analyst Interpretation (our reading of cited evidence, including calculations) or Insufficient Information (the evidence is missing; the missing datapoint and why it matters are stated). Missing evidence is never an adverse conclusion.

Perimeter and periods: Murphy Oil Corporation consolidated, including 100 percent of MP Gulf of Mexico, LLC (MP GOM), which has a 20 percent noncontrolling interest (NCI) (EX-99.1 2026-11-04 page:6). Filing figures include NCI; release headline metrics exclude it, and each such figure is labelled. Periods follow the CP-1 handoff: Q3 2026, 9M 2026 (nine months ended September 30, 2026), FY2025 and FY2024. Locators use `page:N`, the chunk number of the retained text extraction.

Prohibited and not done here: no peer ranking, no instrument recommendation, no recovery conclusion, no score. Material from outside the sources is labelled external; none is used.

## Sources

### Issuer sources relied on

| Source (exact name) | sha256 | Use in this handoff |
| --- | --- | --- |
| 10-K_2025-12-31_mur-20251231.htm.jsonl | c16d5d2420f4bb44dfe1750a952efb626f89571137858e2ac70733c2eb2e689d | Business description, assets, reserves, employees, exhibits, capital allocation risk factors, debt history |
| 10-Q_2026-03-31_mur-20260331.htm.jsonl | d566f6d07ea8b1f603a66a35f7401d96364d9e6eb05d9a099bfb89d283abc3ab | Q1 2026 financing events and discoveries |
| 10-Q_2026-06-30_mur-20260630.htm.jsonl | fce04c2bd9f3b4a6b7e478f16ad61267a81b35840396e9479017f47656dba038 | Q2 2026 events, six-month figures |
| 10-Q_2026-09-30_mur-20260930.htm.jsonl | b147365971e4aae7d6b9ba5fb1957e3afe56838663b5e3650eda237bbf2505f6 | Revenue mix, MD&A drivers, outlook, hedging, leases, subsequent events |
| EX-99.1_2026-05-06_mur-2026q1xex991.htm.jsonl | e744f241b72a8349b639a4aa3e30a129b2d6c215dc449c6dde3de97f6a877f8e | Q1 2026 headline results and management narrative |
| EX-99.1_2026-08-05_mur-2026q2xex991.htm.jsonl | e539fda8d909d906b9600fb569bd69a3204d1238c76ef5932e4e80c62a82c36d | Q2 2026 headline results and management narrative |
| EX-99.1_2026-11-04_mur-2026q3xex991.htm.jsonl | 74bcf894de6bb55cd6cce5e2656dafd86d31eac8462cf1bb5793b8acd23b2fdd | Q3 2026 results, operations summary, guidance, prices |

The run `context` file is not issuer evidence. Its deal terms, quotes, ratings, sponsor, parent and guarantor fields are blank or empty; blanks are not treated as zero or as "none exist".

### Supplied handoffs

| Module | sha256 | Use |
| --- | --- | --- |
| CP-0 | 403edb4227a4b11394670d0864302fb8b9a59504dd78e89f0fe1d69a345893bb | Source readiness, conflict log, gap list |
| CP-1 | 4d5950c4064f287f2e32c5d0c0406bc21b674c599f97781d7194c385f998c5b5 | Financial base: debt stack, liquidity, calculated EBITDA, leverage, cover, claims outside debt |

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| Murphy is a listed, unsponsored oil and gas producer with no buyout or acquisition driving the credit. The main changes are a 2026 refinancing and rising exploration spending in Côte d'Ivoire, Vietnam and the Gulf of America. | Medium | Ownership percentages, customer concentration, the capital allocation plan terms and any debt restrictions on distributions are not in the sources, so governance and creditor-control views are limited. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Crude oil and condensate supplies 86.1 percent of nine-month 2026 revenue from production, and no commodity derivatives were in place at September 30, 2026. | Cash flow moves directly with oil prices; the higher 2026 earnings rest on higher realized prices while volumes fell. | High |
| The United States supplies 79.7 percent of nine-month 2026 revenue, and United States offshore alone supplies 50.2 percent. | Concentration in Gulf of America fields means natural decline must be offset by continued capital spending. | Medium |
| Nine-month 2026 exploration expense was 155.2 million dollars, including 86.7 million dollars of unsuccessful well costs, with appraisal programs in Côte d'Ivoire and Vietnam. | Exploration absorbs cash and can fail; successes create later development capital needs before they add cash flow. | Medium |
| The 2026 financing was a 500.0 million dollar notes issue, redemption of 227.5 million dollars of earlier notes, an upsized revolver and an 83.9 million dollar finance lease. | Maturities were extended with no note due before May 2029; the debt increase came from the issue and the lease, not a shareholder transaction. | Medium |
| Buybacks were 301.4 million dollars in 2024, 102.6 million dollars in 2025 and 0.8 million dollars in nine months 2026, with 550 million dollars still authorized. | Returns have been cut back as spending rose, which favors creditors; restrictions on distributions and the plan terms are not in the sources. | Medium |

### Business and transaction view

MURPHY OIL CORP is an independent, publicly listed oil and gas exploration and production company with no sponsor, no controlling owner identified in the sources and no acquisition or leveraged transaction driving the credit view. The decision drivers are therefore the operating model and recent change, not transaction structure. Evidence: crude oil and condensate is 86.1 percent of nine-month 2026 revenue from production, no commodity derivative contracts were in place at September 30, 2026, and realized prices rose sharply on the year (for example United States onshore crude at 86.48 dollars per barrel in Q3 2026 against 65.48 dollars in Q3 2025) while total hydrocarbon production fell 7 percent in Q3 2026 and 3 percent in nine months 2026, which management attributes mainly to lower Gulf of America volumes (natural decline) and to the timing of new onshore wells (10-Q Q3 page:34-36). Risk mechanic: an oil-weighted, unhedged revenue base converts price moves almost directly into cash flow, so the 2026 earnings recovery is a price result with lower volumes; sustaining production requires continuing capital in decline-prone Gulf of America fields (about half of nine-month revenue is United States offshore) while the company also funds exploration and appraisal in Côte d'Ivoire, Vietnam and the Gulf of America. Credit implication: leverage and liquidity are currently strong (CP-1 handoff), but they depend on commodity prices and on management choosing to keep exploration and shareholder returns within cash flow; the sources show that discretion being exercised conservatively on buybacks and with a refinancing that extended maturities, but they do not show the covenant or indenture limits that would constrain distributions or new debt. Credit-relevant change in the period: the January 2026 refinancing (500.0 million dollars of 6.500% notes due 2034, 227.5 million dollars of 2027 and 2028 notes redeemed, revolver upsized to 2.0 billion dollars and extended to January 2031), the first oil at Lac Da Vang in Vietnam with an 83.9 million dollar finance lease for its floating storage vessel, raised 2026 production guidance, and an October 2026 drillship agreement worth approximately 225 million to 325 million dollars gross. The view is limited by missing ownership percentages, customer concentration and capital allocation plan terms (see Gaps).

### Company and operating model

| Area | Fact | Category | Source and locator | Risk mechanic and credit implication |
| --- | --- | --- | --- | --- |
| Core activities | Global oil and natural gas exploration and production company with onshore and offshore operations; produces crude oil, natural gas and NGLs mainly in the United States and Canada and explores in targeted areas worldwide; E&P segments are United States, Canada and all other countries, plus Corporate; the US refining and marketing business was separated in 2013 | Documentary Fact | 10-K page:4 | Pure upstream exposure with no downstream offset: revenue and cash flow follow commodity prices and volumes |
| United States assets | Gulf of America: rights to about 556 thousand gross acres, about 65 percent of 2025 US hydrocarbon production, about 91 percent of Gulf output from ten fields; Eagle Ford Shale: about 130 thousand gross acres and about 35 percent of 2025 US production | Documentary Fact | 10-K page:5 | Offshore output depends on a small set of fields and on natural decline; onshore is the shorter-cycle offset |
| Canada assets | Tupper Montney (100 percent working interest, about 139 thousand gross acres), Kaybob Duvernay (70 percent working interest), and non-operated Hibernia (6.5 percent), Hibernia South Extension (4.3 percent) and Terra Nova (18.0 percent) offshore Newfoundland and Labrador | Documentary Fact | 10-K page:5-6 | Gas-weighted onshore volumes and non-operated offshore oil add diversification, but operators control Canada offshore uptime |
| Exploration and new areas | Côte d'Ivoire: five offshore blocks, 1.4 million gross acres, 90 percent (four blocks) and 85 percent working interest; Vietnam: operator with 65 percent (Blocks 144 and 145) and 40 percent (Blocks 15-1/05 and 15-2/17); Brunei 8.051 percent; Brazil blocks; Morocco block at 75 percent working interest signed January 2026, no firm well commitments in the initial three-year phase | Documentary Fact | 10-K page:4-7 | Growth options are discretionary spend with dry-hole risk; acreage expiries in 2026 include 4,267 thousand net acres in Vietnam and 558 thousand in Côte d'Ivoire (10-K page:13) |
| Volume and mix | Q3 2026 production excluding NCI 186,495 BOEPD: onshore about 125,400 (34 percent liquids), offshore about 61,100 (88 percent liquids); Tupper Montney 76,000 BOEPD from 200 BOPD of oil. Including NCI, Q3 2026 was 192,283 BOEPD, down from 206,936 in Q3 2025, and nine months 2026 was 182,494 BOEPD against 189,035 | Documentary Fact | EX-99.1 2026-11-04 page:2-3, page:13; 10-Q Q3 page:34-36 | Gas volumes are large in BOE terms but earn little revenue: Canada onshore gas was 69.7 of 849.2 million dollars of Q3 2026 revenue |
| Revenue streams | Nine months 2026 revenue from sales to customers 2,507.9 million dollars: crude oil and condensate 2,158.6, NGLs 66.7, natural gas 282.6; Q3 2026: 731.0, 25.9 and 92.3 of 849.2 | Documentary Fact | 10-Q Q3 page:8-9 | Oil share of 86.1 percent (nine months, calculated) makes oil price the dominant revenue driver |
| Geographic revenue mix | Nine months 2026: United States 1,997.9 million dollars, Canada 507.1, Other 2.9; United States offshore revenue by product sums to 1,259.7 million dollars; United States share 79.7 percent, United States offshore 50.2 percent, Canada 20.2 percent (calculated) | Analyst Interpretation | 10-Q Q3 page:8-9, page:30 | Revenue is concentrated in United States offshore and onshore oil |
| Pricing | Revenue is "largely index-based with price adjustments for floating market differentials"; Canada onshore gas contracts include floating index pricing and fixed-price physical forward sales. Q3 2026 against Q3 2025 realized prices: United States onshore crude 86.48 against 65.48 dollars per barrel, United States offshore 89.38 against 67.00, Canada offshore 108.21 against 69.42; Canada onshore gas 1.63 against 1.22 dollars per thousand cubic feet | Documentary Fact | 10-Q Q3 page:8; EX-99.1 2026-11-04 page:14 | Oil prices rose about a third year on year (32.1 percent onshore, 33.4 percent offshore, calculated); gas realizations in Canada stay low |
| Price environment | WTI crude futures were 89.42 dollars per barrel at September 30, 2026 and 104.12 dollars at the end of October 2026, which the company describes as a 16 percent increase; the forward curve for the rest of 2026 was 96.46 dollars per barrel at November 2, 2026 | Documentary Fact | 10-Q Q3 page:36 | Current earnings reflect a high-price period; a price reversal would lower cash flow with little offset |
| Hedging | No commodity-based derivative contracts were in place at September 30, 2026. Fixed-price forward gas sales in Canada: 59 MMCF per day at C$3.00 for October to December 2026 and 9.5 MMCF per day at C$3.14 for 2027, accounted for as normal sales | Documentary Fact | 10-Q Q3 page:55, page:53 | Oil is unprotected; the gas forward sales cover a small share of Canadian volume (about 59 of 464 MMCF per day of Q3 2026 Canada onshore gas, calculated) |
| Cost structure | Nine months 2026 against nine months 2025 (million dollars): lease operating expenses 436.4 against 605.0; DD&A 787.9 against 736.9; transportation, gathering and processing 139.4 against 151.1; exploration 155.2 against 57.4, of which unsuccessful exploration well costs and previously suspended exploration costs were 86.7 against 0.1; selling and general 114.1 against 98.7. Lease operating expense per BOE excluding NCI 8.56 against 11.46 dollars | Documentary Fact | 10-Q Q3 page:3, page:30; EX-99.1 2026-11-04 page:12 | Falling operating cost per barrel supports margin; rising exploration and DD&A offset part of it |
| Management explanation of costs | Management attributes lower lease operating expenses to "substantially lower workover and production-related costs in the Gulf of America, partially offset by higher activity in the Eagle Ford Shale" and higher exploration expense to dry hole costs in Côte d'Ivoire and Vietnam | Management Language | 10-Q Q3 page:35-36 | Workover swings can reverse; treat the cost fall as partly non-recurring until repeated |
| Capital spending | Nine months 2026 property additions and dry hole costs 1,333.0 million dollars; capital expenditures attributable to Murphy 1,363.2; 2026 guidance 1,500 to 1,600 million dollars excluding NCI, with 190 million dollars in Q4 2026. Development spending: Gulf of America 447.8, Eagle Ford Shale 232.2, Tupper Montney and Kaybob Duvernay 128.1, Vietnam 99.4; exploration expenditures 471.0 million dollars | Documentary Fact | 10-Q Q3 page:46; EX-99.1 2026-11-04 page:3, page:12 | Spending is a large share of operating cash flow and is partly discretionary, which is the main lever if prices fall |
| Reserves and replacement | Proved reserves 730.0 million BOE at December 31, 2025, of which 311.1 million BOE (43 percent) is undeveloped and 15.0 million BOE is attributable to the NCI; 2025 production 68.9 million BOE; 2025 spend to convert undeveloped reserves about 690 million dollars; expected 450 to 800 million dollars per year over the next three years | Documentary Fact | 10-K page:8-9 | Reserve life is about 10.6 years of 2025 production (calculated); converting undeveloped reserves requires sustained capital |
| Working capital | Net working capital liability of 57.2 million dollars at September 30, 2026 against 246.0 million dollars at December 31, 2025; receivables rose 112.5 and payables rose 50.6 million dollars, which management links to higher oil and NGL prices and Gulf of America drilling | Documentary Fact | 10-Q Q3 page:47 | Working capital is a small liability; price rises tie up receivables |
| Customers | Many purchasers in the markets where Murphy produces; no customer concentration percentage and no major-customer disclosure found | Insufficient Information | 10-K page:141 | Missing datapoint: share of revenue from the largest purchasers; it matters for counterparty and offtake risk |
| MP GOM subsidiary | Murphy reports 100 percent of MP GOM with a 20 percent NCI; formed under a Contribution Agreement dated October 10, 2018 among Murphy Exploration & Production Company - USA, Petrobras America Inc. and MP GOM (exhibit list). NCI net income 71.4 million dollars and distributions 21.2 million dollars in nine months 2026 against 43.2 million dollars distributed in nine months 2025 | Documentary Fact | EX-99.1 2026-11-04 page:6; 10-K page:83; 10-Q Q3 page:3, page:5 | Part of Gulf of America cash flow leaves to the minority holder (the NCI took 13.5 percent of consolidated nine-month 2026 net income, calculated); the holder's identity is not stated in the text read |
| Operating incidents | August 2026 produced water release from a pipeline on private land in Tupper Montney West, reported to authorities and under remediation; higher other operating expense of 28.6 million dollars in Q3 2026 against 5.9 million dollars was attributed to abandonment and environmental remediation costs in the Gulf of America and Canada | Documentary Fact | 10-Q Q3 page:26, page:3, page:35 | Remediation and abandonment costs are recurring operating items; the release amount is not stated |
| Strategic claims | CEO quote: "this breadth of capabilities is what differentiates Murphy" | Management Language | EX-99.1 2026-11-04 page:2 | Promotional; not adopted as evidence of resilience |

### Company profile

| Field | Detail | Category | Source and locator |
| --- | --- | --- | --- |
| Legal name and form | Murphy Oil Corporation, Delaware; incorporated in Louisiana in 1950 as Murphy Corporation and reincorporated in Delaware in 1964 | Documentary Fact | 10-K page:4 |
| Listing | Common stock, 1.00 dollar par, ticker MUR, New York Stock Exchange; large accelerated filer | Documentary Fact | 10-K page:1 |
| Headquarters | Houston, Texas | Documentary Fact | 10-K page:1, page:4 |
| Sector and country | Crude petroleum and natural gas; United States (context fields); operations in the United States, Canada, Brunei, Côte d'Ivoire, Vietnam and exploration in Brazil and Morocco | Documentary Fact | context; 10-K page:4-7 |
| Reporting entity | Consolidated group including MP GOM (20 percent NCI); no separate issuer-only, borrower-only or guarantor-only statements | Documentary Fact | 10-Q Q3 page:8; CP-0 handoff |
| Operating subsidiaries | Murphy Exploration & Production Company - USA (US), Murphy Oil Company Ltd. (Canada), Murphy Exploration & Production Company - International (Brazil, Brunei, Côte d'Ivoire, Vietnam), all wholly owned | Documentary Fact | 10-K page:4 |
| Credit agreement parties | Borrowers Murphy Oil Corporation, Murphy Exploration & Production Company - International and Murphy Oil Company Ltd.; guarantors Murphy Exploration & Production Company and Murphy Exploration & Production Company - USA (Second Amendment exhibit, January 2, 2026) | Documentary Fact | 10-K page:85 |
| Employees | 813 employees at December 31, 2025: 542 office-based and 271 field | Documentary Fact | 10-K page:19 |
| Shares | 143,381,125 shares outstanding at October 31, 2026; 142,830,352 at January 31, 2026; market value held by non-affiliates 2,375,149,725 dollars at June 30, 2025 | Documentary Fact | 10-Q Q3 page:1; 10-K page:2 |
| Auditor | KPMG LLP, Houston; unqualified opinion on FY2025 statements and internal control (report dated February 25, 2026) | Documentary Fact | 10-K page:92-93 |
| Fiscal year-end | December 31 | Documentary Fact | 10-K page:1 |
| Sponsor, parent, controlling holder | None stated in the sources; equity is exchange-listed; beneficial ownership is in the proxy statement, which is incorporated by reference and not supplied | Insufficient Information | 10-K page:2 |
| Credit ratings | Not stated; the filings mention S&P and Moody's only as drivers of pricing | Insufficient Information | 10-K page:113; 10-Q Q3 page:14 |

### Transaction summary and new debt issues

There is no acquisition, buyout, sponsor transaction or restructuring in the sources and none in the run context, so the transaction row is Insufficient Information by design: no transaction source exists, and nothing is invented. The relevant transactions are financings and asset-level events, each stated with its status as of the cutoff.

Financing, completed: on January 2, 2026 the company amended its credit agreement to a 2.0 billion dollar senior unsecured guaranteed revolving facility maturing January 2, 2031, with 12.3 million dollars of transaction costs, replacing the previous 1.35 billion dollar facility maturing October 7, 2029; on January 23, 2026 it closed a public offering of 500.0 million dollars of 6.500% senior notes due February 15, 2034 with 8.3 million dollars of costs, using the proceeds to repurchase and repay debt and fees and for general corporate purposes; in the first quarter of 2026 it redeemed the remaining 78.9 million dollars of 5.875% notes due 2027 and 148.6 million dollars of 6.375% notes due 2028, 227.5 million dollars in total at a cost of 3.5 million dollars, and repaid the 100.0 million dollar revolver draw outstanding at December 31, 2025 (10-Q Q3 page:14-15; 10-K page:113-114). Earlier, in October 2024, it closed 600.0 million dollars of 6.000% notes due 2032, used to fund tenders and repurchases that the 10-K describes as a debt-neutral transaction (10-K page:114). Net effect on liquidity: the revolver commitment rose by 650.0 million dollars and cash plus undrawn capacity was 2,499.9 million dollars at September 30, 2026 (CP-1 handoff). A shelf registration permits further offerings through October 15, 2027.

Lease financing, completed: in Q3 2026 a finance lease commenced for the Lac Da Vang floating storage and offloading vessel, September 2026 to October 2039, with a right-of-use asset of 103.4 million dollars and a lease liability of 83.9 million dollars (10-Q Q3 page:32). This is a new debt-like claim of the kind that lease financing creates outside the notes.

Pending or subsequent, within the cutoff: in October 2026 the company agreed to use a deepwater drillship in the Gulf of America for an initial ten wells at approximately 225 million to 325 million dollars gross, with options for up to five more wells, expected to start in the first quarter of 2027 and not recognized at September 30, 2026 (10-Q Q3 page:32); it secured six exploration blocks from the August Gulf of America lease sale and signed agreements with Mauritania for two offshore blocks, and is working to finalize an agreement in Cameroon before year-end (10-Q Q3 page:34, page:52). In January 2026 it signed a Petroleum Agreement for a 75 percent working interest in a Moroccan deepwater block (10-K page:4-5). These are exploration commitments of unquantified size beyond the drillship.

Asset transactions in the history: purchase of the Pioneer floating production storage and offloading vessel from BW Offshore (UK) Limited for a gross price of 125.0 million dollars in the first quarter of 2025, with a five-year operations and maintenance contract that began in 2025; a 23.0 million dollar purchase of additional Eagle Ford Shale working interest in the third quarter of 2025; and, in 2023, sales of part of the Kaybob Duvernay working interest and the entire 30 percent non-operated working interest in the Placid Montney (10-Q Q3 page:13; 10-K page:5-6). The text read does not describe the terms of the 2023 sales.

New debt issue summary: the only new notes in the period are the 6.500% notes due 2034 (500.0 million dollars). No sponsor, use-of-proceeds dispute, rating action or market quote is in the sources; the instruments' security, guarantors and covenants are not printed in the notes read and the indentures are not supplied (see Gaps).

### Ownership and control

| Item | Detail | Category | Source and locator |
| --- | --- | --- | --- |
| Owner class | Publicly traded common stock; 195,100,628 shares issued and 143,381,125 outstanding at October 31, 2026, with 51,719,503 treasury shares at September 30, 2026 | Documentary Fact | 10-Q Q3 page:1, page:5 |
| Control rights | No controlling shareholder, class structure or voting arrangement is described in the sources read; Item 12 is incorporated from the proxy statement for the May 13, 2026 meeting | Insufficient Information | 10-K page:2 |
| Economic interest | Not disclosed in the sources: holders and percentages; none is inferred | Insufficient Information | 10-K page:2 |
| Prior ownership | Spin-off of the US refining and marketing business in August 2013 (Murphy USA Inc. retains its environmental exposure); Murphy holds retained environmental liabilities for formerly owned refineries sold in 2011 | Documentary Fact | 10-K page:4; 10-Q Q3 page:26 |
| Dividend recapitalisation history | None documented in the sources; documented distributions are ordinary dividends and open-market buybacks | Documentary Fact | 10-K page:47, page:96 |
| Subsidiary minority | 20 percent NCI in MP GOM | Documentary Fact | EX-99.1 2026-11-04 page:6 |

### Timeline

| Date | Event | Category | Source and locator |
| --- | --- | --- | --- |
| 1950 and 1964 | Incorporated in Louisiana as Murphy Corporation; reincorporated in Delaware as Murphy Oil Corporation | Documentary Fact | 10-K page:4 |
| 2013 | US refining and marketing business separated | Documentary Fact | 10-K page:4 |
| October 2018 | Contribution Agreement forming MP GOM with Petrobras America Inc. (exhibit) | Documentary Fact | 10-K page:83 |
| 2023 | Sale of part of Kaybob Duvernay and the 30 percent Placid Montney interest; Terra Nova production resumed in Q4 2023 | Documentary Fact | 10-K page:5-6 |
| August 8, 2024 | Board authorized a share repurchase program of up to 1,100 million dollars | Documentary Fact | 10-Q Q3 page:53 |
| October 2024 | 600.0 million dollars of 6.000% notes due 2032 issued; 521.1 million dollars of 2027, 2028 and 2029 notes tendered | Documentary Fact | 10-K page:114 |
| Q1 2025 | Pioneer FPSO purchased for a gross 125.0 million dollars | Documentary Fact | 10-Q Q3 page:13 |
| Q3 2025 | Impairment of 115.0 million dollars (92.0 million dollars excluding NCI) on the Dalmatian field in the Gulf of America after reserve reductions | Documentary Fact | 10-Q Q3 page:13 |
| January 2, 2026 | Amended 2.0 billion dollar revolving credit facility, maturity January 2, 2031 | Documentary Fact | 10-Q Q3 page:14 |
| January 2026 | Morocco Petroleum Agreement (75 percent working interest) | Documentary Fact | 10-K page:4-5 |
| January 23, 2026 | 500.0 million dollars of 6.500% notes due 2034 closed | Documentary Fact | 10-K page:114 |
| Q1 2026 | 227.5 million dollars of 2027 and 2028 notes redeemed; Banjo #1 and Cello #1 (Mississippi Canyon 385) discoveries announced | Documentary Fact | 10-Q Q3 page:12, page:15 |
| Q2 2026 | Bubale-1X discovery in Côte d'Ivoire; Hai Su Vang appraisal program concluded in Vietnam | Documentary Fact | 10-Q Q3 page:12 |
| Q3 2026 | Chinook #8 online; first oil at Lac Da Vang; finance lease for its FSO commenced; Bubale West-1X and Lac Da Trang North-1X results; full-year production guidance raised | Documentary Fact | EX-99.1 2026-11-04 page:2; 10-Q Q3 page:32 |
| Subsequent event, October 2026 | Drillship agreement (225 million to 325 million dollars gross) | Documentary Fact | 10-Q Q3 page:32 |
| Subsequent event, after September 30, 2026 | Six Gulf of America blocks secured; Mauritania agreements; amended by-laws adopted November 4, 2026 | Documentary Fact | 10-Q Q3 page:34, page:57 |

### Governance, capital allocation and disclosure behaviour

Assessed at issuer level only, from documented actions; no individual is assessed. Legal capacity (what documents permit), willingness (what was done or stated) and feasibility (liquidity, leverage, market access) are kept apart.

| Behaviour | Documented action | Category | Behaviour category and dimension | Legal capacity, willingness, feasibility | Source and locator |
| --- | --- | --- | --- | --- | --- |
| Debt reduction | "Since 2022, the Company undertook several actions to reduce overall debt" and plans to continue deleveraging; 2024 refinancing was debt-neutral; 2026 notes issue repaid 227.5 million dollars of shorter notes and the revolver, but total debt still rose by 249.3 million dollars from December 31, 2025 to September 30, 2026 (calculated from the CP-1 handoff) | Documentary Fact | Neutral or Mixed; leverage tolerance | Capacity: indenture and credit agreement limits not supplied. Willingness: stated deleveraging goal, partly met. Feasibility: calculated total debt over EBITDA 0.89x | 10-K page:33; 10-Q Q3 page:14 |
| Shareholder distributions | Buybacks 301.4 million dollars (2024), 102.6 million dollars (2025), 0.8 million dollars (nine months 2026, excise tax); 550 million dollars remains authorized; dividends 1.20 dollars (2024) and 1.30 dollars (2025) per share, 0.35 dollars per quarter in 2026, 150.5 million dollars in nine months 2026; company states it is "currently more likely to use available adjusted free cash flow for share repurchases than bond repayment" | Documentary Fact; the stated preference is Management Language | Neutral or Mixed; capital allocation | Capacity: restrictions not supplied. Willingness: buybacks cut while dividends rose. Feasibility: calculated free cash flow after dividends and NCI distributions of 12.9 million dollars in nine months 2026 (CP-1 handoff) | 10-K page:96; 10-Q Q3 page:53, page:4 |
| Disclosure | Quarterly non-GAAP reconciliations to GAAP (adjusted net income, EBITDA, EBITDAX, free cash flow, net debt), segment note by area, covenant compliance statement each quarter | Documentary Fact | Supportive; disclosure | Willingness shown by recurring reconciliations; covenant levels for the amended facility are not disclosed in the 10-Qs | EX-99.1 2026-11-04 page:8-11; 10-Q Q3 page:14 |
| Creditor-adverse actions | Searched all seven sources for priming, uptier, drop-down, non-pro rata, collateral release, restricted payment and change of control: no match. The only documented debt actions are the voluntary tender and redemption of 2027, 2028 and 2029 notes (10-K page:114; 10-Q Q3 page:15) | Insufficient Information | Insufficient Information; creditor control | Missing datapoint: indenture and credit agreement text; absence of a mention is not proof of absence | 10-K page:112-114 |
| Related-party flows | None found; the 20 percent NCI in MP GOM receives distributions (21.2 million dollars in nine months 2026) | Documentary Fact | Neutral or Mixed; related-party leakage | Distributions follow the minority holder's economic interest; terms of the MP GOM agreement are not supplied | 10-Q Q3 page:5 |
| Investment appetite | Exploration and appraisal programs across Côte d'Ivoire, Vietnam, Gulf of America, Morocco and Mauritania and a pending Cameroon agreement | Documentary Fact | Neutral or Mixed; growth appetite | Spending is largely discretionary; the drillship commitment adds a contracted element from Q1 2027 | 10-Q Q3 page:52, page:32 |

Evidence quality: High for the filing-based rows (primary, dated, issuer-specific); Medium for rows combining a filing with the release; Insufficient for ownership percentages, customer concentration and covenant text.

### Conflicts logged

| Conflict | Span A | Span B | Effect |
| --- | --- | --- | --- |
| Coupon on the notes due December 2042 | "5.875% notes, due December 2042" (10-K page:112) | "6.375% notes, due December 2042" (10-Q Q3 page:13); the exhibit list names a "5.125% Notes due 2042" (10-K page:83) | Logged, not reconciled; the coupon on 339.8 million dollars of notes is unresolved |
| 2025 revenue comparatives in the segment note | Segment note consolidated total revenues and other income 733.2 million dollars (Q3 2025) and 2,096.7 million dollars (nine months 2025) (10-Q Q3 page:29-30) | Statement of operations 732,985 and 2,094,266 thousand dollars (10-Q Q3 page:3) | Logged, not reconciled; small, limited to 2025 comparatives |
| Production perimeter | 192,283 BOEPD including NCI (10-Q Q3 page:34) | 186,495 BOEPD excluding NCI (EX-99.1 2026-11-04 page:1) | Not a conflict in substance: different stated perimeters; both retained |

These are inherited from the CP-0 handoff; none counters the credit translations below except the coupon conflict, which bears on interest cost for the 2042 notes.

### Credit translations

| Theme | Evidence | Risk mechanic | Credit implication |
| --- | --- | --- | --- |
| Revenue durability | Crude oil 86.1 percent of nine-month 2026 revenue; no commodity derivatives at September 30, 2026; Q3 2026 realized onshore crude 86.48 dollars per barrel against 65.48 dollars (10-Q Q3 page:8-9, page:55; EX-99.1 2026-11-04 page:14) | Unhedged oil exposure transmits price changes to revenue, EBITDA and cash available for debt service with little lag | Strong 2026 coverage and leverage rest on a high-price period; downside cases need price sensitivities, which are outside this module |
| Margin and cash-flow risk | Lease operating expense per BOE excluding NCI 8.56 dollars against 11.46 dollars, explained by lower Gulf of America workovers; exploration expense 155.2 million dollars against 57.4 million dollars (10-Q Q3 page:35-36; EX-99.1 2026-11-04 page:12) | Cost relief from workovers can reverse; exploration dry holes reduce earnings and cash without adding reserves | Margin gains are partly non-recurring; free cash flow is thin after investment, so distributions and exploration are the adjustment levers |
| Concentration | United States offshore 50.2 percent of nine-month revenue; Gulf of America about 65 percent of 2025 US production and ten fields about 91 percent of Gulf output (10-K page:5) | Few fields carry much of the cash flow and decline naturally; downtime or a field-specific event hits revenue directly | Maintenance capital in the Gulf of America is a structural need that competes with exploration |
| Sponsor and shareholder alignment | No sponsor; buybacks down from 301.4 million dollars to 0.8 million dollars while dividends per share rose; 550 million dollars of buyback capacity remains and management expects buybacks to be preferred over bond repayment (10-K page:96; 10-Q Q3 page:53) | Board-discretion returns can be increased as cash flow rises, and are the main leak of cash to equity | Alignment is neutral to mixed; creditor protection depends on indenture and credit agreement restrictions that are not supplied |
| Key uncertainties | Missing ownership percentages, customer concentration, capital allocation plan terms, notes security and guarantors, covenant text; unresolved 2042 notes coupon | Each limits the view of who controls decisions, who owes cash flow to the company and what constrains distributions | Monitoring posture: obtain the indentures, the credit agreement and the May 7, 2025 capital allocation disclosure before any committee reliance on creditor-control conclusions |

### Consumer readiness

| Module | Readiness | What it should take from this handoff | Why it matters | Gap | Required action |
| --- | --- | --- | --- | --- | --- |
| CP-2 | Ready with limitations | Oil-weighted, unhedged revenue base; United States offshore concentration; exploration and drillship commitments; 2026 refinancing and maturity profile; conservative buyback pattern | The synthesis must tie leverage and liquidity to price sensitivity and discretionary spend | Customer concentration, ownership, covenant and indenture text, capital allocation plan terms | Carry the limitations; do not describe creditor protections as verified |
| CP-5 | Ready with limitations | The three logged conflicts and the Insufficient Information rows | The validator must check locators and not accept inferred ownership or covenant statements | Coupon conflict unresolved; segment comparatives differ slightly | Treat the coupon as open and check the 2025 comparatives against the statement of operations |

### Monitoring items missing from the source set

| Item | Severity | Why it matters |
| --- | --- | --- |
| Covenant certificate and conformed credit agreement | High | Headroom and distribution limits cannot be confirmed |
| Indentures for each note series | High | Ranking, guarantors, change-of-control and restricted payments are unknown |
| Capital allocation disclosure of May 7, 2025 (Form 8-K, not supplied) | Medium | The share of adjusted free cash flow to be returned determines how much cash leaves before debt reduction |
| Debt and maturity schedule | Low | Available from the debt note and the CP-1 handoff |
| Add-back bridge | Low | Management reconciliations are in the releases; full-year ex-NCI figures are in the 10-K |
| Principal holders (proxy statement) | Medium | Control and alignment cannot be assessed |

## Calculations

All inputs are from the cited pages; results rounded for display.

1. Revenue mix, nine months 2026 (10-Q Q3 page:8-9, US$ thousands): crude oil and condensate 2,158,615 / 2,507,861 = 86.1 percent; NGLs 66,652 / 2,507,861 = 2.7 percent; natural gas 282,594 / 2,507,861 = 11.3 percent (the three rounded shares sum to 100.1 percent because of rounding). Q3 2026: 731,015 / 849,175 = 86.1 percent.
2. Geographic mix, nine months 2026: United States = onshore crude 671,559 + offshore crude 1,182,280 + onshore NGLs 40,153 + offshore NGLs 21,714 + onshore gas 26,494 + offshore gas 55,674 = 1,997,874; 1,997,874 / 2,507,861 = 79.7 percent, equal to the segment note's 1,997.9 (page:30). United States offshore = 1,182,280 + 21,714 + 55,674 = 1,259,668; / 2,507,861 = 50.2 percent. Canada = 82,669 + 219,198 + 4,785 + 200,426 = 507,078; / 2,507,861 = 20.2 percent.
3. Canada onshore gas share of Q3 2026 revenue: 69,743 / 849,175 = 8.2 percent. Tupper Montney share of Q3 2026 production excluding NCI: 76,000 / 186,495 = 40.8 percent; onshore 125,400 / 186,495 = 67.2 percent (EX-99.1 2026-11-04 page:2-3).
4. Volume mix, nine months 2026 including NCI (EX-99.1 2026-11-04 page:13): crude oil and condensate 90,887 BOPD / 182,494 BOEPD = 49.8 percent; NGLs 11,398 / 182,494 = 6.2 percent; gas 481,254 MCFD / 6 = 80,209 BOEPD, / 182,494 = 44.0 percent.
5. Price changes, Q3 2026 against Q3 2025 (EX-99.1 2026-11-04 page:14): onshore crude 86.48 / 65.48 - 1 = 32.1 percent; offshore crude 89.38 / 67.00 - 1 = 33.4 percent.
6. Production change including NCI (10-Q Q3 page:34; EX-99.1 2026-11-04 page:13): Q3 192,283 / 206,936 - 1 = -7.1 percent (the filing says 7 percent); nine months 182,494 / 189,035 - 1 = -3.5 percent (the filing says 3 percent).
7. Gulf of America share of 2025 production including NCI (10-K page:5): (61,233 + 52,000 / 6) = 69,900 BOEPD / 188,682 BOEPD = 37.0 percent. The 10-K states 65 percent of US production.
8. Reserves (10-K page:8): 730.0 / 68.9 = 10.6 years of 2025 production; undeveloped 311.1 / 730.0 = 42.6 percent, which the 10-K rounds to 43 percent.
9. NCI share of earnings, nine months 2026: 71,437 / 527,718 = 13.5 percent.
10. Exploration change: 155,229 - 57,389 = 97,840, equal to the 97.8 million dollars in the MD&A (10-Q Q3 page:36).
11. Revolver commitment change: 2,000.0 - 1,350.0 = 650.0 million dollars (10-Q Q3 page:14; 10-K page:113).
12. Total debt change from December 31, 2025 to September 30, 2026: 1,634,352 - 1,385,080 = 249,272 thousand dollars (CP-1 handoff).
13. Hedged share of Canada onshore gas: 59 MMCF per day / (464,262 MCFD / 1,000 = 464.3 MMCF per day) = 12.7 percent for Q4 2026 only; 9.5 / 464.3 = 2.0 percent for 2027 (calculated from Q3 2026 volume as a rough scale, not a forecast).

## Gaps

| Gap | Search and result | Severity | Consumers | Action |
| --- | --- | --- | --- | --- |
| Ownership: holders, percentages, control rights, any sponsor | Item 12 and Part III are incorporated by reference from the proxy statement for May 13, 2026, which is not in the pack (10-K page:2). No percentage is inferred | Medium | CP-2, CP-5 | Obtain the proxy statement |
| Customer concentration | Searched major customer, significant customer, percent of revenue, concentration of credit: only a statement that many purchasers exist (10-K page:141) | Medium | CP-2 | Obtain disclosure by purchaser if any |
| Capital allocation plan | The plan is described by reference to a Form 8-K filed May 7, 2025, which is not supplied (10-Q Q3 page:53) | Medium | CP-2 | Obtain the 8-K |
| Indentures, credit agreement text, covenant certificate | Only exhibit references (10-K page:83-85); see the CP-0 and CP-1 handoffs | High | CP-2, CP-5 | Obtain documents |
| Holder of the 20 percent NCI in MP GOM and the MP GOM agreement terms | The 10-K exhibit list names Petrobras America Inc. as a party to the 2018 Contribution Agreement; the text read does not name the NCI holder | Low | CP-2 | Treat identity as unconfirmed |
| Coupon on the 2042 notes | Open conflict | Medium | CP-2, CP-5 | Obtain the indenture |
| Amount of the August 2026 produced water release and its cost | Not stated (10-Q Q3 page:26) | Low | CP-2 | Monitor |
| Terms of the 2023 asset sales | Not described in the text read (10-K page:5-6) | Low | CP-2 | None required for the snapshot |
| Earnings presentation and stockholder update | Referenced but not supplied (EX-99.1 2026-11-04 page:1, page:4) | Low | CP-2 | Add if slide narrative is needed |

Unknown is not zero: none of these gaps is treated as nil or as an adverse conclusion. Subsequent events are identified in the timeline and the transaction summary; nothing is dated after 2026-11-05.

## Next module

Proceed to CP-2 (fundamental credit synthesis), then CP-5. CP-2 should combine the CP-1 financial base with this handoff: the oil-weighted, unhedged revenue base (86.1 percent crude oil, no commodity derivatives at September 30, 2026) and the United States offshore concentration (50.2 percent of nine-month 2026 revenue); the discretionary but large exploration and capital programs (nine-month exploration expense 155.2 million dollars, 2026 capital expenditure guidance 1,500 to 1,600 million dollars excluding NCI, drillship commitment of approximately 225 million to 325 million dollars gross from the first quarter of 2027); the refinancing that left no note due before May 2029; the conservative buyback pattern with 550 million dollars still authorized; and the NCI leakage from MP GOM. It must keep the open items as open: ownership percentages, customer concentration, covenant and indenture text, capital allocation plan terms, and the 2042 notes coupon conflict, and must not state recovery outcomes, instrument recommendations or peer rankings. CP-5 should test each locator above against the page-level sources, in particular the 86.1 percent, 79.7 percent and 50.2 percent mix shares, which are calculated from the revenue note, not printed.
