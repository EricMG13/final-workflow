## Request

This is the fundamental credit synthesis for MURPHY OIL CORP (ticker MUR), as of 2026-11-05, on the credit_snapshot pathway. It combines the financial base from the CP-1 handoff with the business and transaction context from the CP-1A handoff, in USD, for the periods Q3 2026, nine months 2026 (9M 2026), FY2025 and the twelve months to September 30, 2026 (LTM Q3 2026). It gives a credit view, not a recommendation, ranking or recovery estimate.

## Sources

### Issuer sources relied on

The figures in this synthesis come from the upstream handoffs, which rest on the sources below. The debt note, liquidity, revenue note, reserves and the claims outside debt were spot-checked against the filings while writing; no conflict with the handoffs was found.

| Source (exact name) | sha256 |
| --- | --- |
| 10-K_2025-12-31_mur-20251231.htm.jsonl | c16d5d2420f4bb44dfe1750a952efb626f89571137858e2ac70733c2eb2e689d |
| 10-Q_2026-03-31_mur-20260331.htm.jsonl | d566f6d07ea8b1f603a66a35f7401d96364d9e6eb05d9a099bfb89d283abc3ab |
| 10-Q_2026-06-30_mur-20260630.htm.jsonl | fce04c2bd9f3b4a6b7e478f16ad61267a81b35840396e9479017f47656dba038 |
| 10-Q_2026-09-30_mur-20260930.htm.jsonl | b147365971e4aae7d6b9ba5fb1957e3afe56838663b5e3650eda237bbf2505f6 |
| EX-99.1_2026-05-06_mur-2026q1xex991.htm.jsonl | e744f241b72a8349b639a4aa3e30a129b2d6c215dc449c6dde3de97f6a877f8e |
| EX-99.1_2026-08-05_mur-2026q2xex991.htm.jsonl | e539fda8d909d906b9600fb569bd69a3204d1238c76ef5932e4e80c62a82c36d |
| EX-99.1_2026-11-04_mur-2026q3xex991.htm.jsonl | 74bcf894de6bb55cd6cce5e2656dafd86d31eac8462cf1bb5793b8acd23b2fdd |

The run `context` file is not issuer evidence; its ratings, quotes and valuation inputs are blank and are not treated as zero.

### Supplied handoffs

| Module | sha256 | What this synthesis takes from it |
| --- | --- | --- |
| CP-0 | 403edb4227a4b11394670d0864302fb8b9a59504dd78e89f0fe1d69a345893bb | Source limits, the conflict log and the gap list |
| CP-1 | 4d5950c4064f287f2e32c5d0c0406bc21b674c599f97781d7194c385f998c5b5 | Financial figures, debt stack, liquidity, calculated EBITDA, ratios, claims outside debt, covenant indications |
| CP-1A | 7945a44700eadeabed9be261a818aba8aaa8237d27c6ae8595ee9fe98ab9b034 | Business and operating model, ownership, transaction history, capital allocation behaviour, conflicts, consumer readiness |

In this document, bracketed references name the handoff and the section or row used, for example [CP-1 Debt stack] or [CP-1A Company and operating model: Revenue streams].

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| Murphy's credit is sound today: total debt is 0.89x calculated EBITDA, liquidity is USD 2,499.9 million and no note matures before May 2029. It is exposed to oil prices and to discretionary spending that absorbs most operating cash flow. | Medium | Covenant and indenture terms, ratings, ownership percentages and customer concentration are not in the sources, so creditor protections and limits on distributions cannot be confirmed. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Total debt is USD 1,634.4 million, 0.89x calculated EBITDA of USD 1,837.5 million, and interest paid is covered 21.29x. | Debt service capacity is strong at current prices; the ratios rest on calculated, consolidated EBITDA, not a covenant definition. | Medium |
| Crude oil is 86.1 percent of nine-month 2026 revenue and no commodity derivatives were in place at September 30, 2026. | A price fall reaches cash flow directly; a 10 percent lower oil price on nine-month volumes would cut EBITDA by about 14.0 percent. | Medium |
| Nine-month 2026 operating cash flow of USD 1,517.6 million funded USD 1,333.0 million of property additions and dry hole costs and USD 150.5 million of dividends. | The cushion after investment and dividends is thin, so exploration and distributions are the adjustment levers. | Medium |
| Cash of USD 500.3 million and USD 1,999.6 million undrawn on a revolver maturing January 2031 meet all debt maturities for years. | Refinancing risk is low until 2029, when USD 117.6 million of notes mature; larger maturities start in 2032. | High |
| Claims outside debt include asset retirement obligations of USD 1,065.4 million and operating leases of USD 653.8 million. | Including them with pension and retiree medical liabilities, calculated leverage is 1.93x, a more conservative view than debt alone. | Medium |

### Credit view

MURPHY OIL CORP is a financially conservative but price-exposed oil producer, and its credit is sound today. The strongest support is low leverage (total debt of USD 1,634.4 million is 0.89x calculated last-twelve-months EBITDA of USD 1,837.5 million), liquidity of USD 2,499.9 million and no note maturing before May 2029. The weakest point is that crude oil supplies 86.1 percent of revenue with no commodity derivatives in place, while exploration, development and a new drillship commitment absorb most operating cash flow, leaving little after dividends. What decides the outcome is the oil price and management's willingness to cut discretionary spending and buybacks when it falls; the covenant and indenture limits that would bound that discretion are not in the sources.

### Credit assessment

Category: Analyst Interpretation. Confidence: Medium, below High because CP-1A judges this module ready only with limitations and because covenants, indentures, ratings, ownership and customer concentration are missing. Basis: [CP-1 Financials and credit metrics; Chart data: leverage, interest cover, liquidity, debt maturities; Debt stack] and [CP-1A Business and transaction view; Credit translations; Consumer readiness].

Rationale. Evidence: MURPHY OIL CORP has total debt of USD 1,634.4 million, net debt of USD 1,134.1 million, cash of USD 500.3 million, calculated LTM EBITDA of USD 1,837.5 million, interest paid of USD 86.3 million and cash plus undrawn committed capacity of USD 2,499.9 million, with the nearest note maturity in May 2029 [CP-1]. Risk mechanic: those figures come from a period when United States onshore crude realized USD 86.48 per barrel in Q3 2026 against USD 65.48 in Q3 2025, on an unhedged, oil-weighted revenue base whose volumes fell 7 percent in Q3 2026 [CP-1A Company and operating model: Pricing; Hedging; Volume and mix]. Credit implication: near-term default risk is low on the reported figures, because leverage, liquidity and the maturity profile give a large buffer; the risk sits in how the company behaves if prices fall, which depends on contract terms the sources do not provide.

### Credit thesis

Category: Analyst Interpretation. MURPHY OIL CORP is a low-leverage, well-funded but oil-price-exposed producer whose creditworthiness depends on keeping discretionary spending and shareholder returns inside cash flow. Basis: [CP-1 Financial base view] and [CP-1A Governance, capital allocation and disclosure behaviour].

### Key findings

First, the company's leverage is low and has fallen even though debt rose. Total debt was USD 1,385.1 million at December 31, 2025 and USD 1,634.4 million at September 30, 2026, an increase of USD 249.3 million from a USD 500.0 million notes issue, a USD 83.9 million finance lease and the repayment of USD 227.5 million of notes and the USD 100.0 million revolver draw, while calculated EBITDA rose from USD 1,394.0 million (FY2025) to USD 1,837.5 million (LTM Q3 2026), so total debt over EBITDA moved from 0.99x to 0.89x [CP-1 Debt stack; Chart data: leverage]. The management-basis cross-check gives 0.92x on adjusted EBITDA attributable to Murphy of USD 1,784.8 million.

Second, the improvement is a price result. Revenue from production rose to USD 2,507.9 million for nine months 2026 from USD 2,076.8 million, with realized prices up about a third and production down 3 percent, and lease operating costs fell on lower Gulf of America workovers, which management itself describes as partly offset by activity elsewhere [CP-1 Financials and credit metrics; CP-1A Company and operating model: Cost structure; Management explanation of costs]. Part of the cost gain may not repeat, and none of the price gain is protected, because crude oil is 86.1 percent of revenue and there were no commodity derivatives at September 30, 2026.

Third, free cash flow is modest. Calculated free cash flow (operating cash flow less property additions and dry hole costs) was USD 184.6 million for nine months 2026, which after USD 150.5 million of dividends and USD 21.2 million of distributions to the minority holder of MP Gulf of Mexico, LLC leaves USD 12.9 million; management's own adjusted free cash flow was negative USD 32.2 million for the same period, excluding the minority share [CP-1 Free cash flow and shareholder distributions]. Cash still rose by USD 123.1 million because operating cash flow exceeded investing outflow by USD 155.9 million, while financing used USD 32.8 million.

Fourth, maturities and liquidity are comfortable. No note matures until May 2029 (USD 117.6 million), followed by USD 600.0 million in October 2032, USD 500.0 million in February 2034 and USD 339.8 million in December 2042; the USD 2.0 billion revolver matures January 2, 2031 and is undrawn apart from USD 0.4 million of letters of credit [CP-1 Chart data: debt maturities; Liquidity]. The 2026 refinancing moved the company from a revolver and shorter notes to this profile.

Fifth, claims outside the debt figure are large. Asset retirement obligations are USD 1,065.4 million, operating lease liabilities USD 653.8 million, and net pension and retiree medical liabilities were USD 195.8 million at December 31, 2025, before commitments of USD 1,648.0 million at that date and a new drillship agreement of about USD 225 million to USD 325 million gross from the first quarter of 2027 [CP-1 Claims outside the debt figure]. Adding the first three to total debt gives USD 3,549.3 million, or 1.93x calculated LTM EBITDA (see Calculations).

Sixth, creditor protections are unverified. The previous revolver's tests were a maximum leverage ratio of 3.25x and a minimum interest coverage ratio of 2.50x before an investment grade ratings date, and a 60 percent maximum debt to total capitalization after it; the amended facility's terms, the indentures and the ratings are not supplied, and which test applies is unknown [CP-1 Covenants and definitions; CP-0 Gaps]. The mechanical distance to the stated levels is wide (see Calculations) but is not covenant headroom.

### Strengths and weaknesses

Strengths. Low leverage is a documentary result: total debt is USD 1,634.4 million against calculated LTM EBITDA of USD 1,837.5 million, and net debt is 0.62x (Documentary Fact for the figures, Analyst Interpretation for the characterisation) [CP-1 Chart data: leverage]. Liquidity and maturity profile: USD 2,499.9 million of cash and undrawn capacity, a revolver to January 2031 and no note before May 2029 (Documentary Fact) [CP-1 Liquidity; Chart data: debt maturities]. Operating cash flow was USD 1,517.6 million for nine months 2026, 52.0 percent above nine months 2025, and calculated LTM EBITDA covers interest paid 21.29x (Documentary Fact for the cash flow, Analyst Interpretation for the cover) [CP-1 Calculations]. Asset base: proved reserves of 730.0 million barrels of oil equivalent at December 31, 2025, about 10.6 years of 2025 production, spread across Eagle Ford Shale, Gulf of America, Tupper Montney, Kaybob Duvernay, Canada offshore and Vietnam, with 43 percent undeveloped (Documentary Fact for reserves, Analyst Interpretation for diversification) [CP-1A Company and operating model: United States assets; Canada assets; Reserves and replacement]. Capital allocation flexibility: buybacks fell from USD 301.4 million in 2024 to USD 102.6 million in 2025 and USD 0.8 million in nine months 2026, which favors creditors, and no related-party leakage, creditor-adverse transaction or sponsor is documented (Documentary Fact for the amounts, Analyst Interpretation for the reading) [CP-1A Governance, capital allocation and disclosure behaviour]. Disclosure quality: quarterly reconciliations of non-GAAP measures and a covenant compliance statement each quarter (Documentary Fact) [CP-1A Governance].

Weaknesses. Unhedged oil exposure: crude oil is 86.1 percent of revenue and no commodity derivatives were in place at September 30, 2026; a 10 percent lower oil price on nine-month volumes would have cut revenue and EBITDA by about USD 215.9 million, or 14.0 percent of nine-month calculated EBITDA, before any cost offset (Documentary Fact for the exposure, Analyst Interpretation for the arithmetic) [CP-1A Hedging; Revenue streams]. Thin cash cushion after investment and dividends, as described above (Documentary Fact for the amounts) [CP-1 Free cash flow]. Concentration and decline: United States offshore supplies 50.2 percent of nine-month revenue, and production including the minority share fell 7 percent in Q3 2026, mostly on Gulf of America volumes (Documentary Fact for the percentages, Management Language for the cause) [CP-1A Geographic revenue mix; Volume and mix]. Discretionary, high-risk spending: exploration expense was USD 155.2 million for nine months 2026, including USD 86.7 million of unsuccessful well costs, and the drillship agreement adds a contracted element from 2027 (Documentary Fact) [CP-1A Cost structure; Transaction summary]. Claims outside debt, including asset retirement obligations equal to about 65 percent of total debt (Analyst Interpretation, calculated) [CP-1 Claims outside the debt figure]. Unverified creditor terms: covenants, indentures, ratings, ownership percentages and customer concentration are missing (Insufficient Information; each missing datapoint is listed under Gaps) [CP-0 Gaps; CP-1A Gaps]. Perimeter: the minority holder takes a share of Gulf of America cash flow, 13.5 percent of consolidated nine-month 2026 net income, and releases and filings use different perimeters (Documentary Fact) [CP-1A Company and operating model: MP GOM subsidiary].

### Key credit risks

| Risk | Mechanic | Credit implication | Severity | Basis |
| --- | --- | --- | --- | --- |
| Oil price decline on an unhedged base | Crude oil is 86.1 percent of revenue; no commodity derivatives at September 30, 2026; WTI futures were USD 89.42 per barrel at September 30, 2026 | EBITDA and cash available for debt service fall quickly; the company would have to cut exploration, capital and buybacks to hold leverage | Material | [CP-1A Revenue streams; Hedging; Price environment] |
| Gulf of America concentration and natural decline | United States offshore is 50.2 percent of nine-month revenue, with ten fields supplying about 91 percent of Gulf output | Maintenance capital must continue; a field-specific event or faster decline hits revenue and liquidity | Material | [CP-1A Geographic revenue mix; United States assets] |
| Discretionary spending and new commitments | Nine-month property additions and dry hole costs were USD 1,333.0 million; the drillship agreement adds about USD 225 million to USD 325 million gross from 2027; exploration across Côte d'Ivoire, Vietnam, Gulf of America and new blocks | Spending can outrun cash flow if prices fall or wells are dry; contracts reduce flexibility | Material | [CP-1 Free cash flow; CP-1A Capital spending; Transaction summary] |
| Distributions and debt capacity not bounded by known terms | USD 550 million of buyback authorization remains and management states buybacks are more likely than bond repayment | Cash could leave the group ahead of debt reduction; indenture and credit agreement limits are unknown | Material | [CP-1A Governance: Shareholder distributions] |
| Unverified covenants, indentures and ratings | Only the previous facility's tests are described; the investment grade ratings date status is unknown | Headroom, guarantor coverage and ranking cannot be confirmed; monitoring posture is limited | Material | [CP-1 Covenants and definitions; CP-0 Gaps] |
| Claims outside debt | Asset retirement obligations USD 1,065.4 million; operating leases USD 653.8 million; pension and retiree medical USD 195.8 million; commitments USD 1,648.0 million | These call on cash alongside debt service; calculated leverage including the first three is 1.93x | Material | [CP-1 Claims outside the debt figure] |
| Minority holder and perimeter | 20 percent noncontrolling interest in MP Gulf of Mexico, LLC; distributions USD 21.2 million in nine months 2026 | Part of Gulf of America cash flow is not available to Murphy creditors; headline measures differ by perimeter | Minor | [CP-1A MP GOM subsidiary] |
| Coupon label on the 2042 notes | 5.875% in the 10-K and 6.375% in the Q3 10-Q on USD 339.8 million of notes | About USD 1.7 million a year of interest at 0.5 percentage points; trivial against EBITDA but unresolved | Minor | [CP-0 conflict log; CP-1A Conflicts logged] |
| Operating and environmental incidents | August 2026 produced water release at Tupper Montney West, amount not stated; abandonment and remediation costs raised other operating expense | Recurring cost with unquantified tail; monitored | Minor | [CP-1A Operating incidents] |

## Calculations

Inputs are from the CP-1 and CP-1A handoffs unless a source is named; EBITDA means the calculated, consolidated figure defined in the CP-1 handoff (operating income plus DD&A plus impairment).

1. Illustrative oil price sensitivity (arithmetic, not a forecast): nine-month 2026 crude oil and condensate revenue of USD 2,158.6 million (CP-1A, from 10-Q Q3 page:8-9) times 10 percent = USD 215.9 million; divided by nine-month 2026 calculated EBITDA of USD 1,537.3 million = 14.0 percent. It assumes constant volumes, no cost or royalty offset and no tax effect.
2. Mechanical distance to the previous facility's stated levels (not covenant headroom): total debt USD 1,634.4 million divided by 3.25 = USD 502.9 million, so calculated LTM EBITDA of USD 1,837.5 million could fall by 72.6 percent before total debt over EBITDA reached 3.25x; interest paid of USD 86.3 million times 2.50 = USD 215.8 million, so EBITDA could fall by 88.3 percent before EBITDA over interest paid reached 2.50x. The covenant definitions are not supplied.
3. Claims-inclusive leverage (illustrative): total debt USD 1,634.352 million + operating lease liabilities USD 653.756 million (September 30, 2026) + asset retirement obligations USD 1,065.394 million (September 30, 2026) + pension and retiree medical net liabilities USD 195.814 million (USD 132.415 million + USD 63.399 million, December 31, 2025) = USD 3,549.316 million; divided by USD 1,837.474 million = 1.93x. It mixes dates, treats asset retirement obligations as debt-like although they are costs of operations, and excludes commitments and letters of credit. Asset retirement obligations over total debt: 1,065.394 / 1,634.352 = 65.2 percent.
4. Cash walk, nine months 2026 (USD million, 10-Q Q3 page:4-5): operating cash flow 1,517.609 - investing outflow 1,361.686 = 155.923; less financing outflow 32.834, plus exchange effect 0.016 = 123.105, equal to the increase in cash from 377.196 to 500.301.
5. Free cash flow after distributions, nine months 2026 (CP-1): 184.570 - 150.528 - 21.164 = 12.878, shown as USD 12.9 million.
6. Interest cost sensitivity of the 2042 notes coupon: 339.761 million times 0.5 percentage points = USD 1.7 million a year (1,698.8 thousand).
7. Figures carried unchanged from CP-1 and CP-1A, recomputed here as a check: total debt 1,634.352 / EBITDA 1,837.474 = 0.89x; net debt 1,134.051 / 1,837.474 = 0.62x; EBITDA 1,837.474 / interest paid 86.305 = 21.29x; liquidity 500.301 + 1,999.6 = 2,499.9; operating cash flow growth 1,517.609 / 998.162 - 1 = 52.0 percent. All match.

## Gaps

| Gap | What it affects | Severity | Action |
| --- | --- | --- | --- |
| Indentures and credit agreement text, covenant definitions and certificate | Covenant headroom, guarantor coverage, ranking, restrictions on distributions and new debt; the credit view's confidence | High | Obtain the indentures (including the Eighth Supplemental Indenture), the Second Amendment and the conformed credit agreement |
| Credit ratings and investment grade ratings date status | Which covenant set applies and the pricing step on the 2042 notes | Medium | Obtain a rating source outside the pack, labelled external |
| Ownership percentages and control rights (proxy statement not supplied) | Governance and alignment view | Medium | Obtain the proxy statement for the May 13, 2026 meeting |
| Customer concentration | Counterparty and offtake risk | Medium | Obtain purchaser disclosure if any |
| Capital allocation plan terms (Form 8-K of May 7, 2025 not supplied) | How much free cash flow is committed to buybacks before debt reduction | Medium | Obtain the 8-K |
| Coupon on the 2042 notes | Interest cost on USD 339.8 million of notes | Medium | Obtain the indenture or the filing that explains the change |
| Management adjusted EBITDA attributable to Murphy for the LTM period | Leverage uses calculated consolidated EBITDA; the management-basis figure is calculated from a mixed set | Low | Add a fourth quarter 2025 release if a management-basis figure is required |
| Interim cash taxes, letters of credit outside the revolver, pension funded status at September 30, 2026 | Cash conversion and claims outside debt | Low | Treat as not supplied; use December 31, 2025 values where labelled |
| CP-1A readiness judgment of this module is "Ready with limitations", not ready | Confidence is held below High; the limitations are those above | Medium | Close the High and Medium gaps before reliance on creditor-control conclusions |

No upstream handoff is corrected by this synthesis: the CP-1 and CP-1A figures reproduce from their inputs. Unknown is not zero: none of the gaps is treated as nil or as an adverse conclusion. Nothing used is dated after 2026-11-05.

## Next module

Proceed to CP-5 (evidence trace validator). It should test the locators in the CP-1 and CP-1A handoffs behind the figures used here, in particular the calculated EBITDA bridge, the 86.1 percent and 50.2 percent revenue shares (calculated from the revenue note, not printed), the USD 1,634.4 million total debt, the claims outside debt, and the open coupon conflict on the 2042 notes. It should treat the covenant, indenture, ratings, ownership and customer concentration items as open and should not accept any statement that creditor protections are verified.
