## Request

Module: business, ownership and transaction context for MAXLINEAR, INC (MaxLinear, Inc., Nasdaq: MXL, issuer id mxl), as of 2026-11-05, evidence cutoff 2026-11-05. Pathway: credit snapshot; reporting currency USD (amounts in thousands unless a label says millions); current period q3-2026, prior period fy-2025. Reader question: which transaction, business, ownership and operating facts matter most to a creditor, and what history or change has credit consequences. The fact rows below carry one of four tags (Documentary Fact, Management Language, Analyst Interpretation, Insufficient Information) and an evidence quality (High, Medium, Low, Insufficient). No peer ranking, instrument recommendation or recovery conclusion is given. The context names no sponsor, parent, borrower entity, ratings or legal documents.

## Sources

### Issuer sources relied on

Locators are `page:N` chunks of the pinned text extractions, not printed pages.

| Source name | sha256 |
| --- | --- |
| 10-K_2025-12-31_mxl-20251231.htm.jsonl | 88c5a5c8ff6cf18541031ab4aef4feb9645b937db462a2943427cc48c137e1d9 |
| 10-Q_2026-03-31_mxl-20260331.htm.jsonl | 42848ffc444d8c47a09304ae1148778a878e57d84c54fa74dc1f2b0e6e5d0dd8 |
| 10-Q_2026-06-30_mxl-20260630.htm.jsonl | 01411c1534e3e0c0e916b41e14102517d827593ed353c6e2edbb7bcfabe4eb3d |
| 10-Q_2026-09-30_mxl-20260930.htm.jsonl | 75f4d013edbcd52763843513db2d44d0258392fcbcf7fab3f738307f7e5ec1a3 |
| EX-99.1_2026-04-22_a03312026exhibit991.htm.jsonl | 80656f36f632a9814cfc0d89b1465026471d15c2a52a4f467e504c7d5e0b776a |
| EX-99.1_2026-07-23_a06302026exhibit991.htm.jsonl | 513984500469e10cfb125419373d89d4b53d02f7f1ffe85723d32af0bb949f83 |
| EX-99.1_2026-10-22_a09302026exhibit991.htm.jsonl | 2f6d78692e5e0106407183ea23f9296509641c88888df05a93887a904e78fabf |

Run context (not issuer evidence; used only for the sector label and the absence of sponsor, ratings and legal documents): context, sha256 39695f94e05534dbaa55be69eaec116e2e3f550f0af980e236d8132f5e5386f2.

### Supplied handoffs

| Module | sha256 | Use |
| --- | --- | --- |
| CP-0 | 5befe5c880ee0e3433b442e8789a41a9cded34b374570aca05a9aef7730f3cef | Source readiness, entity roles, covenant conflicts; opened and carried forward |
| CP-1 | 2832c94f6492e1df4076ecb5839e253635a2fd23b2e187e34996c901c739795e | Financial base, debt schedule, claims outside debt, covenants; opened and its figures reused unchanged |

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| MaxLinear is a widely held fabless chip designer with no disclosed sponsor, whose 2026 shift toward AI data center optical products lifts growth and concentration together; transaction risks are an unsized Silicon Motion dispute and 2026 credit facility amendments. | Medium | No proxy statement, executed credit agreement or customer names are supplied, so control rights, covenant capacity and counterparty concentration cannot be verified. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Infrastructure was 57% of Q3 2026 revenue against 32% a year earlier, while broadband revenue fell. | The mix shift toward data center raises growth but ties debt service to a few product ramps. | High |
| The ten largest customers were 56% of nine-month 2026 revenue, and customers order without long-term purchase commitments. | Revenue visibility is short, so one design loss or order pause could move cash flow quickly. | High |
| The terminated Silicon Motion merger left an open arbitration and three stockholder suits, none quantified. | An adverse outcome could draw on the revolver and cash, which the liquidity covenant tests. | Medium |
| The credit agreement was amended on 2026-04-22 and 2026-10-16, adding revolver capacity and lowering the liquidity floor; no bonds are outstanding and no sponsor is disclosed. | Lenders extended flexibility, but terms rest on issuer summaries because the executed agreements are not supplied. | Medium |
| Capital allocation is mixed: no dividends ever, USD 20.0 million repurchased in 2025, none in nine months 2026, and a USD 8.0 million note receivable from a supplier. | Shareholder returns are modest, but supply-security funding adds exposure to a supplier's utilization. | Medium |

### Business and transaction view

MaxLinear, Inc. is a Delaware, Carlsbad-headquartered fabless designer of communications systems-on-chip that sells through distributors, module makers, original equipment manufacturers and original design manufacturers, and it is publicly held with no sponsor, parent or controlling holder disclosed in the sources (45 record holders and about 34,000 beneficial holders at 2026-01-22). Its business is changing fast: infrastructure, mainly optical products for data centers, was 57% of Q3 2026 net revenue against 32% in Q3 2025, while broadband fell from 46% to 24% of the quarter's revenue. That change raises revenue and margin, but concentrates risk: the ten largest customers were 56% of nine-month 2026 revenue (65% in FY2025, when two customers were 28%), customers buy on purchase orders with no long-term commitments, shipments to Asia were 85% of nine-month 2026 revenue (Hong Kong 52% in Q3 2026), one supplier took 52% of Q3 2026 inventory purchases, and the company states it has curtailed business with certain customers in China because of export controls. The creditor-relevant transaction history is the terminated Silicon Motion merger of 2022 to 2023: the company paid a USD 18.3 million ticking fee when committed financing was terminated and now faces a confidential Singapore arbitration in which Silicon Motion seeks the termination fee, further damages and costs, plus stockholder suits in two courts and a derivative action. No amount is accrued or estimated, and the filings state that damages could require drawing all lines of credit. On the financing side the sources show a single secured bank structure that was extended and enlarged in 2026 (second amendment of 2026-04-22; third amendment of 2026-10-16, a subsequent event to the quarter) and no notes or new debt issues; the only other 2026 funding transactions are an USD 8.0 million sale of an interest in claims and a revolver draw of USD 40.0 million. Strongest contrary evidence: the filings are consistent and primary, but the facts that would test control and creditor treatment (proxy statement, executed credit agreement and amendments, customer identities, order backlog) are not supplied, so governance conclusions are limited to documented actions. Consequence: the business view supports a fast-growing but concentrated, order-driven semiconductor credit with an unresolved legal overhang; the monitoring posture should key on customer concentration, supplier prepayments and the Silicon Motion docket.

### Company and operating model

| Area | Fact | Category | Evidence quality | Locator | Credit relevance |
| --- | --- | --- | --- | --- | --- |
| Core activities | Fabless provider of communications systems-on-chip combining RF, analog, mixed-signal and digital signal processing; products sold to distributors, module makers, OEMs and ODMs | Documentary Fact | High | 10-K `page:7`-`page:8`; third quarter 10-Q `page:8` | Asset-light model; no owned fabrication, so capital intensity sits in prepayments and purchase commitments |
| End-market mix, Q3 2026 | Infrastructure 124,907 (57%), broadband 53,345 (24%), connectivity 24,713 (11%), industrial and multi-market 15,092 (7%); a year earlier 40,343, 58,236, 18,968 and 8,912 | Documentary Fact | High | Third quarter 10-Q `page:34`-`page:35`, `page:50`-`page:51` | Growth is carried by infrastructure; broadband, the largest FY2025 line, declined |
| End-market mix, FY2025 | Broadband 204,423 (44%), infrastructure 148,164 (32%), connectivity 77,990 (17%), industrial and multi-market 37,064 (8%) | Documentary Fact | High | 10-K `page:112`-`page:113` | Shows how quickly mix moved within three quarters |
| Revenue model | Product sales direct and through distributors (48% of Q3 2026 revenue against 36% a year earlier); intellectual property sale agreements carry upfront consideration plus variable consideration tied to the recipient's revenue | Documentary Fact | High | Third quarter 10-Q `page:36`; 10-K `page:145` | Distributor share rising increases price protection and stock rotation exposure; variable IP consideration is lumpy |
| Pricing and volume drivers | "Price changes did not have a material impact to revenues period over period"; revenue depends on winning design wins with design-in life cycles of 24 to 60 months | Documentary Fact | High | Third quarter 10-Q `page:47`, `page:51` | Growth is volume-led; pricing power not evidenced either way |
| Revenue visibility | Customers purchase on a purchase-order basis with no long-term purchase commitments; purchase orders are received about six to twenty-six weeks before delivery | Documentary Fact | High | Third quarter 10-Q `page:47`; 10-K `page:22` | Short visibility; order cancellations or pauses show up quickly in cash flow |
| Order backlog | Backlog is not disclosed | Insufficient Information | Insufficient | Searched all sources for "backlog": only an accounting policy reference | Missing datapoint limits revenue visibility assessment |
| Customer concentration | Nine months 2026: one customer 10% and ten largest 56% of net revenue; FY2025: two customers 28% and ten largest 65%; FY2024: one customer 12% and ten largest 60% | Documentary Fact | High | Third quarter 10-Q `page:46`; 10-K `page:106` | Concentration is high but the single-customer weight was lower in 2026 than in FY2025 |
| Customer identities | Customers are not named | Insufficient Information | Insufficient | All sources | Counterparty and hyperscaler exposure cannot be assessed beyond management language |
| Geography | Q3 2026 shipments by ship-to location: Asia 194,509 (89%), Europe 13,133 (6%), United States 8,165 (4%); Hong Kong 52%, mainland China 12%, Vietnam 12% of Q3 2026 revenue; all sales in USD | Documentary Fact | High | Third quarter 10-Q `page:34`, `page:46` | Ship-to concentration in Hong Kong; destination of end systems is outside Asia per the company, which is a management belief |
| Export controls | "Since October 2022, we have restricted or curtailed business with certain customers and partners in China as a result of BIS restrictions" | Documentary Fact | High | 10-K `page:28` | Regulatory event risk on a customer and shipment base weighted to Asia |
| Manufacturing and supply | Foundry partners TSMC and UMC; assembly and test subcontractors including ASE; certain products supplied turnkey by Intel; one supplier (Vendor A, not named) took 52% of Q3 2026 inventory purchases | Documentary Fact | High | 10-K `page:22`-`page:23`; third quarter 10-Q `page:34` | Single-supplier dependence and wafer prepayments drive working capital and supply risk |
| Supplier funding | Note receivable from a supplier of 8.0 million, repayable 2.0 million a year by March 31 from 2027 through 2030 if production utilization targets are met; 6.0 million long term | Documentary Fact | High | Third quarter 10-Q `page:18` | Recovery depends on the supplier's utilization, an exposure on top of purchase obligations |
| Cost structure | Q3 2026 cost of net revenue 41% of net revenue, research and development 28%, selling, general and administrative 17%; employee-related costs 69,749 of the Q3 2026 expense block | Documentary Fact | High | Third quarter 10-Q `page:44`, `page:50` | Operating leverage: large fixed R&D and people costs against rising revenue |
| Capital spending and working capital | Nine months 2026 purchases of property and equipment 9,662 and intangible assets 5,373; "Our planned capital expenditures as of September 30, 2026 are expected to increase to support our production needs"; working capital absorbed cash for wafer prepayments and inventory | Documentary Fact | High | Third quarter 10-Q `page:6`, `page:59`, `page:62` | Growth is cash-consuming before it is cash-generating (see the financial base) |
| Management narrative | "the significant growth inflection underway across MaxLinear’s overall business", with the Keystone PAM4 DSP platform and the Rushmore and Annapurna product families named | Management Language | Medium | Third quarter release `page:1` | Attributed claim, not adopted; corroborated in direction by the revenue mix |
| Management outlook | Q4 2026 revenue guided to 240 to 260 million | Management Language | Medium | Third quarter release `page:2` | Forward claim; sets the next working-capital step |

### Company profile

| Attribute | Value | Category | Evidence quality | Locator | Note |
| --- | --- | --- | --- | --- | --- |
| Registrant and incorporation | MaxLinear, Inc., incorporated in Delaware in September 2003; Commission file number 001-34666 | Documentary Fact | High | 10-K `page:1`, `page:139` | Single reporting entity with wholly-owned subsidiaries |
| Listing and share count | Common stock listed on Nasdaq (MXL); 91,000,008 shares outstanding at 2026-10-15; large accelerated filer | Documentary Fact | High | Third quarter 10-Q `page:1` | Market capitalization not supplied |
| Headquarters and country | Carlsbad, California, United States; lease of about 68,000 square feet expiring December 2029; other leased sites in Asia, Europe, Israel and elsewhere | Documentary Fact | High | 10-K `page:98` | Country stated once here |
| Sector | Semiconductors and related devices (run context label) | Documentary Fact | Low | Context | From the run context, not issuer evidence |
| Employees | 1,115 full-time employees at 2025-12-31: 786 research and development, 200 sales and marketing, 27 operations and semiconductor technology, 102 administration | Documentary Fact | High | 10-K `page:30` | Engineering-heavy cost base |
| Ownership class | Publicly traded; 45 record holders and about 34,000 beneficial holders at 2026-01-22; no sponsor | Documentary Fact | High | 10-K `page:103`; context | Widely held; no controlling holder disclosed |
| Beneficial ownership percentages and control rights | Not in the sources; the 10-K incorporates Part III by reference to the proxy statement, which is not supplied | Insufficient Information | Insufficient | 10-K `page:128` | Missing datapoint: holders above 5%, board control; relevant to change-of-control default |
| Prior ownership and recapitalisation | No dividend recapitalisation, sponsor history or prior ownership change is described; the company has never declared or paid a cash dividend | Documentary Fact | High | 10-K `page:103` | Absence of disclosure is not proof of absence |
| Leadership | Chairman and Chief Executive Officer is a combined role; Chief Financial Officer and Chief Corporate Strategy Officer signs the 10-Q | Documentary Fact | Medium | Third quarter release `page:1`; third quarter 10-Q `page:66` | Combined chair and CEO is a governance fact, no personal assessment made |
| Auditor and controls | Grant Thornton LLP, auditor since 2016; auditor's opinion that internal control over financial reporting was effective at 2025-12-31; disclosure controls effective at 2026-09-30 | Documentary Fact | High | 10-K `page:125`-`page:136`; third quarter 10-Q `page:64` | Reporting reliability supports use of filed figures |
| Subsidiaries and guarantors | Exar Corporation and MaxLinear Communications, LLC are named wholly-owned subsidiaries and parties to the third amendment; guarantors are "certain of its domestic subsidiaries" not named | Documentary Fact | High | Third quarter 10-Q `page:23`, `page:48` | Guarantor identity and coverage unresolved |
| Capital structure headline | Secured term loan and revolver, 165,000 of principal at 2026-09-30, both maturing in 2028; no bonds | Documentary Fact | High | Third quarter 10-Q `page:19`-`page:23` (figures as in the financial base) | Only bank debt; no co-issuers |
| Ratings | None supplied | Insufficient Information | Insufficient | Context | No agency view |

### Transaction summary and new debt issues

The terminated Silicon Motion merger is the defining transaction. On 2022-05-05 MaxLinear agreed to acquire Silicon Motion Technology Corporation, a Cayman Islands maker of NAND flash controllers, by statutory merger, with debt financing committed by Wells Fargo Bank and other lenders under a second amended and restated commitment letter dated 2022-10-24 (10-K `page:157`). MaxLinear terminated the agreement on 2023-07-26, stating it owed no break-up fee; Silicon Motion disputes the termination and filed a notice of arbitration with the Singapore International Arbitration Centre on 2023-10-05, seeking the termination fee, additional damages, fees and costs, in a confidential proceeding (third quarter 10-Q `page:14`, `page:38`). The financing commitments were terminated and the company paid Wells Fargo a ticking fee of USD 18.3 million in August 2023 (10-K `page:158`). Silicon Motion stockholders have sued MaxLinear and officers: a putative class action filed 2023-08-31, dismissed with prejudice on 2025-07-15 and on appeal to the Ninth Circuit with briefing completed on 2026-04-13; a second federal action filed 2024-06-13 by HBK funds in which all but one claim survived a motion to dismiss; and a third action filed by the same plaintiffs on 2026-05-14 in San Diego Superior Court alleging fraud and related claims; a derivative action filed 2025-02-12 is stayed (third quarter 10-Q `page:38`-`page:41`). The company accrues no loss, regards an unfavorable outcome as reasonably possible and says a reasonable range cannot be estimated (`page:43`). Its 10-K states that damages or settlement could be significant and could require drawing all existing lines of credit, and that financing on favorable terms may not be available (10-K `page:37`-`page:38`). This is an unresolved contingent claim, not a debt instrument.

The only debt documents are the June 23, 2021 Credit Agreement (Initial Term Loan, original USD 350.0 million, and a revolver) and its amendments: a benchmark replacement on 2023-06-29; the Second Amendment of 2026-04-22, which extended the revolver from 2026-06-23 to 2028-03-23, added USD 30 million of commitments and a USD 10.0 million letter of credit commitment, raised the revolver margin to 2.25% and set a total net leverage ceiling of 3.50 to 1.00 and a liquidity floor of USD 80.0 million; and the Third Amendment of 2026-10-16, a subsequent event after the quarter, which adds USD 70 million of commitments for a total of USD 200 million and lowers the liquidity floor to USD 60.0 million. Proceeds of the revolver finance working capital and general corporate purposes. No new notes or other debt issues appear in the sources. In nine months 2026 the company borrowed USD 60.0 million on the revolver and repaid USD 20.0 million, leaving USD 40.0 million drawn, and in March 2026 it sold an interest in certain claims for up to USD 10.0 million, receiving USD 8.0 million used to pay costs of those claims, recorded as a long-term liability (third quarter 10-Q `page:24`). Use of the revolver draw beyond working capital is not itemised; the cash flow statement points to wafer prepayments and inventory (`page:62`).

Other transactions: a USD 2.0 million convertible note receivable from a privately-held entity (2026-01-05, 3.87% interest, due 2029-01-05) and the supplier note receivable above (third quarter 10-Q `page:18`); a contingent consideration of USD 2.6 million from an acquisition in January 2023, unpaid pending resolution of certain matters (`page:17`); a share repurchase program of up to USD 75.0 million authorized on 2025-11-20, under which USD 20.0 million was repurchased in 2025 and none in nine months 2026, leaving about USD 55.0 million available (`page:44`). The executed credit agreement, amendments and the filing that carries the Third Amendment are not supplied; terms above are the issuer's summaries.

### Timeline

| Date | Event | Type | Locator |
| --- | --- | --- | --- |
| 2003-09 | Incorporated in Delaware | Foundation | 10-K `page:139` |
| 2021-06-23 | Credit Agreement: term B loan of 350.0 million and revolver of up to 100.0 million | Refinancing | 10-K `page:165` |
| 2022-05-05 | Merger Agreement with Silicon Motion | Acquisition (terminated) | 10-K `page:157` |
| 2023-01 | Acquisition with contingent consideration still unpaid | Acquisition | Third quarter 10-Q `page:17` |
| 2023-06-29 | Credit agreement amended for benchmark replacement | Refinancing | Third quarter 10-Q `page:22` |
| 2023-07-26 | MaxLinear terminates the Merger Agreement; 2023-08-16 Silicon Motion disputes; 2023-10-05 notice of arbitration | Disposal of deal; legal | Third quarter 10-Q `page:14` |
| 2023-08 | Ticking fee of 18.3 million paid to Wells Fargo on termination of financing | Financing cost | 10-K `page:158` |
| 2023 and 2024 | Workforce reductions; restructuring continued in 2025 and nine months 2026 | Restructuring | 10-K `page:158`; third quarter 10-Q `page:14` |
| 2025-02-12 | Derivative suit filed (stayed) | Legal | Third quarter 10-Q `page:40` |
| 2025-07-15 | Silicon Motion stockholder class action dismissed with prejudice; appealed 2025-08-08 | Legal | Third quarter 10-Q `page:39` |
| 2025-11-20 | 75.0 million share repurchase authorized | Capital allocation | Third quarter 10-Q `page:44` |
| 2026-01-29 | Form 10-K filed | Disclosure | Third quarter 10-Q `page:8`-`page:9` |
| 2026-04-22 | Second Amendment to the credit agreement | Refinancing | Third quarter 10-Q `page:22` |
| 2026-05-14 | HBK plaintiffs file state court complaint | Legal | Third quarter 10-Q `page:40` |
| 2026-07-02 | Dish files notice of bankruptcy; its action against MaxLinear stayed until 2026-11-02 | Legal | Third quarter 10-Q `page:42` |
| 2026-10-16 | Third Amendment: 70 million more revolver commitments; liquidity floor to 60 million | Subsequent event (after the 2026-09-30 period) | Third quarter 10-Q `page:44`, `page:48` |
| 2026-10-22 | Third quarter release and 10-Q issued | Disclosure | Third quarter release `page:1`; 10-Q `page:9` |

### Governance and capital allocation behaviour

Assessed at issuer level on documented actions only; no sponsor exists, so sponsor behaviour is Insufficient Information and nothing is inferred from ownership type.

| Dimension | Documented action | Behaviour category | Legal capacity | Willingness | Feasibility | Evidence quality | Locator |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Distributions | No cash dividend ever declared or paid; share repurchases of 20.0 million in 2025 under a 75.0 million program, none in nine months 2026 | Neutral or Mixed | Restricted payments are limited by the credit agreement, basket sizes not supplied | Repurchased 20.0 million in 2025, a year in which cash and cash equivalents fell from 118,575 to 72,806 and the net loss was 136,681 (financial base) | Cash and equivalents of 81,085 and the liquidity covenant constrain further returns | High | 10-K `page:103`; third quarter 10-Q `page:23`, `page:44` |
| Acquisitions | Pursued a large committed-financing acquisition that was terminated, with an 18.3 million ticking fee and litigation costs; small tuck-in with contingent consideration; minority-style funding of a private entity by convertible note | Neutral or Mixed (one transaction does not show appetite) | Debt incurrence, investments and fundamental changes limited by covenants | Documented deal attempt and later small investments | Liquidity floor and 3.50 to 1.00 leverage ceiling bound large deals | High | 10-K `page:157`-`page:158`; third quarter 10-Q `page:17`-`page:18` |
| Disclosure | Terms of the 2026 amendments disclosed within days in the 10-Q and release; effective internal control; arbitration confidential; no reported leverage ratio or covenant EBITDA | Supportive on reporting, limited on covenant detail | Not applicable | Disclosure timely | Not applicable | High | 10-K `page:125`; third quarter 10-Q `page:44` |
| Creditor treatment | No priming, uptier, drop-down, non-pro-rata exchange or collateral release is described in the sources read; guarantor and collateral package stated as substantially all assets | Insufficient Information (absence in summaries, executed documents not supplied) | Cannot be assessed without the agreement | No adverse action documented | Not applicable | Low | Third quarter 10-Q `page:23` |
| Related-party leakage | A search of all sources for "related party" and "related parties" returned no match in the 10-K or the third quarter 10-Q | Insufficient Information | Not assessable | Not assessable | Not applicable | Low | Searches of all sources |

### Conflicts and version changes logged

These are logged as found; none is reconciled here.

| Item | Source A | Source B | Downstream effect |
| --- | --- | --- | --- |
| Count of Silicon Motion stockholder suits | 10-K `page:98`: "MaxLinear and certain of its officers have been named as defendants in two lawsuits brought by stockholders of Silicon Motion" | Third quarter 10-Q `page:38`: "named as defendants in three lawsuits brought by stockholders of Silicon Motion" (the third, filed 2026-05-14, appears on `page:40`) | Version change: the docket grew by one action after the 10-K; legal overhang is widening, not shrinking |
| Liquidity covenant wording | Second quarter 10-Q `page:23`: "not to exceed 100% of the Consolidated EBITDA for the most recently ended Test Period" | Second quarter 10-Q `page:60`: "no less than $80 million" | Carried from the readiness handoff; unresolved without the agreement; counters any reading of liquidity headroom as verified |
| Revolver commitments at quarter end | Third quarter 10-Q `page:60`: revolver "of up to $200.0 million, under which $40.0 million in borrowings were outstanding as of September 30, 2026" | Third quarter 10-Q `page:44`: the 70 million increase was entered into on October 16, 2026 | Carried; 200 million is a post-quarter commitment total |
| Springing leverage test | 10-K `page:167`: secured net leverage test if revolver borrowings exceed 1% of commitments | Third quarter 10-Q `page:23`-`page:24`: total net leverage ceiling of 3.50 to 1.00 and liquidity floor, no springing test mentioned | Carried; covenant package unresolved |

### Credit translations

| Theme | Evidence | Risk mechanic | Credit implication | Conflict that counters it | Category |
| --- | --- | --- | --- | --- | --- |
| Revenue durability | Infrastructure at 57% of Q3 2026 revenue; ten largest customers 56%; no long-term purchase commitments; purchase orders placed six to twenty-six weeks ahead (`page:34`-`page:35`, `page:46`-`page:47`; 10-K `page:22`) | Growth rests on a few design wins and data center product ramps ordered without commitment; a pause cuts revenue before costs adjust, because R&D and people costs are fixed in the near term | Debt service capacity is cyclical; coverage and leverage headroom can reverse within a quarter or two; monitor customer concentration and bookings visibility | None logged against this theme; backlog is not disclosed | Analyst Interpretation |
| Margin and cash-flow risk | Gross margin 58.7% in Q3 2026 against 56.9% a year earlier (release `page:1`); operating cash flow negative over nine months 2026 on wafer prepayments (`page:62`); purchase obligations of 272,967 (financial base) | Supplier prepayments and committed purchases precede revenue; single supplier at 52% of Q3 inventory purchases | Cash conversion lags profit; revolver reliance rises with growth; liquidity, not earnings, is binding | Liquidity covenant wording conflict and quarter-end revolver commitments (above) mean headroom is unverified | Analyst Interpretation |
| Concentration | Hong Kong 52% of Q3 2026 revenue; Asia 85% of nine-month revenue; China business curtailed under BIS restrictions (10-K `page:28`) | Export-control or tariff changes can remove shipments quickly; customer identities undisclosed | Event risk on revenue and on supplier access; cannot be sized without customer data | None | Analyst Interpretation |
| Sponsor and shareholder alignment | No sponsor; no dividends ever; 20.0 million repurchased in 2025; 55.0 million authorization remaining | Distributions are discretionary and covenant-limited; limited extraction history | Alignment is neutral; no sponsor-support or leakage evidence either way | None | Analyst Interpretation |
| Key uncertainties | Silicon Motion arbitration and three stockholder suits, no accrual, damages "could be significant" (10-K `page:38`); IP litigation with Comcast, Dish, Cox and DIRECTV; Dish bankruptcy stay to 2026-11-02 | An award or settlement is a cash call that would reduce unrestricted cash counted in the liquidity covenant and could require drawing the revolver | Material tail risk to liquidity and refinancing in 2028; stress headroom for an unsized claim | Conflicting suit counts and unresolved covenant wording counter any firm headroom estimate | Analyst Interpretation |

### Readiness of downstream consumers

| Consumer | Readiness | Take from this handoff | Why it matters | Gap | Required action |
| --- | --- | --- | --- | --- | --- |
| CP-2 credit synthesis | READY_WITH_LIMITATIONS | Business risk drivers (mix, concentration, order basis, supplier dependence), transaction history, legal overhang, governance behaviour | Business risk is the first decision driver and sets the stress cases for the financial base | Customer identities, backlog, proxy, executed agreements, covenant EBITDA | State each as Insufficient Information; stress an unsized claim; do not infer sponsor behaviour |
| CP-5 evidence trace | READY_WITH_LIMITATIONS | Fact rows with locators, the conflicts table and the category tags | Each fact row can be traced to a quoted locator | Locators are extraction chunks; fidelity not reviewed | Trace figures against the financial base and the filings; flag the logged conflicts |

### Monitoring gaps by severity

| Missing item | Severity | Why it matters |
| --- | --- | --- |
| Executed credit agreement, amendments and compliance certificate | High | Covenant capacity, baskets, guarantors and EBITDA definition |
| Proxy statement and holder list above 5% | Medium | Control rights, board structure and change-of-control exposure |
| Silicon Motion arbitration size indicators | High | Liquidity stress |
| Customer identities and backlog | Medium | Revenue visibility and counterparty risk |
| Debt and maturity schedule | Resolved | Available from the notes (financial base) |
| Add-back bridge for covenant EBITDA | Medium | Only the management non-GAAP bridge exists |
| Ratings | Low | No agency view supplied |
| Events 2026-10-22 to 2026-11-05 | Medium | Docket and credit facility developments unobserved |

## Calculations

No new calculation was performed. Figures in this handoff are printed in the cited sources or reused unchanged from the financial base (total debt principal 165,000, cash and cash equivalents 81,085, purchase obligations 272,967). Percentages of revenue are as printed in the filings.

## Gaps

- Executed credit agreement, all amendments and the filing that carries the third amendment are not supplied (context sets legal documents to none); the amendment dates and terms come from the 10-K and 10-Qs. Severity High; affects CP-2 and CP-5.
- Silicon Motion exposure is not quantified, the arbitration is confidential, and stockholder suit counts changed between the 10-K and the third quarter 10-Q (two to three). Severity High.
- Beneficial owners above 5%, board composition and control rights are not supplied because the proxy statement is incorporated by reference. Severity Medium.
- Customer identities, order backlog and the identity of Vendor A are not disclosed. Severity Medium.
- Entropic Communications, LLC is a party in several patent actions; the filings read describe that MaxLinear assigned certain patents to it but do not state its relationship to MaxLinear or its share of intellectual property income. Severity Low.
- No sources after 2026-10-22; the Dish stay ran to 2026-11-02 and the status afterwards is unknown. Severity Medium.
- Ratings, market data and peer information are not supplied and no ranking is made. Severity Low.
- Sector is taken from the run context, not issuer evidence. Severity Low.

## Next module

Proceed to CP-2 (credit synthesis). It should take from this handoff: the business-risk drivers (infrastructure mix at 57% of Q3 2026 revenue, customer concentration with the ten largest at 56%, order-based visibility, supplier concentration and prepayments), the Silicon Motion overhang as an unquantified contingent claim to be stressed against liquidity, the 2026 amendments (flagged as subsequent where dated after 2026-09-30) and the Insufficient Information rows (ownership percentages, customer identities, backlog, executed agreements). Carry forward the four logged conflicts and the tag on every fact row; use the financial base figures unchanged; make no sponsor-behaviour inference. CP-5 should then trace each fact row to its locator.
