# CP-1 — Financial base: NCL CORP Ltd. (ncl-corp-ltd)

## Request

- Issuer: NCL CORP Ltd. (issuer id `ncl-corp-ltd`; the filings name the registrant NCL Corporation Ltd., "NCLC"), as of 2026-11-05, information cutoff 2026-11-05 (context). Reporting currency USD. The statements print US$ thousands; every amount below is converted to US$ millions (US$m) by dividing by 1,000 and is shown to one decimal. Current period Q3 2026; prior period FY2025 (context).
- Run: `ncl-corp-ltd-2026-11-05-credit_snapshot-host`, pathway `credit_snapshot`. Execution: host session; the host read the pinned page text and wrote this answer. No provider was called.
- Perimeter: NCL Corporation Ltd. and its consolidated subsidiaries, as filed by the issuer itself in its 10-K and 10-Qs. The parent, Norwegian Cruise Line Holdings Ltd. ("NCLH"), is a separate registrant whose group figures appear only in the earnings releases. No NCLH figure is used as an issuer figure here; where a release figure is quoted it is labelled parent-level.
- Question: what is the reported financial base for the credit view, with debt, claims outside debt, liquidity, maturities, coverage and the covenant picture, for FY2025 and the first three quarters of 2026?
- Locators are `page:N` of the pinned `.jsonl` text of each source, not printed page numbers. Periods: FY2025, Q1 2026, Q2 2026, Q3 2026, nine months 2026 (9M 2026), nine months 2025 (9M 2025) and last twelve months to September 30, 2026 (LTM Q3 2026). LTM and discrete Q2 2026 and Q3 2026 flows are calculated, as shown under Calculations.

## Sources

| Source | sha256 | Role |
| --- | --- | --- |
| 10-K_2025-12-31_nclc-20251231x10k.htm.jsonl | 1590d4030e80abfbd09d00a74521526f72070052531a8716f865a880a8fa9501 | Audited FY2025 statements, notes, EBITDA reconciliation, debt note |
| 10-Q_2026-03-31_nclc-20260331x10q.htm.jsonl | 1693fea3f52de137a2e148c9e6f9853be5398eb34944625b7e837b2bd396c943 | Unaudited Q1 2026 statements, debt note, repayment schedule |
| 10-Q_2026-06-30_nclc-20260630x10q.htm.jsonl | 2f18ccd1a947471efb9474a7bd377c5db5871d9445b97fe0a1fc7e783f6d645f | Unaudited Q2 2026 and six-month statements, debt note, repayment schedule |
| 10-Q_2026-09-30_nclc-20260930x10q.htm.jsonl | 7769d1c310cec4c8e024523931f2cd599a487768128283054dca38ddd11d7d93 | Unaudited Q3 2026 and nine-month statements, debt note, liquidity, subsequent events |
| EX-99.1_2026-05-04_exh_991.htm.jsonl | 19e48d4c7cb2b40fb1bcbfbbe436e7e39f669c8965c4e705c327d948db3f04d8 | Q1 2026 parent press release; used only to label the perimeter difference |
| EX-99.1_2026-07-30_exh_991.htm.jsonl | ffe75efbccd58bfc3c88fabf4a188883f7003d5a095dba1da47bbe08c4d94307 | Q2 2026 parent press release; used only to label the perimeter difference |
| EX-99.1_2026-10-29_exh_991.htm.jsonl | 6f93f8906074ef388d05f277a1b3874ed298e830f3945372d3d73a8925dc791c | Q3 2026 parent press release; parent-level liquidity and leverage, labelled |
| context | 1eac4b587c5c6cd9d96c3f400eed0e70dc9aa1137a14c30469dde7d21791294f | User run settings; not issuer evidence |

| Handoff | sha256 | Use |
| --- | --- | --- |
| CP-0 | 240a9004c9f054e89ac320762ee0dbd447c416d5523fbbb0826a7a829f32f3c2 | Source readiness: all four selected consumers ready with limitations; carries the release-versus-filing perimeter conflict, the missing agreements and covenant values, and the lack of an instrument-level debt table at September 30, 2026 |

Consistency with CP-0: this answer confirms CP-0 on each point it checked. Three refinements. First, CP-0 said the parent's release Adjusted EBITDA is "not interchangeable" with the issuer's; that holds, but the two are numerically close for Q3 2026 (the release states “of $937 million” for Q3 2026 (Q3 release, page:1) and the issuer reconciles 936,702 thousand (Q3 10-Q, page:36)), so the gap is small and the perimeter label is what matters. Second, CP-0 did not note that "2031 Notes" names two different instruments, see Debt by instrument. Third, CP-0 did not record that the 10-K carries a springing maturity on the Revolving Loan Facility tied to November 17, 2026 (a contract date after the cutoff); see Covenants and facility terms. No earlier statement of CP-0 is withdrawn.

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| On the issuer's own filings, debt is 5.51x last-twelve-months Adjusted EBITDA at Q3 2026, up from 5.34x at FY2025, because earnings slipped while debt rose to 14,884.5. October 2026 refinancing raised revolver capacity. | Medium | No covenant ratio values, credit agreements or instrument table at Q3 2026 are supplied, and Adjusted EBITDA is a company non-GAAP measure. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Net debt over last-twelve-months Adjusted EBITDA is 5.42x at Q3 2026 against 5.26x at FY2025. | Leverage has moved up, not down, through 2026. | Medium |
| Adjusted EBITDA for Q3 2026 was 936.7 against 1,019.4 a year earlier, with Net Yield lower. | Earnings are softening into the 2027 maturities. | Medium |
| Liquidity of about 1.4 billion at Q3 2026 compares with 1.6 billion at FY2025; revolver availability fell while cash rose. | Quarter-end cushion is thinner, before the October 2026 upsizing. | Medium |
| Operating cash flow less additions to property and equipment was (582.7) for 9M 2026, and 13 newbuilds carry large committed payments. | Growth capex is funded by debt and export-credit loans, not free cash flow. | Medium |
| Scheduled principal is 1,105.7 in 2027 and 4,134.3 in 2030. | A heavy 2030 wall follows a manageable near-term profile. | Medium |

### Financial base view

The reported base for the issuer, as filed, shows balance-sheet debt of 14,884.5 at Q3 2026 (current and long-term debt plus exchangeable notes at carrying value) against last-twelve-months Adjusted EBITDA of 2,700.1, which gives 5.51x, and 5.42x after deducting cash of 250.7. At FY2025 the same measures were 5.34x and 5.26x. The deterioration comes from both terms: debt carrying value rose from 14,583.4 while last-twelve-months Adjusted EBITDA slipped from 2,731.4, with the third quarter of 2026 at 936.7 against 1,019.4 a year earlier, down 8.1%. Reported net income is not a clean guide because other income of 200.1 in Q3 2026 (largely conversion-option gains) lifted net income to 631.9, above operating income of 624.2. Interest expense, net fell to 564.5 for 9M 2026 from 782.4, but the 9M 2025 figure included an extinguishment-related amount of 202.5, so the underlying fall is small. Cash interest is printed only for FY2025, so interim cash interest cover is Not supplied. Operating cash flow of 1,709.3 for 9M 2026 did not cover additions to property and equipment of 2,292.0, so growth is financed with new debt and export-credit loans; undrawn export-credit facilities of about 10.8 billion are stated against ship contracts of 19,421.2. Scheduled principal is 1,105.7 in 2027 and 4,134.3 in 2030, so the near-term profile is manageable and the 2030 wall is heavy. After the quarter, an 8.750% notes issue, a larger revolver and a covenant-definition amendment changed the picture, but only in summary form. Everything here is on the issuer's own perimeter; the parent's release shows different cash, net income, debt and leverage and is not mixed in.

### Chart data: leverage

| Period | Total debt / EBITDA | Net debt / EBITDA | Reporting unit | Basis and limitation |
| --- | --- | --- | --- | --- |
| FY2025 | 5.34 | 5.26 | x | Balance-sheet debt 14,583.4 (current portion, long-term debt and exchangeable notes at carrying value) and net debt 14,379.4 at December 31, 2025, over FY2025 Adjusted EBITDA 2,731.4. Adjusted EBITDA is a company non-GAAP measure. Principal basis (scheduled repayments 14,994.6) gives 5.49x. |
| LTM Q1 2026 | 5.34 | 5.28 | x | Debt 15,025.1 and net debt 14,845.9 at March 31, 2026 over LTM Adjusted EBITDA 2,811.4 (calculated). Principal basis (15,609.5) gives 5.55x. |
| LTM Q2 2026 | 5.38 | 5.31 | x | Debt 14,982.4 and net debt 14,770.1 at June 30, 2026 over LTM Adjusted EBITDA 2,782.7 (calculated). Principal basis (15,467.7) gives 5.56x. |
| LTM Q3 2026 | 5.51 | 5.42 | x | Debt 14,884.5 and net debt 14,633.8 at September 30, 2026 over LTM Adjusted EBITDA 2,700.1 (calculated). Principal basis (15,498.0, including finance leases) gives 5.74x. Before the October 2026 refinancing; excludes operating leases of 940.3. The parent release shows 5.5x on its own perimeter; that figure is not the issuer's. |

### Chart data: interest cover

| Period | EBITDA / cash interest | Reporting unit | Basis and limitation |
| --- | --- | --- | --- |
| FY2025 | 2.87 | x | FY2025 Adjusted EBITDA 2,731.4 over cash paid for interest and related fees, net of capitalized interest, of 952.0 including early redemption premiums (10-K page:169). Excluding the 162.4 early redemption premium (cash flow statement) the ratio is 3.46x. Not a covenant ratio. |
| LTM Q1 2026 | Not supplied: the March 2026 10-Q prints no cash interest paid | x | Only interest expense, net is printed. Proxy, not cash: LTM Adjusted EBITDA 2,811.4 over LTM interest expense, net 911.3 is 3.09x (calculated); that expense includes non-cash discount amortization and 2025 extinguishment losses. |
| LTM Q2 2026 | Not supplied: the June 2026 10-Q prints no cash interest paid | x | Proxy, not cash: LTM Adjusted EBITDA 2,782.7 over LTM interest expense, net 841.2 is 3.31x (calculated). |
| LTM Q3 2026 | Not supplied: the September 2026 10-Q prints no cash interest paid | x | Proxy, not cash: LTM Adjusted EBITDA 2,700.1 over LTM interest expense, net 753.1 is 3.59x (calculated); the LTM window no longer contains the 2025 extinguishment losses but still contains non-cash discount amortization. |

### Chart data: liquidity

| Period | Cash | Undrawn committed facilities | Reporting unit | Basis and limitation |
| --- | --- | --- | --- | --- |
| FY2025 | 204.0 | 1400 | US$m | Cash and cash equivalents; no restricted cash line is printed. Undrawn is the amount the 10-K states as "borrowings available" under the Revolving Loan Facility, printed as 1.4 billion. Letters of credit: Not supplied (searched). Total stated liquidity about 1.6 billion. |
| Q1 2026 | 179.2 | 1400 | US$m | Availability printed as 1.4 billion in the Q1 10-Q; total stated about 1.6 billion. Rounded to 0.1 billion in the source. |
| Q2 2026 | 212.3 | 1300 | US$m | Availability printed as 1.3 billion; total stated about 1.5 billion. |
| Q3 2026 | 250.7 | 1100 | US$m | Availability printed as 1.1 billion; total stated about 1.4 billion. Excludes the October 2026 revolver upsizing and the 380.0 revolver repayment. Undrawn export-credit facilities of about 10.8 billion are restricted to ship construction and are not included. |

### Chart data: debt maturities

| Period | Debt maturing | Reporting unit | Basis and limitation |
| --- | --- | --- | --- |
| Q4 2026 | 238.6 | US$m | Remainder of 2026 scheduled principal at September 30, 2026, including exchangeable notes and finance leases (Q3 10-Q page:12). |
| FY2027 | 1105.7 | US$m | Includes the remaining 2027 exchangeable notes, principal 192.0 and 24.1 at September 30, 2026, which the issuer expects to repay in cash or refinance. |
| FY2028 | 1346.1 | US$m | Includes the 6.125% senior unsecured notes due 2028, which the October 2026 proceeds were used to redeem (Q3 10-Q page:11); the pro forma effect on this bucket is Not supplied. |
| FY2029 | 1370.0 | US$m | Scheduled principal at September 30, 2026. |
| FY2030 | 4134.3 | US$m | At December 31, 2025 the 2030 maturities in the debt table were the Revolving Loan Facility (stated maturity January 22, 2030 in the 10-K), two 2030 exchangeable series, the 6.25% senior unsecured notes and the Seahawk 1 term loan; the split at Q3 2026 is not printed. |
| FY2031 | 1875.1 | US$m | Scheduled principal at September 30, 2026; before the October 2026 8.750% notes due 2031 (950.0) are added. |
| Thereafter | 5428.2 | US$m | 2032 onward; the December 31, 2025 table shows the 2032 and 2033 senior notes and newbuild loans maturing 2032 to 2041 in this range. Total of all periods 15498.0 (principal, including finance leases, before unamortized discounts). |

### Financials and credit metrics

| Metric (US$m unless stated) | FY2025 | Q1 2026 | Q2 2026 | Q3 2026 | 9M 2026 | 9M 2025 | LTM Q3 2026 | Basis and locators |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Total revenue | 9,827.6 | 2,331.2 | 2,640.5 | 2,946.8 | 7,918.5 | 7,583.2 | 10,162.9 | Reported (10-K page:121; Q1 10-Q page:2; Q2 10-Q page:2; Q3 10-Q page:2). LTM calculated. |
| Operating income | 1,562.0 | 233.3 | 363.9 | 624.2 | 1,221.4 | 1,375.2 | 1,408.2 | Reported; LTM calculated. |
| Interest expense, net | 971.0 | 184.4 | 189.9 | 190.1 | 564.5 | 782.4 | 753.1 | Reported; includes amortization of discounts and fees, and extinguishment losses in 2025. LTM calculated. |
| Net income | 623.7 | 214.2 | 148.0 | 631.9 | 994.2 | 527.6 | 1,090.3 | Reported; includes other income (expense), net, mostly conversion-option and currency items. LTM calculated. |
| Depreciation and amortization (income statement) | 1,078.8 | 260.7 | 271.2 | 287.7 | 819.6 | 725.9 | 1,172.5 | Reported; the cash flow statement line is larger because it includes financing-fee amortization. LTM calculated. |
| Adjusted EBITDA (company non-GAAP) | 2,731.4 | 533.3 | 666.1 | 936.7 | 2,136.0 | 2,167.3 | 2,700.1 | Reported (10-K page:83; Q1 10-Q page:30; Q2 10-Q page:33; Q3 10-Q page:36). Q3 2026 is as printed; LTM calculated. |
| Adjusted EBITDA margin (%) | 27.8 | 22.9 | 25.2 | 31.8 | 27.0 | 28.6 | 26.6 | Calculated as Adjusted EBITDA over total revenue; seasonal, third quarter strongest. |
| Net cash provided by operating activities | 2,077.3 | 811.5 | 605.0 | 292.8 | 1,709.3 | 1,617.6 | 2,169.0 | Reported for FY2025, Q1 2026 and the 9M columns (10-K page:123; Q1 10-Q page:3; Q3 10-Q page:3); Q2 2026 and Q3 2026 derived from year-to-date reports. LTM calculated. |
| Additions to property and equipment, net | 3,259.6 | 1,436.7 | 457.7 | 397.7 | 2,292.0 | 2,822.0 | 2,729.7 | Reported cash flow line; Q2 2026 and Q3 2026 derived. LTM calculated. |
| Operating cash flow less additions to property and equipment | (1,182.3) | (625.2) | 147.3 | (104.9) | (582.7) | (1,204.4) | (560.7) | Calculated; not a company-defined measure; excludes ship sale proceeds of 105.0 in 9M 2026. |
| Cash and cash equivalents | 204.0 | 179.2 | 212.3 | 250.7 | n/a (instant) | n/a (instant) | n/a (instant) | Balance sheets (10-K page:122; Q1 10-Q page:2; Q2 10-Q page:2; Q3 10-Q page:2). |
| Balance-sheet debt (current, long-term and exchangeable at carrying value) | 14,583.4 | 15,025.1 | 14,982.4 | 14,884.5 | n/a (instant) | n/a (instant) | n/a (instant) | Calculated from the four balance sheet lines; FY2025 equals the 10-K debt note total (10-K page:140). |
| Net debt (balance-sheet debt less cash) | 14,379.4 | 14,845.9 | 14,770.1 | 14,633.8 | n/a (instant) | n/a (instant) | n/a (instant) | Calculated. |
| Scheduled principal repayments, total (incl. finance leases) | 14,994.6 | 15,609.5 | 15,467.7 | 15,498.0 | n/a (instant) | n/a (instant) | n/a (instant) | Debt repayment schedules (10-K page:150; Q1 10-Q page:10; Q2 10-Q page:11; Q3 10-Q page:12). |
| Total shareholders' equity | 2,118.7 | 2,449.8 | 2,516.7 | 3,233.2 | n/a (instant) | n/a (instant) | n/a (instant) | Balance sheets. |
| Advance ticket sales | 3,200.6 | 3,718.9 | 3,651.2 | 3,142.0 | n/a (instant) | n/a (instant) | n/a (instant) | Balance sheets; seasonal customer deposits, partly refundable. |
| Total debt / LTM Adjusted EBITDA (x) | 5.34 | 5.34 | 5.38 | 5.51 | n/a (ratio) | n/a (ratio) | 5.51 | Calculated at each period end on LTM Adjusted EBITDA. |
| Net debt / LTM Adjusted EBITDA (x) | 5.26 | 5.28 | 5.31 | 5.42 | n/a (ratio) | n/a (ratio) | 5.42 | Calculated. |
| LTM Adjusted EBITDA / LTM interest expense, net (x) | 2.81 | 3.09 | 3.31 | 3.59 | n/a (ratio) | n/a (ratio) | 3.59 | Calculated; proxy, not cash cover. FY2025 includes extinguishment losses. |
| LTM Adjusted EBITDA / cash interest (x) | 2.87 | Not supplied | Not supplied | Not supplied | n/a (ratio) | n/a (ratio) | Not supplied | Cash interest paid is printed for FY2025 only (10-K page:169). |

### Operating indicators and revenue mix

| Indicator | Q3 2026 | Q3 2025 | 9M 2026 | 9M 2025 | Basis and locators |
| --- | --- | --- | --- | --- | --- |
| Passengers carried | 983,214 | 803,268 | 2,750,963 | 2,211,002 | Reported (Q3 10-Q page:34). |
| Capacity Days | 6,766,454 | 6,417,724 | 19,749,163 | 18,170,560 | Reported (Q3 10-Q page:34). |
| Occupancy Percentage | 106.5% | 106.4% | 104.2% | 104.0% | Reported (Q3 10-Q page:34). |
| Net Yield (US$ per Capacity Day) | 319.65 | 341.89 | 299.21 | 309.81 | Reported company measure (Q3 10-Q page:34). |
| Adjusted Net Cruise Cost Excluding Fuel per Capacity Day (US$) | 152.29 | 155.65 | 161.48 | 162.56 | Reported company measure (Q3 10-Q page:35). |
| Revenue, North America (US$m) | 1,672.6 | 1,463.0 | 4,991.7 | 4,200.7 | Revenue by destination (Q3 10-Q page:9). |
| Revenue, Europe (US$m) | 1,257.9 | 1,349.4 | 2,104.9 | 2,386.5 | Revenue by destination (Q3 10-Q page:9). |
| Revenue, Asia-Pacific (US$m) | 12.4 | 124.8 | 588.2 | 763.6 | Revenue by destination (Q3 10-Q page:9). |
| Revenue, Other (US$m) | 3.8 | 0.9 | 233.7 | 232.5 | Revenue by destination (Q3 10-Q page:9). |

The business reports a single reportable segment (10-K page:128). The 10-Q segment note instead presents an adjusted operating income build of 665.8 for Q3 2026 against 768.5 (Q3 10-Q page:6), which is the segment profit measure of that single segment and a company non-GAAP presentation.

### Debt by instrument

Balance sheet debt at December 31, 2025, as the 10-K debt note prints it (10-K page:139 to page:140). Carrying values in US$m; the exchangeable note rows include conversion option liabilities per the note footnotes. The quarterly reports print no equivalent instrument table, so September 30, 2026 balances by instrument are Not supplied (Q3 10-Q page:11 to page:12 print the exchangeable note table and the repayment schedule only).

| Instrument | Rate | Final maturity | Carrying value December 31, 2025 |
| --- | --- | --- | --- |
| Revolving Loan Facility (senior secured) | 5.54% | 2030 | 1,100.0 |
| 1.125% exchangeable notes | 1.13% | 2027 | 187.0 |
| 2.50% exchangeable notes | 2.50% | 2027 | 23.4 |
| 0.875% exchangeable notes | 0.88% | 2030 | 394.9 |
| 0.75% exchangeable notes | 0.75% | 2030 | 1,319.8 |
| 6.25% senior unsecured notes | 6.25% | 2030 | 311.5 |
| 7.75% senior unsecured notes | 7.75% | 2029 | 596.0 |
| 6.125% senior unsecured notes | 6.13% | 2028 | 522.6 |
| 5.875% senior unsecured notes (the "2031 Notes" in the 10-K) | 5.88% | 2031 | 1,187.1 |
| 6.75% senior unsecured notes | 6.75% | 2032 | 1,779.6 |
| 6.25% senior unsecured notes | 6.25% | 2033 | 840.7 |
| Breakaway three loan | 3.27% | 2027 | 137.0 |
| Breakaway four loan | 3.16% | 2029 | 253.7 |
| Seahawk 1 term loan | 3.99% | 2030 | 318.9 |
| Seahawk 2 term loan | 3.98% | 2031 | 453.2 |
| Leonardo newbuild one loan | 2.68% | 2034 | 794.9 |
| Leonardo newbuild two loan | 2.77% | 2035 | 861.7 |
| Leonardo newbuild three loan | 1.83% | 2037 | 1,071.9 |
| Leonardo newbuild four loan | 1.96% | 2038 | 278.1 |
| Explorer newbuild loan | 3.76% | 2028 | 84.0 |
| Splendor newbuild loan | 3.20% | 2032 | 236.5 |
| Grandeur newbuild loan | 3.70% | 2035 | 423.0 |
| Vista newbuild loan | 3.64% | 2035 | 468.8 |
| Allura newbuild loan | 1.50% | 2037 | 623.2 |
| Prestige newbuild loan | 5.72% | 2038 | 156.2 |
| Prestige Class 2 newbuild loan | 5.72% | 2041 | 15.1 |
| Sonata newbuild loan | 5.72% | 2039 | 119.1 |
| Arietta newbuild loan | 5.72% | 2040 | 16.8 |
| Finance lease and license obligations | Various | 2028 | 8.7 |
| Total debt (10-K total, 29 rows above) | n/a | n/a | 14,583.4 |

- Issuer and guarantors as printed: NCLC is issuer of the exchangeable notes, with NCLH as guarantor: “pursuant to an indenture among NCLC, as issuer, NCLH, as guarantor, and U.S. Bank National Association, as trustee” (Q3 10-Q page:27). NCLC is borrower under the Revolving Loan Facility with subsidiary guarantors (Q3 10-Q page:29). The guarantors of each senior note series, and the security for each newbuild loan, are not stated in the debt table; “Approximately $15 billion of the net book value of our assets was pledged as collateral for certain of our debt as of September 30, 2026.” (Q3 10-Q page:42).
- Naming trap: the 10-K labels the 5.875% notes due 2031 as the "2031 Notes", while the Q3 10-Q defines the new 8.750% notes due October 15, 2031 as the "2031 Notes" (Q3 10-Q page:11). They are different instruments. The 10-K table uses 2031 for the 5.875% issue only.
- Exchangeable notes at September 30, 2026 (principal, carrying value, Q3 10-Q page:12): 2027 1.125% 192.0 and 188.3; 2027 2.5% 24.1 and 23.7; 2030 0.875% 353.9 and 306.2; 2030 0.750% 1,407.0 and 1,127.2. In May 2026 NCLC fixed cash settlement for exchanges of both 2027 series (Q3 10-Q page:12).
- 2026 changes to the stack: Norwegian Luna export-credit term loan of €1.0 billion at 1.91% due February 25, 2038 (Q3 10-Q page:11); October 2026 issue of 950.0 of 8.750% senior unsecured notes due 2031, with proceeds used to “redeem all of the outstanding 6.125% senior notes due 2028” (Q3 10-Q page:11), to repay 380.0 of revolver borrowings and to prepay about 42.2 of export-credit facilities.

### Claims outside debt

| Claim | Amount | Inside or outside the debt figure | Locator |
| --- | --- | --- | --- |
| Operating lease liabilities, current and non-current | 34.2 and 906.1 at September 30, 2026 (940.3 together; 32.1 and 897.9 at December 31, 2025) | Outside | Q3 10-Q page:10 |
| Non-cancelable ship construction contracts, 13 ships | 19,421.2 total; 864.3 remainder of 2026, 2,495.1 in 2027, 1,456.1 in 2028 | Outside; about 10.8 billion of committed undrawn export-credit facilities fund about 80% of most contracts | Q3 10-Q page:20 and page:42 |
| Advance ticket sales (customer deposits) | 3,142.0; contract liabilities about 2.2 billion, “approximately 45% were refundable” | Outside; operating liability | Q3 10-Q page:3 and page:9 |
| Due to NCLH (parent intercompany) | 56.1 | Outside | Q3 10-Q page:3 |
| Shipboard Retirement Plan | Obligation amount: Not supplied in the 10-Q pages read; described as an unfunded defined benefit plan | Outside | Q3 10-Q page:29 |
| Havana Docks litigation (Helms-Burton Act) | Final judgment of about 112.9 was entered in 2022; the Eleventh Circuit dismissed the claim in October 2024; the Supreme Court reversed that dismissal on May 21, 2026 and remanded on June 22, 2026; oral argument is scheduled for January 19, 2027; likelihood of loss reasonably possible, no liability recorded | Outside; the named defendant is NCLH, and whether NCLC bears the exposure is not stated | Q3 10-Q page:22 |
| Credit card processor reserves | None required at September 30, 2026 | Outside | Q3 10-Q page:39 |
| Factoring, supply-chain finance, purchase commitments other than ships | Not supplied (searched; no occurrence found) | Not applicable | Q3 10-Q, whole source |

### Covenants and facility terms

- Covenant types, from the 10-K: “Certain of our debt facilities include maintenance and financial covenants.” (10-K page:41). Under the Seventh ARCA, a loan to value ratio of less than 0.70 to 1.00, free liquidity of no less than 250 million at all times, an EBITDA to consolidated debt service ratio of at least 1.25 to 1.00 at each quarter-end unless free liquidity is at least 300 million, and a total net funded debt to total capitalization ratio (level not printed) (10-K page:41).
- Reported compliance: “As of September 30, 2026, we were in compliance with all of our debt covenants.” (Q3 10-Q page:13). Reported covenant ratio values and headroom: Not supplied. The issuer's EBITDA, free liquidity and debt service definitions differ from the Adjusted EBITDA and balance-sheet debt computed here, so no headroom is inferred.
- October 2026 amendment: the third amendment “also modified certain existing financial covenant definitions and the related collateral” (Q3 10-Q page:12). The text of the amendment is Not supplied.
- Springing maturity, as stated in the 10-K: if on November 17, 2026 the 2027 1.125% or 2.5% exchangeable notes have not been repaid or refinanced with indebtedness maturing after April 23, 2030 and a liquidity test is not satisfied, the revolver maturity date becomes November 17, 2026 (10-K page:142). November 17, 2026 is after the cutoff and is a contract term, not an event. The Q3 10-Q does not restate this term, and whether the third amendment changed it is Not supplied. The liquidity test is not defined in the pages read.
- Ratings, as printed: “Our Moody’s long-term issuer rating is B1, and our senior unsecured rating is B3.” (Q3 10-Q page:39); S&P Global issuer credit rating B+, revolver issue-level BB, senior unsecured B+ (same page).

### Events, comparability and subsequent events

- Q1 2026: delivery of Norwegian Luna and its €1.0 billion export-credit loan (Q1 10-Q page:9).
- Q2 2026: cash settlement fixed for the 2027 exchangeable notes (May 2026, Q2 10-Q page:10); memorandum of agreement for the sale of Oceania Sirena in July 2026, a subsequent event at that report date (Q2 10-Q page:21 to page:22).
- Q3 2026: Oceania Sirena sold in September 2026, with a loss on disposal of 16.8 (Q3 10-Q page:7) and ship sale proceeds of 105.0 for 9M 2026 (Q3 10-Q page:3); a bareboat charter for Norwegian Sky started in September 2026 (Q3 10-Q page:10). Restructuring costs of 22.4 and professional advisory fees of 5.4 for 9M 2026 are added back in Adjusted EBITDA (Q3 10-Q page:36). Q3 2026 other income of 200.1 reverses a (134.4) loss a year earlier (Q3 10-Q page:2).
- After September 30, 2026 and before the cutoff: the 950.0 notes issue and revolver third amendment (Q3 10-Q page:11 to page:12) and a memorandum of agreement for the sale of Oceania Insignia, closing September 2027 (Q3 10-Q page:24). The parent's release states pro forma liquidity of 2.1 billion, parent-level and management-prepared (Q3 release page:3).
- Comparability: revenue by destination shows Asia-Pacific revenue of 12.4 in Q3 2026 against 124.8, so mix shifts between years are large. FY2025 interest expense, net includes about 202.5 of extinguishment losses (10-K page:150).

### Interpretation: data to risk to credit implication

- Leverage. Evidence: Adjusted EBITDA for Q3 2026 fell 8.1% to 936.7 (Q3 10-Q page:34), while debt rose to 14,884.5. Mechanism: with a higher numerator and a lower denominator, leverage mechanically rises, and the quarter that carries most seasonal profit weakened. Implication: leverage on the issuer's own filings is 5.51x, above the 5.34x at FY2025; the company states net leverage on a parent basis of 5.5x, a consistent but non-identical measure.
- Earnings quality. Evidence: Net Yield per Capacity Day fell to 319.65 from 341.89 in Q3 2026 and occupancy was roughly unchanged; the filing states the booked position “remains below its optimal range” (Q3 10-Q page:32). Mechanism: capacity grew (Capacity Days 6,766,454 against 6,417,724) while yield fell, so volume masks price. Implication: management describes about 125 million, 100 million and 100 million of run-rate savings as benefits to be realized over time (Q3 10-Q page:33); Adjusted Net Cruise Cost Excluding Fuel per Capacity Day was lower at 152.29 against 155.65, but the revenue side has not recovered, so earnings recovery is unproven.
- Cash flow and funding model. Evidence: operating cash flow less additions to property and equipment is (582.7) for 9M 2026. Mechanism: newbuild deliveries are financed by export-credit loans at low fixed rates, such as the 1.91% Luna loan, but total debt grows with each delivery. Implication: deleveraging depends on EBITDA growth, not on free cash flow, until the newbuild cycle slows; committed ship payments of 19,421.2 stay ahead.
- Liquidity and refinancing. Evidence: availability fell to 1.1 billion at Q3 2026, then October 2026 actions raised revolver commitments from about 2.5 billion to about 2.8 billion and repaid 380.0. Mechanism: the remaining 2027 exchangeable notes (216.2 principal in total, 212.5 carrying) are classified as current at September 30, 2026, and the 2030 wall of 4,134.3 follows. Implication: near-term liquidity looks adequate on the filings, but the springing-maturity term and amended covenants need the agreements before comfort.
- Perimeter. The earnings releases describe the parent, whose cash, net income and debt differ from the issuer's. Implication: credit metrics for this issuer must come from the 10-K and 10-Qs.

## Calculations

All inputs are US$ thousands as printed, converted to US$m by dividing by 1,000.

### LTM Adjusted EBITDA

LTM = FY2025 + year-to-date current − year-to-date prior.
- LTM Q1 2026: 2,731,377 + 533,254 − 453,211 = 2,811,420.
- LTM Q2 2026: 2,731,377 + 1,199,333 − 1,147,997 = 2,782,713.
- LTM Q3 2026: 2,731,377 + 2,136,035 − 2,167,348 = 2,700,064.
- Check: 533,254 + 666,079 + 936,702 = 2,136,035 (Q1 + Q2 + Q3 2026 equals 9M 2026). Inputs: 10-K page:83; Q1 10-Q page:30; Q2 10-Q page:33; Q3 10-Q page:36.

### LTM and discrete income and cash flow lines

- Revenue LTM Q3 2026: 9,827,592 + 7,918,528 − 7,583,192 = 10,162,928.
- Operating income LTM: 1,562,019 + 1,221,395 − 1,375,203 = 1,408,211.
- Net income LTM: 623,727 + 994,151 − 527,577 = 1,090,301.
- Depreciation and amortization LTM: 1,078,755 + 819,624 − 725,889 = 1,172,490.
- Interest expense, net LTM: Q1 971,036 + 184,447 − 244,222 = 911,261; Q2 971,036 + 374,362 − 504,235 = 841,163; Q3 971,036 + 564,473 − 782,390 = 753,119.
- Operating cash flow: Q2 2026 = 1,416,512 − 811,513 = 604,999; Q3 2026 = 1,709,302 − 1,416,512 = 292,790; LTM = 2,077,283 + 1,709,302 − 1,617,591 = 2,168,994.
- Additions to property and equipment: Q2 2026 = 1,894,361 − 1,436,667 = 457,694; Q3 2026 = 2,292,043 − 1,894,361 = 397,682; LTM = 3,259,606 + 2,292,043 − 2,821,959 = 2,729,690.
- Operating cash flow less additions: FY2025 2,077,283 − 3,259,606 = −1,182,323; Q1 811,513 − 1,436,667 = −625,154; Q2 604,999 − 457,694 = 147,305; Q3 292,790 − 397,682 = −104,892; 9M 2026 1,709,302 − 2,292,043 = −582,741; 9M 2025 1,617,591 − 2,821,959 = −1,204,368; LTM = −1,182,323 + (−582,741) − (−1,204,368) = −560,696.
- Adjusted EBITDA margin: Q3 936,702 / 2,946,763 = 31.8%; 9M 2026 2,136,035 / 7,918,528 = 27.0%; 9M 2025 2,167,348 / 7,583,192 = 28.6%; FY2025 2,731,377 / 9,827,592 = 27.8%; Q1 533,254 / 2,331,221 = 22.9%; Q2 666,079 / 2,640,544 = 25.2%; LTM 2,700,064 / 10,162,928 = 26.6%.
- Q3 2026 change in Adjusted EBITDA: 936,702 / 1,019,351 − 1 = −8.1% (matches the 10-Q statement of an 8.1% decrease). 9M 2026 revenue change: 7,918,528 / 7,583,192 − 1 = 4.4%.

### Debt and leverage ratios

- Balance-sheet debt = current portion of long-term debt + current portion of exchangeable notes + long-term debt + exchangeable notes. FY2025: 875,899 + 0 + 11,782,439 + 1,925,103 = 14,583,441. Q1 2026: 959,304 + 208,970 + 12,246,225 + 1,610,581 = 15,025,080. Q2 2026: 925,195 + 211,454 + 12,158,526 + 1,687,207 = 14,982,382. Q3 2026: 918,784 + 212,464 + 12,214,862 + 1,538,363 = 14,884,473.
- Net debt = debt − cash: FY2025 14,583,441 − 203,996 = 14,379,445; Q1 15,025,080 − 179,200 = 14,845,880; Q2 14,982,382 − 212,261 = 14,770,121; Q3 14,884,473 − 250,722 = 14,633,751.
- Total debt / LTM Adjusted EBITDA: FY2025 14,583,441 / 2,731,377 = 5.34; Q1 15,025,080 / 2,811,420 = 5.34; Q2 14,982,382 / 2,782,713 = 5.38; Q3 14,884,473 / 2,700,064 = 5.51.
- Net debt / LTM Adjusted EBITDA: FY2025 14,379,445 / 2,731,377 = 5.26; Q1 14,845,880 / 2,811,420 = 5.28; Q2 14,770,121 / 2,782,713 = 5.31; Q3 14,633,751 / 2,700,064 = 5.42.
- Principal basis: 14,994,609 / 2,731,377 = 5.49; 15,609,507 / 2,811,420 = 5.55; 15,467,745 / 2,782,713 = 5.56; 15,497,999 / 2,700,064 = 5.74.
- Adjusted EBITDA / interest expense, net (LTM): FY2025 2,731,377 / 971,036 = 2.81; Q1 2,811,420 / 911,261 = 3.09; Q2 2,782,713 / 841,163 = 3.31; Q3 2,700,064 / 753,119 = 3.59.
- Cash interest cover FY2025: 2,731,377 / 952,000 = 2.87; excluding early redemption premium 162,374: 2,731,377 / (952,000 − 162,374) = 2,731,377 / 789,626 = 3.46. Inputs: 10-K page:169 (952.0 as printed in US$ millions, converted to thousands) and 10-K page:123 (premium).
- Operating lease liabilities: 34,192 + 906,131 = 940,323 (Q3 10-Q page:10).

### Liquidity

- Reported liquidity is printed rounded: Q3 2026 about 1.4 billion = cash 250.7 + 1.1 billion available under the Revolving Loan Facility (Q3 10-Q page:6 and page:38). Sum of printed components 250.7 + 1,100 = 1,350.7, consistent with the rounded 1.4 billion. A revolver drawn amount is not printed at Q3 2026; it is therefore Not supplied (the 10-K prints 1,100.0 drawn at December 31, 2025, 10-K page:139).
- Consistency check on the parent's pro forma: printed availability 1.1 billion + commitment increase of about 0.3 billion (about 2.5 to about 2.8) + 380.0 repaid is about 1.78 billion, in line with the parent's stated 1.8 billion; this checks the arithmetic only and is not an issuer figure.

### Underlying interest change

- 9M 2025 interest expense, net 782,390 includes extinguishment and modification of debt of 202,525 (Q3 10-Q page:35 Adjusted Net Income table). Excluding it: 782,390 − 202,525 = 579,865. 9M 2026 564,473 / 579,865 − 1 = −2.7%. Without the exclusion the reported change is 564,473 / 782,390 − 1 = −27.9%.

### Tie-outs

- Revenue: 2,331,221 + 2,640,544 + 2,946,763 = 7,918,528 equals 9M 2026 reported.
- Debt table: the 29 carrying values in Debt by instrument add to 14,583,441, equal to the 10-K total debt (10-K page:140).
- Repayment schedules: FY2025 875,899 + 1,036,770 + 1,271,964 + 1,297,287 + 3,805,032 + 6,707,657 = 14,994,609; Q3 2026 238,600 + 1,105,695 + 1,346,141 + 1,370,035 + 4,134,290 + 1,875,062 + 5,428,176 = 15,497,999.
- Unreconciled: the parent's total debt of 15,086.5 and net debt of 14,830.0 (Q3 release page:18) differ from the issuer's 14,884.5 and 14,633.8; the difference is not explained in the supplied text and is not bridged.

## Gaps

| Gap | Severity | Affected consumers | Remediation |
| --- | --- | --- | --- |
| Covenant ratio values, definitions and headroom are not printed; only compliance statements are. | High | CP-2, CP-5 | Obtain the credit agreement and compliance certificate; until then headroom is Not calculable. |
| The October 2026 third amendment and the notes indenture are summarized only; the effect on the springing maturity of November 17, 2026 and on collateral is unknown. | High | CP-2 | Obtain the amendment and the 8.750% notes indenture from exhibit filings. |
| No instrument-level debt table at September 30, 2026; the full table is at December 31, 2025. Security and guarantor by instrument are not printed. | Medium | CP-2 | Rebuild from the 10-K table plus described 2026 events; flag as derived. |
| Cash interest paid is printed for FY2025 only; interim cash cover is Not supplied. | Medium | CP-2 | Use interest expense, net as a labelled proxy. |
| Revolver drawn amount and letters of credit at Q3 2026 are Not supplied (searched for letters of credit, LC and standby; no occurrence). | Medium | CP-2 | Use stated availability, rounded to 0.1 billion. |
| Parent and issuer debt and net debt do not reconcile in the supplied text. | Medium | CP-2, CP-5 | Keep perimeters separate. |
| Adjusted EBITDA is a company non-GAAP measure; the covenant EBITDA definition is not supplied. | Medium | CP-2 | Treat leverage as indicative, not covenant leverage. |
| Operating lease interest and rent, pension obligation amount, and the Havana Docks exposure to NCLC are not quantified for the issuer. | Low | CP-2 | Carry as contingent or outside-debt items. |
| A discrete Q4 2025 and any figure after October 29, 2026 are Not supplied. | Low | All | State as Not supplied. |
| Text extraction was not compared with the filed HTML or XBRL; tables are flattened. | Low | CP-5 | Re-check figures that drive a conclusion. |

## Next module

CP-1A should run next on the business, fleet, ownership and transaction context (ship sales and charters, the October 2026 financing and the parent relationship). CP-2 and CP-5 follow. Carry forward these limits: the issuer-only perimeter, the missing covenant values and agreements, the November 17, 2026 springing-maturity term, the absence of an instrument table at September 30, 2026, and the two different instruments labelled "2031 Notes".
