## Request

Business, ownership and transaction context for Novelis Inc. (issuer id novelis-inc), as of 2026-11-05 (cutoff 2026-11-05), creditor perspective. Reporting currency USD, millions unless stated. Current period: fiscal Q2 2027 (quarter ended September 30, 2026); prior period: fiscal 2026 (year ended March 31, 2026). Fiscal years end March 31.

This handoff covers the company and operating model, ownership and governance behavior, the transaction and financing timeline, credit-relevant history and the monitoring gaps. It makes no peer ranking, instrument recommendation or recovery conclusion. Financial figures repeat the accepted financial base handoff; where a figure appears here it carries the same value, period and locator as there.

Aliases in locators: AR is the fiscal 2026 annual report; Q3R, Q1R and Q2R are the quarterly reports for December 31, 2025, June 30, 2026 and September 30, 2026; RQ4, RQ1 and RQ2 are the releases of May 19, August 5 and November 5, 2026. A locator is the alias and the page chunk of the supplied extraction.

Category tags used below: Documentary Fact (a filing states it), Management Language (management's characterization, quoted and not adopted), Analyst Interpretation (my reading of cited evidence), Insufficient Information (the evidence is missing).

## Sources

### Issuer sources relied on

| Alias | Source name | sha256 |
| --- | --- | --- |
| AR | 10-K_2026-03-31_nvl-20260331.htm.jsonl | 630dfaef3a347b5bc90017d13c739e132a0efac3aeb6333b93d9aa9c3f125e30 |
| Q3R | 10-Q_2025-12-31_nvl-20251231.htm.jsonl | 7c3c815c655f1bd83efacf6827b6774b4b93e5d320aad458b7e7fc75e1ccd80b |
| Q1R | 10-Q_2026-06-30_nvl-20260630.htm.jsonl | ba8ddb9d46239114d2dd866f92530127628a312e217f01c622dff70805bd90cb |
| Q2R | 10-Q_2026-09-30_nvl-20260930.htm.jsonl | d32d6f8b1877bce87168ef75701298999272e2cc239c9328390eaafc7d40bcff |
| RQ4 | EX-99.1_2026-05-19_novelisq4fy26results.htm.jsonl | da5b2fe17bee59287d9273512c195f4d710d0a86a8be059e4808658cb30ef647 |
| RQ1 | EX-99.1_2026-08-05_novelisq1fy27results.htm.jsonl | 93f30ffce44ee10a450dca4f333141188846c86ffae4127361330647232321d7 |
| RQ2 | EX-99.1_2026-11-05_novelisq2fy27results.htm.jsonl | 33ba4aaebc2945cb7c0c06cf8f15a6d1a483e8561da72ad63830ee26f556284c |

Context source (settings, not issuer evidence): context, sha256 e98b858a20d2c069629867a63f74620ff3a26183f951dc5fd1ab64bb298a449a.

### Supplied handoffs

| Module | sha256 | Use |
| --- | --- | --- |
| CP-0 | 787badb2d016843af79e07c22b3c2caac4fdffcb4864359dfe055d24dace3838 | Source readiness: ready with limitations; no executed agreements, no ratings, no slides, no 10-K/A. |
| CP-1 | ac0e30aff72597e230e57d534438bf73c91f6af508951774174683b88a68ca6b | Financial base: leverage, liquidity, maturities and Adjusted EBITDA definition; figures here match it. |

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| Novelis is a wholly owned subsidiary of Hindalco with a conversion business model, large customer concentration and a roughly 5.0 billion Bay Minette build now starting up. The parent has funded part of it with 950 of equity. | High | No executed financing documents, rating reports or transaction agreements were supplied, so control rights and distribution capacity are described only at filing-summary level. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Metal price is largely passed through under a conversion model, but the metal price lag and Oswego fire items sit outside Adjusted EBITDA. | Margin resilience is supported, while reported earnings quality needs the adjustments read with it. | Medium |
| The top 10 customers were 57% of fiscal 2026 net sales against 41% the year before, and Ball alone was 18%. | Concentration raises revenue risk from one customer decision. | High |
| The parent bought 950 of new shares in fiscal 2026 and no return of capital has been paid in fiscal 2027; a brand royalty of up to 24 was agreed. | Documented parent behavior is supportive, but support is not a commitment. | Medium |
| Bay Minette produced its first coil in September 2026, with commercial shipments expected in the first quarter of fiscal 2028. | Cash needs and start-up costs continue before the plant earns. | Medium |

### Business and transaction view

Novelis Inc. is a Canadian-incorporated, Atlanta-headquartered producer of aluminum rolled products that is wholly owned indirectly by Hindalco Industries Ltd. and files as a voluntary filer without public equity (AR page:1; page:2). Its model converts purchased primary and recycled metal into sheet, plate and foil for beverage packaging, automotive, aerospace and specialty customers, and passes metal price through to customers under a three-part price of an LME base, a local market premium and a conversion premium (AR page:73), so margin per tonne rather than metal price is the economic driver, and the open exposure is the timing difference called metal price lag (AR page:74). The creditor-relevant business facts are three. First, revenue is concentrated: the 10 largest customers were 57% of fiscal 2026 net sales against 41% in fiscal 2025, and one customer, Ball, was 18% (AR page:33; page:188). Second, the company is in the middle of a capital programme centered on a greenfield plant in Bay Minette, Alabama that management sizes at approximately 5.0 billion (AR page:72) and that the company says is funded through cash flows from operations and "a combination of local financing, our senior secured credit facilities, equity contributions from our common shareholder, and senior notes" (Q2R page:61), which is consistent with the rise in leverage and revolver usage shown in the financial base. Third, two fires at the Oswego plant in September and November 2025 idled the Oswego hot mill until its restart in early June 2026 and management estimated a total negative cash flow impact of approximately 1.7 billion before insurance (AR page:70; Q2R page:36); cumulative net insurance recoveries were 519 through September 30, 2026 (Q2R page:48). Ownership behavior in the filings is supportive on equity (950 of subscriptions at 150 a share in fiscal 2026) and mixed on distributions (a 35 return of capital in fiscal 2026 and a new brand royalty to an affiliate), and the filings give no signal of creditor-adverse transactions such as priming or drop-downs; that absence is an observation about the pages read, not proof of the legal capacity to do them, which depends on indenture and credit agreement terms that were not supplied.

### Company and operating model

| Area | Facts | Category | Locator |
| --- | --- | --- | --- |
| Core activities | Casting, hot and cold rolling, finishing and recycling of aluminum sheet, plate and light gauge products; 29 facilities including 15 with recycling in nine countries; 12,750 employees at fiscal 2026 | Documentary Fact | AR page:8 |
| Products and end markets | Fiscal 2026 net sales by end market: beverage packaging 10,038; specialty 3,959; automotive 3,707; aerospace and industrial plate 730; total 18,434 | Documentary Fact | AR page:188 |
| Geography | Four segments. Fiscal 2026 segment net sales including intersegment and proportional affiliates: North America 7,932; Europe 5,272; Asia 3,430; South America 2,861. Fiscal 2026 segment Adjusted EBITDA: 435, 379, 311 and 521 | Documentary Fact | AR page:20; AR page:187 |
| Customers | Direct sales to large fabricators and OEMs under supply contracts of generally one to five years; distributors 6% of net sales; Ball 18% of net sales in fiscal 2026 (17% in fiscal 2025, 14% in fiscal 2024); 10 largest customers 57%, 41% and 48% for fiscal 2026, 2025 and 2024 | Documentary Fact | AR page:23; AR page:33; AR page:188 |
| Revenue model and pricing | Conversion model: price is a base aluminum price quoted off the LME, a local market premium and a conversion premium; the filing says this lets increases or decreases in aluminum price pass through to customers | Documentary Fact | AR page:73 |
| Price lag exposure | Metal price lag arises from the time between pricing metal purchases and sales and from fixed forward price contracts; LME contracts are hedged and local premiums only partly. Metal price lag was a deduction of 515 from Adjusted EBITDA in fiscal 2026 | Documentary Fact | AR page:74; RQ4 page:9 |
| Volume drivers | Rolled product shipments were 3,557 kt in fiscal 2026 and 1,835 kt in the six months ended September 30, 2026 against 1,904 kt a year earlier; the Q2 release cites higher beverage packaging and aerospace shipments offset by lower automotive and specialty | Documentary Fact | RQ4 page:1; RQ2 page:11; RQ2 page:2 |
| Cost structure | Cost of goods sold exclusive of depreciation and amortization was 15,587 of net sales of 18,434 in fiscal 2026; the company purchased or tolled about 1,298 kt of primary aluminum and 2,155 kt of recycled aluminum in fiscal 2026; energy is a major input | Documentary Fact | AR page:110; AR page:17; AR page:18 |
| Scrap and tariffs | Management cites tight scrap spreads in fiscal 2025 that improved afterwards, and tariffs; the fiscal 2026 Adjusted EBITDA impact of tariffs was 143 per the release. In September 2026 the company announced a temporary production and staffing reduction at Kingston, Canada, over at least six months because of duties on Canadian aluminum entering the United States | Management Language | AR page:18; RQ4 page:1; Q2R page:47 |
| Capital spending | Capital expenditures were 2,343 in fiscal 2026 and 1,543 in the six months ended September 30, 2026; management expects 2.1 to 2.4 billion for fiscal 2027, of which about 350 is maintenance | Documentary Fact; guidance is Management Language | AR page:111; Q2R page:4; Q2R page:48 |
| Working capital | Inventories were 4,401 at March 31, 2026 and 5,145 at September 30, 2026; the company factors trade receivables (expense 73 in fiscal 2026) and supplier finance programs held confirmed invoices of 1.5 billion in accounts payable at September 30, 2026 | Documentary Fact | AR page:110; Q2R page:3; AR page:137; Q2R page:8 |
| Cash conversion | Operating cash flow was negative 418 for the six months ended September 30, 2026 against positive 411 a year earlier, which management ties to working capital and the Oswego fires | Documentary Fact; explanation is Management Language | Q2R page:4; RQ2 page:2 |

### Company profile

| Item | Facts | Category | Locator |
| --- | --- | --- | --- |
| Legal entity and perimeter | Novelis Inc., formed in Canada on September 21, 2004; consolidated registrant; some notes are issued by Novelis Corporation and Novelis Sheet Ingot GmbH and guaranteed by Novelis Inc. and certain subsidiaries | Documentary Fact | AR page:8; AR page:150; Q2R page:19; Q2R page:20 |
| Country and sector | Incorporated in Canada, headquartered in Atlanta, Georgia; sector per the run context is rolling, drawing and extruding of nonferrous metals (context, not issuer evidence) | Documentary Fact | AR page:1; AR page:8 |
| Ownership | All shares held indirectly by Hindalco Industries Ltd.: directly by AV Minerals (Netherlands) N.V. since the September 1, 2022 plan of arrangement; 606,333,333 common shares outstanding; no public market for the shares | Documentary Fact | AR page:2; AR page:8 |
| Ownership history | Acquired by Hindalco on May 15, 2007; the 2022 arrangement merged AV Metals, Inc. into Novelis Inc. as a combination of entities under common control | Documentary Fact | AR page:8 |
| Control rights and economic interest | Sole shareholder elects directors (a director was elected by the sole shareholder on November 3, 2026). Percentages beyond sole ownership, shareholder agreements and any parent guarantee: Insufficient Information, the supplied pages state none | Documentary Fact; Insufficient Information | Q2R page:74 |
| Equity support | Subscription agreements: 5,000,000 shares for 750 on December 23, 2025 and 1,333,333 shares for 200 on February 18, 2026, 150 a share, total 950 of equity contributions in fiscal 2026 | Documentary Fact | Q2R page:8; AR page:111 |
| Distributions | Return of capital of 35 in fiscal 2026 (first quarter) and 100 in fiscal 2024; none in the six months ended September 30, 2026 | Documentary Fact | AR page:111; Q2R page:16 |
| Related-party arrangements | Intellectual property license with Birla Group Holdings Private Limited effective July 1, 2026, royalty for fiscal 2027 not to exceed 24, with 11 expensed in the quarter; accounts payable to related parties 455 and receivables 295 at September 30, 2026; purchases of tolling services from the Alunorf affiliate | Documentary Fact | Q2R page:16; Q3R page:16 |
| Governance changes | A director resigned effective December 31, 2026 and an independent director of Hindalco was elected effective January 1, 2027, both inside the cutoff as announced events | Documentary Fact | Q2R page:74 |
| Reporting | Voluntary filer with audited annual and unaudited quarterly statements; SEC file number 001-32312 | Documentary Fact | AR page:1 |
| Credit ratings | Not supplied: no rating agency report or rating is in the pack; filings mention rating-linked terms only (a loan margin step and suspension of note covenants at investment grade) | Insufficient Information | Q2R page:20; Q2R page:21 |
| Market data | Not supplied: no equity (the shares are private), quotes, spreads or peer data | Insufficient Information | AR page:2 |

### Transaction summary and new debt issues

Financing activity over the last two fiscal years is a sequence of completed refinancings and new money for the Bay Minette programme, all described in the debt note. In fiscal 2025 the company issued 750 of 6.875% Senior Notes due January 2030 through Novelis Corporation and used the net proceeds to repay 738 of borrowings under the asset-based revolver (AR page:151), and entered a floating rate Term Loan Facility that provided 1,250 of proceeds and matures March 2032 (AR page:85; Q2R page:18); in September 2025 the term loan margin was cut from 2.00% to 1.75% over three-month Term SOFR (Q2R page:18). On August 18, 2025 Novelis Corporation issued 750 of 6.375% Senior Notes due August 2033 and used the net proceeds to buy 737 of the 750 outstanding 3.25% Senior Notes due November 2026 in a cash tender, leaving 13 outstanding (Q2R page:20; page:17). The Baldwin County Industrial Development Authority issued tax-exempt bonds loaned to Novelis Corporation to fund the Bay Minette plant: Series 2025A of 400 in June 2025 at 5.00%, Series 2025B of 100 in September 2025 at 4.625% and Series 2026A of 225 in March 2026 at 4.30%, each with a mandatory tender (June 2032 or March 2033) before final maturity (Q2R page:22 to page:24). The asset-based revolver was enlarged by 500 on February 19, 2026 to 2.5 billion and by a further 500 on June 16, 2026 to 3.0 billion, with maturity extended to June 16, 2031 (Q2R page:18). On July 23, 2026 the company signed an unsecured 500 term loan, fully drawn, due July 24, 2028 at Term SOFR plus 1.00% rising to 1.25% on certain rating events (Q2R page:21). Uncommitted trade and bank lines were added: a Citi facility of up to 300 after a January 2026 increase from 200, and an MUFG facility of up to 500 from May 26, 2026, both undrawn at September 30, 2026 (Q2R page:19). Use of proceeds disclosed: bonds and the Bay Minette related issuance for construction costs, the 2033 notes for the tender of the 2026 notes, the March 2025 term loan to repay earlier term loans, and the 6.875% notes to repay revolver borrowings (Q2R page:18; page:20; page:22; AR page:151). The use of proceeds for the July 2026 term loan is Insufficient Information in the pages read.

Equity and distributions: the parent subscribed 950 of new shares in fiscal 2026 for capital projects (AR page:86; Q2R page:8), the company returned 35 of capital to the parent in the first quarter of fiscal 2026 and has paid none in fiscal 2027 (Q2R page:16). The Aditya Birla brand license from July 1, 2026 is a new related-party cost of up to 24 for fiscal 2027 (Q2R page:16).

Operating events with transaction-like effects: the Oswego fires of September 16 and November 20, 2025, with the hot mill restarting in early June 2026 and cumulative net insurance recoveries of 519 through September 30, 2026 (Q2R page:36; page:48); the June 2024 Sierre flood in Switzerland, financed in part by a CHF 100 million loan from the Banque Cantonale du Valais whose interest is payable by the Canton of Valais (Q2R page:21); restructuring under the 2025 Efficiency Plan with cumulative costs of 185 and a target of approximately 350 to 400 of annualized savings by the end of fiscal 2028 (Q2R page:47); and the Bay Minette plant, whose cold mill produced its first coil in September 2026 with commercial shipments targeted for the first quarter of fiscal 2028 (RQ2 page:2). The annual report said the plant was expected to commission in fiscal 2027 and in the second half of calendar 2026 (AR page:2; page:72), while the Q2 release reports a first coil in September 2026 and targets commercial shipments in the first quarter of fiscal 2028. These are different milestones, commissioning and commercial shipments, so no delay is concluded and no conflict is logged.

Subsequent events within the cutoff, after the quarter ended September 30, 2026: the board changes of November 3, 2026 (Q2R page:74); the 13 balance of the 3.25% notes falls due on November 15, 2026 by contract (AR page:150; Q2R page:17), which is a scheduled maturity and not a reported event; and the Q2 results release of November 5, 2026. No acquisition, disposal, sponsor change, rating action or new debt issue dated after September 30, 2026 was found in the supplied sources. No pending transaction is described.

### Governance and sponsor behavior

| Behavior | Evidence | Category | Legal capacity, willingness, feasibility |
| --- | --- | --- | --- |
| Equity support: Supportive | 950 of subscriptions in fiscal 2026 to help fund capital projects (AR page:86) | Documentary Fact | Willingness shown by action; no legal commitment to continue is stated, and the filing says "There can be no assurances that similar funding from equity contributions from our common shareholder will be made available in the future" (Q2R page:61) |
| Distributions: Neutral or Mixed | Return of capital of 35 in the first quarter of fiscal 2026 while equity was also being contributed, none since (AR page:111; Q2R page:16) | Documentary Fact | Capacity under the notes: covenants limit dividends and restricted payments "beyond certain amounts" (Q2R page:19); the baskets are not supplied |
| Related-party leakage: Neutral or Mixed | Brand license royalty up to 24 for fiscal 2027 to an Aditya Birla Group company (Q2R page:16) | Documentary Fact | Approved by the board on August 4, 2026 (Q2R page:16); affiliate-transaction covenant text not supplied |
| Creditor-adverse actions | None found in the supplied pages: no priming, uptiering, drop-down, non-pro-rata exchange or collateral release is described | Insufficient Information | Cannot be excluded without the indentures and credit agreements; the unrestricted subsidiary designation right is mentioned in the covenant summary (Q2R page:19) |

### Credit translations

- Revenue durability. Evidence: supply contracts of "one to five years", a stated "high degree of renewal business" and significant switching costs (AR page:23) against a top 10 customer share of 57% in fiscal 2026 from 41% (AR page:33). Mechanism: long contracts and qualification costs support volume visibility, but a few customers hold most of the volume, so one non-renewal or insourcing decision moves a large share of revenue. Implication: revenue is durable in the base case and lumpy in the downside; the leverage tolerance of the credit is lower than the stable sector profile suggests.
- Margin and earnings quality. Evidence: price pass-through under the conversion model (AR page:73) and adjustments for metal price lag, fire losses and start-up costs inside Adjusted EBITDA (RQ4 page:9). Mechanism: pass-through protects conversion margin against metal price moves, but timing gains and losses, fire items and start-up costs are excluded from the measure, so the measure and cash earnings can differ by large amounts in a period. Implication: leverage computed on Adjusted EBITDA should be read with the exclusions; the financial base carries both.
- Cash flow and liquidity. Evidence: capital spending guidance of 2.1 to 2.4 billion for fiscal 2027 (Q2R page:48), negative operating cash flow for the six months (Q2R page:4) and revolver availability of 606 (Q2R page:19). Mechanism: the build continues for the rest of the year and start-up costs continue until normal capacity, while insurance recoveries are uncertain in amount and timing. Implication: refinancing and liquidity depend on revolver access and on delivery of management's expected return to positive free cash flow, which is a management expectation (RQ2 page:3).
- Sponsor alignment. Evidence: 950 of equity contributions and no fiscal 2027 distribution, against a new affiliate royalty. Mechanism: the parent has put in cash when the programme needed it; there is no stated obligation. Implication: treat parent support as demonstrated behavior, not a credit enhancement; the pages read contain no parent guarantee.
- Key uncertainties: timing of Bay Minette commercial shipments, the amount and timing of remaining Oswego insurance recoveries, the effect of tariffs and duties (including a customs matter in which the company carries a cash deposit of approximately 127 for antidumping duties it is appealing, Q2R page:39), a union strike at the Yeongju plant that management says may affect beverage packaging shipments (Q2R page:47), and the absence of executed financing documents.

### Consumer assessments

| Consumer | Readiness | What to take from this handoff | Why it matters | Gap and required action |
| --- | --- | --- | --- | --- |
| CP-2 credit synthesis | Ready with limitations | Business model, customer concentration, parent behavior, Bay Minette and Oswego timelines, financing history | Explains why leverage and short-term borrowings rose and what must happen for deleveraging | No executed agreements or ratings; carry capacity to distribute and guarantee scope as unverified |
| CP-5 evidence trace | Ready | Every fact here has a page locator and a category tag; management estimates are tagged Management Language | Allows the trace to test claims against the filings | Check the Bay Minette timing statement and the customer concentration figures against the cited pages |

### Conflicts

One internal inconsistency is logged and not reconciled. The annual report debt table lists "Series 2026A Bonds, due June 2033" (AR page:145) while its footnote says the bonds have "a mandatory tender for purchase on March 1, 2033" (AR page:145) and the Q2 quarterly report table lists "Series 2026A Bonds, due March 2033" (Q2R page:17). The amount is 225 and the difference is one quarter in the tender date label; the financial base used the later report's maturity buckets, which do not depend on the label. Two differences of basis are noted so they are not mistaken for conflicts. Total shipments of 3,731 kt in the annual report business section include affiliates on a proportionately consolidated basis and intersegment sales (AR page:20; page:21), while the release reports rolled product shipments of 3,557 kt for the same fiscal year (RQ4 page:1); they are different measures. Segment net sales add to more than consolidated net sales for the same reason (AR page:20; AR page:21).

## Calculations

No new arithmetic was performed in this handoff. Figures repeat the financial base handoff or the cited filing pages. The one derived comparison, the Bay Minette timing, compares milestone dates stated in two documents and involves no calculation.

## Gaps

| Gap | Severity | Consumers | Remediation |
| --- | --- | --- | --- |
| Executed indentures, credit agreements and bond loan agreements not supplied; capacity for distributions, additional debt and collateral release unverified | High | CP-2 | Obtain the documents, or keep all capacity statements at filing-summary level |
| No rating agency material, outlooks or market quotes | Medium | CP-2 | Leave ratings and market-implied views Not supplied |
| Control rights, shareholder agreements and any parent support commitment not stated in the pages read | Medium | CP-2 | Treat parent support as behavior only |
| Remaining Oswego insurance recoveries and the total cost are estimates; the fire cash impact of about 1.7 billion is a management estimate at the date of the annual report | Medium | CP-2 | Carry as management estimate with the cumulative recoveries of 519 as the documented figure |
| Bay Minette total cost, funded and unfunded amount at September 30, 2026 are not itemized in the pages read beyond the approximately 5.0 billion programme size | Medium | CP-2 | Use capital spending guidance; do not compute remaining cost |
| Use of proceeds for the 2026 term loan is not stated | Low | CP-2 | Leave as Insufficient Information |
| Covenant certificate and a covenant add-back bridge are not supplied; the Adjusted EBITDA reconciliation is the only bridge | Medium | CP-2 | State that Adjusted EBITDA is not a covenant measure |
| Earnings slides and the 10-K/A are not supplied | Low | CP-2 | Use releases and filings |

## Next module

Run CP-2 on the financial base and this business and transaction context. It should test the deleveraging claim against the Bay Minette timeline, the capital spending guidance and the revolver availability, keep the customer concentration and Adjusted EBITDA definition risks in the credit view, treat parent support as demonstrated behavior only, and carry the missing executed agreements and ratings as limits. CP-5 follows to trace the evidence.
