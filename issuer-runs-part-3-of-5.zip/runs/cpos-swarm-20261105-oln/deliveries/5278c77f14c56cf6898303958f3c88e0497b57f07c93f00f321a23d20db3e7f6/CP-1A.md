## Request

Business, ownership and transaction context for OLIN Corp (Olin Corporation, NYSE: OLN), as of 2026-11-05, pathway credit_snapshot, current period Q3 2026 against FY2025, reporting currency USD. Scope: which transaction, business, ownership and operating facts matter most to a creditor, the pending Huntsman merger and its new credit facility, issuer-level governance and capital allocation behaviour, and a dated timeline to the 2026-11-05 cutoff. Figures repeat the accepted financial handoff exactly.

## Sources

### Issuer sources relied on

| Source name | Use in this module | sha256 |
| --- | --- | --- |
| 10-K_2025-12-31_oln-20251231.htm.jsonl | Business description, customers, operations, history, ratings, covenant amendments | 4c4aa24234dd70c75f25e45010299b0359519fd53db6b33485bc189c79880655 |
| 10-Q_2026-03-31_oln-20260331.htm.jsonl | Rating actions of February 2026, Q1 events | b7b2893c43ac8c80dd177251279128741771bfa43d75cbf90bad3645179170d6 |
| 10-Q_2026-06-30_oln-20260630.htm.jsonl | Merger announcement terms, termination fee and expense reimbursement | 31cc1696caa1e392e8267ebed3744e51e1777dcbf99f80668497471e88c3bcb0 |
| 10-Q_2026-09-30_oln-20260930.htm.jsonl | Controlling source for the merger, the October 27, 2026 amendment, segments, legal matters, outlook | fcb130292ef752affbb45743362d92ca38d4b7b812532fc678ec7413956a3cd3 |
| EX-99.1_2026-05-07_exhibit991q12026earningspr.htm.jsonl | Management commentary Q1 2026 (attributed) | 9f1321ffd9728e7b42deb60dc916ea8598957e5a719c0c9054fc2f70430134aa |
| EX-99.1_2026-07-30_exhibit991q22026earningspr.htm.jsonl | Management commentary Q2 2026, Freeport VCM outage (attributed) | 08a70fcc145c266c21d73e09e50eda1490a6994f07dbbc111206ffd51445010c |
| EX-99.1_2026-10-29_exhibit991q32026earningspr.htm.jsonl | Management commentary Q3 2026, merger timing, guidance (attributed) | 27ebe9b3524b1cfc010f76a20b291e6a4f5bd41b4c9d2abf5a2ffd63c041424f |

The settings source `context` (sha256 09d8a3ab70b39856c937eb920b788157e416ce636cea1515d7a99dd15e9d89b1) is not issuer evidence. It states sector as Chemicals & Allied Products and leaves sponsor, parent, guarantors, deal terms, ratings, peers and market data blank; blanks are not treated as zero.

### Supplied handoffs

| Module | sha256 |
| --- | --- |
| CP-0 | 728efd77512ff127e878c235404a8f40fc8f81833ce6d2ce37a46e77c06dd33e |
| CP-1 | 7df7316b863cab8ea464b4d35c09d645a7fd3da78a51db340a44c7a910837154 |

Corrections to earlier handoffs: the CP-0 handoff states ratings are printed only as of September 30, 2026; the 10-K and the Q1 2026 10-Q also print them (corrected in the CP-1 handoff, and relied on here). The CP-1 handoff treats the termination fee as USD 121 million only; the Q2 2026 10-Q also states reimbursement of Huntsman expenses of up to USD 30 million (10-Q Q2 page:56), which is added here.

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| OLIN Corp is a listed, sponsor-free chlor alkali, epoxy and ammunition producer with weaker earnings in 2026 and a pending all-stock merger with Huntsman. No sponsor is involved, but the merger adds execution risk. | Medium | Huntsman financials, the merger agreement and the pro forma capital structure are not in the pack. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Chlor Alkali Products and Vinyls fell to USD 80.2 million of segment income in the nine months of 2026, hit by the Freeport vinyl chloride monomer outage. | Earnings concentration in one segment drives leverage of 5.21x. | High |
| Winchester and Epoxy improved, with Winchester at USD 77.1 million of segment income for the nine months. | Ammunition and epoxy partly offset chemical weakness, but epoxy demand stays weak. | Medium |
| The Huntsman merger is expected to close in the first quarter of 2027 with a new USD 2,500.0 million credit facility. | Refinancing replaces Olin's bank facilities, but combined leverage cannot be assessed. | Medium |
| Olin kept its USD 0.20 quarterly dividend while nine month free cash flow was negative and made no share repurchases in 2026. | Distributions continue under covenant relief, limited to regular dividends. | Medium |

### Business and transaction view

OLIN Corp is a publicly listed, sponsor-free manufacturer whose creditor case rests on integrated chlor alkali and epoxy assets plus a defence-linked ammunition business, and whose near-term outcome is set by a single pending transaction: an all-stock merger of equals with Huntsman Corporation, expected to close in the first quarter of 2027. The strongest support is diversification and integration, with three segments, no customer above 10 percent of 2025 sales and a captive chlorine outlet through epoxy and chlorinated organics. The weakest point is the Chlor Alkali Products and Vinyls segment, where the Freeport vinyl chloride monomer outage cut segment income to USD 80.2 million for the nine months from USD 270.8 million. What decides the credit is whether the merger closes, what the combined company borrows under the new USD 2,500.0 million facility, and whether fourth quarter 2026 earnings meet the USD 80 million to USD 100 million guidance, so execution risk on the merger is the main swing factor.

### Company and operating model

| Item | Value |
| --- | --- |
| Reporting entity and perimeter | Olin Corporation, a Virginia corporation incorporated in 1892, reporting consolidated with its subsidiaries; guarantor subsidiaries are not named (Documentary Fact; 10-Q Q3 page:6, page:13) |
| Business description | "A leading vertically integrated global manufacturer and distributor of chemical products and a leading U.S. manufacturer of ammunition" is the company's own description (Management Language; 10-K page:4) |
| Segments and mix | Chlor Alkali Products and Vinyls 54%, Epoxy 20% and Winchester 26% of 2025 sales per the 10-K (Documentary Fact; 10-K page:4); nine months 2026 sales were 2,427.2, 1,189.9 and 1,455.5 of 5,072.6 (47.8%, 23.5% and 28.7%, derived; 10-Q Q3 page:23) |
| Revenue model | Industrial and commercial users and distributors; epoxy resins, caustic soda and sporting ammunition sold to many users, chlorine and chlorinated organics in substantial quantities to a relatively small number; no single customer above 10% of 2025 sales; U.S. government agencies about 13% of 2025 sales (Documentary Fact; 10-K page:13) |
| Pricing and volume drivers | Operating model prioritises Electrochemical Unit margins over sales volumes (Management Language; 10-Q Q3 page:56). Nine month 2026 Chlor Alkali segment income fell USD 190.6 million, driven by the Freeport outage (72.2), lower volumes (55.3), lower pricing (42.0), a legacy litigation charge (36.1), raw materials (32.1) and a smaller 45V tax credit (12.1), partly offset by lower operating costs (59.2) (Documentary Fact; 10-Q Q3 page:41) |
| Cost structure | Electricity is the largest raw material in chlor alkali, about 76% from natural gas or hydroelectric sources; about 73% of salt is internal; ethylene is supplied under a long-term arrangement (Documentary Fact; 10-K page:6). Epoxy inputs are chlorine, caustic soda, cumene, propylene and aromatics (10-K page:9). Winchester buys copper-based strip, lead and propellant under multi-year contracts at conversion charges over exchange metal prices (10-K page:12). Raw materials and utilities purchase commitments were USD 5,559.4 million at December 31, 2025 (10-K page:69) |
| Capital spending and depreciation | Management expects 2026 capital spending of about USD 200 million "to maintain our current operating facilities" and depreciation and amortization of about USD 470 million (Management Language; 10-Q Q3 page:45, page:48); nine month capital spending was USD 106.6 million (10-Q Q3 page:4) |
| Working capital | Nine month 2026 working capital increased USD 191.0 million against USD 264.9 million in 2025; receivables rose USD 133.4 million and inventories USD 81.0 million (Documentary Fact; 10-Q Q3 page:48); last-in, first-out reserve USD 203.0 million (10-Q Q3 page:11) |
| Geography | Nine month 2026 sales: United States 3,580.3, Europe 446.0, other foreign 1,046.3 of 5,072.6 (70.6% United States, derived; 10-Q Q3 page:23); Epoxy sold about 59% outside the United States in 2025 (10-K page:13) |
| Winchester contracts | Operates the government-owned Lake City Army Ammunition Plant under a contract of seven years from October 1, 2020 extended by three years, terminable for convenience; the plant is government-owned and contractor-operated; military and law enforcement sales were 887.7 of 1,455.5 in the nine months and over-time revenue 330.0 (Documentary Fact; 10-K page:10, page:13; 10-Q Q3 page:24) |
| Seasonality | Fourth quarter is typically the weakest seasonal quarter (Documentary Fact; 10-Q Q3 page:45) |

### Company profile

| Item | Value |
| --- | --- |
| Name, ticker and exchange | Olin Corporation, OLN, New York Stock Exchange (Documentary Fact; 10-Q Q3 page:1) |
| Country, sector and headquarters | United States; sector Chemicals & Allied Products is a user setting in the context, not an issuer statement; headquarters Clayton, MO (10-Q Q3 page:1) |
| Fiscal year, filer status and auditor | Year ending December 31; large accelerated filer; KPMG LLP, St. Louis, auditor since 1954 (10-K page:80) |
| Shares outstanding | 114,005,726 at September 30, 2026 (Documentary Fact; 10-Q Q3 page:1) |
| Senior management named in the pack | Ken Lane, President and Chief Executive Officer (EX-99.1 Q3 page:1); Todd A. Slater, Senior Vice President and Chief Financial Officer (10-Q Q3 page:61) |
| Ownership | Publicly traded; no sponsor or controlling holder is named in the pack; beneficial owners are incorporated from the proxy statement, which is not supplied (Insufficient Information; 10-K page:142) |
| Ratings at September 30, 2026 | Fitch BB+ Rating Watch Positive; Moody's Ba2 Negative; S&P BB Credit Watch Developing (Documentary Fact; 10-Q Q3 page:52, page:53) |
| Bank agent | Bank of America, N.A. is administrative and collateral agent of the Credit Agreement (10-Q Q3 page:60) |
| Market capitalisation and enterprise value | Not supplied: the context leaves market inputs blank; the 10-K states non-affiliate market value of approximately USD 2,296.9 million at June 30, 2025, which is stale (10-K page:2) |
| Merger counterparty | Huntsman Corporation; combined company to be named OlinHuntsman Corporation (Documentary Fact; 10-Q Q3 page:7) |

### Transaction summary and new debt issues

On June 15, 2026 Olin entered into a definitive agreement with Huntsman Corporation for an all-stock merger of equals to form OlinHuntsman Corporation; each Huntsman share converts into 0.5476 Olin shares, and Olin holders are expected to own approximately 54.5% and Huntsman holders approximately 45.5% of the combined company (10-Q Q3 page:7, page:8). Shareholders of both companies approved the proposals on August 25, 2026 and the Hart-Scott-Rodino waiting period expired, but remaining regulatory approvals and customary conditions are outstanding and closing is expected in the first quarter of 2027, having been expected in the first half of 2027 in the July release (10-Q Q3 page:8; EX-99.1 Q2 page:3). The registration statement on Form S-4/A was declared effective on July 13, 2026 (10-Q Q3 page:58). Olin could owe a termination fee of USD 121 million, and the Q2 2026 10-Q adds reimbursement of Huntsman expenses of up to USD 30 million (10-Q Q2 page:56). Olin booked acquisition-related costs of USD 13.7 million in Q3 2026 and USD 24.3 million in the nine months and expects USD 35 million to USD 40 million for 2026 (10-Q Q3 page:45). The merger agreement restricts certain Olin actions without Huntsman's consent before closing (10-Q Q3 page:57).

The new debt is the OlinHuntsman Credit Facility of USD 2,500.0 million under a second amendment dated October 27, 2026 to Olin's credit agreement, effective on the merger Closing Date subject to closing and customary conditions. It has a term loan of USD 750.0 million replacing Olin's existing USD 650.0 million term loan facility, and a revolver of USD 1,750.0 million replacing Olin's USD 1,200.0 million revolver and Huntsman's revolver. The term loan amortises at 1.250% per quarter from the first full fiscal quarter after closing through the fourth anniversary quarter, then 1.875% per quarter, and the facility matures five years after the Closing Date. It is guaranteed by certain Olin subsidiaries and certain Huntsman subsidiaries, secured by first priority liens on certain assets, carries a pricing grid on the net leverage ratio, and has covenants on secured debt to EBITDA and on EBITDA to interest expense, with levels not supplied. The term loan is expected to be fully drawn at closing, with proceeds and any revolver loans used to refinance Olin's senior secured facility, repay and terminate Huntsman's revolver and pay fees (10-Q Q3 page:8, page:9). Olin's senior notes of USD 669.3 million, USD 515.3 million and USD 600.0 million and its USD 465.0 million receivables facility are not stated to be refinanced (CP-1 handoff; 10-Q Q3 page:12). No new notes issuance is described. Huntsman's debt, its balance sheet, its amounts under its revolver and the pro forma capital structure are not in the pack, so combined leverage and the net new debt at closing are not calculable.

### Fact register

| Fact | Category | Dimension informed | Locator and limitation |
| --- | --- | --- | --- |
| Olin is publicly traded with no sponsor or controlling holder named | Insufficient Information | Ownership and control | 10-K page:142; proxy not supplied; no percentage is inferred |
| Segment income of Chlor Alkali Products and Vinyls was USD 80.2 million for nine months 2026 against USD 270.8 million | Documentary Fact | Operating resilience | 10-Q Q3 page:40; driver detail on page:41 |
| The Freeport VCM outage reduced Q2 2026 adjusted EBITDA by USD 40 million and was estimated at USD 20 million for Q3 2026; the Q3 segment impact was USD 32.1 million | Documentary Fact | Operating resilience | EX-99.1 Q2 page:1; 10-Q Q3 page:41; the Q3 impact exceeded the July estimate |
| Management says VCM assets were restored to normal operations in Q3 2026 | Management Language | Operating resilience | EX-99.1 Q3 page:1; unverified by the filing |
| Winchester segment income rose to USD 33.8 million in Q3 2026 from USD 19.3 million, and was USD 77.1 million for the nine months of 2026 | Documentary Fact | Diversification | 10-Q Q3 page:43 |
| Epoxy segment income was USD 0.6 million in Q3 2026 after a USD 32.2 million loss; the 10-Q says global demand remains weak and U.S. and European Epoxy remain significantly challenged by subsidised Asian competition | Documentary Fact | Operating resilience | 10-Q Q3 page:33, page:42 |
| Shintech jury verdict on February 10, 2026, final judgment on September 11, 2026; about USD 114 million paid in the nine months | Documentary Fact | Legal and liquidity | 10-Q Q3 page:25; appeal timing uncertain |
| State of Texas sued Blue Cube on April 9, 2026 over Freeport emissions events | Documentary Fact | Regulatory | 10-Q Q3 page:58; outcome and amount Not supplied |
| Blue Water Alliance with Mitsui ended at the end of 2025; USD 31.3 million paid to Mitsui in Q1 2026 | Documentary Fact | Capital allocation | 10-Q Q3 page:36 |
| Debt guarantees and collateral were added for the bank facilities on February 19, 2026, to fall away by September 30, 2027 or on Olin's election | Documentary Fact | Creditor control and ranking | 10-Q Q3 page:13; ranking against the senior notes, whose security is Not supplied, cannot be set |
| Pension plan benefits would automatically increase to absorb surplus if corporate action in contemplation of plan termination or merger follows a change of control within three years | Documentary Fact | Merger consequence | 10-Q Q3 page:16; whether the Huntsman merger is a change of control under the plan is not stated |
| Management says it is "advancing permitted pre-close integration planning" | Management Language | Integration | EX-99.1 Q3 page:2; no synergy amount is given in any source |
| Synergy targets, integration costs beyond 2026 and financing fees | Insufficient Information | Merger value | Searched synergy across all sources; amounts not supplied |

### Ownership and capital allocation

Share repurchases were USD 711.3 million in 2023, USD 300.3 million in 2024 and USD 50.5 million in 2025, and nil in the nine months of 2026; USD 1,948.9 million of authorisation remained at September 30, 2026 (10-K page:83; 10-Q Q3 page:4, page:59). Dividends were USD 91.6 million in 2025 and USD 68.3 million in the nine months of 2026 at USD 0.20 per quarter, described as the 398th consecutive quarterly dividend in May 2026 (10-K page:83; EX-99.1 Q1 page:3). Nine month 2026 free cash flow before dividends was USD -36.9 million (CP-1 handoff), so, as an Analyst Interpretation, dividends and the USD 31.3 million Mitsui payment were covered by net long-term debt borrowings of USD 185.3 million (10-Q Q3 page:4). During the covenant relief period the February 2026 amendment limits dividends and distributions beyond regularly scheduled dividends, debt incurrence and certain asset sales (10-K page:141). Acquisitions were modest: AMMO small caliber assets for USD 55.8 million on April 18, 2025 and White Flyer targets for USD 63.5 million on October 1, 2023 (10-Q Q3 page:7; 10-K page:10); acquisition appetite is not inferred from these.

### Timeline

| Date | Event | Status |
| --- | --- | --- |
| 1892 | Olin incorporated in Virginia | Documentary Fact (10-K page:4) |
| October 1, 2020 | Winchester assumes operation of Lake City Army Ammunition Plant | Documentary Fact (10-K page:10) |
| October 1, 2023 | White Flyer targets acquired for USD 63.5 million | Documentary Fact (10-K page:10) |
| December 2024 | Closure of Chlorine 3 at Freeport, TX announced | Documentary Fact (10-Q Q3 page:9) |
| March 14, 2025 | USD 600.0 million 6.625% notes due 2033 issued; USD 1,850.0 million credit facility signed; 2025 and 2027 notes redeemed | Documentary Fact (10-Q Q3 page:13, page:14) |
| April 18, 2025 | AMMO small caliber assets acquired for USD 55.8 million | Documentary Fact (10-Q Q3 page:7) |
| September 18, 2025 | Mitsui joint venture Blue Water Alliance to end by year end | Documentary Fact (10-Q Q3 page:36) |
| November 11, 2025 | Ethylene dichloride supply arrangement with Braskem announced | Documentary Fact (10-K page:6) |
| December 2025 | Closure of Guarujá, Brazil epoxy resin plant decided, expected Q1 2026 | Documentary Fact (10-K page:10) |
| February 10, 2026 | Jury verdict for Shintech; USD 75.0 million charged Q4 2025 and USD 11.1 million Q1 2026 | Documentary Fact (10-Q Q3 page:25) |
| February 19, 2026 | Credit facility amended with covenant relief, guarantees and collateral; USD 109.7 million term loan amortisation prepaid | Documentary Fact (10-Q Q3 page:13) |
| February 2026 | Fitch to BB+ from BBB-, Moody's to Ba2 from Ba1, S&P to BB from BB+ | Documentary Fact (10-Q Q1 page:43) |
| April 9, 2026 | State of Texas lawsuit against Blue Cube | Documentary Fact (10-Q Q3 page:58) |
| June 15, 2026 | Merger agreement with Huntsman (announced June 16, 2026); June 17, 2026 Fitch to Rating Watch Positive, S&P to Credit Watch Developing, Moody's affirmed Ba2 Negative | Documentary Fact (10-Q Q3 page:7, page:53; EX-99.1 Q3 page:3) |
| Q2 2026 | Unplanned shutdown of Freeport VCM plant | Documentary Fact (EX-99.1 Q2 page:1) |
| July 13, 2026 | Form S-4/A declared effective | Documentary Fact (10-Q Q3 page:58) |
| August 25, 2026 | Shareholder approvals; Hart-Scott-Rodino waiting period expired | Documentary Fact (10-Q Q3 page:8) |
| September 11, 2026 | Final judgment in Shintech case | Documentary Fact (10-Q Q3 page:25) |
| October 27, 2026 | Second amendment creating the OlinHuntsman Credit Facility; Fifteenth Amendment to the PNC funding agreement | Subsequent event to the September 30, 2026 balance sheet (10-Q Q3 page:8, page:60) |
| First quarter 2027 | Expected merger closing | Management Language, forward-looking (EX-99.1 Q3 page:1) |
| September 30, 2027 | Latest end of covenant relief and release of guarantees and liens | Contract term (10-Q Q3 page:13) |
| November 19, 2027 | Receivables financing agreement matures | Contract term (10-Q Q3 page:14) |

### Governance and sponsor behaviour

| Behaviour | Category | Mechanic | Legal capacity, willingness and feasibility |
| --- | --- | --- | --- |
| Equity buybacks of USD 300.3 million in 2024 and USD 50.5 million in 2025, then none in 2026 | Neutral or Mixed | Buybacks consumed cash while leverage rose, then stopped; no creditor-adverse transfer is documented | Capacity: the remaining USD 1,948.9 million authorisation exists but relief covenants limit non-regular distributions; willingness: halted in 2026; feasibility: negative free cash flow |
| Dividend held at USD 0.20 per quarter through 2026 | Neutral or Mixed | Dividends of USD 68.3 million in nine months exceeded nine month free cash flow before dividends of USD -36.9 million, so borrowing funded the shortfall | Capacity: regular dividends permitted during relief; willingness: maintained; feasibility: depends on fourth quarter earnings and merger timing |
| Amendment of February 19, 2026 granting lenders guarantees and collateral and tighter limits on debt, dividends and asset sales | Supportive | Bank lenders gain security in exchange for relaxed covenants; senior note holders do not obviously share in it | Analyst Interpretation: ranking of the notes against the new collateral is Not supplied because indentures are not in the pack |
| Transparent reporting of the Freeport outage, litigation charge and rating actions | Supportive | Disclosed with quantified impacts in each release and filing | Evidence quality High: primary, dated, issuer-specific |
| Merger agreement covenants restricting Olin actions without Huntsman consent | Neutral or Mixed | Operating flexibility is limited until closing; asset sales or financing changes need consent | Capacity limited by contract; willingness not tested; the agreement is not supplied |
| No priming, uptier, drop-down, non-pro-rata exchange or collateral release by Olin is documented | Insufficient Information | Absence in a limited pack is not proof of absence | Evidence quality Medium: filings only, no indentures or credit agreement |

### Credit translations

Evidence, mechanic and implication for the main conclusions:

First, earnings concentration. Evidence: Chlor Alkali Products and Vinyls segment income of USD 80.2 million for nine months 2026 against USD 270.8 million, with the Freeport VCM outage costing USD 72.2 million (10-Q Q3 page:41). Mechanic: the segment carries the largest share of depreciation and amortization (282.4 of 353.7 in nine months 2026, 10-Q Q3 page:23), so volume loss and price weakness flow directly into trailing adjusted EBITDA, which fell to USD 536.6 million. Implication: net debt to adjusted EBITDA rose to 5.21x from 4.08x at FY2025 and cash interest cover fell to 3.15x from 3.66x (CP-1 handoff), narrowing tolerance for further operating shocks. Counter-evidence: Winchester and Epoxy improved, and management guides fourth quarter 2026 adjusted EBITDA of USD 80 million to USD 100 million, which is a management expectation.

Second, merger transition. Evidence: all-stock merger with a new USD 2,500.0 million facility replacing Olin's bank facilities and Huntsman's revolver (10-Q Q3 page:8, page:9). Mechanic: the new term loan of USD 750.0 million is expected to be fully drawn at closing and amortises at 1.250% per quarter, while refinancing resets covenants, collateral and the pricing grid; Huntsman's obligations enter the structure. Implication: refinancing risk for Olin's bank debt is addressed only if the merger closes; the combined leverage and the ranking of existing notes cannot be assessed from this pack, and rating agencies are on watch with different directions (Fitch positive, S&P developing, Moody's negative outlook), which signals uncertainty about the combined credit.

Third, liquidity under relief. Evidence: cash of USD 214.8 million, USD 1,029.6 million undrawn revolver, USD 465.0 million receivables facility maturing November 19, 2027 and covenant relief ending by September 30, 2027 (CP-1 handoff). Mechanic: if the merger does not close, the relief period still ends by September 30, 2027 on current terms and the receivables facility then matures within about two months. Implication: monitoring posture should focus on the merger timetable, fourth quarter earnings and any covenant amendment; the numeric covenant levels are not supplied.

### Conflicts logged

| Conflict | Span A | Span B | Downstream effect |
| --- | --- | --- | --- |
| Winchester share of 2025 sales | "which represented 26% of 2025 sales" (10-K page:4) | Segment sales of 1,724.6 on total 6,780.8 (10-K page:129), about 25.4% | Minor rounding or definition difference; logged, not reconciled; segment amounts from page:129 are used for any figure |
| Leverage covenant wording | "ratio of secured debt to earnings before interest expense, taxes, depreciation and amortization (net leverage ratio)" (10-K page:106) | "ratio of consolidated total debt, net of unrestricted cash and cash equivalents, to earnings before interest expense, taxes, depreciation and amortization (net leverage ratio)" (10-Q Q3 page:14) | The covenant debt definition is unclear; headroom cannot be tested; the executed agreement is needed |
| Merger closing timing | "expected to occur in the first half of 2027" (EX-99.1 Q2 page:3) | "close in first quarter 2027" (EX-99.1 Q3 page:1) | Dated update, not a contradiction; the later statement is used and the earlier labelled |
| Termination payment | "termination fee of $121 million or reimburse certain expenses of Huntsman in an amount up to $30 million" (10-Q Q2 page:56) | "termination fee of $121 million" (10-Q Q3 page:58) | The later filing omits the reimbursement; whether it still applies is Not supplied |

### Consumers

| Module | Readiness | What to take from this handoff | Why it matters | Gap and required action |
| --- | --- | --- | --- | --- |
| CP-2 | READY_WITH_LIMITATIONS | Segment drivers, the merger terms and new facility, rating actions, governance behaviour and the four conflicts | Credit synthesis must weigh concentrated earnings, relief-period covenants and an unclosed merger | Huntsman financials, executed legal documents and covenant levels are Not supplied; state them as limits and avoid combined-company conclusions |
| CP-5 | READY_WITH_LIMITATIONS | Locators for each fact and the conflict log; corrections to the CP-0 and CP-1 handoffs | Evidence trace must catch figures that repeat across handoffs | Verify the corrected statements on ratings and the reimbursement; the unsupplied agreements limit verification |

## Calculations

- Segment mix, nine months 2026 (10-Q Q3 page:23): 2,427.2 / 5,072.6 = 47.8%; 1,189.9 / 5,072.6 = 23.5%; 1,455.5 / 5,072.6 = 28.7%.
- United States share, nine months 2026: 3,580.3 / 5,072.6 = 70.6%.
- Winchester share of FY2025 sales: 1,724.6 / 6,780.8 = 25.4%, against 26% stated (10-K page:4, page:129).
- Winchester military and law enforcement share, nine months 2026: 887.7 / 1,455.5 = 61.0%.
- Chlor Alkali segment income change, nine months: 80.2 - 270.8 = -190.6, equal to the printed decrease (10-Q Q3 page:41); the listed drivers sum as -72.2 - 55.3 - 42.0 - 36.1 - 32.1 - 12.1 + 59.2 = -190.6.
- Term loan step-up at closing: 750.0 new commitment against 528.1 outstanding on the existing term loan is 221.9 more term debt, if the new term loan is fully drawn and the 528.1 balance is unchanged at closing; Huntsman revolver and other debt are Not supplied, so net new debt is Not calculable.
- Quarterly term loan amortisation on 750.0 assumed fully drawn: 1.250% = 9.375 per quarter, or 37.5 per year; 1.875% = 14.0625 per quarter, or 56.25 per year.
- Lake City contract term implied: seven years from October 1, 2020 ends in 2027, plus three years of extension ends in 2030 (derived from 10-K page:10; exact dates not printed).
- Figures carried from the CP-1 handoff without change: 5.21x, 4.08x, 3.15x, 3.66x, trailing adjusted EBITDA 536.6, free cash flow before dividends -36.9 for nine months 2026.

## Gaps

| Gap | Effect | Remediation |
| --- | --- | --- |
| The Merger Agreement, joint proxy and S-4 are not supplied; conditions, outside date, financing commitments and exact termination terms are unknown. | Probability and timing of closing, and break-up consequences, cannot be assessed beyond summary text. | Supply the Form 8-K of June 16, 2026 and the S-4/A. |
| Huntsman financial statements and debt are not supplied. | Pro forma leverage, liquidity and the net new debt at closing are Not calculable. | Supply Huntsman filings. |
| Synergy and integration cost targets are not stated in any source. | Value from the merger cannot be linked to deleveraging. | Management disclosure or proxy. |
| Beneficial owners of Olin shares are in the proxy statement, not supplied. | Ownership concentration cannot be stated. | Supply the 2026 proxy statement. |
| Indentures and the credit agreement are not supplied; ranking and covenant terms of the senior notes against the newly secured bank debt are unknown. | Structural position of note holders is Not supplied. | Supply the documents. |
| Whether the Huntsman merger is a change of control under the domestic pension plan is not stated. | Pension surplus consequence is unassessed. | Review plan terms. |
| Management statements on VCM restoration and fourth quarter outlook are attributed claims. | Treated as Management Language only. | Test against fourth quarter results after the cutoff. |

Amounts are USD millions as reported. Facts after September 30, 2026 are labelled subsequent events. Nothing dated after 2026-11-05 is used as fact; expected closing and contract dates are forward terms.

## Next module

Proceed to CP-2 with this handoff and the CP-1 handoff. Carry forward: earnings concentration in Chlor Alkali Products and Vinyls, the unclosed Huntsman merger and the conditional USD 2,500.0 million facility, relief-period covenants with unsupplied levels, rating watches in different directions, and the four logged conflicts. Do not draw combined-company conclusions without Huntsman evidence.
