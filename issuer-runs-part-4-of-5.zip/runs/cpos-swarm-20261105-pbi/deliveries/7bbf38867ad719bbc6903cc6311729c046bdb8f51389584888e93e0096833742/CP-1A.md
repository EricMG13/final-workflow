## Request

Issuer: PITNEY BOWES INC /DE/ (Pitney Bowes Inc., Delaware, NYSE: PBI, issuer id pbi). As-of date: 2026-11-05; evidence cutoff 2026-11-05. Pathway: credit_snapshot. Reporting currency: USD; amounts are US$ millions to one decimal, converted from the thousands the filings print, unless a row says otherwise. Current period: Q3 2026 (three months and nine months ended 2026-09-30); prior period: FY2025.

Scope: the business and transaction context for the credit snapshot. It captures the company, its operating model, ownership, the transactions and financings of the period, a dated timeline, issuer-level governance and capital-allocation behaviour, credit translations and the monitoring gaps. It gives no peer ranking, no instrument recommendation and no recovery conclusion. Figures are carried from the supplied sources and from the accepted financial base; where this handoff states one, it is a located source figure or a reference to that base.

Perimeter: Pitney Bowes Inc. and its wholly owned subsidiaries, consolidated (10-K page:69). The context names no sponsor, parent, borrower or guarantor and lists no transaction, so the company is treated as a listed operating business with no sponsor identified.

## Sources

### Issuer sources relied on

| Source (exact name) | sha256 | Used for |
| --- | --- | --- |
| 10-K_2025-12-31_pbi-20251231.htm.jsonl | 4f5deb57a07fe1eea64b3f9a9468185d34382c2ac8c5a94646c45747e0b2326e | Business description (pages 5-9), competition and suppliers (pages 7-8), executive officers (pages 10-11), risk factors (pages 12-17, 23), properties (page:30), distributions (page:31), Item 9B (pages 52-54), segment and revenue notes (pages 81-84), Ecommerce Restructuring (page:85), restructuring (page:97), debt (pages 97-101), pensions (pages 102-105) |
| 10-Q_2026-03-31_pbi-20260331.htm.jsonl | 624a80b6cca522410fd3993e4d3c4a11f7096c24a4986d50fced927a53e82f28 | Q1 2026 segment results (pages 28-29), outlook (page:30) |
| 10-Q_2026-06-30_pbi-20260630.htm.jsonl | 1df859f2a36df1a95ab3c12f91757b26486c9d8b234afc186a635a7369a5958d | Q2 2026 debt events and amendments (pages 20 and 40), outlook (page:34) |
| 10-Q_2026-09-30_pbi-20260930.htm.jsonl | 9ac96ecd84cbfc34b739239b40a8f155d4a7193f9d71c03e1504313a41bfda22 | Primary source: segments, revenue, finance assets, debt Note 10, pensions, contingencies, MD&A, distributions, exhibits |
| EX-99.1_2026-05-05_q12026earningspressrelea.htm.jsonl | 429691f75b3fe167dac89bd697b030c14535bbbb0b53e2afaf1e37a0eeb21619 | Q1 2026 capital allocation and guidance (attributed management claims) |
| EX-99.1_2026-07-29_q22026earningspressrelea.htm.jsonl | 0a144327096e38bc9546ab64951475ad37b63f71db5dc4f751be723ca256bc40 | Q2 2026 capital allocation and guidance (attributed) |
| EX-99.1_2026-10-28_ex991q32026earningspress.htm.jsonl | 42e81ba5c9c8e886a22fe22bd69da5cf53cfc84b55897aeb23cc53c06bbc9f1b | Q3 2026 capital allocation, segment commentary, guidance (attributed) |

The run context (sha256 c37c14ec550e9841f87339ac47485b30200b39c05673baeb478fd6400a5b7677) supplies dates and currency only and is not issuer evidence.

### Supplied handoffs

| Module | sha256 | Use |
| --- | --- | --- |
| CP-0 (source readiness) | cad86cb0a3fd98500e899a766aea0470956626c6150c1885edf57ff710f357b9 | Source map, gap register, version and maturity conflicts; read in full and carried forward |
| CP-1 (financial base) | bcde32ba969dc3f68634f56be69b4c3c438b14957c4d8e94474c2f62621f2491 | Leverage, interest cover, liquidity, maturity profile, debt schedule, claims outside debt; read in full and carried forward |

### Checks on the supplied handoffs

The earlier handoffs cannot be edited, so they are checked here. No statement in either is found wrong. One point is added to the financial base: it noted the repurchase authorization of 750 million; the 10-K and the Q3 10-Q describe how that total was built in different words (see Conflicts logged), which the financial base did not need to resolve. The financial base's figures used below (debt principal of 1,918.4, net finance receivables of 995.1, customer deposits of 647.9, buybacks of 205.7 and dividends of 40.6 for nine months 2026) were re-read against the Q3 10-Q and agree.

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| Pitney Bowes is a listed, non-sponsored mailing and shipping technology and mail-sortation business whose creditor case rests on eroding mail revenue, cost cuts, a shrinking finance book and shareholder returns that compete with debt reduction. | Medium | No credit agreement, indenture, proxy statement or legal document is supplied, so legal capacity, ownership and control rights rest on company summaries. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| No client exceeded 10% of 2025 sales, but revenue depends on USPS and mail volume; nine-month revenue fell 2% and the meter population is declining. | Breadth limits concentration risk but not secular erosion, so earnings depend on continued cost reduction. | High |
| Presort adjusted segment EBIT fell to 91.0 for nine months from 123.3, with gross margin down to 31.6% from 37.2% and 15 million of higher transportation and fuel costs. | A fixed network of 34 operating centers makes margin sensitive to volume and fuel, weakening the second earnings pillar. | High |
| SendTech adjusted segment EBIT rose to 351.2 from 299.3 on cost reductions, while net finance receivables ran off to 995.1. | Part of cash generation is liquidation of the finance book, so recurring cash flow is lower than reported operating cash flow suggests. | Medium |
| Debt principal fell 107.8 in nine months while buybacks and dividends totaled 246.3, after 378.4 of buybacks in 2025. | Distributions compete with retiring the 2029 notes; the documents that would show distribution limits are not supplied. | Medium |
| Leadership and board changed in 2025, activism is disclosed, and the Ecommerce Restructuring left claims, including one seeking more than 100 million. | Governance and legacy claims need monitoring; no creditor-adverse action is documented in the sources. | Medium |

### Business and transaction view

The company is a listed operating business with no sponsor, no acquisition and no leveraged buyout in the sources. Its credit story is one of managed decline: a mailing and shipping technology segment (SendTech Solutions) whose services revenue is eroding with the meter population but whose profit has been lifted by cost cuts, a mail-sortation segment (Presort Services) that is the largest USPS workshare partner and is now losing margin to transportation cost and pricing, and a financing business inside SendTech, run partly through a Utah industrial bank, that funds client leases and loans and is shrinking. The transactions that matter are financing and capital-allocation events rather than ownership events: the August 2024 exit from the Global Ecommerce business, the February 2025 credit agreement, the August 2025 convertible notes, the 2026 refinancing that replaced notes due in 2027 with a larger term loan and further 2029 notes, a 2026 revolver increase to 450 million, a September 2026 tender and term-loan repricing, and large share repurchases. The creditor-relevant change over the period is lower debt and lower interest, a smaller and cheaper cost base, and a leadership and board refresh with activist history, alongside a stockholders' deficit and substantial distributions. Governance evidence is documentary and mixed rather than adverse; legal capacity to add debt, make distributions or release collateral cannot be assessed because the debt documents are not supplied.

### Company and operating model

| Segment | Products and services | Clients and concentration | FY2025 revenue | FY2025 adjusted segment EBIT | 9M 2026 revenue | 9M 2026 adjusted segment EBIT | Q3 2026 revenue | Q3 2026 adjusted segment EBIT | Cost structure, drivers and visibility | Locators |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| SendTech Solutions | Physical and digital shipping and mailing technology, supplies, maintenance, financing of equipment (including other manufacturers' equipment), revolving credit and deposits through the Pitney Bowes Bank, cross-border services | Small and medium businesses, retail, enterprise and government clients; no client above 10% of consolidated net sales | 1,256.0 | 412.2 | 928.1 | 351.2 | 305.3 | 115.0 | Gross margin 68.1% for nine months 2026 against 66.2%; lower selling, general and administrative expense of 259.1 against 304.1; services revenue pressured by a declining meter population; products revenue pressured as clients extend leases; future performance obligations of 624.4 mostly maintenance bundled with leases | 10-K pages 6, 51, 81, 84; Q3 10-Q pages 7-10, 30-31 |
| Presort Services | Sortation services that qualify First Class, Marketing Mail, Flats and Bound Printed Matter for USPS workshare discounts; pickup to delivery, proprietary Mail Exchange, own fleet | Mailers; revenue depends on the USPS and on large mailers' volumes; no client above 10% of consolidated net sales | 636.6 | 165.3 | 457.0 | 91.0 | 150.9 | 31.9 | Gross margin 31.6% for nine months 2026 against 37.2%; transportation and fuel costs up 15 million; network of 34 operating centers and more than 350 drivers and vehicles is largely fixed; volume down 2% for nine months and up 4% in Q3 2026; pricing actions offset volume | 10-K pages 6-8, 30, 81, 84; Q3 10-Q pages 31-32; Q3 release page:2 |
| Group | Two reportable segments; corporate functions | About 6,600 employees, 75% in the United States; revenue FY2025 United States 1,595.0 and outside the United States 297.6 | 1,892.6 | Not printed as a group figure; total adjusted segment EBIT 577.5 less corporate expenses 116.2 | 1,385.1 | 442.3 less corporate expenses 81.9 | 456.2 | 146.9 less corporate expenses 33.0 | Revenue FY2025 by type: services 1,206.0, products 364.7, financing and other 321.9; nine-month 2026 revenue down 2% on the secular decline in mailing, partly offset by cost savings | 10-K pages 9, 64, 83-84; Q3 10-Q pages 2, 10 |

### Company profile

| Attribute | Value | Category | Locator |
| --- | --- | --- | --- |
| Legal name and form | Pitney Bowes Inc., Delaware corporation; Commission file number 1-3579 (1-03579 in the 10-Qs); IRS employer number 06-0495050 | Documentary Fact | 10-K page:1; Q3 10-Q page:1 |
| Sector and country (run context) | Office Machines, NEC; United States | Documentary Fact (context) | Context |
| Listing and filer status | Common stock and 6.7% Notes due 2043 on the New York Stock Exchange (PBI, PBI.PRB); large accelerated filer | Documentary Fact | 10-K page:1; Q3 10-Q page:1 |
| Headquarters | 27 Waterview Drive, Shelton, Connecticut; headquarters relocated to Shelton effective January 1, 2026 | Documentary Fact | Q3 10-Q page:1; 10-K page:30 |
| Business | Technology-driven company providing digital shipping solutions, mailing innovation and financial services, with clients described as including more than 90 percent of the Fortune 500 | Management Language | 10-K page:5 |
| Scale | About 6,600 employees; total revenue 1,892.6 in FY2025; total assets 2,992.3 and stockholders' deficit of (836.7) at 2026-09-30 | Documentary Fact | 10-K page:9; Q3 10-Q page:3 |
| Ownership | Public; 135,554,541 shares outstanding at October 20, 2026; no controlling holder, holder table or voting arrangement in the sources read; the proxy statement that carries Part III is not supplied | Documentary Fact (share count); Insufficient Information on holders | Q3 10-Q page:1; 10-K page:2 |
| Insider-affiliated holding | Shares of an investment fund affiliated with the Chief Executive Officer are disclosed; a trading plan adopted in November 2025 covers up to 6,000,000 shares through December 31, 2026; the total holding is not stated | Documentary Fact; holding Insufficient Information | 10-K page:53 |
| Banking subsidiary | The Pitney Bowes Bank, a Utah industrial bank regulated by the Utah Department of Financial Institutions and the FDIC; customer deposits of 647.9 at 2026-09-30 | Documentary Fact | 10-K page:9; Q3 10-Q page:3 |
| Executive officers | Chief Executive Officer since May 2025, Chief Financial Officer since July 2025, President of SendTech since September 2025, General Counsel since April 2024, President of Presort since January 2024 | Documentary Fact | 10-K pages 10-11 |
| Auditor and controls | PricewaterhouseCoopers LLP, auditor since 1934; opinion dated February 19, 2026; internal control over financial reporting reported effective | Documentary Fact | 10-K pages 62, 64 |
| Credit ratings | None stated in the sources; the context lists none | Insufficient Information | Searched all sources |
| Financial position at 2026-09-30 | Debt principal 1,918.4; cash and equivalents 268.5; revolver capacity 427.0 (financial base) | Documentary Fact, consistent with the financial base | Q3 10-Q pages 3, 19-20 |
| Distributions | Quarterly dividend $0.10 per share approved for payment December 8, 2026; repurchase authorization of 750 million with 165.9 remaining at 2026-09-30 | Documentary Fact; dividend text is Management Language | Q3 release page:1; Q3 10-Q pages 38-39 |
| Strategy | Continue cost-cutting, "opportunistically reduce debt and lower interest costs", return capital through repurchases and dividends | Management Language | Q3 10-Q page:34 |

### Transaction summary and new debt issues

No acquisition, sponsor buyout, dividend recapitalisation or change of control appears in the supplied sources, so transaction type is Insufficient Information as an ownership event; the relevant events are exit, financing, disposal and distribution transactions. The principal exit is the Ecommerce Restructuring. On August 8, 2024 the company sold 81% of the voting interests of the subsidiary that held most of the Global Ecommerce segment to an affiliate of Hilco, "with a subsidiary of Pitney Bowes retaining 19% of the voting interests and 100% of the economic interests" (10-K page:85, status: completed). The ecommerce debtors then filed Chapter 11 and a liquidation plan became effective on December 9, 2024. The company provided a senior secured debtor-in-possession loan, initially funded at 28 million with 20 million repaid, and the remaining balance is fully reserved; it states that it remains exposed to continuing costs and claims (10-K pages 17 and 85). A vendor dispute arising from the ecommerce business led to a suit filed in November 2024 against the company and a Presort subsidiary seeking more than 100 million, still pending in September 2026 (Q3 10-Q page:24). The financing history is as follows. In February 2025 the company entered a senior secured credit agreement providing a revolving credit facility of 265 million, later increased to 400 million, maturing March 2028, a 160 million term loan maturing March 2028 and a 615 million term loan maturing March 2032, with proceeds used to repay the earlier term loans (10-K page:42, status: completed). In August 2025 it issued 230 million of 1.50% convertible senior notes due August 2030, with a net 221 million of proceeds, a capped call costing 24.7 million and 61.9 million of the proceeds used to repurchase 5.5 million shares (10-K pages 43 and 100). A tender in December 2025 retired 80 million of the 2037 and 2043 notes at a gain of 10 million (10-K page:44). During 2026 the company issued a further 150 million of 7.25% notes due March 2029 on identical terms under a supplemental indenture dated March 2, 2026, increased the revolver from 400 million to 450 million, borrowed an additional 150 million of term loan and extended its maturity, used those proceeds to repay the 6.875% notes due March 2027, and amended the credit agreement in May (Third Amendment), June (Fourth Amendment) and September (Fifth Amendment dated September 29, 2026) (Q3 10-Q pages 20 and 39; Q2 10-Q pages 20 and 40; status: executed and in effect, terms not supplied). In the third quarter it completed a tender of 46 million of the 2037 and 2043 notes at a discount to par and repriced the March 2032 term loan, reducing the margin by 75 basis points (Q3 10-Q page:20; Q3 release page:1). The effect on leverage of the March 2026 notes and the term loan was neutral to modestly negative at first, because 300 million of new debt replaced 346.7 million of notes, and the net reduction came from cash; the effect on maturities is that the first final maturity moved from March 2027 to March 2029 (financial base). In 2026 the additional term loan repaid the 2027 notes; the sources read do not state the use of the additional 2029 notes' proceeds, and in the same quarter share repurchases of 135.6 were paid (Q1 10-Q page:4), a timing coincidence that is not stated as a use. In 2025 part of the convertible proceeds funded share repurchase. The liquidity effect is that the undrawn revolver capacity stood at 427.0 at 2026-09-30 with nothing drawn, after 176.7 was borrowed and repaid during 2026. After the balance-sheet date, pension lump sums of 66 million were paid from plan assets in October 2026 and an intended buy-out of the remaining U.S. plan is planned before year end (Q3 10-Q page:23, subsequent event), and 649,378 shares were repurchased for 11 million from October 1 to 23, 2026 (Q3 10-Q page:39, subsequent event). The credit agreement, its amendments, the indentures and the guarantor list are not supplied, so every financing term above is the company's own description.

### Fact register

| Ref | Area | Category | Fact | Evidence quality | Locator |
| --- | --- | --- | --- | --- | --- |
| F1 | Company | Management Language | "technology-driven company that provides digital shipping solutions, mailing innovation, and financial services to clients around the world" | High (attributed) | 10-K page:5 |
| F2 | Company | Documentary Fact | "Our reportable segments are SendTech Solutions and Presort Services." | High | Q3 10-Q page:9 |
| F3 | Company | Documentary Fact | "Presort Services conducts mail sortation operations through a network of 34 operating centers throughout the United States." | High | 10-K page:30 |
| F4 | Company | Documentary Fact | "The Bank is chartered as an Industrial Bank under the laws of the State of Utah." | High | 10-K page:9 |
| F5 | Company | Documentary Fact | FY2025 revenue 1,892.6: services 1,206.0, products 364.7, financing and other 321.9; United States 1,595.0 and outside the United States 297.6 | High | 10-K pages 64 and 83 |
| F6 | Operating model | Documentary Fact | "No single client comprised more than 10% of our consolidated net sales in 2025 or 2024." | High | 10-K page:51 |
| F7 | Operating model | Documentary Fact | "A significant portion of our revenue depends upon the ability of these posts, especially the USPS, to provide reliable, competitive mail and package delivery services to our clients." | High | 10-K page:12 |
| F8 | Operating model | Documentary Fact | "Continuing declines in traditional mail volumes impact our financial results." | High | 10-K page:13 |
| F9 | Operating model | Documentary Fact | "Contract terms for these services initially range from one to five years and contain annual renewal options." | High | Q3 10-Q page:7 |
| F10 | Operating model | Documentary Fact | Future performance obligations in SendTech total 624.4: remainder of 2026 82.7, 2027 222.3, 2028 to 2031 319.4 | High | Q3 10-Q page:8 |
| F11 | Operating model | Documentary Fact | "primarily due to a declining meter population" explains lower SendTech services revenue in Q3 2026; financing revenue fell "primarily due to a decline in our leasing portfolio" | High | Q3 10-Q page:30 |
| F12 | Operating model | Documentary Fact | Products revenue declined as "customers opting to extend leases of their existing advanced-technology equipment rather than purchase new equipment" | High | Q3 10-Q page:31 |
| F13 | Operating model | Documentary Fact | SendTech gross margin 68.1% for nine months 2026 against 66.2%, driven by a 5 million tariff refund, a 2025 revenue adjustment and mix; Presort gross margin 31.6% against 37.2% | High | Q3 10-Q pages 31-32 |
| F14 | Operating model | Documentary Fact | Presort nine-month revenue fell with "a 2% decline in total mail volumes" and gross margin fell on "increased transportation and fuel costs of $15 million" | High | Q3 10-Q page:32 |
| F15 | Operating model | Management Language | Q3 2026 Presort revenue "returning to year-over-year growth, driven by increased volume from new client wins", with volume 3.4 billion pieces, up 4% | High (attributed) | Q3 release page:2 |
| F16 | Operating model | Management Language | Year-to-date adjusted free cash flow "reflects the benefit of increased prepayments due to new customers, resulting from the exit of a significant mail sortation competitor" | High (attributed) | Q3 release page:2 |
| F17 | Operating model | Documentary Fact | Gross finance receivables of 1,256.5 at 2026-09-30, of which 956.7 low risk and 12.8 more than 90 days past due; net finance receivables 995.1 against 1,101.6 at 2025-12-31 | High | Q3 10-Q pages 11 and 14 |
| F18 | Operating model | Documentary Fact | Capital expenditures of 66.3 in FY2025 (SendTech 42.6, Presort 14.0, corporate 9.7) and 45.0 for nine months 2026 | High | 10-K page:84; Q3 10-Q page:4 |
| F19 | Operating model | Documentary Fact | Cost actions: the 2024 Plan eliminated about 3,200 positions at charges of 89; the 2025 Plan "was completed at the end of the second quarter of 2026", eliminating about 550 positions at cumulative charges of 45 | High | 10-K page:97; Q3 10-Q page:19 |
| F20 | Operating model | Management Language | Outlook: "low to mid-single digit decline in revenue driven by the continued secular decline in mailing" | High (attributed) | Q3 10-Q page:34 |
| F21 | Ownership | Documentary Fact | 135,554,541 shares outstanding at October 20, 2026, against 149,942,698 at January 31, 2026; no holder table, controlling holder or voting agreement is stated in the sources read | High | Q3 10-Q page:1; 10-K page:2 |
| F22 | Ownership | Documentary Fact | A trading arrangement adopted November 10, 2025 for up to 6,000,000 shares to December 31, 2026; "Shares are held directly by Hestia Capital Partners, LP" and an affiliated fund; the Chief Executive Officer is the managing member of the general partner and investment manager | High | 10-K page:53 |
| F23 | Governance | Documentary Fact | "We have undergone recent changes in our senior management and in the composition of our Board of Directors." | High | 10-K page:17 |
| F24 | Governance | Documentary Fact | "We have been and may continue to be subject to shareholder activism in the future." | High | 10-K page:23 |
| F25 | Transaction | Documentary Fact | Ecommerce Restructuring: 81% of voting interests sold, with a Pitney Bowes subsidiary retaining 19% of the voting interests and 100% of the economic interests; deconsolidated; economic interest carried at a fair value of zero | High | 10-K page:85 |
| F26 | Transaction | Documentary Fact | "The remaining unpaid balance on the DIP Facility is fully reserved" | High | 10-K page:85 |
| F27 | Transaction | Documentary Fact | A suit by the parent of a former ecommerce vendor seeks "more than $100 million in lease payments, interest, fees and additional, related damages"; pending in the Northern District of Illinois | High | Q3 10-Q page:24 |
| F28 | Debt | Documentary Fact | New credit agreement in 2025 providing a revolver of 265 million (later 400 million) and term loans of 160 million and 615 million | High | 10-K page:42 |
| F29 | Debt | Documentary Fact | "We also used $61.9 million of the proceeds to repurchase 5.5 million of our common stock." (convertible notes proceeds) | High | 10-K page:43 |
| F30 | Debt | Documentary Fact | Tender completed in December 2025 for 80 million of the 2037 and 2043 notes at a gain of 10 million; a further 46 million tendered in Q3 2026 at a discount | High | 10-K page:44; Q3 10-Q page:20 |
| F31 | Debt | Documentary Fact | 2026: an additional 150 million of 7.25% notes due March 2029; an additional 150 million of term loan used to repay the notes due March 2027; revolver increased from 400 million to 450 million; margin on the March 2032 term loan reduced by 0.75% | High | Q3 10-Q page:20 |
| F32 | Debt | Documentary Fact | Amendments to the credit agreement dated May 18, 2026 (Third), June 23, 2026 (Fourth) and September 29, 2026 (Fifth) are listed as exhibits; none is supplied | High | Q2 10-Q page:40; Q3 10-Q page:39 |
| F33 | Capital allocation | Documentary Fact | "During 2025, we purchased 35,853,442 shares at an aggregate cost of $378 million." | High | 10-K page:31 |
| F34 | Capital allocation | Documentary Fact | Nine months 2026: common stock repurchases of 205.7 and dividends of 40.6; 1,025,819 shares bought in Q3 at an average of $16.84 | High | Q3 10-Q pages 4 and 39 |
| F35 | Capital allocation | Management Language | Quarterly dividend increased from $0.09 to $0.10, "Marking the Fifth Increase in the Past Six Quarters" | High (attributed) | Q1 release page:1 |
| F36 | Capital allocation | Documentary Fact | Pension de-risking: buy-in contracts for part of the U.S. plan and all of the Canada plan in 2025; lump sums of 66 million paid in October 2026 with a buy-out intended before year end | High | 10-K pages 104-105; Q3 10-Q page:23 |
| F37 | Disclosure | Documentary Fact | Internal control over financial reporting reported effective; out-of-period corrections of 4 million (Q1 2025) and 5 million (Q4 2025) judged not material; the 10-K cover marks a correction of an error | High | 10-K pages 2, 62, 69 |
| F38 | Disclosure | Documentary Fact | Later filings cite "Form 10-K/A for the year ended December 31, 2025"; no 10-K/A is in the pack | High | Q3 10-Q page:5 |
| F39 | Legal capacity | Insufficient Information | Debt baskets, restricted payments, priming, drop-down and collateral release capacity cannot be assessed because the credit agreement and indentures are not supplied | n/a | Absent |
| F40 | Ownership | Insufficient Information | Control rights, voting arrangements, holder percentages and any stockholder agreements are not disclosed in the sources read | n/a | Absent |

### Timeline

| Date | Event | Type | Locator |
| --- | --- | --- | --- |
| August 8, 2024 | Sale of 81% of the voting interests of the main ecommerce subsidiary; Chapter 11 filing follows | Disposal | 10-K page:85 |
| November 2024 | Suit seeking more than 100 million filed by the parent of a former ecommerce vendor | Litigation | Q3 10-Q page:24 |
| December 9, 2024 | Liquidation plan for the ecommerce debtors becomes effective | Restructuring | 10-K page:85 |
| February 2025 | New senior secured credit agreement; earlier term loans repaid | Refinancing | 10-K page:42 |
| May 2025 | Chief Executive Officer appointed | Management change | 10-K page:11 |
| July 2025 | Chief Financial Officer appointed | Management change | 10-K page:11 |
| August 2025 | 230 million 1.50% convertible notes issued; share repurchase of 61.9 million | Financing | 10-K page:43 |
| September 2025 | President of SendTech Solutions appointed | Management change | 10-K page:11 |
| December 2025 | Tender for 80 million of 2037 and 2043 notes; U.S. pension buy-in | Debt reduction; de-risking | 10-K pages 44, 104 |
| December 31, 2025 | Stamford corporate office closed; headquarters in Shelton from January 1, 2026 | Restructuring | 10-K pages 30, 97 |
| February 16, 2026 | Board increases the repurchase authorization | Capital allocation | 10-K page:31 |
| February 17, 2026 | Employment letter with the Chief Executive Officer, three-year term | Governance | 10-K page:53 |
| March 2, 2026 | Supplemental indenture for an additional 150 million of 7.25% notes due 2029 | Financing | Q3 10-Q page:39 |
| Q2 2026 | Term loan upsized by 150 million and extended; 6.875% notes due 2027 repaid; Third and Fourth Amendments | Refinancing | Q3 10-Q page:20; Q2 10-Q page:40 |
| Second quarter 2026 | 2025 Plan completed | Restructuring | Q3 10-Q page:19 |
| Q3 2026 | Tender of 46 million of 2037 and 2043 notes; 2032 term loan repriced; pension lump-sum campaign | Debt reduction; de-risking | Q3 10-Q pages 20, 23 |
| September 29, 2026 | Fifth Amendment to the credit agreement | Amendment | Q3 10-Q page:39 |
| October 2026 | Pension lump sums of 66 million paid; 649,378 shares repurchased to October 23 | Subsequent events | Q3 10-Q pages 23, 39 |
| October 28 and 29, 2026 | Q3 release and 10-Q | Reporting | Q3 release page:1; Q3 10-Q page:40 |
| December 8, 2026 | Dividend of $0.10 per share payable (a contract term, not an event to date) | Scheduled | Q3 release page:1 |

### Governance and issuer behaviour

No sponsor exists, so sponsor behaviour is Insufficient Information and is not inferred from ownership. Issuer-level behaviour is assessed from documented actions only, kept separate from legal capacity and feasibility, and no individual is assessed.

| Behaviour | Category | Evidence | Mechanic | Dimension informed |
| --- | --- | --- | --- | --- |
| Debt principal reduced from 2,026.2 to 1,918.4 in nine months; 6.875% notes due 2027 repaid; notes tendered at a discount; revolver borrowings repaid | Supportive (Analyst Interpretation of F30, F31) | F30, F31 | Cash and refinancing proceeds retire the nearest maturities and cut interest; the first final maturity moves to 2029 | Deleveraging |
| Buybacks of 378.4 and dividends of 51.1 in FY2025 against operating cash flow of 383.3, with 61.9 of convertible proceeds applied to repurchase; 205.7 and 40.6 in nine months 2026 | Neutral or Mixed (Analyst Interpretation of F29, F33, F34) | F29, F33, F34 | Distributions exceeded free cash flow in 2025 and drew on cash and new debt; in 2026 they were covered by cash flow but exceed debt reduction | Capital allocation and creditor support |
| Reorganization of the ecommerce business through a sale to a third party, a debtor-in-possession loan and a retained economic interest, leaving claims against the company | Neutral or Mixed (Analyst Interpretation of F25 to F27) | F25, F26, F27 | Separated a loss-making business from the group but left funded exposure, a reserved loan and unresolved litigation | Legacy liabilities |
| Pension de-risking by buy-in, lump sums and a planned buy-out | Neutral or Mixed (Analyst Interpretation of F36) | F36 | Reduces asset-liability volatility but raises reported pension cost through lower expected return; settlement cost and funding are not quantified for 2026 | Pension and legacy |
| Leadership and board turnover in 2025 and disclosed activism | Neutral or Mixed (Analyst Interpretation of F23, F24) | F23, F24 | Strategy and capital-allocation preferences may shift with ownership and board composition | Governance stability |
| Reporting: effective controls opinion, small out-of-period corrections and an annual-report amendment not in the pack | Neutral or Mixed (Analyst Interpretation of F37, F38) | F37, F38 | Disclosure quality is a monitoring item; the content of the amendment is unknown | Disclosure and control |
| Legal capacity to add debt, make distributions or release collateral | Insufficient Information | F39 | Cannot be assessed without the debt documents | Legal capacity |

### Credit translations

- **Revenue durability.** Evidence: a declining meter population and lower leasing revenue (F11), clients extending leases (F12), a management outlook of continued secular decline (F20) and revenue down 2% for nine months. Mechanic: SendTech revenue is a recurring service, maintenance and lease base that shrinks as installed meters fall, and the financing revenue follows the leasing portfolio down; there is bundled visibility of 624.4 (F10) but contract terms are one to five years (F9). Implication: revenue declines slowly and predictably, so debt service depends on cost reduction and run-off cash rather than growth. Counter-evidence: Q3 2026 Presort volume growth and new client wins (F15) are management claims for one quarter, and none of the logged conflicts changes this reading.
- **Presort margin and cost exposure.** Evidence: Presort adjusted segment EBIT of 91.0 against 123.3 for nine months, gross margin down to 31.6%, transportation and fuel costs up 15 million (F13, F14). Mechanic: a network of 34 operating centers and a fleet of more than 350 vehicles is largely fixed, so volume loss and fuel inflation fall straight through to margin, and management expects the pressure to continue in the fourth quarter. Implication: the second earnings pillar is weakening, concentrating segment earnings in SendTech, whose 351.2 (299.3 a year earlier) is 79% of the 442.3 segment total.
- **USPS dependence without client concentration.** Evidence: no client above 10% of sales (F6) but a significant portion of revenue depends on the USPS (F7) and on carrier contracts. Mechanic: postal rates, workshare discounts and the USPS's financial health act as a common factor across both segments. Implication: concentration is in one counterparty's policy and finances rather than in clients; the sources give no contract terms.
- **Finance book run-off as a cash source.** Evidence: net finance receivables of 995.1 against 1,101.6, with a 87.5 contribution to nine-month operating cash flow (F17; financial base). Mechanic: lease and loan collections fund debt service and distributions while the portfolio shrinks, and the Bank's deposits of 647.9 are a regulated funding line. Implication: cash flow quality is lower than operating cash flow indicates, and a smaller finance book also lowers financing revenue. The sources do not say whether any group cash sits in the Bank.
- **Distributions versus debt reduction.** Evidence: buybacks and dividends of 246.3 against debt principal reduction of 107.8 for nine months, and 429.4 in FY2025 (F33, F34, F35). Mechanic: the repurchase authorization had 165.9 remaining at 2026-09-30 and the first final maturity is 476.0 of notes due March 2029 with a springing provision. Implication: the pace of distributions determines the liquidity available to meet that provision; legal limits on distributions cannot be assessed (F39).
- **Legacy claims.** Evidence: the retained economic interest and reserved loan in the ecommerce debtors (F25, F26) and a claim seeking more than 100 million (F27). Mechanic: no accrual is printed and the outcome depends on litigation; management states that the outcome will not have a material adverse effect. Implication: a contingent claim outside the debt figure; it is a monitoring item rather than a quantified loss.

### Conflicts logged

Four conflicts are logged and none is reconciled. Each counters a credit translation only at the level of precision noted.

- **Term loan and revolver maturity.** The Q2 10-Q says the term loan was extended "to March 2031" and the revolver extended to March 2031 (Q2 10-Q page:20); the Q3 10-Q describes the same Q2 extension as "to May 2031" and the revolver as maturing in May 2031 (Q3 10-Q page:20). It affects the maturity profile by two months for the 294.5 term loan and for the revolver, not the 2029 first maturity.
- **Repurchase authorization.** The 10-K says "the Board of Directors authorized a new $500 million share repurchase program" and then an increase "of $250 million" (10-K page:31); the Q3 10-Q says the Board "authorized an increase in our $250 million share repurchase program to $750 million" (Q3 10-Q page:38). Both give a total of 750 million but describe the starting program as 500 million and as 250 million; it counters any statement of how much authorization was added in February 2026.
- **Margin on the 2028 term loan.** The 10-K prints "Term loan due March 2028 SOFR + 2.10% 154,000" (10-K page:98) and the Q1 10-Q prints "Term loan due March 2028 SOFR + 1.85% 152,000" (Q1 10-Q page:18). It affects the cost of the term loan by 0.25% on 150 to 300 of principal.
- **Tender gain.** The Q3 10-Q text says the tender "recorded a gain of $5 million in other (income) expense" while the table prints a quarterly gain of (3,155) thousand (Q3 10-Q pages 20 and 26). It affects the description of third-quarter debt activity by about 2 million.

### Monitoring gaps

| Missing item | Severity | Why it matters |
| --- | --- | --- |
| Credit agreement and all amendments, covenant certificates, liquidity and EBITDA definitions | High | Covenant headroom, the springing maturity tests and legal capacity for debt, distributions and collateral cannot be assessed |
| Indentures, guarantor list and security documents | Medium | Ranking of the 2029, 2037 and 2043 notes and the secured status of the term loans cannot be verified |
| Proxy statement or holder register | Medium | Ownership, control rights, board composition and any stockholder agreements are unknown |
| Form 10-K/A for FY2025 | Medium | The content and any restatement effect of the amendment are unknown |
| Stand-alone Bank and financing-business statements, and the location of group cash | Medium | Regulated deposit funding and cash availability to service holding-company debt cannot be assessed |
| Pleadings and accrual for the vendor litigation | Medium | The size and timing of the claim, beyond the sum sought, are not measurable |
| Mail-volume, price and client-retention data for Presort and meter population for SendTech | Medium | Revenue visibility cannot be quantified beyond management commentary |
| Pension funded status and settlement cost at 2026-09-30 | Low | The cost and cash effect of the lump sums and buy-out are not quantified |

### Consumers

| Module | Readiness | What it should take from this handoff | Why it matters | Gap | Action |
| --- | --- | --- | --- | --- | --- |
| CP-2 fundamental credit synthesis | READY_WITH_LIMITATIONS | Business-risk rows F5 to F20, ownership rows F21 and F22, governance rows F23 to F24 and F33 to F38, the timeline, the credit translations and the logged conflicts | Revenue durability, Presort margin, finance book run-off and distributions drive the business-risk view | Legal capacity (F39) and ownership (F40) are Insufficient Information; four conflicts logged | Carry the gaps as Insufficient Information, not as adverse findings, and keep the conflicts visible |
| CP-5 evidence trace | READY_WITH_LIMITATIONS | Every row's locator and category; the subsequent events (October 2026 pension lump sums and repurchases); attributed management claims (F1, F15, F16, F20, F35) | Trace needs page-level locators, dated events and the attribution of management language | Source text is a text extraction without chart review; legal documents and the 10-K/A are absent | Open each locator, confirm quotes and figures, and flag management claims as attributed |

## Calculations

No new analytical calculation is made beyond the checks below, which test that printed figures tie or compute a share from printed inputs. Amounts are thousands as printed unless a row says millions.

- Revenue by segment, FY2025: 1,256,001 + 636,628 = 1,892,629, equal to total revenue (10-K page:81). By type: 1,206,031 + 364,709 + 321,889 = 1,892,629 (10-K page:64). By geography: 1,594,983 + 297,646 = 1,892,629 (10-K page:83). United States share: 1,594,983 over 1,892,629 is 84.3%.
- Revenue by segment, nine months 2026: 928,132 + 456,961 = 1,385,093; Q3 2026: 305,255 + 150,927 = 456,182 (Q3 10-Q page:9).
- Nine-month revenue change: 1,385,093 less 1,415,004 is a decrease of 29,911, or 2.1%; the filing prints (2%) (Q3 10-Q page:28). Presort: 456,961 against 476,900, a decrease of 19,939, or 4.2%; the filing prints (4%) in the release (Q3 release page:7).
- Segment adjusted EBIT margin on segment revenue, nine months 2026 against 2025: SendTech 351,243 over 928,132 is 37.8% against 299,341 over 938,104 at 31.9%; Presort 91,045 over 456,961 is 19.9% against 123,345 over 476,900 at 25.9% (Q3 10-Q page:9). SendTech share of total adjusted segment EBIT: 351,243 over 442,288 is 79.4%.
- Presort adjusted segment EBIT change: 91,045 less 123,345 is a decrease of 32,300; SendTech: 351,243 less 299,341 is an increase of 51,902.
- Allocated finance interest, nine months 2026: 9,583 + 9,028 + 8,466 = 27,077 (Q1 10-Q page:29; Q2 10-Q page:33; Q3 10-Q page:33).
- Finance receivables: 1,101,575 less 995,101 is a decrease of 106,474, or 9.7% (Q3 10-Q page:11).
- Shares outstanding: 150,703,556 at December 31, 2025 (10-K page:117) and 135,554,541 at October 20, 2026 (Q3 10-Q page:1), a decrease of 15,149,015 over different dates; during 2025 shares outstanding fell from 182,405,867 to 150,703,556, a decrease of 31,702,311.
- Distributions: FY2025 378,361 + 51,059 = 429,420 against operating cash flow of 383,257 (10-K page:67); nine months 2026 205,725 + 40,599 = 246,324 against debt principal reduction of 107,778 (financial base).
- Convertible dilution: 230,000 of principal at 70.4648 shares per 1,000 is 16.2 million shares, equal to the 16,207 thousand shares covered by the capped call (Q3 10-Q pages 21-22).
- Tender, Q3 2026: (31,143 - 25,441) + (349,279 - 308,514) = 46,467 using Q2 10-Q page:19 and Q3 10-Q page:19; the filing says 46 million.

## Gaps

| # | Gap | Severity | Effect | Remediation |
| --- | --- | --- | --- | --- |
| 1 | No credit agreement, amendments, indentures, guarantor list or security documents; legal capacity (debt, distributions, priming, collateral release) cannot be assessed | High | Willingness and feasibility are assessed from actions only; capacity is Insufficient Information | Obtain the documents; until then do not infer permissions |
| 2 | Ownership: no holder table, control rights or voting arrangements; Part III is incorporated from an unsupplied proxy statement; the insider-affiliated fund's total holding is not stated | Medium | Sponsor-style alignment and control are not assessable | Obtain the proxy statement |
| 3 | Form 10-K/A cited by later filings is not in the pack | Medium | Any amended FY2025 content is unknown | Obtain the 10-K/A |
| 4 | Stand-alone statements for the Pitney Bowes Bank and the financing business, and where group cash is held, are not supplied | Medium | Cash availability and the regulated deposit funding cannot be separated from consolidated figures | Obtain or request the data |
| 5 | The vendor litigation: no accrual amount or pleadings; management states no material adverse effect is expected | Medium | Contingent claim cannot be measured beyond the sum sought | Monitor; treat as unquantified |
| 6 | Revenue visibility data (client retention, mail volumes by class, meter population, contract renewal terms) and USPS contract terms are not supplied | Medium | Durability rests on management commentary | None available in the pack |
| 7 | Management-attributed items (outlook, new client wins, prepayments from a competitor's exit, dividend increases, the strategy) are claims | Low | Cannot be treated as filed fact; the prepayment benefit may reverse | Keep labelled Management Language |
| 8 | Conflicts on maturity labels, margin, repurchase authorization wording and the tender gain are logged, not reconciled | Low | Precision of the maturity profile and the described capital-allocation history | Quote both; the financial base states the basis used |
| 9 | Pension funded status at 2026-09-30 and the settlement cost of the lump sums and buy-out are not printed | Low | The cost of pension de-risking is not quantified | Request the data |
| 10 | Ratings, quotes, valuation inputs and peer data are not supplied; no peer ranking or recommendation is made | Low | Market context absent | Outside the selected module set |

## Next module

Run the fundamental credit synthesis (CP-2) next, using the fact register F1 to F40, the timeline, the governance table and the credit translations as its business-risk basis, and the financial base for leverage, liquidity and coverage. It must carry forward as Insufficient Information the legal-capacity and ownership gaps, keep the 2029 notes with their springing provision as the first final maturity and the main refinancing risk, treat covenant headroom as Not calculable, present the Adjusted EBITDA on both pension bases as the financial base does, and keep management language attributed. The evidence trace (CP-5) follows and should open the page locators cited in the fact register and confirm each quoted span.
