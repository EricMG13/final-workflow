# CP-0 — Source readiness: LendingTree, Inc. (tree)

## Request

- Issuer: LendingTree, Inc. (issuer id `tree`; Nasdaq: TREE), as of 2026-11-05, information cutoff 2026-11-05 (context).
- Run: `tree-2026-11-05-credit_snapshot-host`, pathway `credit_snapshot`. Requested modules after this one: CP-1, CP-1A, CP-2 and CP-5 (the launcher's `minimum` set). CP-0 runs first as their dependency.
- Context settings: reporting currency USD; current period q2-2026; prior period fy-2025. The filings state amounts in thousands of US dollars (statements) and in millions (narrative and releases), which matches the context.
- Execution: host session. The host read the pinned files and wrote this answer. No provider was called.
- Question: can the supplied filings and releases support CP-1, CP-1A, CP-2 and CP-5, and what remains blocked?
- Assertion: SOURCE_SUFFICIENCY_ONLY; CP_MODEL_INPUT_CONTRACT_NOT_EVALUATED. No credit conclusion, legal interpretation or investment opinion. No figure is normalized, reconciled or calculated here.

## Sources

| Source | sha256 | Role |
| --- | --- | --- |
| 10-K_2025-12-31_tree-20251231.htm.jsonl | 8cb6cb5e097dc2e8360d276758588e587f0ac910e30b439c9a6d5f22fdc532f1 | Form 10-K for the fiscal year ended December 31, 2025 (163 pages of source text) |
| 10-Q_2025-09-30_tree-20250930.htm.jsonl | 249304d8f29fc14b902a9aacbb2c6a074e549655cafbbfa182447cab0a8e6bd0 | Form 10-Q for the quarter ended September 30, 2025 (56 pages) |
| 10-Q_2026-03-31_tree-20260331.htm.jsonl | 9f7be701e3beaeb193c8f4c45fa295df34640347810fab7e7e1868937c8317f9 | Form 10-Q for the quarter ended March 31, 2026 (38 pages) |
| 10-Q_2026-06-30_tree-20260630.htm.jsonl | 4c93c158274dd2856277ea5350526f695a8bcd4a41e0bedcd9b748ac31b890ae | Form 10-Q for the quarter ended June 30, 2026 (45 pages) |
| EX-99.1_2026-03-02_tree-123125xer.htm.jsonl | 930047033d516e80ede0b1af19850b29c93444522e483a1dc8c6992d4283ee5d | Exhibit 99.1 earnings release for fourth quarter 2025, dated March 2, 2026 (14 pages) |
| EX-99.1_2026-04-30_tree-33126xer.htm.jsonl | 9b95e0c334507932b6d82bc72cf01d0a8f620ab6313637adea07e7f7ef2b4190 | Exhibit 99.1 earnings release for first quarter 2026, dated April 30, 2026 (10 pages) |
| EX-99.1_2026-07-29_tree-63026xer.htm.jsonl | b737e26fe71071d22f2d669bce2532cab38eb1e5741e87f2852ff6a85cf82520 | Exhibit 99.1 earnings release for second quarter 2026, dated July 29, 2026 (10 pages) |
| context | d200051bbc093266762c46db0da57fcc23aae21f45bdfa41362781dff2cb6e7d | User run settings; not issuer evidence |

Supplied handoffs: none (CP-0 is the first module). Locators are `page:N`, the source chunk number in each pinned file, not the printed page. The first line of each source file names a sha256 of the original HTML. That is a different hash from the pinned file hash listed above; this answer uses the pinned file hash.

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| The supplied annual report, three quarterly reports and three earnings releases can support the planned financial, business, synthesis and claim-tracing work, with limitations. Audited FY2025 and unaudited June 30, 2026 statements are present. The credit agreement is not. | Medium | The credit agreement and covenant definitions are not supplied, and the latest document is dated July 30, 2026, before the November 5, 2026 cutoff. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Audited FY2025 and unaudited June 30, 2026 statements, segment tables and issuer non-GAAP reconciliations are all located in the filings and releases. | Supports a reported financial foundation; non-GAAP measures stay labelled as issuer-defined and are not treated as audited. | High |
| One debt facility is described: the 2025 Credit Facility, with a $75.0 million revolver and a $400.0 million term loan maturing August 21, 2030. | Debt work is bounded to one first lien facility, described only through note summaries, not the executed agreement. | Medium |
| The only financial covenant is a first lien net leverage ratio of 5.00 to 1.00, tested only if revolver usage exceeds $20.0 million. No ratio is reported. | Covenant headroom cannot be computed or verified from the supplied text. | Medium |
| Nothing dated after July 30, 2026 is supplied, although the cutoff is November 5, 2026. | Later events, including any third quarter 2026 results, are Not supplied, not absent. | High |

### Readiness view

The supplied set is sufficient for source-based work on all four downstream modules, with bounded limitations, so each is READY_WITH_LIMITATIONS and none is conditional or blocked. The 10-K and the three 10-Qs are filed reports and control their statement facts; the three releases are management-prepared and carry attributed supporting claims, non-GAAP measures and outlook. The main restrictions are the absent 2025 Credit Agreement (so covenant definitions, guarantor list and letter of credit usage are unverified), the absence of any document after July 30, 2026, and text-only extraction with no original HTML or XBRL view. These are source limitations; they do not say that downstream analysis has been done.

### Readiness verdict

| Consumer | Status | Basis |
| --- | --- | --- |
| CP-1 | READY_WITH_LIMITATIONS | Audited FY2025, FY2024 and FY2023 statements (10-K page:110, page:111) and unaudited June 30, 2026 statements with comparatives (10-Q page:2 to page:4) are located, with Note 10 debt (10-Q page:18, page:19) and non-GAAP reconciliations (10-Q page:36, page:38). Text extraction only; tables are flattened. |
| CP-1A | READY_WITH_LIMITATIONS | Business, three segments, products and customer concentration are located (10-K page:11, page:12; 10-Q page:23, page:24, page:33). Executed agreements, the 2026 proxy statement and a subsidiary list are not supplied. |
| CP-2 | READY_WITH_LIMITATIONS | Debt note, covenant summary, collateral and guarantee description and liquidity text are located (10-K page:144 to page:146; 10-Q page:19, page:39, page:40). The credit agreement, ratio computation and letter of credit usage are not supplied. |
| CP-5 | READY_WITH_LIMITATIONS | Every source has stable page chunks, so claims can be traced. Visual and table-layout checks against the filed HTML are not possible. |

Command sheet: CP-1 RUN; CP-1A RUN; CP-2 RUN; CP-5 RUN.

### Source register

#### Form 10-K for FY2025 (`10-K_2025-12-31_tree-20251231.htm.jsonl`)

- Family and authority: filed annual report, original authority for the audited statements. `page:1`: "For the Fiscal Year Ended December 31, 2025", "Commission File No. 001-34063", "LendingTree, Inc.". Accelerated filer (page:1).
- Audit: `page:109`: "/s/ PricewaterhouseCoopers LLP Charlotte, North Carolina March 9, 2026" and "We have served as the Company’s auditor since 2012." Internal control over financial reporting was concluded effective and attested by the auditor (page:155).
- Statements: balance sheet and statement of operations on `page:110` (Revenue "$ 1,117,324 $ 900,219 $ 672,502" for 2025, 2024, 2023); cash flows `page:111` and `page:112` (supplemental "Interest paid $ 37,203"; "Income tax payments 1,772"). Adjusted EBITDA reconciliation `page:96` ("Adjusted EBITDA $ 132,887 $ 104,113"), issuer non-GAAP and unaudited.
- Debt: Note 13 starts `page:142`; 2025 Credit Facility terms `page:144` to `page:146`; liquidity discussion `page:97` and `page:98`; risk-factor summary of covenants, collateral and guarantees `page:38` and `page:39`.
- Units and currency: "(in thousands, except par value and share amounts)" on page:109; USD.
- Perimeter: consolidated LendingTree, Inc. and subsidiaries. `page:113`: "LendingTree, Inc. is the parent of LT Intermediate Company, LLC, which holds all of the outstanding ownership interests of LendingTree, LLC".

#### Form 10-Q for Q3 2025 (`10-Q_2025-09-30_tree-20250930.htm.jsonl`)

- Filed quarterly report, `page:1` "For the Quarterly Period Ended September 30, 2025". Unaudited. Gives the three-month and nine-month figures for Q3 2025 (page:2, "Revenue $ 307,792 $ 260,789 $ 797,636 $ 638,697") and the debt position after the August 21, 2025 refinancing (page:23: "$400.0 million borrowings outstanding under the 2025 Term Loan"). Covenant compliance at that date `page:25`. Signed October 31, 2025 (page:56).

#### Form 10-Q for Q1 2026 (`10-Q_2026-03-31_tree-20260331.htm.jsonl`)

- Filed quarterly report, `page:1` "For the Quarterly Period Ended March 31, 2026". Unaudited. Statements `page:2` to `page:4`; debt Note 10 `page:17` and `page:18` ("The Company was in compliance with all covenants at March 31, 2026"); Adjusted EBITDA `page:33`. Signed May 1, 2026 (page:38).

#### Form 10-Q for Q2 2026 (`10-Q_2026-06-30_tree-20260630.htm.jsonl`)

- Filed quarterly report, `page:1` "For the Quarterly Period Ended June 30, 2026". Current-period authority. Unaudited. Balance sheet "June 30, 2026 December 31, 2025" and start of operations `page:2`; operations and equity `page:3`; cash flows `page:4`; Note 10 Debt `page:18` and `page:19`; Note 11 contingencies `page:20`; Note 13 segments `page:21`; MD&A results `page:26`; variable marketing margin `page:35` and `page:36`; Adjusted EBITDA `page:37` and `page:38`; liquidity `page:39`; market risk `page:40`. Signed July 30, 2026 (page:45).
- Units: "(in thousands, except par value and share amounts)" (page:2). Basis note `page:6`: "Certain prior period amounts have been reclassified to conform to the current period presentation".

#### Earnings releases (three Exhibit 99.1 files)

- Fourth quarter 2025 release, dated March 2, 2026: headline "Consolidated revenue of $319.7 million" (page:1); Adjusted EBITDA reconciliation `page:8`; outlook `page:4`.
- First quarter 2026 release, dated April 30, 2026: "Consolidated revenue of $327.3 million" (page:1); outlook `page:3`; reconciliation `page:6`.
- Second quarter 2026 release, dated July 29, 2026: "Consolidated revenue of $313.4 million" (page:1); segment results `page:2`; outlook `page:3`; statements `page:3` and `page:4`; reconciliations `page:5` and `page:6`.
- Version relationship: each release repeats statement figures from the matching 10-K or 10-Q and adds management narrative, quarter-on-quarter comparisons and outlook. The filed report controls statement facts; the release is not independent corroboration of them. Each outlook is a separate dated management claim, and the July 29, 2026 outlook supersedes the earlier ones for current expectations without erasing them as history.

### Information-availability boundary

- The latest pinned document is the Q2 2026 10-Q, signed July 30, 2026 (10-Q page:45); the latest release is dated July 29, 2026. Both are before the 2026-11-05 as-of date and cutoff.
- Nothing dated between July 30, 2026 and November 5, 2026 is supplied. Any third quarter 2026 report, release, financing or other current report in that window is Not supplied. The sources do not say whether such documents exist, so their absence is not evidence of no event.
- The latest debt balance date is July 30, 2026 ("As of July 30, 2026, we had $397.0 million borrowings outstanding under the 2025 Term Loan", 10-Q page:39). Balances after that date are Not supplied.

### Identity and perimeter

- Reporting entity and issuer: LendingTree, Inc., Delaware, Nasdaq "TREE" (10-Q page:1). It is the parent of LT Intermediate Company, LLC, which holds LendingTree, LLC and its subsidiaries (10-Q page:4).
- Borrower: the 10-K and 10-Q say "the Company entered into a credit agreement" (10-Q page:18) and do not name the borrower entity inside the group. The Company, the pledging subsidiaries and the guarantor group are not named in the supplied text. The 10-K says the obligations are "unconditionally guaranteed on a senior basis by the Company's material domestic subsidiaries" (page:146) and exhibit 21.1 "Subsidiaries of LendingTree, Inc." is listed but its content is not supplied (page:161). Borrower and guarantor identity is an unresolved distinction, kept as a gap. The context leaves borrower, parent and guarantor fields blank; that is not evidence of their absence.
- Instrument roles: a $400.0 million 2025 Term Loan and a $75.0 million 2025 Revolving Facility, both maturing August 21, 2030, under the 2025 Credit Agreement dated August 21, 2025 (10-Q page:18), first lien, secured by "substantially all of its assets" (10-K page:146). Earlier instruments (2021 Credit Agreement, 2024 Term Loan, 0.50% Convertible Senior Notes due July 15, 2025) were refinanced or repaid in 2025 (10-K page:97) and are history, not current debt.
- Equity-linked instruments: warrants expired February 11, 2026 (10-Q page:14); convertible notes were settled in 2025. The June 30, 2026 balance sheet shows long-term debt only through the term loan lines (10-Q page:2, page:18).
- Largest customer: one Network Partner, named as "Progressive Casualty Insurance", accounted for 27% of FY2025 consolidated revenue, all in the Insurance segment (10-K page:12). The 10-Q does not repeat the percentage for 2026 in the pages read; the 2026 concentration is Not supplied.

### Consumer evidence demand

| Consumer | Evidence it needs | Located | Limitation carried forward |
| --- | --- | --- | --- |
| CP-1 | Annual and interim statements, discrete quarters and year-to-date, segments, add-backs, KPIs, debt carrying values, cash-paid interest and tax, non-GAAP | 10-K page:96, page:110 to page:112, page:125, page:142 to page:146; 10-Q Q2 page:2 to page:4, page:18, page:19, page:21, page:36, page:38; Q1 10-Q page:2 to page:4, page:17, page:18; Q3 2025 10-Q page:2, page:23; releases | Cash-paid income tax is printed for FY2025 only (10-K page:112); the 10-Q supplemental lines show interest paid only (Q2 10-Q page:4). Facility-level debt exists for one facility. Flattened text tables. Reclassified prior-period amounts (10-Q page:6) |
| CP-1A | Business, segments, products, customers, history, strategy, litigation | 10-K page:11, page:12, page:80, page:113, page:151; Q2 10-Q page:23, page:24, page:31 to page:35; release page:1 to page:3 | Proxy statement, subsidiary list and executed agreements not supplied; 2026 customer concentration not supplied |
| CP-2 | Debt terms, collateral, guarantees, covenants, liquidity, maturities | 10-K page:38, page:39, page:97, page:98, page:144 to page:146; Q2 10-Q page:18, page:19, page:39, page:40 | Credit agreement not supplied; covenant ratio value and letter of credit usage not stated; no rating report |
| CP-5 | Traceable claims and locators | All seven sources have page chunks | Original HTML and XBRL not supplied; extraction fidelity not reviewed against images |

### Analytical read-through

- Usable coverage: the audited FY2025 statements and three unaudited interim periods (March 31, 2026, June 30, 2026, plus September 30, 2025 for the prior-year comparison) cover discrete quarters, six-month and nine-month year-to-date columns, three segments, issuer-defined Adjusted EBITDA and variable marketing margin, and the single facility's carrying value. The Q2 10-Q reconciles segment profit to pre-tax income (page:21) and net income to Adjusted EBITDA (page:38), so non-GAAP add-backs can be traced to filed GAAP lines.
- Strongest contrary evidence and limitation: the facility terms exist only as summaries. The 10-K states the covenant as "a first lien net leverage ratio of 5.00 to 1.00" tested "only if the loans and certain other obligations under the 2025 Revolving Facility exceed $20.0 million" (page:145), and the 10-Q states only that "The Company was in compliance with all covenants at June 30, 2026" (page:19). Evidence leads to a source risk: the definition of first lien net leverage, its EBITDA add-backs and the credit agreement baskets are not in the pack. The consequence is that a downstream module can describe the test and the compliance statement but cannot verify headroom or restricted-payment capacity.
- Second source risk: the term-loan rate label. The 10-Q says borrowings "bear interest based on the Secured Overnight Financing Rate ("SOFR") of 7.89%" (page:19) while the 10-K pricing is a spread over Term SOFR of 4.50%, or 4.25% after a Moody's rating condition achieved in January 2026 (page:145). The label may be an all-in rate, not the benchmark alone. Downstream modules must quote it as printed and flag the ambiguity.
- Third source risk: management narrative versus filing. The July 29, 2026 release states an outlook for 2026 and the third quarter (page:3); the 10-Q does not. These are attributed management claims, forward-looking and unaudited, and cannot override filed figures.
- Fourth source risk: a large tax-related swing in FY2025 net income. The 10-K statement of operations shows "Income tax benefit (expense) 130,284" against pre-tax income of "21,024" (page:110), and the fourth quarter release says the benefit reduced the full valuation allowance (page:1). Downstream modules must separate net income from operating results.
- What cannot proceed from these sources alone: covenant headroom against the credit agreement definitions, guarantor-level analysis, letter of credit availability under the revolver, rating-agency analysis, market-price or valuation analysis, and anything after July 30, 2026.
- Next evidence action: obtain the August 21, 2025 Credit Agreement (listed as exhibit 10.39, incorporated from the Form 8-K filed August 21, 2025, 10-K page:161), exhibit 21.1, any filing or release dated after July 30, 2026 including a third quarter 2026 10-Q and release, and the 2026 proxy statement.

## Calculations

No new calculation. CP-0 does not normalize, reconcile or calculate figures. Printed amounts used above are quoted from the cited locators.

## Gaps

| Gap | Severity | Affected consumers | Remediation |
| --- | --- | --- | --- |
| 2025 Credit Agreement (exhibit 10.39, 10-K page:161) not supplied; covenant definitions, baskets, borrower and guarantor names, and the first lien net leverage ratio value are Not supplied | High for legal or covenant work; Medium for the selected modules | CP-2, CP-1A | Supply the agreement and any compliance certificate or covenant ratio disclosure |
| No document dated after July 30, 2026; third quarter 2026 results and any current reports are Not supplied | Medium | CP-1, CP-1A, CP-2 | Supply later filings or confirm that none exist before the cutoff |
| Letters of credit outstanding under the revolver: searched for "letter of credit", "letters of credit" and "standby" in all sources; only the fee terms and the $30.0 million sublimit are printed (10-K page:145, page:146), no usage amount | Medium | CP-2 | Supply the credit agreement or a revolver availability statement |
| Exhibit 21.1 subsidiary list not supplied | Low to Medium | CP-1A, CP-2 | Supply the exhibit |
| Cash-paid income tax for 2026 periods not printed in the 10-Qs read; only interest paid is shown (Q2 10-Q page:4) | Low | CP-1 | Use FY2025 10-K page:112 and mark 2026 as Not supplied |
| 2026 largest-customer concentration not located in the 10-Qs or releases (searched "Progressive" and "27%"); FY2025 figure of 27% is in the 10-K (page:12) | Low | CP-1A | Supply a later filing that restates the concentration, if one exists |
| Prior-period reclassification noted in the Q2 10-Q (page:6) without a reconciliation; for example other non-current assets for December 31, 2025 appear as "16,997" in the 10-Q (page:2) while the 10-K shows "16,522" plus "Equity investments (Note 7) 475" (page:110) | Low | CP-1 | Treat the 10-K as the audited source and the 10-Q as the reclassified comparative; do not mix |
| Term-loan rate label (SOFR of 7.89%) is ambiguous against the stated pricing | Low | CP-1, CP-2 | Quote as printed; confirm against the credit agreement |
| No rating report, market price or peer data supplied. A Moody's corporate family rating of B2 (stable) is mentioned as achieved in January 2026 (10-K page:145) but no rating document is supplied | Low for the selected modules | CP-2 | Not required for this scope; keep Not supplied |
| Text extraction only; original HTML and XBRL not supplied; no fidelity review against images | Low | CP-1, CP-5 | Check flagged tables against the filed HTML when available |

## Next module

- CP-1: use the 10-K and 10-Q statements as controlling; keep FY2025 annual, Q1 2026, Q2 2026 and six-month columns separate; label Adjusted EBITDA and variable marketing margin as issuer non-GAAP; use the Q2 10-Q Note 10 for carrying values (gross term loan and issuance cost and discount lines) and record that the revolver was undrawn at June 30, 2026 (page:19); carry the reclassification limitation.
- CP-1A: describe the three segments and the Network Partner concentration from the 10-K; treat the July 29, 2026 outlook as a dated management claim; label anything after July 30, 2026 as Not supplied.
- CP-2: present the facility, collateral, guarantee, 5.00 to 1.00 covenant test and the $20.0 million test trigger as summarized in the notes; report compliance only as the issuer states it; carry the missing credit agreement, letter of credit usage and the rate-label ambiguity as restrictions.
- CP-5: trace each claim to a `page:N` locator in a pinned file; do not use this handoff as an authority for any figure that the source does not print.
