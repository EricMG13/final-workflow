## Request

Issuer: Uniti Group Inc. (issuer id unit; Nasdaq ticker UNIT). As-of date: 2026-11-05. Evidence cutoff: 2026-11-05. Pathway: credit_snapshot. Reporting currency: USD, in millions as the filings print. Current period named by the context: Q2 2026. Prior period named by the context: FY2025.

Task for this module: synthesise the fundamental credit view of Uniti Group Inc. from the accepted financial base and business and transaction handoffs: business risk, financial risk and liquidity, the strengths and weaknesses that drive them, the key credit risks, and the gaps that limit the view. Evidence is the upstream handoffs, with the issuer filings reopened only to confirm figures this module adds. No peer ranking, instrument recommendation or recovery conclusion is given; relative value and security selection are outside this module. Where this module's analysis corrects an upstream handoff it says so plainly.

## Sources

Each issuer file is one JSONL text extraction of an SEC filing. The locator `page:N` is the extraction chunk, not the printed page.

### Issuer sources relied on

| Source name | sha256 | Use in this module |
| --- | --- | --- |
| 10-K_2025-12-31_unit-20251231.htm.jsonl | 6d67619ba1ab3647c20a79710ac6373101e1f3efd1454ad58308edf1101a7a6b | Ranking of the 2027 convertible notes as senior unsecured (page:147); FY2025 capital expenditures and interest paid as carried by the financial base |
| 10-Q_2025-09-30_unit-20250930.htm.jsonl | 5887e391d2d0fd28ff7625b79ed82dcf62027435a26c54f6cbb097f48f8f2e90 | Not used directly in this module |
| 10-Q_2026-03-31_unit-20260331.htm.jsonl | 6eef1c3a3881ef793ddfc9610c4d46208d57c3bb26c5a88a18ed1115bb75d5ba | Maturity table at 2026-03-31 (page:31), used to test the later table |
| 10-Q_2026-06-30_unit-20260630.htm.jsonl | 44ae41cd731221c3fab785c468962d8927f45d4ed20722ebe4d9e689ea9bcd05 | H1 2025 and H1 2026 capital expenditures (page:6), debt table (page:20-21), maturity table (page:30), preferred terms (page:10) |
| EX-99.1_2026-03-02_unit-ex991202510xk.htm.jsonl | c7190cfa9cb627d04b3e648821ebf4356c56f99434b32385548463e0d9accab6 | Not used directly in this module |
| EX-99.1_2026-05-11_unit-ex9911q26.htm.jsonl | cfd5a9da978c996627652ac9d3c7077c0533d727405c7b27dfe93c7e85d28fc5 | Not used directly in this module |
| EX-99.1_2026-07-30_unit-ex9912q26.htm.jsonl | 1d9925874068c008696dd366506144e0d697bf35f0c978f5473bf3052738ff6f | 2026 outlook for Adjusted EBITDA and interest expense, net (page:2) |

### Context file

| Source name | sha256 | Role |
| --- | --- | --- |
| context | e531a4ec67bdeec3bf2b02e8047c90f4c69262abee202a8c1e2071ff24adf370 | Run settings only; not issuer evidence |

### Supplied handoffs

| Module | sha256 | Use |
| --- | --- | --- |
| CP-0 | 013c310c8396f81ac9f077f177c9c4e522274d65b9d75cc140acddd2c5a45803 | Source readiness and carried limitations |
| CP-1 | 825e72c7214f02408d5dc6ffc79807be881b2e40ab76417f16f55955164b5b08 | Financial base: leverage, cover, liquidity, maturities, claims outside debt |
| CP-1A | e66fab52b8a2a4ca43862ac6b5cde9c92bfe871c7c2ccf619345ed47660a1fae | Business, ownership, transaction, behaviour rows, logged conflicts |

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| Uniti has a thin credit profile: total debt is 7.16x trailing Adjusted EBITDA, cash interest cover is 1.94x, and operating cash flow does not fund capital spending. Liquidity of 1,447.0 million and distant maturities give time. | Medium | Covenant levels and executed debt documents are not supplied, and trailing figures mix the pre-merger and combined companies. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Capital expenditures of 799.2 million in the first half of 2026 exceeded operating cash flow of 339.4 million and Adjusted EBITDA of 798.7 million. | The build is debt funded, so leverage and interest cost keep rising until the fiber investments produce earnings. | High |
| Management expects 2026 interest expense, net of 805 million against Adjusted EBITDA of 1,450 to 1,500 million. | Interest absorbs a large share of expected earnings, leaving little room for earnings shortfalls. | Medium |
| Maturities are light before 2029 and heavy in 2031 to 2033, with 3,410.1 million due in 2031 and 2,595.0 million in 2032. | Near-term refinancing risk is low; the later wall relies on continued market access. | Medium |
| Asset-backed notes in unrestricted subsidiaries were 1,799.1 million at 2026-06-30, with 1,140.7 million more issued in July 2026. | Growing non-recourse, asset-level debt reduces the assets available to other secured and unsecured creditors. | Medium |

### Credit view

Uniti Group Inc. carries a weak fundamental credit profile with adequate near-term liquidity. The assessment is an Analyst Interpretation with Medium confidence. Financial risk dominates. At 2026-06-30 total debt principal of 10,680.6 million was 7.16x trailing Adjusted EBITDA and 6.75x net of unrestricted cash, and trailing Adjusted EBITDA covered trailing cash interest paid 1.94 times. Adjusted EBITDA is a company measure that excludes transaction costs and stock-based compensation, and the trailing window includes one pre-merger month. Cash generation does not support the investment programme: first-half 2026 operating cash flow of 339.4 million compared with capital expenditures of 799.2 million, so the build is financed with new debt, and the company reports a net loss in each of Q1 2026 and Q2 2026. Business risk is moderate. Uniti has three segments, no customer above 10% of revenue, a large fiber footprint, and a Kinetic fiber build that management intends to raise penetration and revenue per customer (management strategy), but the Fiber Infrastructure revenue base reset when Windstream's lease income ended on 2025-08-01, hyperscaler IRU revenue is lumpy, and the DSL base is declining. Liquidity is adequate for the next twelve months: 1,447.0 million of cash and revolver availability at 2026-06-30, no instrument maturing before the 2027-12-01 convertible notes and the 2027-12-30 revolver maturities, and 1,140.7 million of further asset-backed proceeds in July 2026 of which 500.0 million is planned for secured debt repayment. Creditor control and structure add risk: the share of debt in non-recourse asset-backed subsidiaries is rising, and covenant levels and executed documents are not supplied. The credit view is therefore that earnings must grow into the debt through the fiber build while market access stays open; the filings contain no evidence that either is secured.

### Key findings

- Leverage and cover are weak, and the apparent improvement is partly a perimeter effect. Total debt to trailing Adjusted EBITDA was 8.13x at FY2025, 7.75x at the trailing period to Q1 2026 and 7.16x at the trailing period to Q2 2026, but each earlier ratio uses a window with fewer Windstream months, so the improvement is partly a perimeter effect rather than a deleveraging. Cash interest cover was 1.78x, 2.34x and 1.94x on the same windows. Mechanism (Analyst Interpretation): higher-cost debt added in 2026 (8.625% unsecured notes and the asset-backed notes) is likely to raise cash interest faster than Adjusted EBITDA at the current build stage. Implication: leverage tolerance is low and a modest earnings shortfall would push trailing cash interest cover to about 1.55x (illustrative, calculated below).
- Free cash flow is structurally negative while the build runs. Operating cash flow less capital expenditures was negative 459.8 million in H1 2026 and negative 437.6 million in FY2025. Adjusted EBITDA less capital expenditures for the trailing period was 151.4 million (calculated below), which does not cover trailing cash interest paid of 768.6 million. Mechanism: capital expenditures at Kinetic of 602.8 million in H1 2026 front-load cost before subscriber revenue. Implication: the company depends on debt issuance or asset monetisation to fund both the build and interest, and creditors depend on continued access to the asset-backed and bond markets.
- Management's 2026 outlook implies interest absorbs most of the trend in earnings. The outlook for Adjusted EBITDA is 1,450 to 1,500 million, interest expense, net 805 million and a net loss of 480 to 530 million (management forward-looking statement). Against first-half interest expense, net of 383.9 million, the outlook implies about 421.1 million in the second half (calculated). Outlook Adjusted EBITDA covers outlook interest expense, net 1.80x to 1.86x (calculated). Implication: GAAP losses persist through 2026 on the company's own outlook.
- Maturity profile is back-ended by instrument due dates but the printed table conflicts. By due date, 876.5 million falls due in 2027 and 2028 (the convertible notes and the 4.75% secured notes) and 7,405.1 million in 2031 to 2033. Within that, the 6.50% unsecured notes of 1,110.0 million fall due in 2029, and the 8.625% unsecured notes plus the 2025 Term Loan, 2,595.0 million together, fall due in 2032. The Q2 10-Q prints a maturity table that places 886.5 million in 2027 and 1,120.0 million in 2028, which differs from the due dates by one year for 2027 to 2030; the Q1 10-Q table agreed with the due dates. This corrects the financial base handoff, which said no maturity table was printed: one is printed at Q2 10-Q page:30. The credit view uses the due dates and flags the conflict. Implication: the wall by year is uncertain by one year for 2027 to 2030 until the company confirms the schedule; the total is not in question.
- Structural priority is shifting toward asset-level debt. Of total principal, 6,964.1 million is secured (credit facility and secured notes 5,165.0 million plus asset-backed notes 1,799.1 million) and 3,716.5 million is senior unsecured, including the 2027 convertible notes (calculated; the convertible notes are described as senior unsecured at 10-K page:147). The asset-backed notes sit in unrestricted subsidiaries that hold fiber assets and customer contracts transferred from non-securitization subsidiaries, with no recourse to the company. After the July 2026 issue the asset-backed share rises from 16.8% to about 24.9% of principal before any repayments (calculated). Mechanism: assets move from the guarantor group to separate noteholders, so value available to the unsecured notes and the other secured creditors falls, and the asset sale offers show part of the proceeds must repay secured debt. Implication: unsecured holders are the most exposed to asset transfers. Legal capacity for transfers depends on indenture terms that are not supplied.
- Liquidity is adequate but supplied by financing, not operations. Cash of 608.9 million and revolver availability of 838.1 million give 1,447.0 million; the Uniti Revolver provides 499.7 million and the Windstream Revolver 338.4 million after 136.6 million of letters of credit. Both revolvers mature 2027-12-30 and the Windstream Revolver commitment steps down after 2027-01-23. Implication: the revolver renewal in 2027 is the first liquidity event that depends on market conditions.
- Equity-like claims sit ahead of common equity and can become cash claims. The preferred stock has a liquidation preference of 575.0 million and an 11% dividend, which is about 63.25 million a year at the face rate (calculated), and Elliott affiliates may require repurchase after the tenth anniversary. Mechanism: the repurchase may be settled in cash or stock. Implication: not a near-term cash issue, but it is a long-dated claim that competes with debt refinancing.
- Data limits restrict the view. Covenant levels and compliance ratios, executed indentures and credit agreements, pro forma Adjusted EBITDA, the outcome of the July 2026 repayment offers and any report after 2026-07-30 are not supplied. A conflict on whether the 1.0 billion 8.625% notes are secured is logged and unresolved; the debt tables describe them as unsecured.

### Strengths and weaknesses

Strengths:

- Scale and diversification of revenue. Three segments, no customer above 10% of revenue, and a network of about 240,000 fiber route miles (Documentary Fact, from the business handoff). Mechanism: reduces dependence on any one customer after the merger ended the dependence of Old Uniti on Windstream. Implication: lower single-customer default risk than before the merger.
- Adequate near-term liquidity and no scheduled maturity before December 2027. Cash and revolver availability of 1,447.0 million, and no instrument maturing in the next twelve months other than term loan amortization (Documentary Fact and Analyst Interpretation). Implication: low near-term refinancing and liquidity risk.
- Demonstrated capital markets access. The company completed asset-backed notes in January and July 2026, 1.0 billion of unsecured notes in February 2026, and a secured refinancing in October 2025 that redeemed the 10.50% notes due 2028 (Documentary Fact). Implication: supports refinancing, though at high coupons.
- Segment margins. Contribution margins of about 52% at Fiber Infrastructure, 50% at Uniti Solutions and 42% at Kinetic in Q2 2026 are stated by management (Management Language), before corporate costs. Implication: scope for operating leverage if revenue grows, not yet visible in cash flow.
- No common dividends. The company states no intention to pay common dividends (Documentary Fact). Implication: cash is retained for the build and debt service.
- Fiber customer growth. Kinetic fiber consumer broadband customers were 602.8 thousand at 2026-06-30 and management states record quarterly fiber net adds (Documentary Fact for the customer count; Management Language for the record claim). Implication: supports future recurring revenue, if build costs per premise are controlled, which is not shown.

Weaknesses:

- High leverage and thin cover. Total debt 7.16x and net debt 6.75x trailing Adjusted EBITDA, cash interest cover 1.94x (Documentary Fact and calculation from the financial base). Implication: little tolerance for earnings shortfalls or rate increases on the floating-rate term loan.
- Negative free cash flow from the build. Operating cash flow of 339.4 million against capital expenditures of 799.2 million in H1 2026 (Documentary Fact). Implication: reliance on external funding.
- GAAP losses. Net loss of 226.2 million in H1 2026 with interest expense, net of 383.9 million exceeding operating income of 143.1 million (Documentary Fact). Implication: earnings do not yet cover the interest burden on a GAAP basis.
- Comparability and earnings quality. The perimeter changed on 2025-08-01, Adjusted EBITDA is a management measure, and Q1 2026 included IRU sales revenue of 85.5 million for the half that is not recurring service revenue (Documentary Fact; Analyst Interpretation on recurrence). Implication: run-rate earnings are harder to judge than reported trailing figures suggest.
- Back-end loaded maturity wall and the shifting structure. Heavy 2031 to 2033 maturities, rising asset-backed debt in unrestricted subsidiaries, and a preferred stock claim with an Elliott repurchase right (Documentary Fact). Implication: refinancing risk is deferred rather than removed, and unsecured holders are more exposed to asset transfers.
- Disclosure gaps and inconsistencies. No covenant levels, no executed documents, and two logged conflicts on ranking and the maturity table (Insufficient Information and Documentary Fact). Implication: the view cannot be tested against creditor protections.

### Key credit risks

| Risk | Mechanic | Credit implication | Severity |
| --- | --- | --- | --- |
| Leverage and cover remain weak as capital spending exceeds cash flow | Debt-funded build adds interest before earnings arrive; floating-rate term loan adds rate exposure | Default risk rises if earnings growth or market access falters | Critical |
| Refinancing dependence on capital markets | Instruments mature mainly 2031 to 2033 and the revolvers mature 2027-12-30; the build requires continued issuance | Liquidity and refinancing risk if markets close | Material |
| Priming by asset-backed structures | Assets and cash flows are moved to unrestricted subsidiaries for non-recourse noteholders | Loss given default for other creditors rises; unsecured most exposed | Material |
| Earnings quality and comparability | Mixed perimeter, lumpy IRU sales revenue, company-defined Adjusted EBITDA | Leverage may be mis-measured; covenant EBITDA unknown | Material |
| Preferred stock and shareholder influence | 575.0 liquidation preference with repurchase right; 25.2% holder with board rights | Competing cash claim and governance influence over financing choices | Minor |
| Disclosure conflicts | Ranking of 8.625% notes and maturity table disagree within filings | Ranking and maturity timing uncertainty | Minor |

## Calculations

All amounts in USD millions, from figures in the accepted handoffs or the cited filing locators. Leverage and cover figures are the financial base's; the items below are new.

| Calculation | Formula and inputs | Result |
| --- | --- | --- |
| LTM capital expenditures, Q2 2026 | 787.8 (FY2025) - 246.2 (H1 2025) + 799.2 (H1 2026); Q2 10-Q page:6; financial base | 1,340.8 |
| Adjusted EBITDA less capital expenditures, LTM | 1,492.2 - 1,340.8 | 151.4 |
| Less LTM cash interest paid | 151.4 - 768.6 | -617.2 |
| Adjusted EBITDA less capital expenditures, H1 2026 | 798.7 - 799.2 | -0.5 |
| Less interest paid, H1 2026 | -0.5 - 368.1 | -368.6 |
| Outlook second-half interest expense, net | 805 - 383.9 | 421.1 |
| Outlook Adjusted EBITDA / outlook interest expense, net | 1,450 / 805 and 1,500 / 805 | 1.80x and 1.86x |
| Total debt / outlook Adjusted EBITDA | 10,680.6 / 1,500 and 10,680.6 / 1,450 | 7.12x and 7.37x |
| Secured debt | 995.0 + 570.0 + 2,200.0 + 1,400.0 = 5,165.0; plus 1,799.1 asset-backed | 6,964.1 |
| Senior unsecured debt | 1,110.0 + 700.0 + 1,600.0 + 306.5 | 3,716.5 |
| Secured plus unsecured | 6,964.1 + 3,716.5 | 10,680.6, equal to total principal |
| Asset-backed share of principal, 2026-06-30 | 1,799.1 / 10,680.6 | 16.8% |
| Asset-backed share after July 2026 issue, before repayments | (1,799.1 + 1,140.7) / (10,680.6 + 1,140.7) | 24.9% |
| Maturities 2031 to 2033 by due date | 3,410.1 + 2,595.0 + 1,400.0 | 7,405.1 |
| Maturities 2027 and 2028 by due date | 306.5 + 570.0 | 876.5 |
| Preferred dividend at the face rate | 11% x 575.0 | 63.25 |
| Illustrative cover if trailing Adjusted EBITDA fell 20% | 0.8 x 1,492.2 / 768.6 | 1.55x |

## Gaps

| Gap | Severity | What it affects | Action |
| --- | --- | --- | --- |
| Covenant tests, levels, headroom and compliance ratios not supplied | High | Financial risk, creditor control | Supply credit agreement definitions and compliance certificate |
| Executed indentures, credit agreements and ABS indentures not supplied; basket capacity for asset transfers unverified | High | Structural priority, ranking | Supply the executed documents |
| Conflict on the ranking of the 1.0 billion 8.625% notes (secured wording in a risk factor, unsecured elsewhere) | Medium | Structure, loss given default | Confirm against the indenture |
| Conflict on the maturity table: Q2 10-Q table differs by one year from instrument due dates for 2027 to 2030 | Medium | Maturity wall timing | Confirm with the company; corrects the financial base statement that no table was printed |
| Pro forma combined-company Adjusted EBITDA not supplied; trailing window includes July 2025 without Windstream | Medium | Leverage and cover level | Supply pro forma Adjusted EBITDA |
| Outcome of the asset sale offers and term loan prepayment, and any filing after 2026-07-30, not supplied | Medium | Post-quarter leverage and liquidity | Supply later filings up to the cutoff |
| Ratings, market prices and valuation inputs not in the context | Low for this module | Market view | Not required here; belongs to later modules |
| Elliott stockholder agreement and preferred certificate of designation not supplied | Low | Governance, preferred claim | Supply if governance detail is needed |

## Next module

- CP-5: trace each figure in this module to the financial base or business handoffs, and the new calculations to their inputs. Label the 2026 outlook as a management forward-looking statement, the segment margin percentages and record claims as management language, and the illustrative cover sensitivity as a calculation, not a forecast.
- Downstream relative value, security selection and committee action: not performed here; carry the unresolved ranking and maturity conflicts and the missing covenant and indenture documents as restrictions.
