## Request

Issuer: Uniti Group Inc. (unit; Nasdaq UNIT). As-of date: 2026-11-05; evidence cutoff 2026-11-05. Pathway: credit_snapshot. Reporting currency USD, amounts in millions as the filings print.

Question: does each material claim in the financial base, business context and credit synthesis handoffs rest on the evidence it names, and do the three tell one consistent story? The review traces claims to the pinned filings and releases, recomputes derived figures, compares figures and scope across the handoffs, grades the set and states whether committee use is permitted, restricted or blocked. The source readiness handoff is the gate and is not itself graded. The review changes no figure in another handoff; where it disagrees it says so here, because an accepted handoff cannot be edited. The review was done by the same session that wrote the handoffs and is not an independent second reviewer.

## Sources

### Issuer sources used to trace claims

Each issuer file is one JSONL text extraction of an SEC filing. The locator `page:N` is the extraction chunk, not the printed page.

| Source name | sha256 | Role in the trace |
| --- | --- | --- |
| 10-K_2025-12-31_unit-20251231.htm.jsonl | 6d67619ba1ab3647c20a79710ac6373101e1f3efd1454ad58308edf1101a7a6b | FY2025 audited statements, Adjusted EBITDA reconciliation, ownership, notes terms, 8.625% notes wording |
| 10-Q_2025-09-30_unit-20250930.htm.jsonl | 5887e391d2d0fd28ff7625b79ed82dcf62027435a26c54f6cbb097f48f8f2e90 | Q3 2025 Adjusted EBITDA used in the quarterly cross-check |
| 10-Q_2026-03-31_unit-20260331.htm.jsonl | 6eef1c3a3881ef793ddfc9610c4d46208d57c3bb26c5a88a18ed1115bb75d5ba | Q1 2026 statements, Adjusted EBITDA, interest paid, revolver availability, maturity table |
| 10-Q_2026-06-30_unit-20260630.htm.jsonl | 44ae41cd731221c3fab785c468962d8927f45d4ed20722ebe4d9e689ea9bcd05 | Controlling source for current statements, debt, liquidity, segments, subsequent events and the printed maturity table |
| EX-99.1_2026-03-02_unit-ex991202510xk.htm.jsonl | c7190cfa9cb627d04b3e648821ebf4356c56f99434b32385548463e0d9accab6 | Q4 and FY2025 headline figures; management statements |
| EX-99.1_2026-05-11_unit-ex9911q26.htm.jsonl | cfd5a9da978c996627652ac9d3c7077c0533d727405c7b27dfe93c7e85d28fc5 | Q1 2026 headline figures matched to the 10-Q |
| EX-99.1_2026-07-30_unit-ex9912q26.htm.jsonl | 1d9925874068c008696dd366506144e0d697bf35f0c978f5473bf3052738ff6f | Q2 2026 headline figures, segment margins, financing, 2026 outlook |

The run context (sha256 e531a4ec67bdeec3bf2b02e8047c90f4c69262abee202a8c1e2071ff24adf370) holds run settings only and is not evidence.

### Supplied handoffs

| Module | sha256 | Status in this review |
| --- | --- | --- |
| CP-0 | 013c310c8396f81ac9f077f177c9c4e522274d65b9d75cc140acddd2c5a45803 | Source readiness gate; not evaluated |
| CP-1 | 825e72c7214f02408d5dc6ffc79807be881b2e40ab76417f16f55955164b5b08 | Evaluated |
| CP-1A | e66fab52b8a2a4ca43862ac6b5cde9c92bfe871c7c2ccf619345ed47660a1fae | Evaluated |
| CP-2 | aa36d2d84bb15fc9e5adcae91ef166e160ca6ea73fd1649fc013e70afc47b4cd | Evaluated (accepted second attempt; the first attempt was rejected for two years missing from the body and is superseded) |

## Findings

### Reader summary

| Bottom line | Confidence | Main limitation |
| --- | --- | --- |
| The figures in the financial base, business context and credit synthesis trace to the filings and recompute correctly, and the three agree except for one wrong statement on the maturity table. Committee use is restricted by missing debt documents. | Medium | The review was done in the same session by the same author, and covenant levels and executed debt documents are not supplied. |

| Finding | Creditor impact | Confidence |
| --- | --- | --- |
| Every figure taken from the filings was found in the source text, and every derived figure recomputed to the stated value. | The numbers a committee would quote can be relied on as stated, within their labels. | High |
| The financial base says no maturity table is printed, but the second-quarter report prints one that differs by one year from instrument due dates for 2027 to 2030. | The year-by-year maturity wall is uncertain by one year; total principal of 10,680.6 million ties either way. | High |
| Four statements are partly supported or loosely worded, including how new debt replaced old borrowings and whether quarter-end cash includes asset-backed proceeds. | These are wording issues; the figures are right and the credit view is unaffected. | Medium |
| No contradiction between the three handoffs was found; two source conflicts, on the 8.625% notes ranking and the maturity table, stay open. | The set tells one consistent story, with ranking and maturity timing still to confirm. | Medium |

### Evidence trace view

The evidence trace holds with one factual correction. Each material claim in the financial base, business context and credit synthesis was matched to a located source span or to a recomputation from located figures, and the three handoffs agree on every shared figure, period and perimeter label. The one claim that fails is in the financial base: it states that no debt maturity table is printed, while the second-quarter 10-Q prints one at page:30. The business context handoff found and logged the conflict between that table and the instrument due dates, and the credit synthesis carries the correction; the financial base itself cannot be edited, so the correction stands here. Four further claims are partly supported as wording, none changes a figure. The integrity verdict for the evaluated set is Restricted, not Committee Ready: the conclusions that matter most to a creditor, covenant headroom, the priority of asset-level debt against other creditors and the ranking of the 8.625% notes, rest on executed documents that are not in the sources. The cautious credit view with Medium confidence follows from the cited basis and is not overstated. The review is limited: the same session wrote and checked the handoffs, from the same extraction text, and locators are extraction chunks rather than printed pages.

### Evaluated set (inputs and status)

| Input | Status | Evaluated | Notes |
| --- | --- | --- | --- |
| CP-0 source readiness | Accepted; gate | No | Perimeter change at 2025-08-01, missing executed documents and nothing after 2026-07-30 carried forward |
| CP-1 financial base | Accepted | Yes | Contains the maturity table statement that this review finds wrong |
| CP-1A business and transaction context | Accepted | Yes | Logs two conflicts and corrects the financial base |
| CP-2 credit synthesis | Accepted | Yes | Confidence Medium, inside the cap set by the upstream limits |

All four are current for the as-of date 2026-11-05 and use USD. No input is stale; the latest source is dated 2026-07-30, and nothing between that date and the cutoff was supplied.

### Material claim register and support review

Verdicts: supported (the named evidence states the claim), partly supported (carries part of it or carries it only with a qualification the claim omits), unsupported (does not carry it).

| Claim | Module | Evidence traced | Verdict | Reviewer note |
| --- | --- | --- | --- | --- |
| Total principal 10,680.6 at 2026-06-30 and 9,540.5 at 2025-12-31 | CP-1, CP-2 | Q2 10-Q page:20-21; 10-K page:139 | Supported | Components re-added |
| Revolver availability 499.7 and 338.4, letters of credit 0.3 and 136.6, liquidity cash plus 838.1 | CP-1, CP-2 | Q2 10-Q page:23-24, page:83 | Supported | Recomputed |
| Liquidity at 2026-03-31 (862.0 availability) and 2025-12-31 (542.1) | CP-1 | Q1 10-Q page:23, page:25, page:73; 10-K page:77, page:141, page:143 | Supported | Windstream Revolver drawn 315.0 at year-end ties |
| Revenue, EBITDA, Adjusted EBITDA and net loss for FY2025, Q1, Q2 and H1 2026 | CP-1, CP-2 | 10-K page:88, page:101; Q1 10-Q page:4, page:79; Q2 10-Q page:4, page:91 | Supported | Reconciliation lines re-added |
| FY2025 net income of 1,304.7 includes a gain of 1,683.9 excluded from Adjusted EBITDA | CP-1 | 10-K page:88, page:101 | Supported | |
| Trailing Adjusted EBITDA 1,492.2 and 1,377.6, and quarterly cross-check 1,492.1 | CP-1, CP-2 | Q1 10-Q page:79; Q2 10-Q page:91; Q3 2025 10-Q page:120; release page:1 | Supported | The 0.1 difference is rounding |
| Total debt to trailing Adjusted EBITDA 8.13x, 7.75x, 7.16x; net 8.08x, 7.04x, 6.75x | CP-1, CP-2 | Calculations below | Supported | Debt is principal; net deducts unrestricted cash only |
| Cash interest cover 1.78x, 2.34x, 1.94x | CP-1, CP-2 | Interest paid: 10-K page:192; Q1 10-Q page:12; Q2 10-Q page:13 | Supported | Neither is a covenant definition; stated. Coupon timing makes single quarters uneven, and the Q1 10-Q attributes part of the working capital effect to timing of interest payments (page:74) |
| Operating cash flow less capital expenditures negative 459.8 in H1 2026 and negative 437.6 in FY2025 | CP-1, CP-2 | Q2 10-Q page:6; 10-K page:102-103 | Supported | |
| Segment results for Q2 2026 (revenue, contribution margin, capital expenditures) | CP-1, CP-1A, CP-2 | Q2 10-Q page:47-49; release page:2 | Supported | Margin percentages of 42%, 52% and 50% recompute from the segment table |
| Windstream contributed 795.9 of 909.7 Q2 revenue | CP-1 | Q2 10-Q page:19, page:63 | Supported | Share recomputes to 87.5% against the 87% stated by the filing |
| Outlook: Adjusted EBITDA 1,450 to 1,500, interest expense, net 805, net loss 480 to 530 | CP-1, CP-2 | Release 2026-07-30 page:2 | Supported | Management forward-looking statement, labelled as such |
| Maturity wall by instrument due date, 7 years | CP-1, CP-1A, CP-2 | Q2 10-Q page:20-21 | Supported | Sums to total principal |
| No maturity table is printed; the maturity table is built from due dates | CP-1 | Q2 10-Q page:30 prints a table | Unsupported | A table is printed and it conflicts with due dates for 2027 to 2030 (see findings) |
| Merger terms: consideration 2,376.6, 62% and 38% split, reverse merger accounting | CP-1A | Q2 10-Q page:9-10, page:16; 10-K page:6 | Supported | Components re-added |
| Windstream Leases settled; leases above market by 559.0, asset purchase agreement unfavourable by 60.0 | CP-1A | Q2 10-Q page:17-18 | Supported | |
| Debt combined under Uniti Services LLC with cross-guarantees on 2025-08-04 | CP-1A, CP-2 | 10-K page:56 | Supported | |
| Elliott holds about 25.2%, with board designation rights; preferred 575.0 liquidation preference; put after tenth anniversary | CP-1A, CP-2 | 10-K page:42, page:44; Q2 10-Q page:10 | Supported | Percentage is as of the 10-K date |
| No common dividends intended | CP-1A, CP-2 | 10-K page:43 | Supported | |
| Kinetic ABS 2026-1 notes of 960.1 non-recourse, issued by unrestricted subsidiaries; 2026-2 notes in July 2026 | CP-1A, CP-2 | Q2 10-Q page:26-29, page:50, page:52 | Supported | 1,140.7 is a sum of three classes shown in the financial base and not in the business context handoff (see findings) |
| Ranking of the 1.0 billion 8.625% notes: logged conflict, unsecured per debt tables | CP-1A, CP-2 | 10-K page:28, page:57; Q2 10-Q page:21, page:26 | Supported | Quoted spans exist as printed |
| Secured debt 6,964.1 and unsecured debt 3,716.5; 2027 convertible notes senior unsecured | CP-2 | 10-K page:147; Q2 10-Q page:20-21 | Supported | Sums to total principal |
| Cautious fundamental credit view with Medium confidence | CP-2 | CP-1 tables and CP-1A rows | Supported | Not above what the basis carries |
| Reader summary of the financial base says new asset-backed notes replaced revolver and term loan borrowings | CP-1 | Q2 10-Q page:6, page:21, page:24, page:26 | Partly supported | Also 1.0 billion of unsecured notes funded the repayment of the Windstream Term Loan; the statement omits it |
| Cash at 2026-03-31 "includes proceeds of the Kinetic ABS 2026-1 notes" | CP-1 | Q1 10-Q page:73 | Partly supported | The filing gives cash of 982.6 and does not state that the notes explain the balance; the inference is plausible, not stated |
| Four swaps with 650.0 of notional after the January 2026 termination | CP-1 | Q2 10-Q page:32 | Partly supported | The 200.0 swap is described as at 2025-12-31 and no termination is stated; the sum assumes it continues |
| Interest "absorbs most of the trend in earnings" under the 2026 outlook | CP-2 | Release page:2 | Partly supported | The outlook supports "more than half" of Adjusted EBITDA (805 against 1,450 to 1,500), not "most of the trend" |
| Heavy 2031 to 2033 maturities and light 2027 to 2028 | CP-1, CP-2 | Q2 10-Q page:20-21 | Supported | By due date; the printed table (page:30) moves 2027 to 2030 amounts one year earlier, so the wall is uncertain by a year |

### Citation trace

| Check | Method | Result |
| --- | --- | --- |
| Verbatim quotes in CP-1A | Each double-quoted span searched in the normalised text of all seven sources | All 5 found, including the 8.625% notes wording and both maturity tables |
| Figures in the handoffs that appear in the sources | Each number token searched in all source text | CP-1: 232 of 257 present; CP-1A: 122 of 123; CP-2: 74 of 93. The remainder are derived figures; a present token is not proof of the right page |
| Derived figures | Each absent number located in a Calculations table | All located except 1,140.7 in CP-1A, a sum shown only in the financial base (a minor presentation gap) |
| Page locators on figure-bearing lines | The page cited in each row of the claim register was opened and searched for the figure or wording; a scripted check of selected figure and page pairs was also run for each handoff | Found on the cited pages; the locators for segment results and swaps were corrected during drafting before the handoffs were submitted |
| Cutoff | Dates after 2026-11-05 | Only labelled future dates: 2027 maturities, 2027-12-30 revolver maturity, hearing and anticipated repayment dates through 2033 |
| Currency and period labels | Read every table header | USD throughout; Q1, Q2, H1 and LTM labelled; no half-year amount used as a full-year figure |

### Figure identity across modules

| Figure | CP-1 | CP-1A | CP-2 | Result |
| --- | --- | --- | --- | --- |
| Total debt principal at 2026-06-30 | 10,680.6 | Not stated | 10,680.6 | Identical |
| Total debt to trailing Adjusted EBITDA | 7.16x | Not stated | 7.16x | Identical |
| Cash interest cover, trailing | 1.94x | Not stated | 1.94x | Identical |
| Liquidity at 2026-06-30 | 1,447.0 | Not stated | 1,447.0 | Identical |
| H1 2026 operating cash flow and capital expenditures | 339.4; 799.2 | Not stated | 339.4; 799.2 | Identical |
| Preferred stock liquidation preference | 575.0 | 575.0 | 575.0 | Identical |
| Kinetic ABS 2026-2 notes | 1,140.7 | 1,140.7 | 1,140.7 | Identical; sum shown in CP-1 only |
| 2027 and 2028 maturities by due date | 306.5 and 570.0 | Logged conflict with the printed table | 876.5 combined | Identical where stated |
| Existence of a printed maturity table | Says none | Says one is printed and corrects CP-1 | Says one is printed and corrects CP-1 | Disagreement; CP-1A and CP-2 are right, see findings |

### Input currency and scale

All inputs are USD in millions. Each handoff states the scale on the line, and the filings print amounts in millions. No scale mismatch was found, for example no value written as thousands that the source prints as millions.

### Gap propagation

| Upstream limitation | Carried by CP-1 | Carried by CP-1A | Carried by CP-2 |
| --- | --- | --- | --- |
| Covenant levels and executed debt documents not supplied | Yes | Yes | Yes |
| Perimeter change at 2025-08-01 and mixed trailing window | Yes | Yes | Yes |
| Company-defined Adjusted EBITDA, not covenant EBITDA | Yes | Not applicable | Yes |
| Nothing after 2026-07-30; outcome of repayment offers not supplied | Yes | Yes | Yes |
| Maturity table conflict | Said no table printed (error) | Logged | Logged |
| Pro forma Adjusted EBITDA not printed | Yes | Not applicable | Yes |
| Ratings, quotes and valuation inputs blank in the context | Not applicable | Yes | Yes |

### Findings register

| Finding | Type | Severity | Modules | Effect |
| --- | --- | --- | --- | --- |
| The financial base states that no debt maturity table is printed; the Q2 10-Q prints one at page:30 that differs by one year from instrument due dates for 2027 to 2030 | Unsupported claim; source conflict | Medium | CP-1 | Maturity wall by year uncertain by one year; total unaffected; corrected in CP-1A and CP-2 |
| Reader summary wording on how new debt replaced old borrowings omits the unsecured notes | Partly supported claim | Minor | CP-1 | Wording only; the debt table is correct |
| The attribution of the March 2026 cash balance to the January asset-backed proceeds is an inference | Partly supported claim | Minor | CP-1 | Figure right; cause not stated by the filing |
| Swap notional of 650.0 assumes the 200.0 swap continues | Partly supported claim | Minor | CP-1 | Hedge coverage of the 995.0 term loan is an estimate |
| Interest "absorbs most of the trend in earnings" is looser than the outlook supports | Wording | Minor | CP-2 | Calculations in the same module support "more than half" |
| 1,140.7 appears in the business context handoff without its sum | Presentation gap | Minor | CP-1A | The sum is in the financial base |
| Ranking of the 1.0 billion 8.625% notes in conflict inside the 10-K | Source conflict | Medium | CP-1A, CP-2 | Carried as unresolved; treated as unsecured per the debt tables |
| The review is not independent of the authors | Process limitation | Medium | All | A second reviewer is still needed |

### Cross-module contradictions

One, resolved in favour of the later modules: CP-1 says no maturity table is printed, while CP-1A and CP-2 say one is printed and conflicts with the due dates. The Q2 10-Q page:30 confirms that a table is printed. Pairs examined and found consistent: leverage and cover in CP-1 against the weak profile in CP-2; adequate liquidity in CP-2 against negative free cash flow in CP-1; the rising asset-backed share in CP-2 against the transaction table in CP-1A; the no common dividend policy in CP-1A against the preferred dividends of 31.2 declared in H1 2026 in CP-1 (common equity versus preferred).

### Verdict consistency

The verdicts agree across modules for every shared claim except the maturity table statement. CP-2's confidence of Medium is no higher than the upstream limits allow, and its gap list contains the inherited gaps.

### Contrary evidence and what would change the view

The strongest evidence against the cautious view is liquidity: cash of 608.9 and availability of 838.1 give 1,447.0 against no instrument maturity before 2027-12-01, and the company raised 1,140.7 more in July 2026. Segment contribution margins of about 52%, 50% and 42% suggest earnings power once the fiber build matures, and the 2026 outlook for Adjusted EBITDA of 1,450 to 1,500 compares with trailing 1,492.2, so the outlook range is close to the trailing figure. What would make that case win: capital expenditures falling after the build so that Adjusted EBITDA less capital expenditures covers interest, market access staying open for asset-backed and bond issuance, and the revolvers being extended before 2027-12-30. Downside chain with observable triggers: initiating condition, slower fiber penetration at Kinetic or fewer hyperscaler bookings; first operational break, Adjusted EBITDA below the low end of the outlook, which needs second-half Adjusted EBITDA of at least 651.3 (calculated); financial transmission, interest expense, net of 805 (outlook) then absorbs a larger share of earnings and cash interest cover falls below the trailing 1.94x; liquidity consequence, revolver drawings and letters of credit use the 838.1 of availability while capital expenditures continue; refinancing consequence, the 2027 maturities of the convertible notes and both revolvers meet a market that may be less open, while a failure of the debt service coverage test on the asset-backed notes would trigger rapid amortization of those notes (Q2 10-Q page:30). Observable triggers: quarterly Adjusted EBITDA against the 651.3 second-half requirement, the Windstream Revolver letter of credit balance, asset-backed debt service coverage disclosures, and the outcome of the asset sale offers.

## Calculations

Independent recomputation of figures from cited inputs. All matched the printed or stated value unless a note says otherwise. USD millions.

| Figure | Inputs | Recomputed | Stated in handoffs |
| --- | --- | --- | --- |
| Notes and convertible principal | 570.0 + 2,200.0 + 1,400.0 + 1,110.0 + 700.0 + 1,600.0 + 306.5 | 7,886.5 | 7,886.5 |
| Fiber and Kinetic ABS principal | 426.0 + 65.0 + 98.0 + 180.0 + 28.2 + 41.8; 677.7 + 113.0 + 169.4 | 839.0; 960.1 | 839.0; 960.1 |
| Total principal | 7,886.5 + 995.0 + 839.0 + 960.1 | 10,680.6 | 10,680.6 |
| Year-end 2025 principal | 315.0 + 500.0 + 1,000.0 + 570.0 + 2,200.0 + 1,400.0 + 1,110.0 + 700.0 + 600.0 + 306.5 + 839.0 | 9,540.5 | 9,540.5 |
| Carrying value | 10,680.6 - 34.0 - 10.0 | 10,636.6 | 10,636.6 |
| Balance sheet check | 12,819.4 + 161.5 | 12,980.9 | 12,980.9 |
| Revolver availability, 2026-06-30 | 500.0 - 0.3; 475.0 - 136.6 | 499.7; 338.4 | 499.7; 338.4 |
| Revolver availability, 2025-12-31 | 475.0 - 315.0 - 117.6 | 42.4 | 42.4 |
| Liquidity | 608.9 + 838.1; 982.6 + 862.0; 53.5 + 542.1 | 1,447.0; 1,844.6; 595.6 | 1,447.0; 1,844.6; 595.6 |
| Adjusted EBITDA reconciliation, Q2 2026 | 345.9 + 7.5 + 9.6 - 5.9 | 357.1 | 357.1 |
| Adjusted EBITDA reconciliation, H1 2026 | 753.1 + 15.1 + 39.7 - 9.2 | 798.7 | 798.7 |
| Adjusted EBITDA reconciliation, FY2025 | 2,620.6 + 23.5 + 211.8 - 1,683.9 + 1.8 | 1,173.8 | 1,173.8 |
| Adjusted EBITDA, Q1 2026 | 407.2 + 7.6 + 30.1 - 3.3 | 441.6 | 441.6 |
| LTM Adjusted EBITDA, Q2 2026 | 1,173.8 - 480.3 + 798.7 | 1,492.2 | 1,492.2 |
| LTM Adjusted EBITDA, Q1 2026 | 1,173.8 - 237.8 + 441.6 | 1,377.6 | 1,377.6 |
| Total debt / LTM Adjusted EBITDA | 10,680.6 / 1,492.2; 10,683.1 / 1,377.6; 9,540.5 / 1,173.8 | 7.16x; 7.75x; 8.13x | Same |
| Net debt / LTM Adjusted EBITDA | 10,071.7 / 1,492.2; 9,700.5 / 1,377.6; 9,487.0 / 1,173.8 | 6.75x; 7.04x; 8.08x | Same |
| LTM cash interest and cover | 660.7 - 260.2 + 368.1 = 768.6; 1,492.2 / 768.6; 660.7 - 211.8 + 138.8 = 587.7 | 1.94x; 2.34x; FY2025 1,173.8 / 660.7 = 1.78x | Same |
| Net loss and revenue, H1 2026 | -70.3 + -155.9; 987.5 + 909.7 | -226.2; 1,897.2 | Same |
| Cash flow split, Q2 2026 | 339.4 - 260.9; 799.2 - 349.2; 368.1 - 138.8 | 78.5; 450.0; 229.3 | Same |
| Operating cash flow less capital expenditures | 339.4 - 799.2; 350.2 - 787.8 | -459.8; -437.6 | Same |
| Segment totals, Q2 2026 | 228.4 + 121.8 + 91.8; 528.2 + 200.3 + 181.2; 350.9 + 77.2 + 6.8 + 15.1 | 442.0; 909.7; 450.0 | Same |
| Segment margins | 228.4 / 539.0; 121.8 / 234.1; 91.8 / 182.5 | 42.4%; 52.0%; 50.3% | About 42%, 52%, 50% |
| Windstream revenue share | 795.9 / 909.7; 1,605.2 / 1,897.2 | 87.5%; 84.6% | Filing states 87% and 85% |
| Merger consideration | 733.7 + 630.4 + 142.7 + 370.7 + 499.1 | 2,376.6 | 2,376.6 |
| Kinetic ABS 2026-2 notes | 805.2 + 134.2 + 201.3 | 1,140.7 | 1,140.7 |
| Maturities by due date | 306.5 + 570.0 + 1,110.0 + 1,289.0 + 3,410.1 + 2,595.0 + 1,400.0 | 10,680.6 | 10,680.6 |
| Printed maturity tables | Q2: 10.0 + 886.5 + 1,120.0 + 1,299.0 + 1,220.1 + 6,145.0; Q1: 7.5 + 316.5 + 580.0 + 1,120.0 + 1,299.0 + 7,360.1 | 10,680.6; 10,683.1 | Totals tie to principal at each date; year allocation conflicts in the Q2 table |
| Secured and unsecured split | 995.0 + 570.0 + 2,200.0 + 1,400.0 + 1,799.1; 1,110.0 + 700.0 + 1,600.0 + 306.5 | 6,964.1; 3,716.5 (sum 10,680.6) | Same |
| Asset-backed share | 1,799.1 / 10,680.6; (1,799.1 + 1,140.7) / (10,680.6 + 1,140.7) | 16.8%; 24.9% | 16.8%; 24.9% |
| Interest share of outlook earnings | 805 / 1,450; 805 / 1,500 | 55.5%; 53.7% | Not stated; supports "more than half" |
| Outlook cover and second-half requirement | 1,450 / 805; 1,500 / 805; 1,450 - 798.7; 1,500 - 798.7 | 1.80x; 1.86x; 651.3; 701.3 | Same |
| Capital expenditures LTM and Adjusted EBITDA less capital expenditures | 787.8 - 246.2 + 799.2 = 1,340.8; 1,492.2 - 1,340.8 | 151.4; less cash interest 768.6 = -617.2 | Same |
| Stress sensitivity | 0.8 x 1,492.2 / 768.6 | 1.55x | 1.55x |
| Quarterly cross-check | 327.8 + 365.6 + 441.6 + 357.1 | 1,492.1 | 1,492.1, within 0.1 of 1,492.2 |

## Gaps

| Gap | Severity | Affects | Action |
| --- | --- | --- | --- |
| Covenant levels, compliance ratios and executed credit agreements and indentures not supplied | High | CP-1, CP-2; any covenant, priority or recovery work | Obtain the executed documents and a compliance certificate |
| Maturity table conflict between the Q2 10-Q table and instrument due dates, and the financial base statement that no table is printed | Medium | CP-1, CP-2 | Confirm the schedule with the company; use the due dates meanwhile |
| Ranking of the 1.0 billion 8.625% notes in conflict inside the 10-K | Medium | CP-1A, CP-2 | Confirm against the indenture |
| Pro forma Adjusted EBITDA for the combined company not supplied | Medium | Trailing leverage and cover | Obtain pro forma figures |
| Nothing after 2026-07-30; outcome of repayment offers not supplied | Medium | Leverage and liquidity after the quarter | Obtain later filings up to the cutoff |
| Review not independent of the authors; same extraction text used; locators are extraction chunks | Medium | All | Second reviewer to compare handoffs with the original filings |
| Table content read as extracted text; no fidelity review of the extraction | Low | All | Spot-check key tables against the original filings |
| Ratings, quotes and valuation inputs blank in the context | Low for this scope | CP-2 | Supply if needed |

## Next module

None remains in the selected set. The integrity verdict is committee use Restricted: the research may support a screening view of liquidity, near-term maturities, leverage and cover on stated bases, and business risk, with their labels, but should not support covenant, structural priority, recovery or exact maturity-year conclusions until the gaps above are closed. Next actions in order: obtain the executed credit agreements and indentures and a covenant compliance certificate; confirm the maturity schedule and the ranking of the 8.625% notes; obtain pro forma Adjusted EBITDA and filings after 2026-07-30; have a second reviewer compare the handoffs with the original filings before external use.
